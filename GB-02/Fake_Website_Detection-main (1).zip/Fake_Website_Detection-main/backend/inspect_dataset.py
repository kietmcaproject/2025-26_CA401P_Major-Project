import pandas as pd
data=pd.read_csv('malicious_phish.csv')
print("Shape:", data.shape)
print("\nColumns:", data.columns)
print("\nFirst 5 rows:")
print(data.head())

print("\nClass distribution:")
print(data['type'].value_counts())
