import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
import pickle

# 1️⃣ Load dataset
data = pd.read_csv("malicious_phish.csv")

print("Original Shape:", data.shape)

# 2️⃣ Drop missing values
data = data.dropna()

print("After removing nulls:", data.shape)

# 3️⃣ Convert multi-class to binary
# benign -> 0
# everything else -> 1

data['label'] = data['type'].apply(lambda x: 0 if x == 'benign' else 1)

# 4️⃣ Keep only required columns
data = data[['url', 'label']]

# 5️⃣ Take random sample of 100,000 rows
data = data.sample(n=100000, random_state=42)

print("After sampling:", data.shape)

# 6️⃣ Split features and labels
X = data['url']
y = data['label']

# 7️⃣ Convert URLs to numerical features using TF-IDF
vectorizer = TfidfVectorizer(
    analyzer='char',        # character-level analysis (better for URLs)
    ngram_range=(3,5),      # capture patterns like "login", "://", ".com"
    max_features=50000
)

X_vectorized = vectorizer.fit_transform(X)

# 8️⃣ Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X_vectorized, y, test_size=0.2, random_state=42
)

# 9️⃣ Train Logistic Regression model
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# 🔟 Evaluate model
y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)

print("\nModel Accuracy:", accuracy)
print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))

# 1️⃣1️⃣ Save model and vectorizer
pickle.dump(model, open("model.pkl", "wb"))
pickle.dump(vectorizer, open("vectorizer.pkl", "wb"))

print("\nModel and Vectorizer saved successfully.")
