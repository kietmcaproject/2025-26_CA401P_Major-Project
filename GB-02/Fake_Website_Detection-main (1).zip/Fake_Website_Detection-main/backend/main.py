from fastapi import FastAPI
from pydantic import BaseModel
import pickle

# Load model and vectorizer
model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

app = FastAPI()

class URLRequest(BaseModel):
    url: str

@app.post("/predict")
def predict(request: URLRequest):
    url = request.url

    # Convert URL to features
    features = vectorizer.transform([url])

    # Predict
    prediction = model.predict(features)[0]
    probability = model.predict_proba(features)[0][1]

    return {
        "prediction": int(prediction),
        "probability_malicious": float(probability)
    }
