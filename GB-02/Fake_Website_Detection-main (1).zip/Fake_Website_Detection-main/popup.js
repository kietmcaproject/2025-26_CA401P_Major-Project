chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (!tabs || !tabs[0]) return;

  chrome.runtime.sendMessage("GET_STATUS", (response) => {

    if (chrome.runtime.lastError) {
      document.getElementById("status").innerText =
        "Background not ready. Reload page.";
      return;
    }

    const urlEl = document.getElementById("url");
    const statusEl = document.getElementById("status");
    const scoreEl = document.getElementById("score");

    if (!response || !response.url) {
      urlEl.innerText = "No website detected";
      statusEl.innerText = "";
      scoreEl.innerText = "";
      return;
    }

    urlEl.innerText = response.url;
    scoreEl.innerText = "Score: " + response.score;

    if (response.suspicious) {
      statusEl.innerText = " Not safe to browse this website, be cautious!";
      statusEl.className = "danger";
    } else {
      statusEl.innerText = "This is a Safe Website , you can browse safely.";
      statusEl.className = "safe";
    }
  });
});
