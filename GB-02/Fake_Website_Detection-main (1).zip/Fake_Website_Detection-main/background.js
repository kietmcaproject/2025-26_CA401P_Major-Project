let lastResult = {
  url: "",
  suspicious: false,
  score: 0
};

const trustedDomains = [
  "google.com",
  "youtube.com",
  "facebook.com",
  "instagram.com",
  "amazon.com",
  "paypal.com",
  "godaddy.com"
];

function getDomain(url) {
  try {
    return new URL(url).hostname.replace("www.", "");
  } catch {
    return "";
  }
}

function analyzeUrl(url) {
  let score = 0;
  const lowerUrl = url.toLowerCase();
  const domain = getDomain(url);

  if (!domain) return { suspicious: false, score: 0 };

  if (trustedDomains.includes(domain)) {
    return { suspicious: false, score: 0 };
  }

  if (!lowerUrl.startsWith("https")) score += 1;
  if (lowerUrl.includes("@")) score += 2;
  if (lowerUrl.match(/\d+\.\d+\.\d+\.\d+/)) score += 2;
  if (lowerUrl.length > 75) score += 1;

  const phishingWords = ["login", "verify", "update", "secure", "account", "bank"];
  phishingWords.forEach(word => {
    if (lowerUrl.includes(word)) score += 2;
  });

  return {
    suspicious: score >= 4,
    score
  };
}

// 🔥 Runs when tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !tab.url) return;
  if (tab.url.startsWith("chrome://")) return;

  const result = analyzeUrl(tab.url);

  lastResult.url = tab.url;
  lastResult.suspicious = result.suspicious;
  lastResult.score = result.score;

  console.log("🌐 Website loaded:", tab.url);
  console.log("🔍 Score:", result.score);

  if (result.suspicious) {
    console.log(" PHISHING DETECTED");
  } else {
    console.log(" SAFE");
  }
});


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request === "GET_STATUS") {
    sendResponse(lastResult);
  }
});
