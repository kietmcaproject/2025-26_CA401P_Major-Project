1. Logistic Regression

Simple linear classifier.

It draws a line to separate phishing vs legit.

Good when:

Data is simple

Features are clean

You want explainability

But:

Not very powerful for complex patterns

🔹 2. Decision Tree

It makes decisions like:

Is URL length > 75?
   Yes → Check HTTPS?
      No → Phishing


Very easy to understand.

Problem:

Can overfit easily

🔹 3. Random Forest ✅ (Best for You)

It creates:
👉 Many decision trees
👉 Takes majority vote

More stable
Less overfitting
Very powerful for phishing detection

This is commonly used in cybersecurity tasks.

🔹 4. KNN

It checks:
“Most similar past URLs were phishing or legit?”

Simple but slow on large data.

🔹 5. SVM

Draws optimal boundary between classes.

Powerful but harder to tune.
uvicorn → runs server

scikit-learn → ML

pandas → dataset handling