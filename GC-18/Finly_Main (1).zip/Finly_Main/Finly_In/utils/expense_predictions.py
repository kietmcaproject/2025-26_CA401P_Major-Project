import sqlite3
import pandas as pd
from sklearn.linear_model import LinearRegression

def predict_next_month_expense(db_path):
    conn = sqlite3.connect(db_path)
    df = pd.read_sql("SELECT amount, date FROM expenses", conn)
    conn.close()

    # Not enough data
    if df.empty or len(df) < 3:
        return None, None

    # Convert date column
    df["date"] = pd.to_datetime(df["date"])

    # Group by month
    monthly = (
        df.groupby(df["date"].dt.to_period("M"))["amount"]
          .sum()
          .reset_index()
    )

    # 🔑 IMPORTANT: Convert Period → string (FIXES YOUR ERROR)
    monthly["date"] = monthly["date"].astype(str)

    # Add numeric month index for ML
    monthly["month_num"] = range(1, len(monthly) + 1)

    # Train model
    X = monthly[["month_num"]]
    y = monthly["amount"]

    model = LinearRegression()
    model.fit(X, y)

    # Predict next month
    next_month_num = [[len(monthly) + 1]]
    prediction = round(model.predict(next_month_num)[0], 2)

    return prediction, monthly
