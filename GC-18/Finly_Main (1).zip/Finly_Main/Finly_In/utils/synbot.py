import cohere
import os
from dotenv import load_dotenv

load_dotenv()

co = cohere.ClientV2(os.getenv("COHERE_API_KEY"))

def get_budget_insights(user_query, transactions_text):
    try:
        response = co.chat(
            model="command-a-03-2025",
            messages=[
                {"role": "system", "content": "You are a financial assistant."},
                {"role": "user", "content": f"{user_query}\n\nTransactions:\n{transactions_text}"}
            ]
        )

        return response.message.content[0].text

    except Exception as e:
        import streamlit as st
        st.error(f"FULL ERROR: {str(e)}")
        return f"Error: {str(e)}"