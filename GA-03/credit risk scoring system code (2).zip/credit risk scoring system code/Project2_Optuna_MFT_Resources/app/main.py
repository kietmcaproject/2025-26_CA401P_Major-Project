import streamlit as st
from prediction_helper import predict

st.set_page_config(
    page_title="Credit Risk Scoring System",
    page_icon="📊",
    layout="wide"
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;1,400&family=DM+Serif+Display&display=swap');

html, body, [class*="css"] {
    font-family: 'DM Sans', sans-serif !important;
}

/* Force light background */
.stApp {
    background-color: #f5f6fa !important;
}

section[data-testid="stSidebar"],
.main .block-container {
    background-color: #f5f6fa !important;
}

/* Header */
.app-header {
    background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%);
    border-radius: 16px;
    padding: 2rem 2.5rem;
    margin-bottom: 2rem;
    color: white;
}
.app-header h1 {
    font-family: 'DM Serif Display', serif;
    font-size: 2rem;
    margin: 0 0 4px 0;
    color: white;
}
.app-header p {
    font-size: 0.88rem;
    opacity: 0.75;
    margin: 0;
    font-weight: 300;
    letter-spacing: 0.3px;
}
.header-badge {
    display: inline-block;
    background: rgba(255,255,255,0.15);
    color: white;
    font-size: 0.65rem;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 20px;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    margin-bottom: 10px;
    backdrop-filter: blur(4px);
}

/* Section labels */
.sec-label {
    font-size: 0.68rem;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: #9ca3af;
    padding: 0.8rem 0 0.4rem;
    border-bottom: 1.5px solid #e5e7eb;
    margin-bottom: 0.75rem;
}

/* Form card */
.form-card {
    background: white;
    border-radius: 14px;
    padding: 1.5rem 1.8rem;
    border: 1px solid #e5e7eb;
    box-shadow: 0 1px 4px rgba(0,0,0,0.04);
    margin-bottom: 1rem;
}

/* Result panel */
.result-panel {
    background: white;
    border-radius: 14px;
    padding: 2rem;
    border: 1px solid #e5e7eb;
    box-shadow: 0 1px 4px rgba(0,0,0,0.04);
    text-align: center;
}
.result-panel-label {
    font-size: 0.68rem;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: #9ca3af;
    margin-bottom: 4px;
}
.result-prob-number {
    font-size: 3.5rem;
    font-weight: 700;
    line-height: 1.1;
}
.result-divider {
    height: 1px;
    background: #f3f4f6;
    margin: 1.2rem 0;
}
.result-score-big {
    font-size: 2rem;
    font-weight: 700;
}
.rating-pill {
    display: inline-block;
    font-size: 0.75rem;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    padding: 6px 18px;
    border-radius: 20px;
    margin-top: 10px;
}

/* Gauge bar */
.gauge-container {
    background: #f3f4f6;
    border-radius: 4px;
    height: 8px;
    margin: 10px 0 4px;
    overflow: hidden;
}
.gauge-bar {
    height: 100%;
    border-radius: 4px;
}

/* Summary metric tiles */
.sum-tile {
    background: #f9fafb;
    border: 1px solid #e5e7eb;
    border-radius: 10px;
    padding: 0.9rem 1rem;
    text-align: center;
    margin-top: 8px;
}
.sum-tile-label {
    font-size: 0.65rem;
    font-weight: 700;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: #9ca3af;
    margin-bottom: 4px;
}
.sum-tile-val {
    font-size: 1rem;
    font-weight: 600;
    color: #1f2937;
}

/* Empty state */
.empty-state {
    background: #f9fafb;
    border: 1.5px dashed #d1d5db;
    border-radius: 14px;
    padding: 3rem 2rem;
    text-align: center;
    color: #9ca3af;
}

/* Streamlit input overrides for light theme */
div[data-testid="stNumberInput"] input {
    background: #f9fafb !important;
    border: 1px solid #d1d5db !important;
    border-radius: 8px !important;
    color: #1f2937 !important;
    font-family: 'DM Sans', sans-serif !important;
    font-size: 0.9rem !important;
}
div[data-testid="stNumberInput"] input:focus {
    border-color: #2563eb !important;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.1) !important;
}
div[data-testid="stSelectbox"] > div > div {
    background: #f9fafb !important;
    border: 1px solid #d1d5db !important;
    border-radius: 8px !important;
    color: #1f2937 !important;
    font-family: 'DM Sans', sans-serif !important;
}
div[data-testid="stNumberInput"] label,
div[data-testid="stSelectbox"] label {
    color: #6b7280 !important;
    font-size: 0.82rem !important;
    font-weight: 500 !important;
}
.stButton > button {
    background: linear-gradient(135deg, #2563eb, #1d4ed8) !important;
    color: white !important;
    border: none !important;
    border-radius: 10px !important;
    padding: 0.75rem 2rem !important;
    font-family: 'DM Sans', sans-serif !important;
    font-size: 0.95rem !important;
    font-weight: 600 !important;
    letter-spacing: 0.4px !important;
    width: 100% !important;
    box-shadow: 0 4px 14px rgba(37,99,235,0.35) !important;
    transition: all 0.2s !important;
}
.stButton > button:hover {
    background: linear-gradient(135deg, #3b82f6, #2563eb) !important;
    box-shadow: 0 6px 20px rgba(37,99,235,0.45) !important;
}
footer { visibility: hidden; }
#MainMenu { visibility: hidden; }
</style>
""", unsafe_allow_html=True)

# ── Header ────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="app-header">
  <div class="header-badge">AI Risk Engine</div>
  <h1>Credit Risk Scoring System</h1>
  <p>Smart Lending Decisions, Instantly</p>
</div>
""", unsafe_allow_html=True)

# ── Two column layout ─────────────────────────────────────────────────────────
left, right = st.columns([3, 2], gap="large")

with left:
    st.markdown('<div class="sec-label">Applicant Profile</div>', unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1:
        age = st.number_input('Age', min_value=18, step=1, max_value=100, value=28)
    with c2:
        income = st.number_input('Annual Income (₹)', min_value=0, value=1200000)
    with c3:
        loan_amount = st.number_input('Loan Amount (₹)', min_value=0, value=2560000)

    loan_to_income_ratio = loan_amount / income if income > 0 else 0

    st.markdown('<div class="sec-label">Loan Details</div>', unsafe_allow_html=True)
    c4, c5, c6 = st.columns(3)
    with c4:
        loan_tenure_months = st.number_input('Tenure (months)', min_value=0, step=1, value=36)
    with c5:
        loan_purpose = st.selectbox('Loan Purpose', ['Education', 'Home', 'Auto', 'Personal'])
    with c6:
        loan_type = st.selectbox('Loan Type', ['Unsecured', 'Secured'])

    st.markdown('<div class="sec-label">Credit Behaviour</div>', unsafe_allow_html=True)
    c7, c8, c9 = st.columns(3)
    with c7:
        avg_dpd_per_delinquency = st.number_input('Avg DPD', min_value=0, value=20,
                                                   help="Average Days Past Due per delinquency")
    with c8:
        delinquency_ratio = st.number_input('Delinquency Ratio (%)', min_value=0, max_value=100, step=1, value=30)
    with c9:
        credit_utilization_ratio = st.number_input('Credit Utilization (%)', min_value=0, max_value=100, step=1, value=30)

    st.markdown('<div class="sec-label">Other Info</div>', unsafe_allow_html=True)
    c10, c11, c12 = st.columns(3)
    with c10:
        num_open_accounts = st.number_input('Open Loan Accounts', min_value=1, max_value=4, step=1, value=2)
    with c11:
        residence_type = st.selectbox('Residence Type', ['Owned', 'Rented', 'Mortgage'])
    with c12:
        st.markdown(f"""
        <div class="sum-tile" style="margin-top:28px;">
            <div class="sum-tile-label">Loan / Income Ratio</div>
            <div class="sum-tile-val">{loan_to_income_ratio:.2f}x</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    calculate = st.button("📊 Calculate Credit Risk")

# ── Right panel ───────────────────────────────────────────────────────────────
with right:
    st.markdown('<div class="sec-label">Risk Assessment Result</div>', unsafe_allow_html=True)

    if calculate:
        probability, credit_score, rating = predict(
            age, income, loan_amount, loan_tenure_months,
            avg_dpd_per_delinquency, delinquency_ratio,
            credit_utilization_ratio, num_open_accounts,
            residence_type, loan_purpose, loan_type
        )

        prob_pct = probability * 100

        # Color config
        config = {
            'Poor':      {'prob_color': '#dc2626', 'pill_bg': '#fee2e2', 'pill_color': '#991b1b', 'gauge': '#ef4444'},
            'Average':   {'prob_color': '#d97706', 'pill_bg': '#fef3c7', 'pill_color': '#92400e', 'gauge': '#f59e0b'},
            'Good':      {'prob_color': '#059669', 'pill_bg': '#d1fae5', 'pill_color': '#065f46', 'gauge': '#10b981'},
            'Excellent': {'prob_color': '#2563eb', 'pill_bg': '#dbeafe', 'pill_color': '#1e40af', 'gauge': '#3b82f6'},
        }
        cfg = config.get(rating, config['Poor'])

        # Result card via st.container (avoids HTML rendering issues)
        with st.container():
            st.markdown(f"""
            <div style="
                background: white;
                border-radius: 14px;
                padding: 2rem 1.5rem;
                border: 1px solid #e5e7eb;
                box-shadow: 0 1px 4px rgba(0,0,0,0.06);
                text-align: center;
            ">
                <div style="font-size:0.68rem; font-weight:700; letter-spacing:2px;
                     text-transform:uppercase; color:#9ca3af; margin-bottom:6px;">
                    Default Probability
                </div>
                <div style="font-size:3.2rem; font-weight:700; color:{cfg['prob_color']}; line-height:1.1;">
                    {prob_pct:.1f}%
                </div>
                <div style="background:#f3f4f6; border-radius:4px; height:8px; margin:12px 0 4px; overflow:hidden;">
                    <div style="width:{min(prob_pct,100):.1f}%; height:100%;
                         background:{cfg['gauge']}; border-radius:4px;"></div>
                </div>
                <div style="font-size:0.72rem; color:#9ca3af; text-align:right; margin-bottom:1.2rem;">
                    Risk level
                </div>
                <hr style="border:none; border-top:1px solid #f3f4f6; margin:1rem 0;">
                <div style="font-size:0.68rem; font-weight:700; letter-spacing:2px;
                     text-transform:uppercase; color:#9ca3af; margin-bottom:4px;">
                    Credit Score
                </div>
                <div style="font-size:2.2rem; font-weight:700; color:{cfg['prob_color']};">
                    {credit_score}
                </div>
                <span style="
                    display:inline-block;
                    background:{cfg['pill_bg']};
                    color:{cfg['pill_color']};
                    font-size:0.72rem;
                    font-weight:700;
                    letter-spacing:2px;
                    text-transform:uppercase;
                    padding:5px 18px;
                    border-radius:20px;
                    margin-top:10px;
                ">
                    {rating}
                </span>
            </div>
            """, unsafe_allow_html=True)

        # Summary tiles
        st.markdown('<div class="sec-label" style="margin-top:1.2rem;">Summary</div>', unsafe_allow_html=True)
        t1, t2 = st.columns(2)
        with t1:
            st.markdown(f"""
            <div class="sum-tile">
                <div class="sum-tile-label">Annual Income</div>
                <div class="sum-tile-val">₹{income:,.0f}</div>
            </div>""", unsafe_allow_html=True)
        with t2:
            st.markdown(f"""
            <div class="sum-tile">
                <div class="sum-tile-label">Loan Amount</div>
                <div class="sum-tile-val">₹{loan_amount:,.0f}</div>
            </div>""", unsafe_allow_html=True)
        t3, t4 = st.columns(2)
        with t3:
            st.markdown(f"""
            <div class="sum-tile">
                <div class="sum-tile-label">Loan / Income</div>
                <div class="sum-tile-val">{loan_to_income_ratio:.2f}x</div>
            </div>""", unsafe_allow_html=True)
        with t4:
            st.markdown(f"""
            <div class="sum-tile">
                <div class="sum-tile-label">Tenure</div>
                <div class="sum-tile-val">{loan_tenure_months} months</div>
            </div>""", unsafe_allow_html=True)

    else:
        st.markdown("""
        <div class="empty-state">
            <div style="font-size:2.5rem; margin-bottom:0.75rem;">📋</div>
            <div style="font-weight:600; color:#6b7280; font-size:0.95rem;">No assessment yet</div>
            <div style="font-size:0.82rem; color:#9ca3af; margin-top:6px;">
                Fill in the applicant details and<br>click <b>Calculate Credit Risk</b>
            </div>
        </div>
        """, unsafe_allow_html=True)

# ── Footer ────────────────────────────────────────────────────────────────────
st.markdown("""
<div style="text-align:center; margin-top:3rem; padding-top:1.5rem;
     border-top: 1px solid #e5e7eb; color:#9ca3af; font-size:0.75rem; letter-spacing:0.5px;">
    CREDIT RISK SCORING SYSTEM
</div>
""", unsafe_allow_html=True)