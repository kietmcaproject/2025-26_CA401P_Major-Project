import express from 'express';
import { GoogleGenerativeAI } from '@google/generative-ai';
import auth from '../middleware/auth.js';

const router = express.Router();

// Helper: retry with delay
async function callWithRetry(fn, retries = 3, delay = 20000) {
  for (let i = 0; i < retries; i++) {
    try {
      return await fn();
    } catch (error) {
      const isRateLimit = error.message?.includes('429') ||
        error.message?.includes('Resource has been exhausted') ||
        error.message?.includes('quota') ||
        error.message?.includes('RESOURCE_EXHAUSTED') ||
        error.message?.includes('retryDelay') ||
        error.status === 429;

      if (isRateLimit && i < retries - 1) {
        console.log(`Rate limited. Retrying in ${delay / 1000}s... (attempt ${i + 2}/${retries})`);
        await new Promise(resolve => setTimeout(resolve, delay));
        delay *= 2; // double delay each retry
      } else {
        throw error;
      }
    }
  }
}

// POST /api/ai/optimize - Optimize resume with Gemini AI
router.post('/optimize', auth, async (req, res) => {
  try {
    const { personalInfo, summary, experience, skills, targetRole } = req.body;

    if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === 'your_gemini_api_key_here') {
      return res.status(400).json({ message: 'Gemini API key is not configured' });
    }

    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash' });

    const prompt = `You are a professional resume optimization expert. Analyze the following resume data and provide optimized versions.

Target Role: ${targetRole || 'Not specified'}

Current Summary: ${summary || 'None provided'}

Current Experience:
${(experience || []).map((exp, i) => `${i + 1}. ${exp.jobTitle} at ${exp.company}: ${exp.description}`).join('\n')}

Current Skills: ${(skills || []).join(', ')}

Please provide optimization in the following JSON format ONLY (no markdown, no code blocks, just raw JSON):
{
  "summary": "An optimized professional summary (2-3 sentences, impactful and keyword-rich)",
  "experience": [
    {
      "index": 0,
      "description": "Optimized bullet points for this role using action verbs and quantifiable achievements"
    }
  ],
  "skillSuggestions": ["skill1", "skill2", "skill3", "skill4", "skill5"],
  "tips": ["tip1", "tip2", "tip3"]
}

Make the content ATS-friendly with relevant keywords. Use strong action verbs. Quantify achievements where possible.`;

    const result = await callWithRetry(async () => {
      return await model.generateContent(prompt);
    });

    const responseText = result.response.text();

    // Parse the JSON response
    let parsed;
    try {
      // Remove any markdown code block wrapping if present
      const cleanJson = responseText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      parsed = JSON.parse(cleanJson);
    } catch (parseError) {
      return res.status(500).json({
        message: 'Failed to parse AI response',
        raw: responseText
      });
    }

    res.json(parsed);
  } catch (error) {
    console.error('AI Optimization Error:', error.message);

    // Provide user-friendly error messages
    const msg = error.message || '';
    if (msg.includes('API_KEY_INVALID') || msg.includes('401') || msg.includes('renew') || msg.includes('billing')) {
      return res.status(401).json({ message: 'Your Gemini API key is invalid or expired. Go to aistudio.google.com → Get API Key → Create a NEW key, and paste it in server/.env' });
    }
    if (msg.includes('429') || msg.includes('quota') || msg.includes('Resource has been exhausted')) {
      return res.status(429).json({ message: 'Gemini API rate limit reached. Please wait a minute and try again.' });
    }
    if (msg.includes('403') || msg.includes('PERMISSION_DENIED')) {
      return res.status(403).json({ message: 'Gemini API access denied. Make sure the Generative Language API is enabled in your Google Cloud console.' });
    }

    res.status(500).json({ message: 'AI optimization failed. Error: ' + msg });
  }
});

export default router;
