import express from 'express';
import axios from 'axios';
import auth from '../middleware/auth.js';

const router = express.Router();

// GET /api/jobs/search?query=...&location=...
router.get('/search', auth, async (req, res) => {
  try {
    const { query, location, page } = req.query;

    if (!query) {
      return res.status(400).json({ message: 'Search query is required' });
    }

    if (!process.env.RAPIDAPI_KEY || process.env.RAPIDAPI_KEY === 'your_rapidapi_key_here') {
      // Return mock data if API key is not configured
      return res.json({
        jobs: getMockJobs(query),
        totalResults: 5,
        message: 'Showing sample results. Configure RAPIDAPI_KEY for real job listings.'
      });
    }

    const response = await axios.get('https://jsearch.p.rapidapi.com/search', {
      params: {
        query: `${query} ${location || ''}`.trim(),
        page: page || '1',
        num_pages: '1',
        date_posted: 'month'
      },
      headers: {
        'x-rapidapi-key': process.env.RAPIDAPI_KEY,
        'x-rapidapi-host': 'jsearch.p.rapidapi.com'
      }
    });

    const jobs = (response.data.data || []).map(job => ({
      id: job.job_id,
      title: job.job_title,
      company: job.employer_name,
      location: job.job_city ? `${job.job_city}, ${job.job_state || job.job_country}` : job.job_country || 'Remote',
      type: job.job_employment_type || 'Full-time',
      posted: job.job_posted_at_datetime_utc,
      description: job.job_description ? job.job_description.substring(0, 300) + '...' : '',
      applyLink: job.job_apply_link || job.job_google_link,
      logo: job.employer_logo
    }));

    res.json({
      jobs,
      totalResults: response.data.total || jobs.length
    });
  } catch (error) {
    console.error('Job Search Error:', error.message);
    res.status(500).json({ message: 'Job search failed', error: error.message });
  }
});

// Mock jobs for when API key isn't configured
function getMockJobs(query) {
  return [
    {
      id: 'mock-1',
      title: `Senior ${query}`,
      company: 'TechCorp Inc.',
      location: 'San Francisco, CA',
      type: 'Full-time',
      posted: new Date().toISOString(),
      description: `We are looking for an experienced ${query} to join our team. You will work on cutting-edge projects and collaborate with talented professionals...`,
      applyLink: '#',
      logo: null
    },
    {
      id: 'mock-2',
      title: `${query} - Remote`,
      company: 'InnovateTech',
      location: 'Remote',
      type: 'Full-time',
      posted: new Date().toISOString(),
      description: `Join our fully remote team as a ${query}. We offer competitive compensation, flexible hours, and the opportunity to work on impactful products...`,
      applyLink: '#',
      logo: null
    },
    {
      id: 'mock-3',
      title: `Junior ${query}`,
      company: 'StartupXYZ',
      location: 'New York, NY',
      type: 'Full-time',
      posted: new Date().toISOString(),
      description: `Great opportunity for aspiring ${query} professionals. We provide mentorship, learning opportunities, and a collaborative environment...`,
      applyLink: '#',
      logo: null
    },
    {
      id: 'mock-4',
      title: `${query} Lead`,
      company: 'GlobalSoft',
      location: 'Austin, TX',
      type: 'Full-time',
      posted: new Date().toISOString(),
      description: `Lead a team of talented developers as a ${query}. Drive technical decisions and shape the future of our platform...`,
      applyLink: '#',
      logo: null
    },
    {
      id: 'mock-5',
      title: `${query} Intern`,
      company: 'FutureTech Labs',
      location: 'Seattle, WA',
      type: 'Internship',
      posted: new Date().toISOString(),
      description: `Kickstart your career as a ${query} intern. Work alongside industry experts on real-world projects with mentorship and growth potential...`,
      applyLink: '#',
      logo: null
    }
  ];
}

export default router;
