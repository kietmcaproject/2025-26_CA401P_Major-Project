import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import { useReactToPrint } from 'react-to-print';
import {
  FiArrowLeft, FiSave, FiPrinter, FiShare2, FiUser, FiBriefcase,
  FiBook, FiCode, FiStar, FiChevronDown, FiPlus, FiTrash2,
  FiEye, FiCopy, FiCheck
} from 'react-icons/fi';
import ClassicTemplate from '../templates/ClassicTemplate';
import ModernTemplate from '../templates/ModernTemplate';
import MinimalTemplate from '../templates/MinimalTemplate';
import CreativeTemplate from '../templates/CreativeTemplate';
import AiOptimizer from '../components/AiOptimizer';
import JobFinder from '../components/JobFinder';
import '../styles/editor.css';
import '../styles/templates.css';

const TEMPLATES = { classic: ClassicTemplate, modern: ModernTemplate, minimal: MinimalTemplate, creative: CreativeTemplate };
const TEMPLATE_NAMES = ['classic', 'modern', 'minimal', 'creative'];

const emptyResume = {
  title: 'Untitled Resume',
  template: 'modern',
  personalInfo: { fullName: '', email: '', phone: '', location: '', website: '', linkedin: '', github: '' },
  summary: '',
  experience: [],
  education: [],
  skills: [],
  projects: []
};

export default function ResumeEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const printRef = useRef(null);
  const saveTimeout = useRef(null);

  const [resume, setResume] = useState(emptyResume);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(true);
  const [skillInput, setSkillInput] = useState('');
  const [collapsedSections, setCollapsedSections] = useState({});
  const [jobsOpen, setJobsOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const fetchResume = async () => {
      try {
        const res = await axios.get(`/resumes/${id}`);
        setResume(res.data);
      } catch {
        toast.error('Resume not found');
        navigate('/dashboard');
      } finally {
        setLoading(false);
      }
    };
    fetchResume();
  }, [id, navigate]);

  const autoSave = useCallback((data) => {
    setSaved(false);
    if (saveTimeout.current) clearTimeout(saveTimeout.current);
    saveTimeout.current = setTimeout(async () => {
      setSaving(true);
      try {
        await axios.put(`/resumes/${id}`, data);
        setSaved(true);
      } catch {
        toast.error('Auto-save failed');
      } finally {
        setSaving(false);
      }
    }, 1000);
  }, [id]);

  const updateResume = (updates) => {
    const updated = { ...resume, ...updates };
    setResume(updated);
    autoSave(updated);
  };

  const updatePersonalInfo = (field, value) => {
    const updated = { ...resume, personalInfo: { ...resume.personalInfo, [field]: value } };
    setResume(updated);
    autoSave(updated);
  };

  const updateExperience = (index, field, value) => {
    const exp = [...resume.experience];
    exp[index] = { ...exp[index], [field]: value };
    updateResume({ experience: exp });
  };

  const addExperience = () => {
    updateResume({ experience: [...resume.experience, { jobTitle: '', company: '', location: '', startDate: '', endDate: '', current: false, description: '' }] });
  };

  const removeExperience = (index) => {
    updateResume({ experience: resume.experience.filter((_, i) => i !== index) });
  };

  const updateEducation = (index, field, value) => {
    const edu = [...resume.education];
    edu[index] = { ...edu[index], [field]: value };
    updateResume({ education: edu });
  };

  const addEducation = () => {
    updateResume({ education: [...resume.education, { degree: '', school: '', location: '', startDate: '', endDate: '', description: '' }] });
  };

  const removeEducation = (index) => {
    updateResume({ education: resume.education.filter((_, i) => i !== index) });
  };

  const addSkill = () => {
    if (skillInput.trim() && !resume.skills.includes(skillInput.trim())) {
      updateResume({ skills: [...resume.skills, skillInput.trim()] });
      setSkillInput('');
    }
  };

  const removeSkill = (index) => {
    updateResume({ skills: resume.skills.filter((_, i) => i !== index) });
  };

  const updateProject = (index, field, value) => {
    const proj = [...resume.projects];
    proj[index] = { ...proj[index], [field]: value };
    updateResume({ projects: proj });
  };

  const addProject = () => {
    updateResume({ projects: [...resume.projects, { name: '', description: '', technologies: '', link: '' }] });
  };

  const removeProject = (index) => {
    updateResume({ projects: resume.projects.filter((_, i) => i !== index) });
  };

  const toggleSection = (section) => {
    setCollapsedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const handlePrint = useReactToPrint({ contentRef: printRef });

  const handleShare = async () => {
    const url = `${window.location.origin}/resume/public/${resume.slug}`;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      toast.success('Share link copied!');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Failed to copy link');
    }
  };

  const manualSave = async () => {
    setSaving(true);
    try {
      await axios.put(`/resumes/${id}`, resume);
      setSaved(true);
      toast.success('Saved!');
    } catch {
      toast.error('Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleAiApply = (updates) => {
    updateResume(updates);
  };

  const TemplateComponent = TEMPLATES[resume.template] || ModernTemplate;

  if (loading) {
    return <div className="page-loader"><div className="spinner spinner-lg"></div></div>;
  }

  return (
    <div className="editor-page">
      {/* Left: Form */}
      <div className="editor-sidebar">
        <div className="editor-toolbar">
          <div className="editor-toolbar-left">
            <button className="editor-back" onClick={() => navigate('/dashboard')}>
              <FiArrowLeft /> Back
            </button>
            <input
              className="editor-title-input"
              value={resume.title}
              onChange={(e) => updateResume({ title: e.target.value })}
              placeholder="Resume title"
            />
          </div>
          <div className="editor-toolbar-right">
            <span className={`save-status ${saved ? 'saved' : saving ? 'saving' : ''}`}>
              {saving ? '⏳ Saving...' : saved ? '✓ Saved' : '● Unsaved'}
            </span>
            <AiOptimizer resumeData={resume} onApply={handleAiApply} />
          </div>
        </div>

        <div className="editor-form-wrapper">
          {/* Personal Info */}
          <div className="editor-section">
            <div className="editor-section-header" onClick={() => toggleSection('personal')}>
              <span className="editor-section-title"><FiUser /> Personal Information</span>
              <FiChevronDown className={`editor-section-toggle ${collapsedSections.personal ? 'collapsed' : ''}`} />
            </div>
            {!collapsedSections.personal && (
              <div className="editor-section-content">
                <div className="form-group">
                  <label>Full Name</label>
                  <input value={resume.personalInfo.fullName} onChange={(e) => updatePersonalInfo('fullName', e.target.value)} placeholder="John Doe" />
                </div>
                <div className="editor-row">
                  <div className="form-group">
                    <label>Email</label>
                    <input value={resume.personalInfo.email} onChange={(e) => updatePersonalInfo('email', e.target.value)} placeholder="john@email.com" />
                  </div>
                  <div className="form-group">
                    <label>Phone</label>
                    <input value={resume.personalInfo.phone} onChange={(e) => updatePersonalInfo('phone', e.target.value)} placeholder="+1 234 567 8900" />
                  </div>
                </div>
                <div className="form-group">
                  <label>Location</label>
                  <input value={resume.personalInfo.location} onChange={(e) => updatePersonalInfo('location', e.target.value)} placeholder="San Francisco, CA" />
                </div>
                <div className="editor-row">
                  <div className="form-group">
                    <label>Website</label>
                    <input value={resume.personalInfo.website} onChange={(e) => updatePersonalInfo('website', e.target.value)} placeholder="yourwebsite.com" />
                  </div>
                  <div className="form-group">
                    <label>LinkedIn</label>
                    <input value={resume.personalInfo.linkedin} onChange={(e) => updatePersonalInfo('linkedin', e.target.value)} placeholder="linkedin.com/in/you" />
                  </div>
                </div>
                <div className="form-group">
                  <label>GitHub</label>
                  <input value={resume.personalInfo.github} onChange={(e) => updatePersonalInfo('github', e.target.value)} placeholder="github.com/you" />
                </div>
              </div>
            )}
          </div>

          {/* Summary */}
          <div className="editor-section">
            <div className="editor-section-header" onClick={() => toggleSection('summary')}>
              <span className="editor-section-title"><FiStar /> Professional Summary</span>
              <FiChevronDown className={`editor-section-toggle ${collapsedSections.summary ? 'collapsed' : ''}`} />
            </div>
            {!collapsedSections.summary && (
              <div className="editor-section-content">
                <textarea
                  value={resume.summary}
                  onChange={(e) => updateResume({ summary: e.target.value })}
                  placeholder="A brief professional summary highlighting your expertise..."
                  rows={4}
                />
              </div>
            )}
          </div>

          {/* Experience */}
          <div className="editor-section">
            <div className="editor-section-header" onClick={() => toggleSection('experience')}>
              <span className="editor-section-title"><FiBriefcase /> Experience ({resume.experience.length})</span>
              <FiChevronDown className={`editor-section-toggle ${collapsedSections.experience ? 'collapsed' : ''}`} />
            </div>
            {!collapsedSections.experience && (
              <div className="editor-section-content">
                {resume.experience.map((exp, i) => (
                  <div key={i} className="editor-item">
                    <div className="editor-item-header">
                      <span className="editor-item-title">Experience {i + 1}</span>
                      <button className="editor-item-remove" onClick={() => removeExperience(i)}><FiTrash2 /></button>
                    </div>
                    <div className="editor-row">
                      <div className="form-group">
                        <label>Job Title</label>
                        <input value={exp.jobTitle} onChange={(e) => updateExperience(i, 'jobTitle', e.target.value)} placeholder="Software Engineer" />
                      </div>
                      <div className="form-group">
                        <label>Company</label>
                        <input value={exp.company} onChange={(e) => updateExperience(i, 'company', e.target.value)} placeholder="Google" />
                      </div>
                    </div>
                    <div className="form-group">
                      <label>Location</label>
                      <input value={exp.location} onChange={(e) => updateExperience(i, 'location', e.target.value)} placeholder="Mountain View, CA" />
                    </div>
                    <div className="editor-row">
                      <div className="form-group">
                        <label>Start Date</label>
                        <input value={exp.startDate} onChange={(e) => updateExperience(i, 'startDate', e.target.value)} placeholder="Jan 2022" />
                      </div>
                      <div className="form-group">
                        <label>End Date</label>
                        <input value={exp.endDate} onChange={(e) => updateExperience(i, 'endDate', e.target.value)} placeholder="Dec 2023" disabled={exp.current} />
                      </div>
                    </div>
                    <div className="checkbox-group">
                      <input type="checkbox" checked={exp.current} onChange={(e) => updateExperience(i, 'current', e.target.checked)} />
                      <label>Currently working here</label>
                    </div>
                    <div className="form-group" style={{ marginTop: 8 }}>
                      <label>Description</label>
                      <textarea value={exp.description} onChange={(e) => updateExperience(i, 'description', e.target.value)} placeholder="Key achievements and responsibilities..." rows={3} />
                    </div>
                  </div>
                ))}
                <button className="add-item-btn" onClick={addExperience}><FiPlus /> Add Experience</button>
              </div>
            )}
          </div>

          {/* Education */}
          <div className="editor-section">
            <div className="editor-section-header" onClick={() => toggleSection('education')}>
              <span className="editor-section-title"><FiBook /> Education ({resume.education.length})</span>
              <FiChevronDown className={`editor-section-toggle ${collapsedSections.education ? 'collapsed' : ''}`} />
            </div>
            {!collapsedSections.education && (
              <div className="editor-section-content">
                {resume.education.map((edu, i) => (
                  <div key={i} className="editor-item">
                    <div className="editor-item-header">
                      <span className="editor-item-title">Education {i + 1}</span>
                      <button className="editor-item-remove" onClick={() => removeEducation(i)}><FiTrash2 /></button>
                    </div>
                    <div className="editor-row">
                      <div className="form-group">
                        <label>Degree</label>
                        <input value={edu.degree} onChange={(e) => updateEducation(i, 'degree', e.target.value)} placeholder="B.S. Computer Science" />
                      </div>
                      <div className="form-group">
                        <label>School</label>
                        <input value={edu.school} onChange={(e) => updateEducation(i, 'school', e.target.value)} placeholder="MIT" />
                      </div>
                    </div>
                    <div className="form-group">
                      <label>Location</label>
                      <input value={edu.location} onChange={(e) => updateEducation(i, 'location', e.target.value)} placeholder="Cambridge, MA" />
                    </div>
                    <div className="editor-row">
                      <div className="form-group">
                        <label>Start Date</label>
                        <input value={edu.startDate} onChange={(e) => updateEducation(i, 'startDate', e.target.value)} placeholder="2018" />
                      </div>
                      <div className="form-group">
                        <label>End Date</label>
                        <input value={edu.endDate} onChange={(e) => updateEducation(i, 'endDate', e.target.value)} placeholder="2022" />
                      </div>
                    </div>
                    <div className="form-group">
                      <label>Description (optional)</label>
                      <textarea value={edu.description} onChange={(e) => updateEducation(i, 'description', e.target.value)} placeholder="GPA, relevant coursework, honors..." rows={2} />
                    </div>
                  </div>
                ))}
                <button className="add-item-btn" onClick={addEducation}><FiPlus /> Add Education</button>
              </div>
            )}
          </div>

          {/* Skills */}
          <div className="editor-section">
            <div className="editor-section-header" onClick={() => toggleSection('skills')}>
              <span className="editor-section-title"><FiCode /> Skills ({resume.skills.length})</span>
              <FiChevronDown className={`editor-section-toggle ${collapsedSections.skills ? 'collapsed' : ''}`} />
            </div>
            {!collapsedSections.skills && (
              <div className="editor-section-content">
                <div className="skills-container">
                  {resume.skills.map((skill, i) => (
                    <span key={i} className="skill-tag">
                      {skill}
                      <button onClick={() => removeSkill(i)}>×</button>
                    </span>
                  ))}
                </div>
                <div className="skill-input-group">
                  <input
                    value={skillInput}
                    onChange={(e) => setSkillInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
                    placeholder="Type a skill and press Enter"
                  />
                  <button className="btn btn-secondary btn-sm" onClick={addSkill}>Add</button>
                </div>
              </div>
            )}
          </div>

          {/* Projects */}
          <div className="editor-section">
            <div className="editor-section-header" onClick={() => toggleSection('projects')}>
              <span className="editor-section-title"><FiCode /> Projects ({resume.projects.length})</span>
              <FiChevronDown className={`editor-section-toggle ${collapsedSections.projects ? 'collapsed' : ''}`} />
            </div>
            {!collapsedSections.projects && (
              <div className="editor-section-content">
                {resume.projects.map((proj, i) => (
                  <div key={i} className="editor-item">
                    <div className="editor-item-header">
                      <span className="editor-item-title">Project {i + 1}</span>
                      <button className="editor-item-remove" onClick={() => removeProject(i)}><FiTrash2 /></button>
                    </div>
                    <div className="form-group">
                      <label>Project Name</label>
                      <input value={proj.name} onChange={(e) => updateProject(i, 'name', e.target.value)} placeholder="My Awesome Project" />
                    </div>
                    <div className="form-group">
                      <label>Technologies</label>
                      <input value={proj.technologies} onChange={(e) => updateProject(i, 'technologies', e.target.value)} placeholder="React, Node.js, MongoDB" />
                    </div>
                    <div className="form-group">
                      <label>Description</label>
                      <textarea value={proj.description} onChange={(e) => updateProject(i, 'description', e.target.value)} placeholder="What does this project do?" rows={2} />
                    </div>
                    <div className="form-group">
                      <label>Link</label>
                      <input value={proj.link} onChange={(e) => updateProject(i, 'link', e.target.value)} placeholder="github.com/you/project" />
                    </div>
                  </div>
                ))}
                <button className="add-item-btn" onClick={addProject}><FiPlus /> Add Project</button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right: Preview */}
      <div className="preview-panel">
        <div className="preview-toolbar">
          <div className="preview-toolbar-label">
            <FiEye /> Live Preview
          </div>
          <div className="preview-toolbar-actions">
            <div className="template-selector-bar">
              {TEMPLATE_NAMES.map(t => (
                <button
                  key={t}
                  className={`template-option ${resume.template === t ? 'active' : ''}`}
                  onClick={() => updateResume({ template: t })}
                >
                  {t}
                </button>
              ))}
            </div>
            <button className="btn btn-secondary btn-sm" onClick={handlePrint} id="print-btn">
              <FiPrinter /> PDF
            </button>
            <button className="btn btn-secondary btn-sm" onClick={handleShare} id="share-btn">
              {copied ? <FiCheck /> : <FiShare2 />}
              {copied ? 'Copied!' : 'Share'}
            </button>
            <button className="jobs-toggle-btn" onClick={() => setJobsOpen(!jobsOpen)} id="jobs-btn">
              <FiBriefcase /> Jobs
            </button>
            <button className="btn btn-primary btn-sm" onClick={manualSave} disabled={saving} id="save-btn">
              <FiSave /> Save
            </button>
          </div>
        </div>
        <div className="preview-content">
          <div className="resume-preview-container" ref={printRef}>
            <TemplateComponent data={resume} />
          </div>
        </div>
      </div>

      {/* Jobs Panel */}
      <JobFinder
        resumeTitle={resume.title}
        skills={resume.skills}
        isOpen={jobsOpen}
        onClose={() => setJobsOpen(false)}
      />
    </div>
  );
}
