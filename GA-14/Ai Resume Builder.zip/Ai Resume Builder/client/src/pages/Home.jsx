import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import {
  FiZap, FiEye, FiLayout, FiShare2, FiBriefcase,
  FiArrowRight, FiStar, FiUsers, FiFileText,
  FiSun, FiMoon, FiMonitor, FiSearch, FiSliders
} from 'react-icons/fi';
import TemplatePreviewCards from '../components/TemplatePreviewCards';
import '../styles/home.css';

export default function Home() {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="home-page">
      {/* Canva-style Navbar */}
      <nav className="home-nav">
        <Link to="/" className="home-nav-brand">
          <FiFileText className="home-nav-icon" />
          <span>ResumeAI</span>
        </Link>

        <div className="home-nav-links">
          <div className="nav-dropdown">
            <button className="nav-dropdown-trigger">Design</button>
            <div className="nav-dropdown-menu">
              <Link to={user ? '/dashboard' : '/register'} className="nav-dropdown-item">
                <FiFileText className="nav-di-icon" />
                <div>
                  <div className="nav-di-title">Resume</div>
                  <div className="nav-di-desc">Build a professional resume</div>
                </div>
              </Link>
              <Link to={user ? '/presentations' : '/register'} className="nav-dropdown-item">
                <FiMonitor className="nav-di-icon" />
                <div>
                  <div className="nav-di-title">Presentation</div>
                  <div className="nav-di-desc">Create stunning slide decks</div>
                </div>
              </Link>
            </div>
          </div>

          <div className="nav-dropdown">
            <button className="nav-dropdown-trigger">Features</button>
            <div className="nav-dropdown-menu">
              <a href="#features" className="nav-dropdown-item">
                <FiZap className="nav-di-icon" />
                <div>
                  <div className="nav-di-title">AI Optimization</div>
                  <div className="nav-di-desc">Enhance your resume with Gemini AI</div>
                </div>
              </a>
              <a href="#features" className="nav-dropdown-item">
                <FiEye className="nav-di-icon" />
                <div>
                  <div className="nav-di-title">Live Preview</div>
                  <div className="nav-di-desc">Real-time editing with instant feedback</div>
                </div>
              </a>
              <a href="#features" className="nav-dropdown-item">
                <FiBriefcase className="nav-di-icon" />
                <div>
                  <div className="nav-di-title">Job Matching</div>
                  <div className="nav-di-desc">Find jobs that match your skills</div>
                </div>
              </a>
              <a href="#features" className="nav-dropdown-item">
                <FiShare2 className="nav-di-icon" />
                <div>
                  <div className="nav-di-title">Share & Export</div>
                  <div className="nav-di-desc">Public links or PDF download</div>
                </div>
              </a>
            </div>
          </div>

          <a href="#templates" className="nav-link">Templates</a>
          <a href="#how-it-works" className="nav-link">How it works</a>
        </div>

        <div className="home-nav-actions">
          <button className="theme-toggle" onClick={toggleTheme} title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}>
            {theme === 'dark' ? <FiSun /> : <FiMoon />}
          </button>
          {user ? (
            <Link to="/dashboard" className="btn btn-primary">
              Dashboard <FiArrowRight />
            </Link>
          ) : (
            <>
              <Link to="/login" className="btn btn-secondary">Sign In</Link>
              <Link to="/register" className="btn btn-primary">
                Get Started Free <FiArrowRight />
              </Link>
            </>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero">
        <div className="hero-bg-effects">
          <div className="hero-orb hero-orb-1"></div>
          <div className="hero-orb hero-orb-2"></div>
          <div className="hero-orb hero-orb-3"></div>
          <div className="hero-grid"></div>
        </div>
        <div className="hero-content">
          <div className="hero-badge">
            <FiZap /> Powered by Google Gemini AI
          </div>
          <h1 className="hero-title">
            Build Your Dream Resume
            <span className="hero-title-gradient"> in Minutes</span>
          </h1>
          <p className="hero-subtitle">
            Create stunning, ATS-friendly resumes with AI-powered optimization,
            live preview, and smart job matching. Stand out from the crowd with
            professional templates designed to land interviews.
          </p>
          <div className="hero-cta">
            <Link to={user ? '/dashboard' : '/register'} className="btn btn-primary btn-lg hero-btn-primary">
              Start Building Free <FiArrowRight />
            </Link>
            <a href="#features" className="btn btn-secondary btn-lg hero-btn-secondary">
              See Features
            </a>
          </div>
          <div className="hero-stats">
            <div className="hero-stat">
              <span className="hero-stat-number">4+</span>
              <span className="hero-stat-label">Pro Templates</span>
            </div>
            <div className="hero-stat-divider"></div>
            <div className="hero-stat">
              <span className="hero-stat-number">AI</span>
              <span className="hero-stat-label">Powered</span>
            </div>
            <div className="hero-stat-divider"></div>
            <div className="hero-stat">
              <span className="hero-stat-number">100%</span>
              <span className="hero-stat-label">Free to Use</span>
            </div>
          </div>
        </div>
        <div className="hero-image">
          <div className="hero-image-glow"></div>
          <img src="/hero-resume.png" alt="AI Resume Builder Preview" />
        </div>
      </section>

      {/* Features Section */}
      <section className="features" id="features">
        <div className="section-header">
          <span className="section-badge">Features</span>
          <h2 className="section-title">Everything You Need to <span>Land Your Dream Job</span></h2>
          <p className="section-subtitle">
            Powerful tools that make resume building effortless and effective
          </p>
        </div>
        <div className="features-grid">
          <div className="feature-card feature-card-large">
            <div className="feature-card-icon feature-icon-ai">
              <FiZap />
            </div>
            <h3>AI-Powered Optimization</h3>
            <p>
              Google Gemini AI analyzes your resume and suggests improvements —
              better summaries, stronger bullet points, and missing skills.
              One-click apply to instantly upgrade your resume.
            </p>
            <img src="/ai-brain.png" alt="AI Optimization" className="feature-card-img" />
          </div>
          <div className="feature-card">
            <div className="feature-card-icon feature-icon-preview">
              <FiEye />
            </div>
            <h3>Live Preview</h3>
            <p>See changes in real-time as you type. Split-pane editor with instant visual feedback.</p>
          </div>
          <div className="feature-card">
            <div className="feature-card-icon feature-icon-template">
              <FiLayout />
            </div>
            <h3>Multiple Templates</h3>
            <p>Choose from Classic, Modern, Minimal, and Creative designs — switch instantly.</p>
          </div>
          <div className="feature-card">
            <div className="feature-card-icon feature-icon-share">
              <FiShare2 />
            </div>
            <h3>Shareable Links</h3>
            <p>Generate public URLs for your resume. Share with recruiters in one click.</p>
          </div>
          <div className="feature-card">
            <div className="feature-card-icon feature-icon-ppt">
              <FiMonitor />
            </div>
            <h3>Presentations</h3>
            <p>Create beautiful slide decks with AI. Present your portfolio and ideas professionally.</p>
          </div>
          <div className="feature-card">
            <div className="feature-card-icon feature-icon-jobs">
              <FiBriefcase />
            </div>
            <h3>Smart Job Matching</h3>
            <p>Automatically find relevant job listings based on your resume content and skills.</p>
          </div>
        </div>
      </section>

      {/* Templates Section */}
      <section className="templates-section" id="templates">
        <div className="section-header">
          <span className="section-badge">Templates</span>
          <h2 className="section-title">Professional Templates <span>Made to Impress</span></h2>
          <p className="section-subtitle">
            Pick a template and start editing — each is ATS-friendly, print-ready, and fully customizable
          </p>
        </div>
        <TemplatePreviewCards />
      </section>

      {/* How It Works */}
      <section className="how-it-works" id="how-it-works">
        <div className="section-header">
          <span className="section-badge">How It Works</span>
          <h2 className="section-title">Three Steps to Your <span>Perfect Resume</span></h2>
        </div>
        <div className="steps-grid">
          <div className="step-card">
            <div className="step-number">01</div>
            <div className="step-icon"><FiUsers /></div>
            <h3>Create Your Account</h3>
            <p>Sign up in seconds. No credit card required. Start building immediately.</p>
          </div>
          <div className="step-connector">
            <FiArrowRight />
          </div>
          <div className="step-card">
            <div className="step-number">02</div>
            <div className="step-icon"><FiFileText /></div>
            <h3>Fill In Your Details</h3>
            <p>Add your experience, education, and skills. Watch the live preview update instantly.</p>
          </div>
          <div className="step-connector">
            <FiArrowRight />
          </div>
          <div className="step-card">
            <div className="step-number">03</div>
            <div className="step-icon"><FiStar /></div>
            <h3>Optimize & Share</h3>
            <p>Let AI enhance your content, pick a template, and share or download your resume.</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="cta-bg-effects">
          <div className="cta-orb cta-orb-1"></div>
          <div className="cta-orb cta-orb-2"></div>
        </div>
        <div className="cta-content">
          <h2>Ready to Build Your <span>Perfect Resume?</span></h2>
          <p>Join thousands of job seekers who landed their dream job with ResumeAI</p>
          <Link to={user ? '/dashboard' : '/register'} className="btn btn-primary btn-lg">
            Get Started Free <FiArrowRight />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="home-footer">
        <div className="footer-content">
          <div className="footer-brand">
            <FiFileText className="footer-icon" />
            <span>ResumeAI</span>
          </div>
          <div className="footer-links">
            <a href="#features">Features</a>
            <a href="#templates">Templates</a>
            <a href="#how-it-works">How It Works</a>
          </div>
          <div className="footer-copy">
            © 2026 ResumeAI. Built with ❤️ and AI.
          </div>
        </div>
      </footer>
    </div>
  );
}
