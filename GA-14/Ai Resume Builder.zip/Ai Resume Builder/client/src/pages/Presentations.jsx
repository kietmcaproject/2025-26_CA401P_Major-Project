import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import {
  FiPlus, FiMonitor, FiTrash2, FiEdit2, FiClock,
  FiArrowRight, FiArrowLeft, FiZap, FiImage, FiType,
  FiList, FiMaximize
} from 'react-icons/fi';
import '../styles/presentations.css';

const SLIDE_THEMES = [
  { id: 'gradient-purple', name: 'Purple Haze', bg: 'linear-gradient(135deg, #7c3aed, #ec4899)', text: '#fff' },
  { id: 'gradient-ocean', name: 'Deep Ocean', bg: 'linear-gradient(135deg, #0ea5e9, #8b5cf6)', text: '#fff' },
  { id: 'gradient-sunset', name: 'Sunset', bg: 'linear-gradient(135deg, #f97316, #ec4899)', text: '#fff' },
  { id: 'dark', name: 'Dark', bg: '#1a1a2e', text: '#f5f3ff' },
  { id: 'light', name: 'Light', bg: '#ffffff', text: '#1a1035' },
  { id: 'gradient-mint', name: 'Fresh Mint', bg: 'linear-gradient(135deg, #10b981, #06b6d4)', text: '#fff' },
];

const emptySlide = (themeId = 'gradient-purple') => ({
  id: Date.now() + Math.random(),
  title: '',
  content: '',
  bullets: [],
  theme: themeId,
  layout: 'title-content',
});

export default function Presentations() {
  const navigate = useNavigate();
  const [presentations, setPresentations] = useState([]);
  const [editing, setEditing] = useState(null); // the current presentation
  const [currentSlide, setCurrentSlide] = useState(0);
  const [presenting, setPresenting] = useState(false);

  const createPresentation = () => {
    const pres = {
      id: Date.now(),
      title: 'Untitled Presentation',
      createdAt: new Date().toISOString(),
      slides: [
        { ...emptySlide(), title: 'Welcome', content: 'Click to edit this slide' },
        { ...emptySlide(), title: 'About', content: 'Add your content here', layout: 'title-content' },
      ],
    };
    setPresentations([pres, ...presentations]);
    setEditing(pres);
    setCurrentSlide(0);
    toast.success('Presentation created!');
  };

  const deletePresentation = (e, id) => {
    e.stopPropagation();
    if (!window.confirm('Delete this presentation?')) return;
    setPresentations(prev => prev.filter(p => p.id !== id));
    if (editing?.id === id) setEditing(null);
    toast.success('Deleted');
  };

  const updateSlide = (field, value) => {
    if (!editing) return;
    const updated = { ...editing };
    updated.slides = [...updated.slides];
    updated.slides[currentSlide] = { ...updated.slides[currentSlide], [field]: value };
    setEditing(updated);
    setPresentations(prev => prev.map(p => p.id === updated.id ? updated : p));
  };

  const addSlide = () => {
    if (!editing) return;
    const theme = editing.slides[currentSlide]?.theme || 'gradient-purple';
    const updated = { ...editing, slides: [...editing.slides, emptySlide(theme)] };
    setEditing(updated);
    setCurrentSlide(updated.slides.length - 1);
    setPresentations(prev => prev.map(p => p.id === updated.id ? updated : p));
  };

  const deleteSlide = (index) => {
    if (!editing || editing.slides.length <= 1) return;
    const updated = { ...editing, slides: editing.slides.filter((_, i) => i !== index) };
    setEditing(updated);
    setCurrentSlide(Math.min(currentSlide, updated.slides.length - 1));
    setPresentations(prev => prev.map(p => p.id === updated.id ? updated : p));
  };

  const addBullet = () => {
    const slide = editing?.slides[currentSlide];
    if (!slide) return;
    updateSlide('bullets', [...(slide.bullets || []), '']);
  };

  const updateBullet = (idx, value) => {
    const slide = editing?.slides[currentSlide];
    if (!slide) return;
    const bullets = [...(slide.bullets || [])];
    bullets[idx] = value;
    updateSlide('bullets', bullets);
  };

  const removeBullet = (idx) => {
    const slide = editing?.slides[currentSlide];
    if (!slide) return;
    updateSlide('bullets', slide.bullets.filter((_, i) => i !== idx));
  };

  const getTheme = (themeId) => SLIDE_THEMES.find(t => t.id === themeId) || SLIDE_THEMES[0];

  // Presenting mode (fullscreen)
  if (presenting && editing) {
    const slide = editing.slides[currentSlide];
    const theme = getTheme(slide.theme);
    return (
      <div className="pres-fullscreen" style={{ background: theme.bg, color: theme.text }}
        onClick={() => setCurrentSlide(prev => Math.min(prev + 1, editing.slides.length - 1))}
      >
        <div className="pres-fs-content">
          <h1 className="pres-fs-title">{slide.title || 'Untitled Slide'}</h1>
          {slide.content && <p className="pres-fs-text">{slide.content}</p>}
          {slide.bullets?.length > 0 && (
            <ul className="pres-fs-bullets">
              {slide.bullets.map((b, i) => <li key={i}>{b}</li>)}
            </ul>
          )}
        </div>
        <div className="pres-fs-controls">
          <span>{currentSlide + 1} / {editing.slides.length}</span>
          <button onClick={(e) => { e.stopPropagation(); setPresenting(false); }}>
            Exit (Esc)
          </button>
        </div>
        {currentSlide > 0 && (
          <button className="pres-fs-nav pres-fs-prev"
            onClick={(e) => { e.stopPropagation(); setCurrentSlide(prev => prev - 1); }}>
            <FiArrowLeft />
          </button>
        )}
      </div>
    );
  }

  // Editor mode
  if (editing) {
    const slide = editing.slides[currentSlide];
    const theme = getTheme(slide?.theme);

    return (
      <div className="pres-editor">
        <div className="pres-editor-header">
          <button className="btn btn-secondary btn-sm" onClick={() => setEditing(null)}>
            <FiArrowLeft /> Back
          </button>
          <input
            className="pres-title-input"
            value={editing.title}
            onChange={e => {
              const updated = { ...editing, title: e.target.value };
              setEditing(updated);
              setPresentations(prev => prev.map(p => p.id === updated.id ? updated : p));
            }}
            placeholder="Presentation Title"
          />
          <button className="btn btn-primary btn-sm" onClick={() => { setCurrentSlide(0); setPresenting(true); }}>
            <FiMaximize /> Present
          </button>
        </div>

        <div className="pres-editor-body">
          {/* Slide panel */}
          <div className="pres-slide-panel">
            {editing.slides.map((s, i) => {
              const t = getTheme(s.theme);
              return (
                <div
                  key={s.id}
                  className={`pres-slide-thumb ${i === currentSlide ? 'active' : ''}`}
                  onClick={() => setCurrentSlide(i)}
                >
                  <div className="pres-thumb-content" style={{ background: t.bg, color: t.text }}>
                    <span className="pres-thumb-title">{s.title || `Slide ${i + 1}`}</span>
                  </div>
                  <span className="pres-thumb-num">{i + 1}</span>
                  {editing.slides.length > 1 && (
                    <button className="pres-thumb-delete" onClick={(e) => { e.stopPropagation(); deleteSlide(i); }}>
                      <FiTrash2 />
                    </button>
                  )}
                </div>
              );
            })}
            <button className="pres-add-slide" onClick={addSlide}>
              <FiPlus /> Add Slide
            </button>
          </div>

          {/* Main preview */}
          <div className="pres-main-area">
            <div className="pres-preview" style={{ background: theme.bg, color: theme.text }}>
              <div className="pres-preview-inner">
                <h2 className="pres-preview-title">{slide?.title || 'Untitled Slide'}</h2>
                {slide?.content && <p className="pres-preview-text">{slide.content}</p>}
                {slide?.bullets?.length > 0 && (
                  <ul className="pres-preview-bullets">
                    {slide.bullets.map((b, i) => <li key={i}>{b}</li>)}
                  </ul>
                )}
              </div>
            </div>
          </div>

          {/* Edit panel */}
          <div className="pres-edit-panel">
            <h3 className="pres-panel-heading">Slide {currentSlide + 1}</h3>
            <label>Title</label>
            <input value={slide?.title || ''} onChange={e => updateSlide('title', e.target.value)} placeholder="Slide title" />
            <label>Content</label>
            <textarea value={slide?.content || ''} onChange={e => updateSlide('content', e.target.value)} placeholder="Slide content" rows={3} />

            <label>Bullet Points</label>
            {(slide?.bullets || []).map((b, i) => (
              <div key={i} className="pres-bullet-row">
                <input value={b} onChange={e => updateBullet(i, e.target.value)} placeholder={`Point ${i + 1}`} />
                <button className="pres-bullet-del" onClick={() => removeBullet(i)}>×</button>
              </div>
            ))}
            <button className="btn btn-sm btn-secondary" onClick={addBullet}><FiPlus /> Add Point</button>

            <label style={{ marginTop: 16 }}>Theme</label>
            <div className="pres-theme-grid">
              {SLIDE_THEMES.map(t => (
                <button
                  key={t.id}
                  className={`pres-theme-chip ${slide?.theme === t.id ? 'active' : ''}`}
                  style={{ background: t.bg }}
                  onClick={() => updateSlide('theme', t.id)}
                  title={t.name}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Dashboard view
  return (
    <div className="pres-dashboard">
      <div className="dashboard-header">
        <div>
          <h1 className="dashboard-title">My <span>Presentations</span></h1>
          <p className="dashboard-subtitle">{presentations.length} presentation{presentations.length !== 1 ? 's' : ''} created</p>
        </div>
        <button className="btn btn-primary create-btn" onClick={createPresentation}>
          <FiPlus /> New Presentation
        </button>
      </div>
      <div className="resume-grid">
        {presentations.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">📊</div>
            <h3>No presentations yet</h3>
            <p>Create your first AI-powered presentation to get started</p>
            <button className="btn btn-primary create-btn" onClick={createPresentation}>
              <FiPlus /> Create Your First Presentation
            </button>
          </div>
        ) : (
          presentations.map((pres, i) => (
            <div key={pres.id} className="glass-card resume-card fade-in" style={{ animationDelay: `${i * 0.05}s` }}
              onClick={() => { setEditing(pres); setCurrentSlide(0); }}
            >
              <div className="resume-card-header">
                <div className="resume-card-icon"><FiMonitor /></div>
                <div className="resume-card-actions">
                  <button className="resume-card-action" onClick={(e) => { e.stopPropagation(); setEditing(pres); }} title="Edit">
                    <FiEdit2 />
                  </button>
                  <button className="resume-card-action delete" onClick={(e) => deletePresentation(e, pres.id)} title="Delete">
                    <FiTrash2 />
                  </button>
                </div>
              </div>
              <div className="resume-card-title">{pres.title}</div>
              <span className="resume-card-template">{pres.slides.length} slides</span>
              <div className="resume-card-date">
                <FiClock style={{ verticalAlign: 'middle', marginRight: 4 }} />
                {new Date(pres.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
