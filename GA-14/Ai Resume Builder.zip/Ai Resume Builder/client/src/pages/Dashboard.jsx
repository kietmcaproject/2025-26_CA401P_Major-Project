import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FiPlus, FiEdit2, FiTrash2, FiFileText, FiClock } from 'react-icons/fi';
import '../styles/dashboard.css';

export default function Dashboard() {
  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchResumes();
  }, []);

  const fetchResumes = async () => {
    try {
      const res = await axios.get('/resumes');
      setResumes(res.data);
    } catch {
      toast.error('Failed to load resumes');
    } finally {
      setLoading(false);
    }
  };

  const createResume = async () => {
    try {
      const res = await axios.post('/resumes', { title: 'Untitled Resume' });
      toast.success('Resume created!');
      navigate(`/editor/${res.data._id}`);
    } catch {
      toast.error('Failed to create resume');
    }
  };

  const deleteResume = async (e, id) => {
    e.preventDefault();
    e.stopPropagation();
    const yes = window.confirm('Are you sure you want to delete this resume?');
    if (!yes) return;
    try {
      await axios.delete(`/resumes/${id}`);
      setResumes(prev => prev.filter(r => r._id !== id));
      toast.success('Resume deleted');
    } catch (err) {
      console.error('Delete error:', err);
      toast.error(err.response?.data?.message || 'Failed to delete resume');
    }
  };

  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="page-loader">
        <div className="spinner spinner-lg"></div>
      </div>
    );
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <div>
          <h1 className="dashboard-title">My <span>Resumes</span></h1>
          <p className="dashboard-subtitle">
            {resumes.length} resume{resumes.length !== 1 ? 's' : ''} created
          </p>
        </div>
        <button className="btn btn-primary create-btn" onClick={createResume} id="create-resume-btn">
          <FiPlus /> New Resume
        </button>
      </div>
      <div className="resume-grid">
        {resumes.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">📄</div>
            <h3>No resumes yet</h3>
            <p>Create your first AI-powered resume to get started</p>
            <button className="btn btn-primary create-btn" onClick={createResume}>
              <FiPlus /> Create Your First Resume
            </button>
          </div>
        ) : (
          resumes.map((resume, i) => (
            <div
              key={resume._id}
              className="glass-card resume-card fade-in"
              style={{ animationDelay: `${i * 0.05}s` }}
              onClick={() => navigate(`/editor/${resume._id}`)}
              id={`resume-card-${resume._id}`}
            >
              <div className="resume-card-header">
                <div className="resume-card-icon">
                  <FiFileText />
                </div>
                <div className="resume-card-actions">
                  <button
                    className="resume-card-action"
                    onClick={(e) => { e.stopPropagation(); navigate(`/editor/${resume._id}`); }}
                    title="Edit"
                  >
                    <FiEdit2 />
                  </button>
                  <button
                    className="resume-card-action delete"
                    onClick={(e) => deleteResume(e, resume._id)}
                    title="Delete"
                  >
                    <FiTrash2 />
                  </button>
                </div>
              </div>
              <div className="resume-card-title">{resume.title}</div>
              <span className="resume-card-template">{resume.template}</span>
              <div className="resume-card-date">
                <FiClock style={{ verticalAlign: 'middle', marginRight: 4 }} />
                {formatDate(resume.updatedAt)}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
