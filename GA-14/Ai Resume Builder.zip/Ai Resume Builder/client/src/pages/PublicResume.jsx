import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import ClassicTemplate from '../templates/ClassicTemplate';
import ModernTemplate from '../templates/ModernTemplate';
import MinimalTemplate from '../templates/MinimalTemplate';
import CreativeTemplate from '../templates/CreativeTemplate';
import '../styles/templates.css';

const TEMPLATES = { classic: ClassicTemplate, modern: ModernTemplate, minimal: MinimalTemplate, creative: CreativeTemplate };

export default function PublicResume() {
  const { slug } = useParams();
  const [resume, setResume] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchResume = async () => {
      try {
        const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
        const res = await axios.get(`${apiUrl}/resumes/public/${slug}`);
        setResume(res.data);
      } catch {
        setError('Resume not found or the link has expired.');
      } finally {
        setLoading(false);
      }
    };
    fetchResume();
  }, [slug]);

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <div className="spinner spinner-lg"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', gap: 16 }}>
        <h2 style={{ color: 'var(--text-secondary)' }}>😕 {error}</h2>
        <Link to="/login" className="btn btn-primary">Go to ResumeAI</Link>
      </div>
    );
  }

  const TemplateComponent = TEMPLATES[resume?.template] || ModernTemplate;

  return (
    <div style={{ background: '#f5f5f5', minHeight: '100vh', padding: '30px 20px', display: 'flex', justifyContent: 'center' }}>
      <div style={{ width: '210mm', background: 'white', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}>
        <TemplateComponent data={resume} />
      </div>
    </div>
  );
}
