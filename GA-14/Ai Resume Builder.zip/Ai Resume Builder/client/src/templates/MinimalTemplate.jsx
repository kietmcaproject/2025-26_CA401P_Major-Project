export default function MinimalTemplate({ data }) {
  const { personalInfo = {}, summary, experience = [], education = [], skills = [], projects = [] } = data || {};

  return (
    <div className="resume-template template-minimal">
      <div className="resume-name">{personalInfo.fullName || 'Your Name'}</div>
      <div className="resume-contact">
        {personalInfo.email && <span>{personalInfo.email}</span>}
        {personalInfo.phone && <span>{personalInfo.phone}</span>}
        {personalInfo.location && <span>{personalInfo.location}</span>}
        {personalInfo.website && <span>{personalInfo.website}</span>}
        {personalInfo.linkedin && <span>{personalInfo.linkedin}</span>}
        {personalInfo.github && <span>{personalInfo.github}</span>}
      </div>

      {summary && (
        <>
          <div className="resume-section-title">Summary</div>
          <div className="resume-summary">{summary}</div>
        </>
      )}

      {experience.length > 0 && (
        <>
          <div className="resume-section-title">Experience</div>
          {experience.map((exp, i) => (
            <div key={i} className="resume-entry">
              <div className="resume-entry-title">{exp.jobTitle}</div>
              <div className="resume-entry-subtitle">{exp.company}{exp.location ? ` — ${exp.location}` : ''}</div>
              <div className="resume-entry-date">
                {exp.startDate}{exp.startDate && ' — '}{exp.current ? 'Present' : exp.endDate}
              </div>
              {exp.description && <div className="resume-entry-desc">{exp.description}</div>}
            </div>
          ))}
        </>
      )}

      {education.length > 0 && (
        <>
          <div className="resume-section-title">Education</div>
          {education.map((edu, i) => (
            <div key={i} className="resume-entry">
              <div className="resume-entry-title">{edu.degree}</div>
              <div className="resume-entry-subtitle">{edu.school}{edu.location ? ` — ${edu.location}` : ''}</div>
              <div className="resume-entry-date">{edu.startDate}{edu.startDate && ' — '}{edu.endDate}</div>
              {edu.description && <div className="resume-entry-desc">{edu.description}</div>}
            </div>
          ))}
        </>
      )}

      {skills.length > 0 && (
        <>
          <div className="resume-section-title">Skills</div>
          <div className="resume-skills-list">
            {skills.map((skill, i) => (
              <span key={i} className="resume-skill-item">{skill}</span>
            ))}
          </div>
        </>
      )}

      {projects.length > 0 && (
        <>
          <div className="resume-section-title">Projects</div>
          {projects.map((proj, i) => (
            <div key={i} className="resume-entry">
              <div className="resume-entry-title">{proj.name}</div>
              {proj.technologies && <div className="resume-entry-subtitle">{proj.technologies}</div>}
              {proj.description && <div className="resume-entry-desc">{proj.description}</div>}
            </div>
          ))}
        </>
      )}
    </div>
  );
}
