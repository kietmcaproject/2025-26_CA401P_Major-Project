export default function ModernTemplate({ data }) {
  const { personalInfo = {}, summary, experience = [], education = [], skills = [], projects = [] } = data || {};

  return (
    <div className="resume-template template-modern">
      <div className="modern-sidebar">
        <div className="resume-name">{personalInfo.fullName || 'Your Name'}</div>
        <div className="resume-tagline">{data?.title || 'Professional'}</div>

        <div className="sidebar-section-title">Contact</div>
        {personalInfo.email && <div className="sidebar-contact-item">📧 {personalInfo.email}</div>}
        {personalInfo.phone && <div className="sidebar-contact-item">📱 {personalInfo.phone}</div>}
        {personalInfo.location && <div className="sidebar-contact-item">📍 {personalInfo.location}</div>}
        {personalInfo.website && <div className="sidebar-contact-item">🌐 {personalInfo.website}</div>}
        {personalInfo.linkedin && <div className="sidebar-contact-item">💼 {personalInfo.linkedin}</div>}
        {personalInfo.github && <div className="sidebar-contact-item">💻 {personalInfo.github}</div>}

        {skills.length > 0 && (
          <>
            <div className="sidebar-section-title">Skills</div>
            <div className="sidebar-skills-list">
              {skills.map((skill, i) => (
                <span key={i} className="sidebar-skill-item">{skill}</span>
              ))}
            </div>
          </>
        )}
      </div>

      <div className="modern-main">
        {summary && (
          <>
            <div className="resume-section-title">About Me</div>
            <div className="resume-summary">{summary}</div>
          </>
        )}

        {experience.length > 0 && (
          <>
            <div className="resume-section-title">Experience</div>
            {experience.map((exp, i) => (
              <div key={i} className="resume-entry">
                <div className="resume-entry-header">
                  <div>
                    <div className="resume-entry-title">{exp.jobTitle}</div>
                    <div className="resume-entry-subtitle">{exp.company}{exp.location ? ` · ${exp.location}` : ''}</div>
                  </div>
                  <div className="resume-entry-date">
                    {exp.startDate}{exp.startDate && ' — '}{exp.current ? 'Present' : exp.endDate}
                  </div>
                </div>
                {exp.description && <div className="resume-entry-desc">{exp.description}</div>}
              </div>
            ))}
          </>
        )}

        {education.length > 0 && (
          <>
            <div className="resume-section-title">Education</div>
            {education.map((edu, i) => (
              <div key={i} className="resume-entry">
                <div className="resume-entry-header">
                  <div>
                    <div className="resume-entry-title">{edu.degree}</div>
                    <div className="resume-entry-subtitle">{edu.school}{edu.location ? ` · ${edu.location}` : ''}</div>
                  </div>
                  <div className="resume-entry-date">{edu.startDate}{edu.startDate && ' — '}{edu.endDate}</div>
                </div>
                {edu.description && <div className="resume-entry-desc">{edu.description}</div>}
              </div>
            ))}
          </>
        )}

        {projects.length > 0 && (
          <>
            <div className="resume-section-title">Projects</div>
            {projects.map((proj, i) => (
              <div key={i} className="resume-entry">
                <div className="resume-entry-title">{proj.name}</div>
                {proj.technologies && <div className="resume-entry-subtitle">{proj.technologies}</div>}
                {proj.description && <div className="resume-entry-desc">{proj.description}</div>}
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
}
