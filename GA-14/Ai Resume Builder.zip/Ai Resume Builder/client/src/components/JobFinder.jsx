import { useState, useEffect } from 'react';
import axios from 'axios';
import { FiBriefcase, FiX, FiMapPin, FiClock, FiExternalLink } from 'react-icons/fi';
import '../styles/jobs.css';

export default function JobFinder({ resumeTitle, skills, isOpen, onClose }) {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (isOpen) {
      searchJobs();
    }
  }, [isOpen, resumeTitle]);

  const searchJobs = async () => {
    const query = resumeTitle || (skills?.length > 0 ? skills.slice(0, 3).join(' ') : '');
    if (!query || query === 'Untitled Resume') return;

    setLoading(true);
    setMessage('');
    try {
      const res = await axios.get('/jobs/search', {
        params: { query, location: '' }
      });
      setJobs(res.data.jobs || []);
      if (res.data.message) setMessage(res.data.message);
    } catch {
      setJobs([]);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    const diff = Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
    if (diff === 0) return 'Today';
    if (diff === 1) return 'Yesterday';
    if (diff < 7) return `${diff}d ago`;
    if (diff < 30) return `${Math.floor(diff / 7)}w ago`;
    return `${Math.floor(diff / 30)}mo ago`;
  };

  if (!isOpen) return null;

  return (
    <div className="jobs-panel">
      <div className="jobs-panel-header">
        <h3><FiBriefcase /> Matching Jobs</h3>
        <button className="jobs-panel-close" onClick={onClose}><FiX /></button>
      </div>

      {message && <div className="jobs-panel-info">{message}</div>}

      <div className="jobs-panel-info">
        Auto-filtered for: <strong>{resumeTitle || 'your role'}</strong>
      </div>

      <div className="jobs-list">
        {loading ? (
          <div className="jobs-loading">
            <div className="spinner"></div>
            <span>Finding matching jobs...</span>
          </div>
        ) : jobs.length === 0 ? (
          <div className="jobs-empty">
            <div className="jobs-empty-icon">🔍</div>
            <p>No jobs found. Try updating your resume title to match a job role.</p>
          </div>
        ) : (
          jobs.map((job) => (
            <div key={job.id} className="job-card">
              <div className="job-card-header">
                <div className="job-logo">
                  {job.logo ? (
                    <img src={job.logo} alt={job.company} />
                  ) : (
                    <span className="job-logo-placeholder"><FiBriefcase /></span>
                  )}
                </div>
                <div>
                  <div className="job-title">{job.title}</div>
                  <div className="job-company">{job.company}</div>
                </div>
              </div>
              <div className="job-meta">
                <span><FiMapPin /> {job.location}</span>
                <span><FiClock /> {formatDate(job.posted)}</span>
                <span>{job.type}</span>
              </div>
              {job.description && (
                <div className="job-description">{job.description}</div>
              )}
              {job.applyLink && job.applyLink !== '#' && (
                <a href={job.applyLink} target="_blank" rel="noopener noreferrer" className="job-apply-btn">
                  <FiExternalLink /> Apply Now
                </a>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
