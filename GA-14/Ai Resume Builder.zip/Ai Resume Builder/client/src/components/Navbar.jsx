import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { FiFileText, FiLogOut, FiHome, FiSun, FiMoon } from 'react-icons/fi';
import '../styles/navbar.css';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="navbar-left">
        <Link to="/" className="navbar-brand" title="Home">
          <FiFileText className="navbar-icon" />
          <span className="navbar-logo">ResumeAI</span>
        </Link>
        {location.pathname !== '/dashboard' && (
          <Link to="/dashboard" className="navbar-home-link">
            <FiHome /> Dashboard
          </Link>
        )}
      </div>
      <div className="navbar-right">
        <button className="theme-toggle" onClick={toggleTheme} title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}>
          {theme === 'dark' ? <FiSun /> : <FiMoon />}
        </button>
        {user && (
          <>
            <div className="navbar-user">
              <div className="navbar-avatar">
                {user.name?.charAt(0).toUpperCase()}
              </div>
              <span>{user.name}</span>
            </div>
            <button className="navbar-logout" onClick={handleLogout}>
              <FiLogOut />
              Logout
            </button>
          </>
        )}
      </div>
    </nav>
  );
}
