import '../styles/template-previews.css';

const sampleData = {
  personalInfo: { fullName: 'Sarah Johnson', email: 'sarah@email.com', phone: '+1 555 123 4567', location: 'San Francisco, CA', linkedin: 'linkedin.com/in/sarah', github: 'github.com/sarah', website: 'sarahj.dev' },
  summary: 'Senior full-stack developer with 6+ years of experience building scalable web applications. Expert in React, Node.js, and cloud architecture.',
  experience: [
    { jobTitle: 'Senior Software Engineer', company: 'Google', location: 'Mountain View, CA', startDate: 'Jan 2022', endDate: 'Present', current: true, description: 'Led development of microservices architecture serving 10M+ users. Improved API response times by 40%.' },
    { jobTitle: 'Full Stack Developer', company: 'Stripe', location: 'SF, CA', startDate: 'Mar 2019', endDate: 'Dec 2021', description: 'Built payment processing features used by 5000+ businesses.' }
  ],
  education: [
    { degree: 'B.S. Computer Science', school: 'Stanford University', startDate: '2015', endDate: '2019' }
  ],
  skills: ['React', 'Node.js', 'TypeScript', 'Python', 'AWS', 'MongoDB'],
  projects: []
};

function MiniClassic() {
  return (
    <div className="tp-page tp-classic">
      <div className="tp-name tp-serif">Sarah Johnson</div>
      <div className="tp-contact-line">san francisco · sarah@email.com · +1 555 123 4567</div>
      <div className="tp-divider"></div>
      <div className="tp-section-title tp-serif">EXPERIENCE</div>
      <div className="tp-exp-title">Senior Software Engineer · Google</div>
      <div className="tp-exp-date">Jan 2022 — Present</div>
      <div className="tp-exp-desc">Led development of microservices architecture serving 10M+ users</div>
      <div className="tp-exp-title" style={{marginTop: 4}}>Full Stack Developer · Stripe</div>
      <div className="tp-exp-date">Mar 2019 — Dec 2021</div>
      <div className="tp-divider"></div>
      <div className="tp-section-title tp-serif">EDUCATION</div>
      <div className="tp-exp-title">B.S. Computer Science</div>
      <div className="tp-exp-date">Stanford University · 2015–2019</div>
      <div className="tp-divider"></div>
      <div className="tp-section-title tp-serif">SKILLS</div>
      <div className="tp-skills-row">
        <span>React</span><span>Node.js</span><span>TypeScript</span><span>AWS</span>
      </div>
    </div>
  );
}

function MiniModern() {
  return (
    <div className="tp-page tp-modern">
      <div className="tp-modern-sidebar">
        <div className="tp-modern-avatar">SJ</div>
        <div className="tp-modern-name">Sarah Johnson</div>
        <div className="tp-modern-role">Software Engineer</div>
        <div className="tp-modern-contact">
          <div>📧 sarah@email.com</div>
          <div>📍 San Francisco</div>
          <div>🔗 linkedin.com</div>
        </div>
        <div className="tp-modern-skills">
          <span>React</span><span>Node.js</span><span>TypeScript</span><span>AWS</span>
        </div>
      </div>
      <div className="tp-modern-main">
        <div className="tp-section-title tp-modern-title">EXPERIENCE</div>
        <div className="tp-exp-title">Senior Software Engineer</div>
        <div className="tp-exp-date">Google · 2022–Present</div>
        <div className="tp-exp-desc">Led microservices for 10M+ users</div>
        <div className="tp-exp-title" style={{marginTop: 4}}>Full Stack Developer</div>
        <div className="tp-exp-date">Stripe · 2019–2021</div>
        <div className="tp-section-title tp-modern-title" style={{marginTop: 6}}>EDUCATION</div>
        <div className="tp-exp-title">B.S. Computer Science</div>
        <div className="tp-exp-date">Stanford · 2015–2019</div>
      </div>
    </div>
  );
}

function MiniMinimal() {
  return (
    <div className="tp-page tp-minimal">
      <div className="tp-minimal-name">Sarah Johnson</div>
      <div className="tp-contact-line tp-minimal-contact">sarah@email.com · San Francisco, CA · +1 555 123 4567</div>
      <div className="tp-minimal-line"></div>
      <div className="tp-exp-desc" style={{marginBottom: 6}}>Senior full-stack developer with 6+ years building scalable apps.</div>
      <div className="tp-minimal-line"></div>
      <div className="tp-section-title tp-minimal-heading">Experience</div>
      <div className="tp-exp-title">Senior Software Engineer — Google</div>
      <div className="tp-exp-date">2022–Present</div>
      <div className="tp-exp-title" style={{marginTop: 3}}>Full Stack Developer — Stripe</div>
      <div className="tp-exp-date">2019–2021</div>
      <div className="tp-minimal-line"></div>
      <div className="tp-section-title tp-minimal-heading">Skills</div>
      <div className="tp-exp-date">React · Node.js · TypeScript · Python · AWS</div>
    </div>
  );
}

function MiniCreative() {
  return (
    <div className="tp-page tp-creative">
      <div className="tp-creative-header">
        <div className="tp-creative-name">Sarah Johnson</div>
        <div className="tp-creative-role">Senior Software Engineer</div>
      </div>
      <div className="tp-creative-body">
        <div className="tp-exp-desc">Full-stack developer with 6+ years building scalable web apps.</div>
        <div className="tp-section-title" style={{color: '#8b5cf6', marginTop: 6}}>EXPERIENCE</div>
        <div className="tp-exp-title">Senior Software Engineer</div>
        <div className="tp-exp-date">Google · 2022–Present</div>
        <div className="tp-exp-title" style={{marginTop: 3}}>Full Stack Developer</div>
        <div className="tp-exp-date">Stripe · 2019–2021</div>
        <div className="tp-section-title" style={{color: '#8b5cf6', marginTop: 6}}>SKILLS</div>
        <div className="tp-creative-tags">
          <span>React</span><span>Node.js</span><span>TypeScript</span>
        </div>
      </div>
    </div>
  );
}

const PREVIEWS = {
  classic: MiniClassic,
  modern: MiniModern,
  minimal: MiniMinimal,
  creative: MiniCreative,
};

const DESCRIPTIONS = {
  classic: 'Traditional, ATS-friendly layout with serif headings and clean structure',
  modern: 'Two-column layout with a dark sidebar — stands out on any desk',
  minimal: 'Clean whitespace-heavy design that lets your content speak',
  creative: 'Gradient header with a bold, creative personality',
};

export default function TemplatePreviewCards({ onSelect }) {
  return (
    <div className="template-preview-grid">
      {Object.entries(PREVIEWS).map(([name, Preview]) => (
        <div key={name} className="template-preview-card" onClick={() => onSelect?.(name)}>
          <div className="template-preview-thumb">
            <Preview />
          </div>
          <div className="template-preview-info">
            <span className="template-preview-name">{name.charAt(0).toUpperCase() + name.slice(1)}</span>
            <span className="template-preview-desc">{DESCRIPTIONS[name]}</span>
          </div>
          <button className="template-use-btn" onClick={(e) => { e.stopPropagation(); onSelect?.(name); }}>
            Use Template
          </button>
        </div>
      ))}
    </div>
  );
}

export { MiniClassic, MiniModern, MiniMinimal, MiniCreative };
