import { useState } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FiZap, FiX, FiCheck } from 'react-icons/fi';
import '../styles/ai.css';

export default function AiOptimizer({ resumeData, onApply }) {
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const handleOptimize = async () => {
    setLoading(true);
    try {
      const res = await axios.post('/ai/optimize', {
        personalInfo: resumeData.personalInfo,
        summary: resumeData.summary,
        experience: resumeData.experience,
        skills: resumeData.skills,
        targetRole: resumeData.title
      });
      setSuggestions(res.data);
      setShowModal(true);
    } catch (err) {
      toast.error(err.response?.data?.message || 'AI optimization failed');
    } finally {
      setLoading(false);
    }
  };

  const applySummary = () => {
    if (suggestions?.summary) {
      onApply({ summary: suggestions.summary });
      toast.success('Summary updated!');
    }
  };

  const applyExperience = () => {
    if (suggestions?.experience) {
      const updatedExp = [...(resumeData.experience || [])];
      suggestions.experience.forEach(opt => {
        if (updatedExp[opt.index]) {
          updatedExp[opt.index] = { ...updatedExp[opt.index], description: opt.description };
        }
      });
      onApply({ experience: updatedExp });
      toast.success('Experience updated!');
    }
  };

  const addSkill = (skill) => {
    const currentSkills = resumeData.skills || [];
    if (!currentSkills.includes(skill)) {
      onApply({ skills: [...currentSkills, skill] });
      toast.success(`Added "${skill}"`);
    }
  };

  return (
    <>
      <button
        className="ai-btn"
        onClick={handleOptimize}
        disabled={loading}
        id="ai-optimize-btn"
      >
        {loading ? <span className="spinner"></span> : <FiZap />}
        {loading ? 'Analyzing...' : 'AI Optimize'}
      </button>

      {showModal && suggestions && (
        <div className="ai-modal-overlay" onClick={() => setShowModal(false)}>
          <div className="ai-modal" onClick={e => e.stopPropagation()}>
            <div className="ai-modal-header">
              <h3><FiZap /> AI Suggestions</h3>
              <button className="ai-modal-close" onClick={() => setShowModal(false)}><FiX /></button>
            </div>
            <div className="ai-modal-body">
              {suggestions.summary && (
                <div className="ai-section">
                  <div className="ai-section-header">
                    <span className="ai-section-title">📝 Optimized Summary</span>
                    <button className="ai-apply-btn" onClick={applySummary}>
                      <FiCheck /> Apply
                    </button>
                  </div>
                  <div className="ai-content">{suggestions.summary}</div>
                </div>
              )}

              {suggestions.experience?.length > 0 && (
                <div className="ai-section">
                  <div className="ai-section-header">
                    <span className="ai-section-title">💼 Enhanced Experience</span>
                    <button className="ai-apply-btn" onClick={applyExperience}>
                      <FiCheck /> Apply All
                    </button>
                  </div>
                  {suggestions.experience.map((exp, i) => (
                    <div key={i} className="ai-content" style={{ marginBottom: 8 }}>
                      {exp.description}
                    </div>
                  ))}
                </div>
              )}

              {suggestions.skillSuggestions?.length > 0 && (
                <div className="ai-section">
                  <div className="ai-section-header">
                    <span className="ai-section-title">🎯 Suggested Skills</span>
                  </div>
                  <div className="ai-skills-list">
                    {suggestions.skillSuggestions.map((skill, i) => (
                      <button key={i} className="ai-skill-chip" onClick={() => addSkill(skill)}>
                        + {skill}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {suggestions.tips?.length > 0 && (
                <div className="ai-section">
                  <div className="ai-section-header">
                    <span className="ai-section-title">💡 Pro Tips</span>
                  </div>
                  <ul className="ai-tips">
                    {suggestions.tips.map((tip, i) => (
                      <li key={i}>{tip}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            <div className="ai-modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowModal(false)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
