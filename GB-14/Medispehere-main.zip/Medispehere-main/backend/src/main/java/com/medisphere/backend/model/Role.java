package com.medisphere.backend.model;

public enum Role {
    PATIENT, DOCTOR, ADMIN
}
