package com.medisphere.backend.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "patient_profiles")
public class PatientProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore
    private User user;

    private LocalDate dob;

    @Enumerated(EnumType.STRING)
    private Gender biologicalSex;

    private String bloodGroup;

    private Integer systolicBp;
    private Integer diastolicBp;
    private Integer fastingSugar;
    private Integer postPrandialSugar;

    private Double weightKg;
    private Double heightCm;

    @Column(length = 5000)
    private String allergies;

    @Column(length = 5000)
    private String chronicConditions;

    @Column(length = 5000)
    private String currentMedications;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public LocalDate getDob() { return dob; }
    public void setDob(LocalDate dob) { this.dob = dob; }

    public Gender getBiologicalSex() { return biologicalSex; }
    public void setBiologicalSex(Gender biologicalSex) { this.biologicalSex = biologicalSex; }

    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public Integer getSystolicBp() { return systolicBp; }
    public void setSystolicBp(Integer systolicBp) { this.systolicBp = systolicBp; }

    public Integer getDiastolicBp() { return diastolicBp; }
    public void setDiastolicBp(Integer diastolicBp) { this.diastolicBp = diastolicBp; }

    public Integer getFastingSugar() { return fastingSugar; }
    public void setFastingSugar(Integer fastingSugar) { this.fastingSugar = fastingSugar; }

    public Integer getPostPrandialSugar() { return postPrandialSugar; }
    public void setPostPrandialSugar(Integer postPrandialSugar) { this.postPrandialSugar = postPrandialSugar; }

    public Double getWeightKg() { return weightKg; }
    public void setWeightKg(Double weightKg) { this.weightKg = weightKg; }

    public Double getHeightCm() { return heightCm; }
    public void setHeightCm(Double heightCm) { this.heightCm = heightCm; }

    public String getAllergies() { return allergies; }
    public void setAllergies(String allergies) { this.allergies = allergies; }

    public String getChronicConditions() { return chronicConditions; }
    public void setChronicConditions(String chronicConditions) { this.chronicConditions = chronicConditions; }

    public String getCurrentMedications() { return currentMedications; }
    public void setCurrentMedications(String currentMedications) { this.currentMedications = currentMedications; }
}
