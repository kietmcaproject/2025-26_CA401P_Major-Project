package com.medisphere.backend.repository;

import com.medisphere.backend.model.MedicalRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicalRecordRepository extends JpaRepository<MedicalRecord, Long> {
    MedicalRecord findByAppointmentId(Long appointmentId);
}
