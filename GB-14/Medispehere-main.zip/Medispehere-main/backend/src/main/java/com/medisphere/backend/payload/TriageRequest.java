package com.medisphere.backend.payload;

public class TriageRequest {
    private String symptoms;

    public String getSymptoms() { return symptoms; }
    public void setSymptoms(String symptoms) { this.symptoms = symptoms; }
}
