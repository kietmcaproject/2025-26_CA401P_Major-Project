package com.medisphere.backend.controller;

import com.medisphere.backend.model.Doctor;
import com.medisphere.backend.model.Role;
import com.medisphere.backend.model.User;
import com.medisphere.backend.payload.JwtResponse;
import com.medisphere.backend.payload.LoginRequest;
import com.medisphere.backend.payload.SignupRequest;
import com.medisphere.backend.repository.DoctorRepository;
import com.medisphere.backend.repository.UserRepository;
import com.medisphere.backend.security.JwtUtils;
import com.medisphere.backend.security.UserDetailsImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/auth")
public class AuthController {
    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    DoctorRepository doctorRepository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtUtils jwtUtils;

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtUtils.generateJwtToken(authentication);
        
        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();    
        String role = userDetails.getAuthorities().iterator().next().getAuthority();

        Long doctorId = null;
        if (role.equals("ROLE_DOCTOR")) {
             User u = userRepository.findById(userDetails.getId()).orElse(null);
             if (u != null) {
                 Doctor doctor = doctorRepository.findAll().stream().filter(d -> d.getUser().getId().equals(u.getId())).findFirst().orElse(null);
                 if (doctor != null) {
                     doctorId = doctor.getId();
                 }
             }
        }

        return ResponseEntity.ok(new JwtResponse(jwt, 
                                                 userDetails.getId(), 
                                                 userDetails.getUsername(), 
                                                 role, doctorId));
    }

    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@RequestBody SignupRequest signUpRequest) {
        if (userRepository.findByEmail(signUpRequest.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body("Error: Email is already in use!");
        }

        User user = new User();
        user.setEmail(signUpRequest.getEmail());
        user.setPassword(encoder.encode(signUpRequest.getPassword()));
        user.setRole(signUpRequest.getRole() != null ? signUpRequest.getRole() : Role.PATIENT);
        user.setName(signUpRequest.getName());

        userRepository.save(user);

        if (user.getRole() == Role.DOCTOR) {
            Doctor doctor = new Doctor();
            doctor.setUser(user);
            doctor.setSpecialization(signUpRequest.getSpecialization());
            doctor.setBio(signUpRequest.getBio());
            doctor.setYearsOfExperience(signUpRequest.getYearsOfExperience());
            doctor.setConsultationFee(signUpRequest.getConsultationFee());
            doctorRepository.save(doctor);
        }

        return ResponseEntity.ok("User registered successfully!");
    }
}
