package com.medisphere.backend.model;

public enum Gender {
    MALE, FEMALE, OTHER
}
