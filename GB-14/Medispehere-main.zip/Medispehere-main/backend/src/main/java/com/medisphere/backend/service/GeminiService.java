package com.medisphere.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GeminiService {

    @Value("${gemini.api.key}")
    private String apiKey;

    @Value("${gemini.api.url}")
    private String apiUrl;

    @Autowired
    private com.medisphere.backend.repository.PatientProfileRepository patientProfileRepository;

    @Autowired
    private com.medisphere.backend.repository.DoctorRepository doctorRepository;

    private final RestTemplate restTemplate = new RestTemplate();

    public String analyzeSymptoms(String symptoms, com.medisphere.backend.model.User patient) {
        com.medisphere.backend.model.PatientProfile profile = patientProfileRepository.findByUserId(patient.getId())
                .orElse(null);

        String ageStr = "unknown";
        String genderStr = "unknown";
        String bpStr = "unknown";
        String sugarStr = "unknown";
        String allergiesStr = "none";
        String chronicStr = "none";

        if (profile != null) {
            if (profile.getDob() != null) {
                ageStr = String.valueOf(java.time.Period.between(profile.getDob(), java.time.LocalDate.now()).getYears());
            }
            if (profile.getBiologicalSex() != null) genderStr = profile.getBiologicalSex().name();
            if (profile.getSystolicBp() != null && profile.getDiastolicBp() != null) {
                bpStr = profile.getSystolicBp() + "/" + profile.getDiastolicBp();
            }
            if (profile.getFastingSugar() != null) sugarStr = profile.getFastingSugar() + " mg/dL";
            if (profile.getAllergies() != null && !profile.getAllergies().isBlank()) allergiesStr = profile.getAllergies();
            if (profile.getChronicConditions() != null && !profile.getChronicConditions().isBlank()) chronicStr = profile.getChronicConditions();
        }

        List<com.medisphere.backend.model.Doctor> allDoctors = doctorRepository.findByIsVerifiedTrue();
        String doctorListStr = allDoctors.stream()
            .map(d -> d.getUser().getName() + " (" + (d.getSpecializationCategory() != null ? d.getSpecializationCategory() : d.getSpecialization()) + ")")
            .collect(java.util.stream.Collectors.joining(", "));

        String prompt = "You are an expert Triage Physician. Patient Profile: " + ageStr + "yo " + genderStr +
                ", BP: " + bpStr + ", Sugar: " + sugarStr + ", Allergies: " + allergiesStr + ", Chronic Conditions: " + chronicStr +
                ". Current Symptoms: " + symptoms + ". " +
                "DIFFERENTIAL LOGIC INSTRUCTIONS:\n" +
                "1. If symptoms are general (Fever, Cold, Cough, Fatigue, Body Ache), you MUST recommend 'General Practice'.\n" +
                "2. Only recommend 'Cardiology' if there are specific signs of chest pain, palpitations, or shortness of breath linked to heart history.\n" +
                "3. Select the Target Specialty ONLY from this exact list: [General Practice, Cardiology, Pediatrics, Dermatology, Orthopedics].\n" +
                "4. Do not let previous examples bias your current decision.\n\n" +
                "Provide a structured JSON response with these keys: summary, possible_causes (list), immediate_actions (list), and target_specialty. " +
                "Do not include any text outside the JSON block.";
        
        return callGeminiApi(prompt);
    }

    public String generatePrescription(String history, String diagnosis) {
        String prompt = "You are an AI medical assistant. Based on the patient history: '" + history +
                "' and current diagnosis: '" + diagnosis +
                "', suggest a formatted prescription and treatment plan.";
        return callGeminiApi(prompt);
    }

    public String generatePatientInsight(String history, String symptoms) {
        String prompt = "You are a Medical Consultant. Analyze the following: Patient Clinical History/Vitals: [" + history + 
                "] and Current Symptoms: [" + symptoms + "]. " +
                "Generate a structured report in JSON format with keys: clinical_summary, suggested_diagnosis, and recommended_plan (include Medications, Dosages, and Lifestyle changes). " +
                "Do not include any text outside the JSON block.";
        return callGeminiApi(prompt);
    }

    public String auditDoctorSpecialization(String degree, String specialization) {
        String prompt = "You are a medical assistant. Categorize this doctor based on their degree '" + degree +
                "' and expertise '" + specialization + "'.\n" +
                "Map them to the most relevant category from this list: Internal Medicine, Cardiology, Dermatology, Pediatrics, Orthopedics, Neurology, Dentistry, or General Practice.\n" +
                "Return ONLY the category name. If you cannot determine it, return 'General Practice'.";
        return callGeminiApi(prompt);
    }

    private String callGeminiApi(String textPrompt) {
        if (apiKey == null || apiKey.trim().isEmpty() || "dummy_key".equals(apiKey.trim())
                || "your_api_key_here".equals(apiKey.trim())) {
            // Provide a mock response if real key is not configured, just for easy local
            // testing.
            return getMockResponse(textPrompt);
        }
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> parts = new HashMap<>();
            parts.put("text", textPrompt);

            Map<String, Object> contentUrl = new HashMap<>();
            contentUrl.put("parts", List.of(parts));

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("contents", List.of(contentUrl));

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);
            String url = apiUrl + "?key=" + apiKey.trim();

            Map response = restTemplate.postForObject(url, request, Map.class);
            // This relies on the structure returned by `generateContent`. Simple heuristic
            // parse:
            List<Map<String, Object>> candidates = (List<Map<String, Object>>) response.get("candidates");
            if (candidates != null && !candidates.isEmpty()) {
                Map<String, Object> content = (Map<String, Object>) candidates.get(0).get("content");
                List<Map<String, Object>> resParts = (List<Map<String, Object>>) content.get("parts");
                if (resParts != null && !resParts.isEmpty()) {
                    return (String) resParts.get(0).get("text");
                }
            }
            return "AI failed to parse response.";
        } catch (org.springframework.web.client.HttpClientErrorException e) {
            System.err.println("Gemini API Error: " + e.getStatusCode());
            // If the key is outright rejected (e.g. 400 Bad Request), fallback to mock
            // string so the app demonstration can continue
            return getMockResponse(textPrompt);
        } catch (Exception e) {
            e.printStackTrace();
            return "Error calling AI service: " + e.getMessage();
        }
    }

    private String getMockResponse(String textPrompt) {
        // IMPORTANT: Check doctor categorization FIRST
        if (textPrompt.contains("Categorize this doctor")) {
            if (textPrompt.toLowerCase().contains("cardiology")) return "Cardiology";
            if (textPrompt.toLowerCase().contains("dermatology")) return "Dermatology";
            if (textPrompt.toLowerCase().contains("pediatric")) return "Pediatrics";
            if (textPrompt.toLowerCase().contains("neurology")) return "Neurology";
            if (textPrompt.toLowerCase().contains("orthopedic")) return "Orthopedics";
            if (textPrompt.toLowerCase().contains("dentist")) return "Dentistry";
            if (textPrompt.toLowerCase().contains("internal")) return "Internal Medicine";
            return "General Practice";
        }
        if (textPrompt.contains("expert Triage Physician")) {
            String symptomsPart = textPrompt.toLowerCase();
            if (textPrompt.contains("Current Symptoms: ")) {
                int start = textPrompt.indexOf("Current Symptoms: ") + 18;
                int end = textPrompt.indexOf(".", start);
                if (end > start) {
                    symptomsPart = textPrompt.substring(start, end).toLowerCase();
                }
            }

            if (symptomsPart.contains("heart") || symptomsPart.contains("chest pain") || symptomsPart.contains("cardio")) {
                return "{\"summary\": \"The patient presents with cardiovascular symptoms that require immediate clinical evaluation by a specialist.\", \"possible_causes\": [\"Angina\", \"Cardiac Dysrhythmia\", \"Myocardial Ischemia\"], \"immediate_actions\": [\"Rest sitting up\", \"Seek emergency care if pain radiates\", \"Monitor heart rate\"], \"target_specialty\": \"Cardiology\"}";
            }
            if (symptomsPart.contains("fever") || symptomsPart.contains("cold") || symptomsPart.contains("body ache") || symptomsPart.contains("sore throat")) {
                return "{\"summary\": \"The patient reports general systemic symptoms including fever and fatigue. These are typical of common infections and should be evaluated by a primary physician.\", \"possible_causes\": [\"Viral Infection\", \"Seasonal Flu\", \"Inflammation\"], \"immediate_actions\": [\"Hydrate aggressively\", \"Monitor temperature\", \"Rest\"], \"target_specialty\": \"General Practice\"}";
            }
            return "{\"summary\": \"The symptoms described are general in nature and require an initial assessment by a primary care physician.\", \"possible_causes\": [\"General Malaise\", \"Fatigue\", \"Minor Infection\"], \"immediate_actions\": [\"Rest and hydrate\", \"Consult matched specialist if symptoms worsen\"], \"target_specialty\": \"General Practice\"}";
        }
        if (textPrompt.contains("Medical Consultant")) {
            return "{\"clinical_summary\": \"Patient history and current symptoms suggest a manageable condition. Primary focus should be on symptom relief and monitoring.\", \"suggested_diagnosis\": \"Generalized Fatigue / Mild Strain\", \"recommended_plan\": \"1. Take Ibuprofen 200mg as needed for pain. 2. Ensure 8 hours of sleep. 3. Avoid heavy lifting for 48 hours.\"}";
        }
        if (textPrompt.contains("prescription and treatment plan"))
            return "Rx: Rest and hydration. \nTreatment Plan: Monitor for 3 days.";
        return "Mock AI Response: Please configure valid Gemini API Key.";
    }

    public List<com.medisphere.backend.model.Doctor> getRecommendedDoctors(String specialty) {
        List<com.medisphere.backend.model.Doctor> allVerified = doctorRepository.findByIsVerifiedTrue();
        return allVerified.stream()
                .filter(d -> (d.getSpecialization() != null && d.getSpecialization().equalsIgnoreCase(specialty)) ||
                            (d.getSpecializationCategory() != null && d.getSpecializationCategory().equalsIgnoreCase(specialty)))
                .collect(java.util.stream.Collectors.toList());
    }
}
