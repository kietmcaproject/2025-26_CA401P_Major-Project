package com.medisphere.backend.repository;

import com.medisphere.backend.model.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
    List<Doctor> findBySpecializationIgnoreCase(String specialization);
    List<Doctor> findByIsVerifiedTrue();
    Optional<Doctor> findByUserId(Long userId);
}
