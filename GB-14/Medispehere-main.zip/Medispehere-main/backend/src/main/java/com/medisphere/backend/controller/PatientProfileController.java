package com.medisphere.backend.controller;

import com.medisphere.backend.model.PatientProfile;
import com.medisphere.backend.model.User;
import com.medisphere.backend.repository.PatientProfileRepository;
import com.medisphere.backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/profile")
public class PatientProfileController {

    @Autowired
    private PatientProfileRepository patientProfileRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping
    public ResponseEntity<?> getMyProfile() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User patient = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Optional<PatientProfile> profile = patientProfileRepository.findByUserId(patient.getId());
        return profile.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.noContent().build());
    }

    @PostMapping
    public ResponseEntity<?> updateProfile(@RequestBody PatientProfile requestData) {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User patient = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        PatientProfile profile = patientProfileRepository.findByUserId(patient.getId())
                .orElse(new PatientProfile());
        
        profile.setUser(patient);
        profile.setDob(requestData.getDob());
        profile.setBiologicalSex(requestData.getBiologicalSex());
        profile.setBloodGroup(requestData.getBloodGroup());
        profile.setSystolicBp(requestData.getSystolicBp());
        profile.setDiastolicBp(requestData.getDiastolicBp());
        profile.setFastingSugar(requestData.getFastingSugar());
        profile.setPostPrandialSugar(requestData.getPostPrandialSugar());
        profile.setWeightKg(requestData.getWeightKg());
        profile.setHeightCm(requestData.getHeightCm());
        profile.setAllergies(requestData.getAllergies());
        profile.setChronicConditions(requestData.getChronicConditions());
        profile.setCurrentMedications(requestData.getCurrentMedications());

        PatientProfile saved = patientProfileRepository.save(profile);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/{patientId}")
    public ResponseEntity<?> getPatientProfile(@PathVariable Long patientId) {
        // Simple authorization: only available for logged-in doctors based on global role scope
        // Detailed row-level role check can be added if required.
        Optional<PatientProfile> profile = patientProfileRepository.findByUserId(patientId);
        return profile.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.noContent().build());
    }
}
