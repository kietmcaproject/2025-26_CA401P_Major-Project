package com.medisphere.backend.payload;

import com.medisphere.backend.model.Role;

public class SignupRequest {
    private String email;
    private String password;
    private String name;
    private Role role;
    
    // For doctors only
    private String specialization;
    private String bio;
    private Integer yearsOfExperience;
    private java.math.BigDecimal consultationFee;

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }

    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    public Integer getYearsOfExperience() { return yearsOfExperience; }
    public void setYearsOfExperience(Integer yearsOfExperience) { this.yearsOfExperience = yearsOfExperience; }

    public java.math.BigDecimal getConsultationFee() { return consultationFee; }
    public void setConsultationFee(java.math.BigDecimal consultationFee) { this.consultationFee = consultationFee; }
}
