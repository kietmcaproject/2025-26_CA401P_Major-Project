package com.medisphere.backend.controller;

import com.medisphere.backend.model.Doctor;
import com.medisphere.backend.model.User;
import com.medisphere.backend.repository.DoctorRepository;
import com.medisphere.backend.repository.UserRepository;
import com.medisphere.backend.service.GeminiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/doctor/profile")
public class DoctorProfileController {

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private GeminiService geminiService;

    @GetMapping
    public ResponseEntity<?> getMyProfile() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Optional<Doctor> drOpt = doctorRepository.findByUserId(user.getId());
        return drOpt.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.noContent().build());
    }

    @PutMapping
    public ResponseEntity<?> updateProfile(@RequestBody Doctor requestData) {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Doctor doctor = doctorRepository.findByUserId(user.getId())
                .orElseThrow(() -> new RuntimeException("Doctor profile not found"));

        // Update all fields
        if (requestData.getPhoneNumber() != null) doctor.setPhoneNumber(requestData.getPhoneNumber());
        if (requestData.getMedicalDegree() != null) doctor.setMedicalDegree(requestData.getMedicalDegree());
        if (requestData.getUniversityName() != null) doctor.setUniversityName(requestData.getUniversityName());
        if (requestData.getGraduationYear() != null) doctor.setGraduationYear(requestData.getGraduationYear());
        if (requestData.getYearsOfExperience() != null) doctor.setYearsOfExperience(requestData.getYearsOfExperience());
        if (requestData.getConsultationFee() != null) doctor.setConsultationFee(requestData.getConsultationFee());
        if (requestData.getHospitalAffiliation() != null) doctor.setHospitalAffiliation(requestData.getHospitalAffiliation());
        if (requestData.getDetailedExpertise() != null) doctor.setDetailedExpertise(requestData.getDetailedExpertise());

        // Sync the chosen specialization from dropdown
        if (requestData.getSpecialization() != null && !requestData.getSpecialization().isBlank()) {
            doctor.setSpecialization(requestData.getSpecialization());
        }

        // Sync bio from expertise for backward compatibility
        if (requestData.getDetailedExpertise() != null && !requestData.getDetailedExpertise().isBlank()) {
            doctor.setBio(requestData.getDetailedExpertise()
                    .substring(0, Math.min(requestData.getDetailedExpertise().length(), 250)));
        }

        // AI Best-Match Audit: only requires degree to be present
        if (doctor.getMedicalDegree() != null && !doctor.getMedicalDegree().isBlank()) {
            // Use specialization from dropdown as the expertise hint for the AI
            String expertiseHint = (doctor.getDetailedExpertise() != null && !doctor.getDetailedExpertise().isBlank())
                    ? doctor.getDetailedExpertise()
                    : doctor.getSpecialization();

            String auditResult = geminiService.auditDoctorSpecialization(doctor.getMedicalDegree(), expertiseHint);
            doctor.setSpecializationCategory(auditResult.trim());
            doctor.setIsVerified(true); // Auto-verify as long as a category is returned
        } else {
            doctor.setIsVerified(false);
            doctor.setSpecializationCategory("Pending Assessment — please fill in your Medical Degree.");
        }

        doctorRepository.save(doctor);
        return ResponseEntity.ok(doctor);
    }
}
