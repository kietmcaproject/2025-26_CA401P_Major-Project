package com.medisphere.backend.model;

public enum AppointmentStatus {
    PENDING, COMPLETED, CANCELLED
}
