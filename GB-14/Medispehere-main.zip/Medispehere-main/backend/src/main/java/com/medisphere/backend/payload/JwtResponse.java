package com.medisphere.backend.payload;

public class JwtResponse {
    private String token;
    private String type = "Bearer";
    private Long id;
    private String email;
    private String role;
    private Long doctorId; // only if doctor

    public JwtResponse(String accessToken, Long id, String email, String role, Long doctorId) {
        this.token = accessToken;
        this.id = id;
        this.email = email;
        this.role = role;
        this.doctorId = doctorId;
    }

    public String getToken() { return token; }
    public String getType() { return type; }
    public Long getId() { return id; }
    public String getEmail() { return email; }
    public String getRole() { return role; }
    public Long getDoctorId() { return doctorId; }
}
