package com.medisphere.backend.controller;

import com.medisphere.backend.model.Appointment;
import com.medisphere.backend.model.AppointmentStatus;
import com.medisphere.backend.model.MedicalRecord;
import com.medisphere.backend.repository.AppointmentRepository;
import com.medisphere.backend.repository.MedicalRecordRepository;
import com.medisphere.backend.service.GeminiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/doctor")
public class DoctorController {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private MedicalRecordRepository medicalRecordRepository;

    @Autowired
    private com.medisphere.backend.repository.PatientProfileRepository patientProfileRepository;

    @Autowired
    private com.medisphere.backend.repository.UserRepository userRepository;

    @Autowired
    private GeminiService geminiService;

    @GetMapping("/{doctorId}/appointments")
    public ResponseEntity<?> getAppointments(@PathVariable Long doctorId) {
        List<Appointment> appointments = appointmentRepository.findByDoctorId(doctorId);
        return ResponseEntity.ok(appointments);
    }

    @GetMapping("/appointments/{appointmentId}/insights")
    public ResponseEntity<?> getInsights(@PathVariable Long appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
        
        String symptoms = appointment.getSymptomsSummary();
        
        // Fetch patient profile for better AI context
        String history = "New patient, no previous records";
        com.medisphere.backend.model.PatientProfile profile = patientProfileRepository.findByUserId(appointment.getPatient().getId()).orElse(null);
        if (profile != null) {
            history = String.format("BP: %s/%s, Sugar: %s, Weight: %s kg, Allergies: %s, Conditions: %s",
                profile.getSystolicBp(), profile.getDiastolicBp(), profile.getFastingSugar(), 
                profile.getWeightKg(), profile.getAllergies(), profile.getChronicConditions());
        }

        String insight = geminiService.generatePatientInsight(history, symptoms);
        Map<String, String> response = new HashMap<>();
        response.put("insight", insight);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/appointments/{appointmentId}/save-ai-analysis")
    public ResponseEntity<?> saveAiAnalysis(@PathVariable Long appointmentId, @RequestBody Map<String, String> requestData) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
        
        String analysis = requestData.get("aiAnalysis");
        
        com.medisphere.backend.model.MedicalRecord record = medicalRecordRepository.findAll().stream()
                .filter(r -> r.getAppointment().getId().equals(appointmentId))
                .findFirst()
                .orElse(new com.medisphere.backend.model.MedicalRecord());
        
        record.setAppointment(appointment);
        record.setAiAnalysis(analysis);
        medicalRecordRepository.save(record);
        
        return ResponseEntity.ok(record);
    }

    @PostMapping("/appointments/{appointmentId}/prescribe")
    public ResponseEntity<?> generatePrescription(
            @PathVariable Long appointmentId,
            @RequestBody Map<String, String> requestData) {
        
        String diagnosis = requestData.get("diagnosis");
        Appointment appointment = appointmentRepository.findById(appointmentId).orElseThrow(() -> new RuntimeException("Appointment not found"));
        String history = "Symptoms: " + appointment.getSymptomsSummary();
        
        String suggestion = geminiService.generatePrescription(history, diagnosis);
        
        Map<String, String> response = new HashMap<>();
        response.put("suggestion", suggestion);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/appointments/{appointmentId}/complete")
    public ResponseEntity<?> completeAppointment(
            @PathVariable Long appointmentId,
            @RequestBody Map<String, String> requestData) {

        Appointment appointment = appointmentRepository.findById(appointmentId).orElseThrow(() -> new RuntimeException("Appointment not found"));
        appointment.setStatus(AppointmentStatus.COMPLETED);
        appointmentRepository.save(appointment);

        MedicalRecord record = new MedicalRecord();
        record.setAppointment(appointment);
        record.setDiagnosis(requestData.get("diagnosis"));
        record.setPrescriptionText(requestData.get("prescriptionText"));
        record.setAiAnalysis(requestData.get("aiAnalysis"));
        medicalRecordRepository.save(record);

        return ResponseEntity.ok(record);
    }

    @GetMapping("/appointments/{id}/record")
    public ResponseEntity<?> getAppointmentRecord(@PathVariable Long id) {
        // In a real app, extract doctor ID from security context
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
        
        MedicalRecord record = medicalRecordRepository.findByAppointmentId(id);
        
        Map<String, Object> response = new HashMap<>();
        response.put("patientName", appointment.getPatient().getName());
        response.put("appointmentDate", appointment.getAppointmentDate());
        response.put("status", appointment.getStatus());
        response.put("symptomsSummary", appointment.getSymptomsSummary());
        
        if (record != null) {
            response.put("diagnosis", record.getDiagnosis());
            response.put("prescriptionText", record.getPrescriptionText());
            response.put("aiAnalysis", record.getAiAnalysis());
        }
        
        return ResponseEntity.ok(response);
    }
}
