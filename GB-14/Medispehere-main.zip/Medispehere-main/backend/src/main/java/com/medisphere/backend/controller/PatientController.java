package com.medisphere.backend.controller;

import com.medisphere.backend.model.Appointment;
import com.medisphere.backend.model.Doctor;
import com.medisphere.backend.model.User;
import com.medisphere.backend.payload.BookingRequest;
import com.medisphere.backend.payload.TriageRequest;
import com.medisphere.backend.repository.AppointmentRepository;
import com.medisphere.backend.repository.DoctorRepository;
import com.medisphere.backend.repository.UserRepository;
import com.medisphere.backend.service.GeminiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/patient")
public class PatientController {

    @Autowired
    private GeminiService geminiService;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private com.medisphere.backend.repository.MedicalRecordRepository medicalRecordRepository;

    @PostMapping("/triage")
    public ResponseEntity<?> performTriage(@RequestBody TriageRequest request) {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User patient = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("Patient not found"));

        String aiResponse = geminiService.analyzeSymptoms(request.getSymptoms(), patient);

        // Extract target specialty and find matching doctors in backend
        String targetSpecialty = "General Practice";
        try {
            String jsonStr = aiResponse.substring(aiResponse.indexOf('{'), aiResponse.lastIndexOf('}') + 1);
            if (jsonStr.contains("\"target_specialty\":")) {
                int start = jsonStr.indexOf("\"target_specialty\":");
                int valueStart = jsonStr.indexOf("\"", start + 19); 
                int valueEnd = jsonStr.indexOf("\"", valueStart + 1);
                targetSpecialty = jsonStr.substring(valueStart + 1, valueEnd).trim();
            }
        } catch (Exception e) {
            System.err.println("Error extracting specialty with fallback: " + e.getMessage());
        }

        List<Doctor> recommendations = geminiService.getRecommendedDoctors(targetSpecialty);

        Map<String, Object> response = new HashMap<>();
        response.put("analysis", aiResponse);
        response.put("recommendations", recommendations);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/doctors")
    public ResponseEntity<?> getDoctors() {
        // Only return AI-verified doctors to protect patient trust
        List<Doctor> doctors = doctorRepository.findByIsVerifiedTrue();
        return ResponseEntity.ok(doctors);
    }

    @PostMapping("/book")
    public ResponseEntity<?> bookAppointment(@RequestBody BookingRequest request) {
        if (request.getAppointmentDate().isBefore(java.time.LocalDate.now())) {
            return ResponseEntity.badRequest()
                    .body(java.util.Map.of("message", "Appointment date cannot be in the past"));
        }

        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User patient = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("Patient not found"));
        Doctor doctor = doctorRepository.findById(request.getDoctorId())
                .orElseThrow(() -> new RuntimeException("Doctor not found"));

        Appointment appointment = new Appointment();
        appointment.setPatient(patient);
        appointment.setDoctor(doctor);
        appointment.setAppointmentDate(request.getAppointmentDate());
        appointment.setTimeSlot(request.getTimeSlot());
        appointment.setSymptomsSummary(request.getSymptomsSummary());

        appointmentRepository.save(appointment);
        return ResponseEntity.ok(appointment);
    }

    @GetMapping("/appointments")
    public ResponseEntity<?> getMyAppointments() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User patient = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("Patient not found"));
        List<Appointment> appointments = appointmentRepository.findByPatientId(patient.getId());
        return ResponseEntity.ok(appointments);
    }

    @GetMapping("/appointments/{id}/record")
    public ResponseEntity<?> getAppointmentRecord(@PathVariable Long id) {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User patient = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("Patient not found"));
        
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
        
        // Security check: Ensure this appointment belongs to the calling patient
        if (!appointment.getPatient().getId().equals(patient.getId())) {
            return ResponseEntity.status(403).body("Unauthorized access to this medical record.");
        }

        com.medisphere.backend.model.MedicalRecord record = medicalRecordRepository.findByAppointmentId(id);
        
        Map<String, Object> response = new HashMap<>();
        response.put("doctorName", appointment.getDoctor().getUser().getName());
        response.put("appointmentDate", appointment.getAppointmentDate());
        response.put("status", appointment.getStatus());
        response.put("symptomsSummary", appointment.getSymptomsSummary());
        
        if (record != null) {
            response.put("diagnosis", record.getDiagnosis());
            response.put("prescriptionText", record.getPrescriptionText());
            response.put("aiAnalysis", record.getAiAnalysis());
        }
        
        return ResponseEntity.ok(response);
    }
}
