package com.medisphere.backend.payload;

import java.time.LocalDate;
import java.time.LocalTime;

public class BookingRequest {
    private Long doctorId;
    private LocalDate appointmentDate;
    private LocalTime timeSlot;
    private String symptomsSummary;

    public Long getDoctorId() { return doctorId; }
    public void setDoctorId(Long doctorId) { this.doctorId = doctorId; }

    public LocalDate getAppointmentDate() { return appointmentDate; }
    public void setAppointmentDate(LocalDate appointmentDate) { this.appointmentDate = appointmentDate; }

    public LocalTime getTimeSlot() { return timeSlot; }
    public void setTimeSlot(LocalTime timeSlot) { this.timeSlot = timeSlot; }

    public String getSymptomsSummary() { return symptomsSummary; }
    public void setSymptomsSummary(String symptomsSummary) { this.symptomsSummary = symptomsSummary; }
}
