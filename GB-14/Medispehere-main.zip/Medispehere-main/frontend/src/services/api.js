import axios from 'axios';
import AuthService from './auth';

const API_URL = 'http://localhost:8080/api/';

// Patient Endpoints
const performTriage = (symptoms, age, gender, medicalHistory) => {
  return axios.post(API_URL + 'patient/triage', { symptoms, age, gender, medicalHistory }, { headers: AuthService.authHeader() });
};

const getDoctors = () => {
  return axios.get(API_URL + 'patient/doctors', { headers: AuthService.authHeader() });
};

const bookAppointment = (data) => {
  return axios.post(API_URL + 'patient/book', data, { headers: AuthService.authHeader() });
};

const getMyAppointments = () => {
  return axios.get(API_URL + 'patient/appointments', { headers: AuthService.authHeader() });
}

const getAppointmentRecord = (id) => {
  return axios.get(API_URL + `patient/appointments/${id}/record`, { headers: AuthService.authHeader() });
};

// Doctor Endpoints
const getDoctorAppointments = (doctorId) => {
  return axios.get(API_URL + `doctor/${doctorId}/appointments`, { headers: AuthService.authHeader() });
};
const getDoctorAppointmentRecord = (id) => {
  return axios.get(API_URL + `doctor/appointments/${id}/record`, { headers: AuthService.authHeader() });
};

const getInsights = (appointmentId) => {
  return axios.get(API_URL + `doctor/appointments/${appointmentId}/insights`, { headers: AuthService.authHeader() });
};

const generatePrescription = (appointmentId, diagnosis) => {
  return axios.post(API_URL + `doctor/appointments/${appointmentId}/prescribe`, { diagnosis }, { headers: AuthService.authHeader() });
};

const completeAppointment = (appointmentId, data) => {
  return axios.post(API_URL + `doctor/appointments/${appointmentId}/complete`, data, { headers: AuthService.authHeader() });
};

const saveAiAnalysis = (appointmentId, aiAnalysis) => {
  return axios.post(API_URL + `doctor/appointments/${appointmentId}/save-ai-analysis`, { aiAnalysis }, { headers: AuthService.authHeader() });
};

// Profile Endpoints
const getMyProfile = () => {
  return axios.get(API_URL + 'profile', { headers: AuthService.authHeader() });
};
const updateMyProfile = (data) => {
  return axios.post(API_URL + 'profile', data, { headers: AuthService.authHeader() });
};
const getPatientProfile = (patientId) => {
  return axios.get(API_URL + `profile/${patientId}`, { headers: AuthService.authHeader() });
};
// Doctor Profile Endpoints
const getDoctorMyProfile = () => {
    return axios.get(API_URL + 'doctor/profile', { headers: AuthService.authHeader() });
};
const updateDoctorProfile = (data) => {
    return axios.put(API_URL + 'doctor/profile', data, { headers: AuthService.authHeader() });
};

export default {
  performTriage,
  getDoctors,
  bookAppointment,
  getMyAppointments,
  getAppointmentRecord,
  getDoctorAppointments,
  getDoctorAppointmentRecord,
  getInsights,
  generatePrescription,
  completeAppointment,
  getMyProfile,
  updateMyProfile,
  getPatientProfile,
  getDoctorMyProfile,
  updateDoctorProfile,
  saveAiAnalysis
};
