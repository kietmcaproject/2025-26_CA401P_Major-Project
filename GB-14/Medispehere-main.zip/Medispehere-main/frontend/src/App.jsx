import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useNavigate, Navigate } from 'react-router-dom';
import AuthService from './services/auth';
import Navbar from './components/Navbar';
import Login from './components/Login';
import Register from './components/Register';
import PatientDashboard from './components/PatientDashboard';
import DoctorDashboard from './components/DoctorDashboard';
import PatientProfilePage from './components/PatientProfilePage';
import VerifiedDoctorsPage from './components/VerifiedDoctorsPage';

function App() {
  const [currentUser, setCurrentUser] = useState(undefined);
  const navigate = useNavigate();

  useEffect(() => {
    const user = AuthService.getCurrentUser();
    if (user) {
      setCurrentUser(user);
    }
  }, []);

  const logOut = () => {
    AuthService.logout();
    setCurrentUser(undefined);
    navigate("/login");
  };

  return (
    <div>
      <Navbar currentUser={currentUser} onLogout={logOut} />
      
      <div className="container mt-4 animate-fade-in">
        <Routes>
          <Route path="/" element={
             currentUser ? (
              currentUser.role === "ROLE_DOCTOR" ? <Navigate to="/doctor" /> : <Navigate to="/patient" />
             ) : <Navigate to="/login" />
          } />
          <Route path="/login" element={<Login setCurrentUser={setCurrentUser} />} />
          <Route path="/register" element={<Register />} />
          <Route path="/patient" element={<PatientDashboard currentUser={currentUser} />} />
          <Route path="/profile" element={<PatientProfilePage currentUser={currentUser} />} />
          <Route path="/doctor" element={<DoctorDashboard currentUser={currentUser} />} />
          <Route path="/doctors" element={<VerifiedDoctorsPage />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
