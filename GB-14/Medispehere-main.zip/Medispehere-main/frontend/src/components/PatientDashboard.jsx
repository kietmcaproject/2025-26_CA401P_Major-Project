import React, { useState, useEffect } from 'react';
import ApiService from '../services/api';
import TriageReport from './TriageReport';
import DoctorCard from './DoctorCard';
import BookingModal from './BookingModal';
import AppointmentDetailModal from './AppointmentDetailModal';

const PatientDashboard = ({ currentUser }) => {
  const [symptoms, setSymptoms] = useState("");
  const [triageData, setTriageData] = useState(null);
  const [recommendedDoctors, setRecommendedDoctors] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(false);
  
  // Modal States
  const [showModal, setShowModal] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState(null);

  // Detail Modal States
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    try {
      const resp = await ApiService.getMyAppointments();
      setAppointments(resp.data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleTriage = async (e) => {
    e.preventDefault();
    setLoading(true);
    setTriageData(null);
    setRecommendedDoctors([]);

    try {
      const resp = await ApiService.performTriage(symptoms);
      let parsedAnalysis = {};
      try {
        const jsonStr = resp.data.analysis.substring(
          resp.data.analysis.indexOf('{'),
          resp.data.analysis.lastIndexOf('}') + 1
        );
        parsedAnalysis = JSON.parse(jsonStr);
      } catch (err) {
        console.error("Failed to parse AI JSON:", err);
        parsedAnalysis = { summary: resp.data.analysis || "Analysis complete." };
      }
      
      setTriageData(parsedAnalysis);
      setRecommendedDoctors(resp.data.recommendations || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const openBookingModal = (doctor) => {
    setSelectedDoctor(doctor);
    setShowModal(true);
  };

  const openDetailModal = async (appointmentId) => {
    try {
      const resp = await ApiService.getAppointmentRecord(appointmentId);
      setSelectedRecord(resp.data);
      setShowDetailModal(true);
    } catch (e) {
      console.error("Failed to fetch medical record", e);
      alert("Medical record not found or access denied.");
    }
  };

  const handleBookingSuccess = (msg) => {
    alert(msg);
    fetchAppointments();
    setTriageData(null);
    setSymptoms("");
  };

  return (
    <div className="container py-4">
      <div className="row g-4">
        <div className="col-lg-8">
          <div className="glass-card mb-4 border-0 shadow-sm animate-fade-in no-print">
            <h4 className="medical-header d-flex align-items-center mb-4 text-primary fw-bold">
              <span className="fs-3 me-2">🤖</span> AI Symptoms Triage
            </h4>
            <form onSubmit={handleTriage}>
              <div className="mb-4">
                <label className="form-label text-secondary fw-bold small text-uppercase mb-2">Detailed Symptom Description</label>
                <textarea
                  className="form-control form-control-lg border-0 bg-light py-3 px-4 shadow-none"
                  rows="4"
                  value={symptoms}
                  onChange={e => setSymptoms(e.target.value)}
                  placeholder="Example: I've had a dull ache in my left chest for 4 hours, feeling slightly dizzy..."
                  required
                  style={{ borderRadius: '15px' }}
                />
              </div>
              <button 
                className="btn btn-medical px-5 py-3 rounded-pill fw-bold fs-5 shadow-sm" 
                type="submit" 
                disabled={loading}
              >
                {loading ? "Analyzing..." : "Generate AI Medical Report"}
              </button>
            </form>
          </div>

          {triageData && <div className="no-print"><TriageReport report={triageData} /></div>}

          {triageData && (
            <div className="mb-5 animate-fade-in no-print">
              <div className="d-flex justify-content-between align-items-end mb-4">
                <h4 className="medical-header mb-0">Recommended Specialists</h4>
                <div className="text-secondary small">Based on your {triageData.target_specialty} needs</div>
              </div>
              
              <div className="row g-3">
                {recommendedDoctors.length === 0 ? (
                  <div className="alert alert-warning py-4 border-0 shadow-sm" style={{ borderRadius: '15px' }}>
                    No specialists currently available for {triageData.target_specialty}.
                  </div>
                ) : (
                  recommendedDoctors.map(doctor => (
                    <div key={doctor.id} className="col-md-6">
                      <DoctorCard doctor={doctor} onBook={openBookingModal} />
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        <div className="col-lg-4 no-print">
          <div className="glass-card sticky-top" style={{ top: '100px' }}>
            <h4 className="medical-header text-primary mb-4 border-bottom pb-2">My Appointments</h4>
            {appointments.length === 0 ? (
              <p className="text-muted small">No scheduled consultations found.</p>
            ) : (
              <div className="list-group list-group-flush">
                {appointments.slice(0, 8).map(app => (
                  <div 
                    key={app.id} 
                    className="list-group-item bg-transparent py-3 px-0 border-0 border-bottom cursor-pointer hover-bg-light"
                    onClick={() => openDetailModal(app.id)}
                    style={{ transition: 'all 0.2s' }}
                  >
                    <div className="d-flex justify-content-between align-items-center mb-1">
                      <h6 className="mb-0 fw-bold">Dr. {app.doctor?.user?.name}</h6>
                      <span className={`badge rounded-pill ${app.status === 'COMPLETED' ? 'bg-success' : 'bg-warning text-dark'} x-small`}>
                        {app.status}
                      </span>
                    </div>
                    <div className="text-secondary small mb-2 d-flex justify-content-between">
                       <span>📅 {app.appointmentDate}</span>
                       <span className="text-primary fw-bold">View Detail →</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div className="mt-3 text-center small text-secondary">
               Click any record to view its medical vault.
            </div>
          </div>
        </div>
      </div>

      <BookingModal 
        show={showModal} 
        onHide={() => setShowModal(false)}
        doctor={selectedDoctor}
        onSuccess={handleBookingSuccess}
      />

      <AppointmentDetailModal 
        show={showDetailModal}
        onHide={() => setShowDetailModal(false)}
        record={selectedRecord}
      />
    </div>
  );
};

export default PatientDashboard;
