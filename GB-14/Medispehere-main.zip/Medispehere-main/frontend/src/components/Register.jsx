import React, { useState } from 'react';
import AuthService from '../services/auth';

const Register = () => {
  const [formData, setFormData] = useState({
      name: '', email: '', password: '', role: 'PATIENT',
      specialization: '', bio: '', yearsOfExperience: 0, consultationFee: 0
  });
  const [message, setMessage] = useState('');
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setMessage('');
    setSuccess(false);
    setLoading(true);

    try {
      const resp = await AuthService.register(formData);
      setMessage(resp.data || "Registration successful!");
      setSuccess(true);
    } catch (error) {
      const resMessage = error.response?.data?.message || error.response?.data || error.message || error.toString();
      setMessage(resMessage);
      setSuccess(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="row justify-content-center mt-5 mb-5">
      <div className="col-md-6">
        <div className="glass-card">
          <h3 className="medical-header text-center">Create an Account</h3>
          <form onSubmit={handleRegister}>
            <div className="row g-3">
              <div className="col-12">
                <label className="form-label text-muted fw-bold small">Full Name</label>
                <input type="text" className="form-control" name="name" onChange={handleChange} required />
              </div>
              <div className="col-md-6">
                <label className="form-label text-muted fw-bold small">Email address</label>
                <input type="email" className="form-control" name="email" onChange={handleChange} required />
              </div>
              <div className="col-md-6">
                <label className="form-label text-muted fw-bold small">Password</label>
                <input type="password" className="form-control" name="password" onChange={handleChange} required />
              </div>
              <div className="col-12">
                <label className="form-label text-muted fw-bold small">I am a...</label>
                <select className="form-select" name="role" onChange={handleChange} value={formData.role}>
                    <option value="PATIENT">Patient</option>
                    <option value="DOCTOR">Medical Professional</option>
                </select>
              </div>

              {formData.role === 'DOCTOR' && (
                <>
                  <div className="col-md-6">
                    <label className="form-label text-muted fw-bold small">Specialization</label>
                    <input type="text" className="form-control" name="specialization" onChange={handleChange} required />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label text-muted fw-bold small">Years of Exp</label>
                    <input type="number" className="form-control" name="yearsOfExperience" onChange={handleChange} />
                  </div>
                  <div className="col-12">
                    <label className="form-label text-muted fw-bold small">Bio</label>
                    <textarea className="form-control" name="bio" rows="2" onChange={handleChange}></textarea>
                  </div>
                  <div className="col-12">
                    <label className="form-label text-muted fw-bold small">Consultation Fee (₹)</label>
                    <input type="number" className="form-control" name="consultationFee" onChange={handleChange} />
                  </div>
                </>
              )}

              <div className="col-12 mt-4 d-grid">
                <button className="btn btn-medical" type="submit" disabled={loading}>
                  {loading && <span className="spinner-border spinner-border-sm me-2"></span>}
                  Create Account
                </button>
              </div>
            </div>

            {message && (
              <div className={`alert mt-3 ${success ? 'alert-success' : 'alert-danger'}`} role="alert">
                {message}
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default Register;
