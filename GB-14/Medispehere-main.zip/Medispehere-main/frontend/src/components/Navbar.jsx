import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = ({ currentUser, onLogout }) => {
  return (
    <nav className="navbar navbar-expand navbar-custom py-3">
      <div className="container">
        <Link to={"/"} className="navbar-brand d-flex align-items-center">
          <span className="medical-header mb-0">Medisphere AI</span>
        </Link>
        <div className="navbar-nav mr-auto">
          {currentUser && (
            <li className="nav-item">
              <Link to={currentUser.role === 'ROLE_DOCTOR' ? "/doctor" : "/patient"} className="nav-link text-dark fw-medium">
                Dashboard
              </Link>
            </li>
          )}
          {currentUser && currentUser.role === 'ROLE_PATIENT' && (
            <li className="nav-item">
              <Link to="/profile" className="nav-link text-info fw-bold ms-3">
                My Health Profile
              </Link>
            </li>
          )}
          <li className="nav-item">
            <Link to="/doctors" className="nav-link text-primary fw-bold ms-3">
              🏥 Verified Doctors
            </Link>
          </li>
        </div>

        {currentUser ? (
          <div className="navbar-nav ms-auto">
            <li className="nav-item d-flex align-items-center me-3">
              <span className="text-muted small">Logged in as {currentUser.email}</span>
            </li>
            <li className="nav-item">
              <button className="btn btn-sm btn-outline-danger" onClick={onLogout}>
                LogOut
              </button>
            </li>
          </div>
        ) : (
          <div className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link to={"/login"} className="nav-link text-dark fw-medium">
                Login
              </Link>
            </li>
            <li className="nav-item ms-2">
              <Link to={"/register"} className="btn btn-medical btn-sm">
                Sign Up
              </Link>
            </li>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
