import React, { useState, useEffect } from 'react';
import ApiService from '../services/api';
import DoctorCard from './DoctorCard';
import BookingModal from './BookingModal';

const VerifiedDoctorsPage = () => {
  const [doctors, setDoctors] = useState([]);
  const [filteredDoctors, setFilteredDoctors] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  // Modal State
  const [showModal, setShowModal] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState(null);

  useEffect(() => {
    fetchDoctors();
  }, []);

  const fetchDoctors = async () => {
    try {
      const resp = await ApiService.getDoctors();
      setDoctors(resp.data);
      setFilteredDoctors(resp.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(true);
      setTimeout(() => setLoading(false), 500);
    }
  };

  const handleSearch = (e) => {
    const term = e.target.value.toLowerCase();
    setSearch(term);
    const filtered = doctors.filter(d => 
      (d.user?.name || '').toLowerCase().includes(term) || 
      (d.specialization || 'General Practice').toLowerCase().includes(term)
    );
    setFilteredDoctors(filtered);
  };

  const openBookingModal = (doctor) => {
    setSelectedDoctor(doctor);
    setShowModal(true);
  };

  const handleBookingSuccess = (msg) => {
    alert(msg);
    // Refreshing list is not strictly needed here but good practice
    fetchDoctors();
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center mb-5">
        <div className="col-md-8 text-center">
          <h2 className="medical-header display-5 mb-3">Verified Medical Specialists</h2>
          <p className="text-secondary fs-5 mb-4">Browse and search through our network of AI-verified doctors verified for clinical accuracy.</p>
          
          <div className="input-group input-group-lg shadow-sm" style={{ borderRadius: '15px', overflow: 'hidden' }}>
            <span className="input-group-text bg-white border-0 ps-4">🔍</span>
            <input 
              type="text" 
              className="form-control border-0 py-3" 
              placeholder="Search by name or specialty (e.g. Cardiology, Pediatrics)..." 
              value={search}
              onChange={handleSearch}
            />
          </div>
        </div>
      </div>

      {loading ? (
        <div className="d-flex justify-content-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading doctors...</span>
          </div>
        </div>
      ) : (
        <div className="row g-4 animate-fade-in">
          {filteredDoctors.length > 0 ? (
            filteredDoctors.map(doctor => (
              <div key={doctor.id} className="col-md-6 col-lg-4 col-xl-3">
                <DoctorCard doctor={doctor} onBook={openBookingModal} />
              </div>
            ))
          ) : (
            <div className="col-12 text-center py-5">
              <div className="fs-1 mb-3">🤷‍♂️</div>
              <h4 className="text-muted">No doctors found matching your search.</h4>
            </div>
          )}
        </div>
      )}

      <BookingModal 
        show={showModal} 
        onHide={() => setShowModal(false)}
        doctor={selectedDoctor}
        onSuccess={handleBookingSuccess}
      />
    </div>
  );
};

export default VerifiedDoctorsPage;
