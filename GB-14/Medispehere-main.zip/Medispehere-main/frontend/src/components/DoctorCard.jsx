import React from 'react';

const DoctorCard = ({ doctor, onBook }) => {
  return (
    <div className="card h-100 shadow-sm border-0 animate-fade-in hover-transform" style={{ borderRadius: '15px' }}>
      <div className="card-body p-4 text-center">
        <div className="mb-3">
          <img 
            src={`https://ui-avatars.com/api/?name=${encodeURIComponent(doctor.user?.name || '')}&background=0D6EFD&color=fff&size=128`} 
            alt={doctor.user?.name} 
            className="rounded-circle shadow-sm"
            style={{ width: '80px', height: '80px', objectFit: 'cover' }}
          />
        </div>
        <h5 className="card-title fw-bold text-dark mb-1">Dr. {doctor.user?.name}</h5>
        <p className="text-primary small fw-bold mb-3">
          {doctor.specialization || 'General Practice'}
        </p>
        
        <div className="d-flex justify-content-center gap-3 mb-4">
          <div className="text-secondary small">
            <div className="fw-bold text-dark">{doctor.yearsOfExperience}+</div>
            Years Exp
          </div>
          <div className="vr"></div>
          <div className="text-secondary small">
            <div className="fw-bold text-dark">₹{doctor.consultationFee}</div>
            Consultation
          </div>
        </div>

        <button 
          className="btn btn-medical w-100 py-2 rounded-pill fw-bold shadow-sm"
          onClick={() => onBook(doctor)}
        >
          Book Appointment
        </button>
      </div>
    </div>
  );
};

export default DoctorCard;
