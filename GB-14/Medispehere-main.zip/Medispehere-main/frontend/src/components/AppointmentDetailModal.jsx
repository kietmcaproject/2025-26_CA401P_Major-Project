import React from 'react';

const AppointmentDetailModal = ({ show, onHide, record }) => {
  if (!show || !record) return null;

  const handlePrint = () => {
    window.print();
  };

  const isCompleted = record.status === 'COMPLETED';

  return (
    <div className="modal show d-block animate-fade-in" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }}>
      <div className="modal-dialog modal-lg modal-dialog-centered">
        <div className="modal-content border-0 shadow-lg overflow-hidden" style={{ borderRadius: '25px' }}>
          
          {/* Header */}
          <div className="modal-header border-0 bg-primary text-white p-4 d-flex justify-content-between align-items-center">
            <div>
              <h5 className="modal-title fw-bold fs-3 mb-0">Consultation Detail</h5>
              <p className="mb-0 opacity-75 small uppercase tracking-wider">Medical Record ID: #{Math.floor(Math.random() * 900000) + 100000}</p>
            </div>
            <div className="d-flex gap-2 no-print">
              <button className="btn btn-light rounded-pill px-4 fw-bold shadow-sm" onClick={handlePrint}>
                🖨️ Print Record
              </button>
              <button type="button" className="btn-close btn-close-white" onClick={onHide}></button>
            </div>
          </div>

          <div className="modal-body p-0">
            <div className="row g-0">
              
              {/* Left Column: Summary */}
              <div className="col-md-5 bg-light p-4 border-end">
                <div className="text-center mb-4">
                  <div className="badge rounded-pill bg-primary p-3 mb-3 shadow-sm">
                    <span className="fs-1">🏥</span>
                  </div>
                  <h4 className="fw-bold text-dark">Dr. {record.doctorName}</h4>
                  <p className="text-secondary small mb-3">Consultation Date: {record.appointmentDate}</p>
                  <span className={`badge rounded-pill ${isCompleted ? 'bg-success' : 'bg-warning text-dark'} px-3 py-2 fw-bold`}>
                    {record.status}
                  </span>
                </div>

                <div className="mt-4 p-3 bg-white rounded-4 shadow-sm">
                  <h6 className="text-primary fw-bold small text-uppercase border-bottom pb-2 mb-3">Patient Symptoms</h6>
                  <p className="text-dark mb-0 small" style={{ fontStyle: 'italic' }}>
                    "{record.symptomsSummary || 'No details provided.'}"
                  </p>
                </div>
              </div>

              {/* Right Column: AI & Clinical */}
              <div className="col-md-7 p-4 bg-white">
                
                {/* AI Folder Section */}
                <div className="mb-4">
                  <div className="d-flex align-items-center mb-2">
                    <span className="me-2 fs-5">🤖</span>
                    <h6 className="fw-bold text-dark mb-0">AI Triage Insights</h6>
                  </div>
                  <div className="p-3 rounded-4" style={{ backgroundColor: '#f0f7ff', border: '1px solid #d1e7ff' }}>
                    <p className="small text-dark mb-0 lh-base">
                      {record.aiAnalysis || "Pending finalization during consultation."}
                    </p>
                  </div>
                </div>

                <hr className="my-4 opacity-50" />

                {/* Prescription Vault Section */}
                <div className={!isCompleted ? 'opacity-50' : ''}>
                  <div className="d-flex align-items-center mb-3">
                    <span className="me-2 fs-5">💊</span>
                    <h6 className="fw-bold text-dark mb-0">Doctor's Clinical Notes</h6>
                  </div>
                  
                  {isCompleted ? (
                    <div className="animate-fade-in">
                      <div className="mb-3">
                        <label className="text-secondary small fw-bold text-uppercase mb-1">Final Diagnosis</label>
                        <div className="fw-bold text-dark border-start border-primary border-4 ps-3 py-1">
                          {record.diagnosis}
                        </div>
                      </div>
                      <div>
                        <label className="text-secondary small fw-bold text-uppercase mb-1">Prescription & Treatment</label>
                        <div className="p-3 bg-light rounded-4 border whitespace-pre-wrap small font-monospace">
                          {record.prescriptionText}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-5">
                      <div className="fs-1 mb-2">⏳</div>
                      <p className="text-secondary small">Consultation in progress.<br/>Official prescription will be available here once finalized.</p>
                    </div>
                  )}
                </div>

              </div>
            </div>
          </div>

          {/* Footer Card Look */}
          <div className="modal-footer border-0 p-4 bg-light justify-content-between">
            <div className="text-secondary small">
              Verified by <strong>Medisphere AI Platform</strong>
            </div>
            <button className="btn btn-outline-secondary rounded-pill px-4" onClick={onHide}>Close Record</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppointmentDetailModal;
