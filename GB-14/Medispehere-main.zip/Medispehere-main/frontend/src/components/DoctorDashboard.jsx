import React, { useState, useEffect } from 'react';
import ApiService from '../services/api';
import DoctorProfilePage from './DoctorProfilePage';

const DoctorDashboard = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState('APPOINTMENTS');
  const [isVerified, setIsVerified] = useState(false);
  const [appointments, setAppointments] = useState([]);
  const [selectedAppt, setSelectedAppt] = useState(null);
  const [insightReport, setInsightReport] = useState(null);
  const [patientProfile, setPatientProfile] = useState(null);
  const [loadingProfile, setLoadingProfile] = useState(false);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [diagnosis, setDiagnosis] = useState('');
  const [prescriptionText, setPrescriptionText] = useState('');
  const [loadingPrescription, setLoadingPrescription] = useState(false);
  const [savingRecord, setSavingRecord] = useState(false);
  
  // Historical Record State
  const [completedRecord, setCompletedRecord] = useState(null);
  const [loadingRecord, setLoadingRecord] = useState(false);

  useEffect(() => {
    if (currentUser?.doctorId) {
      fetchAppointments();
      checkVerification();
    }
  }, [currentUser]);

  const checkVerification = async () => {
    try {
      const resp = await ApiService.getDoctorMyProfile();
      if (resp.data) setIsVerified(resp.data.isVerified === true);
    } catch (e) {
      setIsVerified(false);
    }
  };

  const fetchAppointments = async () => {
    try {
      const resp = await ApiService.getDoctorAppointments(currentUser.doctorId);
      setAppointments(resp.data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleDisplayAppt = async (appt) => {
    setSelectedAppt(appt);
    setInsightReport(null);
    setCompletedRecord(null);
    setDiagnosis('');
    setPrescriptionText('');
    setPatientProfile(null);

    if (appt.status === 'COMPLETED') {
        fetchHistoricalRecord(appt.id);
    }

    if (appt.patient?.id) {
      setLoadingProfile(true);
      try {
        const resp = await ApiService.getPatientProfile(appt.patient.id);
        if (resp.data) setPatientProfile(resp.data);
      } catch (e) { console.error(e); }
      finally { setLoadingProfile(false); }
    }
  };

  const fetchHistoricalRecord = async (apptId) => {
    setLoadingRecord(true);
    try {
        const resp = await ApiService.getDoctorAppointmentRecord(apptId);
        setCompletedRecord(resp.data);
    } catch (e) {
        console.error(e);
    } finally {
        setLoadingRecord(false);
    }
  };

  const handleGetInsight = async () => {
    setLoadingInsight(true);
    try {
      const resp = await ApiService.getInsights(selectedAppt.id);
      let parsed = null;
      try {
        const jsonStr = resp.data.insight.substring(
          resp.data.insight.indexOf('{'),
          resp.data.insight.lastIndexOf('}') + 1
        );
        parsed = JSON.parse(jsonStr);
      } catch (e) {
        parsed = { clinical_summary: resp.data.insight };
      }
      setInsightReport(parsed);
      if (parsed.suggested_diagnosis) setDiagnosis(parsed.suggested_diagnosis);
      if (parsed.recommended_plan) setPrescriptionText(parsed.recommended_plan);
    } catch (e) { console.error(e); }
    finally { setLoadingInsight(false); }
  };

  const handleSaveToRecord = async () => {
    if (!insightReport) return;
    setSavingRecord(true);
    try {
        const reportText = JSON.stringify(insightReport, null, 2);
        await ApiService.saveAiAnalysis(selectedAppt.id, reportText);
        alert("AI Insight has been saved to the permanent medical record.");
    } catch (e) {
        console.error(e);
        alert("Failed to save AI analysis to record.");
    } finally {
        setSavingRecord(false);
    }
  };

  const handleGeneratePrescription = async () => {
    if (!diagnosis) { alert('Please enter a diagnosis first'); return; }
    setLoadingPrescription(true);
    try {
      const resp = await ApiService.generatePrescription(selectedAppt.id, diagnosis);
      setPrescriptionText(resp.data.suggestion);
    } catch (e) { console.error(e); }
    finally { setLoadingPrescription(false); }
  };

  const handleComplete = async () => {
    try {
      const aiAnalysisStr = insightReport ? JSON.stringify(insightReport) : "";
      await ApiService.completeAppointment(selectedAppt.id, { 
        diagnosis, 
        prescriptionText, 
        aiAnalysis: aiAnalysisStr 
      });
      alert('Appointment marked as completed and stored in records!');
      fetchAppointments();
      fetchHistoricalRecord(selectedAppt.id);
      // Keep it selected but update to show record
      setSelectedAppt(prev => ({ ...prev, status: 'COMPLETED' }));
    } catch (e) {
      console.error(e);
      alert('Failed to complete appointment');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="row g-4">
      {/* SIDEBAR */}
      <div className="col-lg-3 no-print">
        <div className="glass-card mb-4 border-0 shadow-sm overflow-hidden" style={{ borderRadius: '15px' }}>
          <div className="bg-primary bg-gradient p-3 text-white text-center">
            <h6 className="mb-0 fw-bold text-uppercase small">Medical Portal</h6>
          </div>
          <div className="p-3">
            <div className="d-grid gap-2">
              <button
                className={`btn text-start py-3 px-4 border-0 rounded-pill fw-bold ${activeTab === 'APPOINTMENTS' ? 'btn-primary shadow text-white' : 'btn-light text-muted'}`}
                onClick={() => setActiveTab('APPOINTMENTS')}
              >
                📋 Appointments
              </button>
              <button
                className={`btn text-start py-3 px-4 border-0 rounded-pill fw-bold ${activeTab === 'PROFILE' ? 'btn-primary shadow text-white' : 'btn-light text-muted'}`}
                onClick={() => setActiveTab('PROFILE')}
              >
                🩺 Professional Profile
                {!isVerified && <span className="badge bg-warning text-dark ms-2 small">!</span>}
              </button>
            </div>
          </div>
        </div>

        <div className={`alert ${isVerified ? 'alert-success border-success' : 'alert-warning border-warning'} d-flex align-items-center py-2 px-3 fw-bold small shadow-sm`} style={{ borderRadius: '12px' }}>
          <span className="fs-4 me-2">{isVerified ? '✅' : '⏳'}</span>
          {isVerified ? 'Verified System Practitioner' : 'Verification Pending'}
        </div>

        {activeTab === 'APPOINTMENTS' && (
          <div className="glass-card mt-4 border-0 shadow-sm" style={{ borderRadius: '15px' }}>
            <h6 className="fw-bold text-secondary mb-3 px-3">Consultation Schedule</h6>
            <div className="list-group list-group-flush" style={{ maxHeight: '400px', overflowY: 'auto' }}>
              {appointments.length === 0 ? (
                <p className="text-center text-muted py-4 small">Clear schedule.</p>
              ) : (
                appointments.map(app => (
                  <button
                    key={app.id}
                    onClick={() => handleDisplayAppt(app)}
                    className={`list-group-item list-group-item-action py-3 px-4 border-0 ${selectedAppt?.id === app.id ? 'bg-info bg-opacity-10 text-info fw-bold border-start border-4 border-info' : 'text-muted'}`}
                  >
                    <div className="d-flex w-100 justify-content-between align-items-center mb-1">
                      <span className="text-truncate" style={{ maxWidth: '120px' }}>{app.patient?.name}</span>
                      <small className={`badge ${app.status === 'COMPLETED' ? 'bg-success' : 'bg-warning'} bg-opacity-25 text-dark x-small`}>{app.status}</small>
                    </div>
                    <div className="x-small opacity-75">{app.appointmentDate} @ {app.timeSlot}</div>
                  </button>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* MAIN CONTENT */}
      <div className="col-lg-9">
        {activeTab === 'PROFILE' && (
          <DoctorProfilePage onVerified={() => { setIsVerified(true); setActiveTab('APPOINTMENTS'); }} />
        )}

        {activeTab === 'APPOINTMENTS' && (
          <>
            {!isVerified && (
              <div className="alert alert-danger shadow-sm mb-4 border-0 d-flex justify-content-between align-items-center p-4 no-print">
                <div className="d-flex align-items-center">
                  <span className="fs-1 me-4">🔒</span>
                  <div>
                    <h5 className="fw-bold mb-1">Account Feature Blocked</h5>
                    <p className="mb-0 opacity-75">Your professional credentials must be AI-verified before you can consult patients.</p>
                  </div>
                </div>
                <button className="btn btn-light fw-bold text-danger px-4 rounded-pill" onClick={() => setActiveTab('PROFILE')}>Finish Profile →</button>
              </div>
            )}

            {selectedAppt ? (
              <div className="glass-card animate-fade-in border-0 shadow-sm" style={{ borderRadius: '20px' }}>
                <div className="d-flex justify-content-between align-items-center mb-4 border-bottom pb-4">
                  <h4 className="medical-header text-primary mb-0 no-print">Consultation Dashboard</h4>
                  <div className="text-end print-only d-none">
                     <h2 className="fw-bold text-primary">MEDICAL RECORD</h2>
                     <p className="small text-muted mb-0">Medisphere Clinical Platform</p>
                  </div>
                  <div className="text-end">
                    <div className="small text-secondary fw-bold">REF ID: #{selectedAppt.id}</div>
                    <div className="small text-muted opacity-75">Status: {selectedAppt.status}</div>
                  </div>
                </div>

                {/* Patient Profile Summary always visible at top */}
                <div className="card border-0 bg-info bg-opacity-10 p-4 mb-4" style={{ borderRadius: '15px' }}>
                  <div className="d-flex justify-content-between align-items-start mb-3">
                    <h6 className="text-info fw-bold small text-uppercase mb-0">Patient Clinical Profile</h6>
                    <span className="fw-bold text-dark fs-5">{selectedAppt.patient?.name}</span>
                  </div>
                  <div className="row g-3 small">
                    <div className="col-md-3"><strong>Sex:</strong> {patientProfile?.biologicalSex || '...'}</div>
                    <div className="col-md-3"><strong>BP:</strong> {patientProfile?.systolicBp ? `${patientProfile.systolicBp}/${patientProfile.diastolicBp}` : '...'}</div>
                    <div className="col-md-3"><strong>Sugar:</strong> {patientProfile?.fastingSugar || '...'}</div>
                    <div className="col-md-3"><strong>Blood:</strong> {patientProfile?.bloodGroup || 'N/A'}</div>
                  </div>
                </div>

                {selectedAppt.status === 'COMPLETED' ? (
                  <div className="animate-fade-in">
                    {loadingRecord ? (
                        <div className="text-center py-5"><div className="spinner-border text-primary"></div></div>
                    ) : completedRecord && (
                        <div className="clinical-archive">
                           <div className="d-flex justify-content-between align-items-center mb-4 no-print">
                              <h5 className="fw-bold text-success mb-0">📜 Clinical Archive Record</h5>
                              <button className="btn btn-outline-primary rounded-pill px-4 btn-sm fw-bold" onClick={handlePrint}>🖨️ Print Clinical Details</button>
                           </div>

                           <div className="bg-light p-4 rounded-4 mb-4 border">
                                <label className="text-secondary fw-bold small text-uppercase mb-2">Original Patient Symptoms</label>
                                <p className="mb-0 text-dark" style={{ fontStyle: 'italic' }}>"{completedRecord.symptomsSummary}"</p>
                           </div>

                           <div className="row g-4">
                              <div className="col-md-6">
                                  <div className="p-4 bg-white border border-light shadow-sm rounded-4 h-100">
                                      <h6 className="fw-bold text-primary border-bottom pb-2 mb-3 small text-uppercase">AI Triage History</h6>
                                      <p className="small mb-0 text-dark lh-base">{completedRecord.aiAnalysis || "No historical AI analysis recorded."}</p>
                                  </div>
                              </div>
                              <div className="col-md-6">
                                  <div className="p-4 bg-white border border-info shadow-sm rounded-4 h-100">
                                      <h6 className="fw-bold text-success border-bottom pb-2 mb-3 small text-uppercase">Prescription Vault</h6>
                                      <div className="mb-3">
                                          <label className="x-small fw-bold text-secondary text-uppercase mb-1">Diagnosis</label>
                                          <div className="fw-bold text-dark">{completedRecord.diagnosis}</div>
                                      </div>
                                      <div>
                                          <label className="x-small fw-bold text-secondary text-uppercase mb-1">Prescribed Plan</label>
                                          <div className="bg-light p-3 rounded small font-monospace whitespace-pre-wrap">{completedRecord.prescriptionText}</div>
                                      </div>
                                  </div>
                              </div>
                           </div>
                        </div>
                    )}
                  </div>
                ) : (
                  <div className="treatment-form">
                    <div className="bg-light p-4 rounded mb-4 border">
                      <label className="text-secondary fw-bold small text-uppercase d-block mb-2">Patient's Reported Symptoms</label>
                      <p className="mb-0 fs-5" style={{ color: '#444' }}>{selectedAppt.symptomsSummary}</p>
                    </div>

                    <div className="row g-4">
                        <div className="col-md-5">
                          <div className="card h-100 border-0 shadow-sm bg-white" style={{ borderRadius: '15px' }}>
                            <div className="card-header bg-dark text-white p-3 d-flex justify-content-between align-items-center" style={{ borderRadius: '15px 15px 0 0' }}>
                              <span className="fw-bold small">🤖 AI Clinical Intelligence</span>
                              <button className="btn btn-sm btn-outline-light border-0" onClick={handleGetInsight} disabled={loadingInsight}>
                                 {loadingInsight ? '...' : 'Refresh'}
                              </button>
                            </div>
                            <div className="card-body">
                              {!insightReport ? (
                                <div className="text-center py-5">
                                  <p className="text-muted mb-4 small">Generate a structured clinical report based on patient profile and current symptoms.</p>
                                  <button className="btn btn-primary rounded-pill px-4 fw-bold" onClick={handleGetInsight} disabled={loadingInsight}>
                                    {loadingInsight ? 'Processing...' : 'Run Clinical Analysis'}
                                  </button>
                                </div>
                              ) : (
                                <div className="animate-fade-in small">
                                  <div className="mb-4">
                                    <label className="fw-bold text-primary text-uppercase x-small d-block mb-1">Clinical Summary</label>
                                    <p className="mb-0 text-dark" style={{ lineHeight: '1.4' }}>{insightReport.clinical_summary}</p>
                                  </div>
                                  <div className="mb-4">
                                    <label className="fw-bold text-primary text-uppercase x-small d-block mb-1">Suggested DX</label>
                                    <p className="mb-0 fw-bold">{insightReport.suggested_diagnosis}</p>
                                  </div>
                                  <div className="mb-4">
                                    <label className="fw-bold text-primary text-uppercase x-small d-block mb-1">Proposed Treatment</label>
                                    <p className="mb-0">{insightReport.recommended_plan}</p>
                                  </div>
                                  <button className="btn btn-sm btn-outline-success w-100 rounded-pill mt-2 fw-bold" onClick={handleSaveToRecord} disabled={savingRecord}>
                                    {savingRecord ? 'Saving...' : '💾 Save to Record'}
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="col-md-7">
                          <div className="card h-100 border-0 shadow-sm ai-glow" style={{ borderRadius: '15px' }}>
                            <div className="card-body p-4">
                              <h5 className="mb-4 text-primary fw-bold">Treatment & Prescription</h5>
                              <div className="mb-3">
                                <label className="fw-bold small text-secondary text-uppercase mb-1">Final Diagnosis</label>
                                <input type="text" className="form-control form-control-lg border-light bg-light shadow-none" value={diagnosis} onChange={e => setDiagnosis(e.target.value)} placeholder="Enter formal diagnosis..." />
                              </div>
                              <div className="mb-3">
                                <div className="d-flex justify-content-between align-items-end mb-2">
                                    <label className="fw-bold small text-secondary text-uppercase mb-0">Treatment Plan</label>
                                    <button className="btn btn-text text-info p-0 small fw-bold" onClick={handleGeneratePrescription} disabled={loadingPrescription}>
                                      {loadingPrescription ? '✨ Thinking...' : '✨ Auto-Fill Text'}
                                    </button>
                                </div>
                                <textarea className="form-control border-light bg-light shadow-none" rows="8" value={prescriptionText} onChange={e => setPrescriptionText(e.target.value)} placeholder="Specify medications, dosage, and duration..."></textarea>
                              </div>
                              <div className="text-end mt-4">
                                <button className="btn btn-success btn-lg px-5 py-3 rounded-pill fw-bold shadow-sm" onClick={handleComplete} disabled={!isVerified}>
                                  {isVerified ? '✅ Finalize & Save' : '🔒 Verification Required'}
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="glass-card text-center py-5 opacity-50 border-0 shadow-sm" style={{ borderRadius: '20px' }}>
                <div className="fs-1 mb-3">👨‍⚕️</div>
                <h5 className="text-muted fw-bold">Welcome, Doctor</h5>
                <p className="text-secondary">Please select an appointment from the schedule to begin or review a consultation.</p>
              </div>
            )}
          </>
        )}
      </div>
      <style>{`
        @media print {
          .no-print { display: none !important; }
          .print-only { display: block !important; }
          .card { border: none !important; box-shadow: none !important; }
          .glass-card { box-shadow: none !important; border: 1px solid #eee !important; }
          body { background: white !important; }
        }
      `}</style>
    </div>
  );
};

export default DoctorDashboard;
