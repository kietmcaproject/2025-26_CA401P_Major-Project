import React from 'react';

const TriageReport = ({ report }) => {
  if (!report) return null;

  return (
    <div className="card shadow-sm border-0 mb-4 animate-fade-in" style={{ borderRadius: '15px', overflow: 'hidden' }}>
      <div className="card-header bg-primary bg-gradient text-white py-3">
        <h5 className="mb-0 fw-bold">🩺 AI Triage Report</h5>
      </div>
      <div className="card-body bg-light">
        <div className="mb-4">
          <label className="text-primary fw-bold small text-uppercase mb-2 d-block">Clinical Summary</label>
          <p className="card-text text-dark fs-6" style={{ lineHeight: '1.6' }}>{report.summary}</p>
        </div>

        <div className="row">
          <div className="col-md-6 mb-4">
            <label className="text-primary fw-bold small text-uppercase mb-2 d-block">Possible Causes</label>
            <ul className="list-group list-group-flush rounded border-0">
              {report.possible_causes?.map((cause, idx) => (
                <li key={idx} className="list-group-item bg-white py-2 px-3 border-start border-4 border-info mb-1 rounded shadow-sm">
                  {cause}
                </li>
              ))}
            </ul>
          </div>

          <div className="col-md-6 mb-4">
            <label className="text-primary fw-bold small text-uppercase mb-2 d-block">Immediate Actions</label>
            <ul className="list-group list-group-flush rounded border-0">
              {report.immediate_actions?.map((action, idx) => (
                <li key={idx} className="list-group-item bg-white py-2 px-3 border-start border-4 border-warning mb-1 rounded shadow-sm">
                  {action}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="alert alert-info border-0 shadow-sm d-flex align-items-center mb-0">
          <div className="fs-3 me-3">🏢</div>
          <div>
            <label className="fw-bold small text-uppercase d-block mb-1">Target Specialty</label>
            <span className="fs-5 fw-bold text-dark">{report.target_specialty}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TriageReport;
