import React, { useState, useEffect } from 'react';
import ApiService from '../services/api';

const SPECIALIZATION_OPTIONS = [
  'Internal Medicine', 'Cardiology', 'Dermatology', 'Pediatrics',
  'Orthopedics', 'Neurology', 'Dentistry', 'General Practice'
];

const DoctorProfilePage = ({ onVerified }) => {
  const [profile, setProfile] = useState({
    phoneNumber: '', medicalDegree: '', universityName: '',
    graduationYear: '', yearsOfExperience: '', hospitalAffiliation: '',
    detailedExpertise: '', consultationFee: '', specialization: ''
  });
  const [status, setStatus] = useState(null);
  const [category, setCategory] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const resp = await ApiService.getDoctorMyProfile();
      if (resp.data) {
        setProfile(prev => ({...prev, ...resp.data}));
        setStatus(resp.data.isVerified);
        setCategory(resp.data.specializationCategory);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      const resp = await ApiService.updateDoctorProfile(profile);
      setProfile(prev => ({...prev, ...resp.data}));
      setStatus(resp.data.isVerified);
      setCategory(resp.data.specializationCategory);
      if (resp.data.isVerified) {
        setMessage("✅ Profile verified by AI! You are now visible to patients.");
        if (onVerified) onVerified();
      } else {
        setMessage("⚠️ Profile saved but pending verification. Please ensure your Degree is filled in.");
      }
    } catch (e) {
      console.error(e);
      setMessage("❌ Failed to update profile. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="glass-card mb-4 animate-fade-in shadow-sm">
      <div className="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2">
        <h3 className="medical-header m-0">Professional Profile</h3>
        <div>
          {status === null
            ? <span className="badge bg-secondary p-2">No Status</span>
            : status === true
              ? <span className="badge bg-success p-2">✓ AI Verified</span>
              : <span className="badge bg-warning text-dark p-2">Pending Verification</span>}
        </div>
      </div>

      {category && (
        <div className={`alert ${status ? 'alert-success' : 'alert-warning'} py-2`}>
          <strong>AI Assigned Category:</strong> {category}
        </div>
      )}

      {message && (
        <div className={`alert ${message.includes('❌') ? 'alert-danger' : message.includes('⚠️') ? 'alert-warning' : 'alert-success'} py-2 small fw-bold`}>
          {message}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        {/* Row 1: Degree, Specialization, University */}
        <div className="row mb-3">
          <div className="col-md-4">
            <label className="form-label text-muted fw-bold">Medical Degree <span className="text-danger">*</span></label>
            <select name="medicalDegree" className="form-select" value={profile.medicalDegree || ''} onChange={handleChange} required>
              <option value="">-- Select Degree --</option>
              <option value="MBBS">MBBS</option>
              <option value="MD">MD</option>
              <option value="DO">DO</option>
              <option value="PhD">PhD</option>
              <option value="BDS">BDS</option>
              <option value="Nursing">Nursing Degree (BSN/MSN)</option>
            </select>
          </div>
          <div className="col-md-4">
            <label className="form-label text-muted fw-bold">Specialization <span className="text-danger">*</span></label>
            <select name="specialization" className="form-select" value={profile.specialization || ''} onChange={handleChange} required>
              <option value="">-- Select Category --</option>
              {SPECIALIZATION_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="col-md-4">
            <label className="form-label text-muted fw-bold">University Name <span className="text-danger">*</span></label>
            <input type="text" name="universityName" className="form-control" value={profile.universityName || ''} onChange={handleChange} required />
          </div>
        </div>

        {/* Row 2: Year, Exp, Fee */}
        <div className="row mb-3">
          <div className="col-md-4">
            <label className="form-label text-muted fw-bold">Graduation Year <span className="text-danger">*</span></label>
            <input type="number" name="graduationYear" className="form-control" value={profile.graduationYear || ''} onChange={handleChange} required />
          </div>
          <div className="col-md-4">
            <label className="form-label text-muted fw-bold">Years of Experience <span className="text-danger">*</span></label>
            <input type="number" name="yearsOfExperience" className="form-control" value={profile.yearsOfExperience || ''} onChange={handleChange} required />
          </div>
          <div className="col-md-4">
            <label className="form-label text-muted fw-bold">Consultation Fee (₹) <span className="text-danger">*</span></label>
            <input type="number" step="0.01" name="consultationFee" className="form-control" value={profile.consultationFee || ''} onChange={handleChange} required />
          </div>
        </div>

        <div className="mb-3">
          <label className="form-label text-muted fw-bold">Hospital Affiliation</label>
          <input type="text" name="hospitalAffiliation" className="form-control" value={profile.hospitalAffiliation || ''} onChange={handleChange} />
        </div>

        <div className="mb-4">
          <label className="form-label text-muted fw-bold">Detailed Expertise <span className="text-muted small fw-normal">(Optional — AI will use your Specialization if left blank)</span></label>
          <textarea
            name="detailedExpertise"
            className="form-control"
            rows="4"
            placeholder="Describe your clinical focus, procedures, or research areas..."
            value={profile.detailedExpertise || ''}
            onChange={handleChange}
          />
        </div>

        <button type="submit" className="btn btn-medical w-100 py-2 fs-5" disabled={loading}>
          {loading ? "Submitting for AI Verification..." : "Save & Verify Profile"}
        </button>
      </form>
    </div>
  );
};

export default DoctorProfilePage;
