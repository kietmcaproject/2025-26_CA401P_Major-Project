import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthService from '../services/auth';

const Login = ({ setCurrentUser }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setMessage("");
    setLoading(true);

    try {
      const response = await AuthService.login(email, password);
      setCurrentUser(response);
      if(response.role === "ROLE_DOCTOR") {
          navigate("/doctor");
      } else {
          navigate("/patient");
      }
    } catch (error) {
      const resMessage = error.response?.data?.message || error.message || error.toString();
      setMessage(resMessage);
      setLoading(false);
    }
  };

  return (
    <div className="row justify-content-center mt-5">
      <div className="col-md-5">
        <div className="glass-card">
          <h3 className="medical-header text-center">Platform Login</h3>
          <form onSubmit={handleLogin}>
            <div className="mb-3">
              <label className="form-label text-muted fw-bold small">Email address</label>
              <input
                type="email"
                className="form-control"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="mb-4">
              <label className="form-label text-muted fw-bold small">Password</label>
              <input
                type="password"
                className="form-control"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <div className="d-grid gap-2">
              <button className="btn btn-medical" type="submit" disabled={loading}>
                {loading && <span className="spinner-border spinner-border-sm me-2"></span>}
                Sign In
              </button>
            </div>
            {message && (
              <div className="alert alert-danger mt-3" role="alert">
                {message}
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
