import React, { useState } from 'react';
import ApiService from '../services/api';

const BookingModal = ({ show, onHide, doctor, onSuccess }) => {
  const [bookingData, setBookingData] = useState({
    appointmentDate: '',
    timeSlot: '09:00:00'
  });
  const [loading, setLoading] = useState(false);

  if (!show || !doctor) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await ApiService.bookAppointment({
        doctorId: doctor.id,
        appointmentDate: bookingData.appointmentDate,
        timeSlot: bookingData.timeSlot,
        symptomsSummary: `Direct booking with Dr. ${doctor.user?.name}`
      });
      onSuccess(`Appointment with Dr. ${doctor.user?.name} confirmed!`);
      onHide();
    } catch (err) {
      console.error(err);
      alert("Failed to book appointment. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal show d-block animate-fade-in" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content border-0 shadow-lg" style={{ borderRadius: '20px' }}>
          <div className="modal-header border-0 pb-0">
            <h5 className="modal-title fw-bold text-primary">Book Appointment</h5>
            <button type="button" className="btn-close" onClick={onHide}></button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="modal-body py-4">
              <div className="d-flex align-items-center mb-4 p-3 bg-light rounded-3">
                <img 
                  src={`https://ui-avatars.com/api/?name=${encodeURIComponent(doctor.user?.name || '')}&background=0D6EFD&color=fff`} 
                  alt="" className="rounded-circle me-3" width="48" height="48" 
                />
                <div>
                  <div className="fw-bold fs-5">Dr. {doctor.user?.name}</div>
                  <div className="text-muted small">{doctor.specializationCategory || doctor.specialization}</div>
                </div>
              </div>

              <div className="mb-3">
                <label className="form-label text-secondary fw-bold small text-uppercase">Preferred Date</label>
                <input 
                  type="date" 
                  className="form-control form-control-lg border-0 bg-light shadow-none" 
                  required
                  min={new Date().toISOString().split('T')[0]}
                  value={bookingData.appointmentDate}
                  onChange={e => setBookingData({...bookingData, appointmentDate: e.target.value})}
                  style={{ borderRadius: '12px' }}
                />
              </div>

              <div className="mb-3">
                <label className="form-label text-secondary fw-bold small text-uppercase">Time Slot</label>
                <select 
                  className="form-select form-select-lg border-0 bg-light shadow-none"
                  required
                  value={bookingData.timeSlot}
                  onChange={e => setBookingData({...bookingData, timeSlot: e.target.value})}
                  style={{ borderRadius: '12px' }}
                >
                  <option value="09:00:00">09:00 AM</option>
                  <option value="10:00:00">10:00 AM</option>
                  <option value="11:00:00">11:00 AM</option>
                  <option value="12:00:00">12:00 PM</option>
                  <option value="14:00:00">02:00 PM</option>
                  <option value="15:00:00">03:00 PM</option>
                  <option value="16:00:00">04:00 PM</option>
                  <option value="17:00:00">05:00 PM</option>
                </select>
              </div>

              <div className="text-center mt-3 small text-muted">
                Consultation Fee: <span className="fw-bold text-dark">₹{doctor.consultationFee}</span>
              </div>
            </div>
            <div className="modal-footer border-0 pt-0 pb-4 justify-content-center">
              <button 
                type="submit" 
                className="btn btn-medical px-5 py-3 rounded-pill fw-bold shadow-sm"
                disabled={loading}
              >
                {loading ? 'Confirming...' : 'Confirm Booking'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default BookingModal;
