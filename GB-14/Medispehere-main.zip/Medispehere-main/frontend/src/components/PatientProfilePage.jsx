import React, { useState, useEffect } from 'react';
import ApiService from '../services/api';

const PatientProfilePage = () => {
  const [profile, setProfile] = useState({
    dob: '', biologicalSex: '', bloodGroup: '',
    systolicBp: '', diastolicBp: '', fastingSugar: '', postPrandialSugar: '',
    weightKg: '', heightCm: '',
    allergies: '', chronicConditions: '', currentMedications: ''
  });
  const [age, setAge] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const resp = await ApiService.getMyProfile();
        if (resp.data) {
          setProfile(prev => ({...prev, ...resp.data}));
          if (resp.data.dob) calculateAge(resp.data.dob);
        }
      } catch (e) { console.error(e); }
    };
    fetchProfile();
  }, []);

  const calculateAge = (dobString) => {
      if (!dobString) { setAge(null); return; }
      const diffStr = Date.now() - new Date(dobString).getTime();
      const ageDt = new Date(diffStr);
      setAge(Math.abs(ageDt.getUTCFullYear() - 1970));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
    if (name === 'dob') calculateAge(value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    // Setup payload cleanly so empty strings become null for numbers to prevent Spring 400 Bad Request
    const payload = { ...profile };
    ['systolicBp', 'diastolicBp', 'fastingSugar', 'postPrandialSugar', 'heightCm', 'weightKg'].forEach(key => {
        if (payload[key] === '') payload[key] = null;
    });

    try {
      await ApiService.updateMyProfile(payload);
      setMessage("Profile saved successfully.");
    } catch (e) {
      console.error(e);
      setMessage("Failed to save profile.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="row justify-content-center">
      <div className="col-lg-10">
        <div className="glass-card mb-4 animate-fade-in">
          <h3 className="medical-header">My Health Profile</h3>
          {message && <div className="alert alert-success">{message}</div>}
          
          <form onSubmit={handleSubmit}>
            <h5 className="text-primary mt-4 border-bottom pb-2">1. General Information</h5>
            <div className="row mb-3">
              <div className="col-md-4">
                <label className="form-label text-muted fw-bold">Date of Birth <span className="text-danger">*</span></label>
                <input type="date" name="dob" className="form-control" value={profile.dob || ''} onChange={handleChange} required />
                {age !== null && <small className="text-success fw-bold">Calculated Age: {age} yrs</small>}
              </div>
              <div className="col-md-4">
                <label className="form-label text-muted fw-bold">Biological Sex <span className="text-danger">*</span></label>
                <select name="biologicalSex" className="form-select" value={profile.biologicalSex || ''} onChange={handleChange} required>
                  <option value="">-- Select --</option>
                  <option value="MALE">Male</option>
                  <option value="FEMALE">Female</option>
                  <option value="OTHER">Other</option>
                </select>
              </div>
              <div className="col-md-4">
                <label className="form-label text-muted fw-bold">Blood Group</label>
                <input type="text" name="bloodGroup" className="form-control" placeholder="e.g. O+" value={profile.bloodGroup || ''} onChange={handleChange} />
              </div>
            </div>

            <div className="row mb-3">
              <div className="col-md-6">
                <label className="form-label text-muted fw-bold">Height (cm)</label>
                <input type="number" step="0.1" name="heightCm" className="form-control" value={profile.heightCm || ''} onChange={handleChange} />
              </div>
              <div className="col-md-6">
                <label className="form-label text-muted fw-bold">Weight (kg)</label>
                <input type="number" step="0.1" name="weightKg" className="form-control" value={profile.weightKg || ''} onChange={handleChange} />
              </div>
            </div>

            <h5 className="text-primary mt-5 border-bottom pb-2">2. Vitals Snapshot</h5>
            <div className="row mb-3">
              <div className="col-md-3">
                <label className="form-label text-muted fw-bold">Systolic BP</label>
                <input type="number" name="systolicBp" className="form-control" placeholder="e.g. 120" value={profile.systolicBp || ''} onChange={handleChange} />
              </div>
              <div className="col-md-3">
                <label className="form-label text-muted fw-bold">Diastolic BP</label>
                <input type="number" name="diastolicBp" className="form-control" placeholder="e.g. 80" value={profile.diastolicBp || ''} onChange={handleChange} />
              </div>
              <div className="col-md-3">
                <label className="form-label text-muted fw-bold">Fasting Sugar (mg/dL)</label>
                <input type="number" name="fastingSugar" className="form-control" placeholder="e.g. 95" value={profile.fastingSugar || ''} onChange={handleChange} />
              </div>
              <div className="col-md-3">
                <label className="form-label text-muted fw-bold">Post-Prandial Sugar</label>
                <input type="number" name="postPrandialSugar" className="form-control" placeholder="e.g. 140" value={profile.postPrandialSugar || ''} onChange={handleChange} />
              </div>
            </div>

            <h5 className="text-primary mt-5 border-bottom pb-2">3. Medical History</h5>
            <div className="mb-3">
              <label className="form-label text-muted fw-bold">Allergies</label>
              <textarea name="allergies" className="form-control" rows="2" placeholder="List any known allergies" value={profile.allergies || ''} onChange={handleChange}></textarea>
            </div>
            <div className="mb-3">
              <label className="form-label text-muted fw-bold">Chronic Conditions</label>
              <textarea name="chronicConditions" className="form-control" rows="2" placeholder="e.g., Asthma, Hypertension" value={profile.chronicConditions || ''} onChange={handleChange}></textarea>
            </div>
            <div className="mb-4">
              <label className="form-label text-muted fw-bold">Current Medications</label>
              <textarea name="currentMedications" className="form-control" rows="2" placeholder="List current medications and dosages" value={profile.currentMedications || ''} onChange={handleChange}></textarea>
            </div>

            <button type="submit" className="btn btn-medical w-100 py-2 fs-5" disabled={loading}>
              {loading ? "Saving..." : "Save My Health Profile"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PatientProfilePage;
