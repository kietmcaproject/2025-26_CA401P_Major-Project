import type { NextConfig } from "next";

// Always use standalone in Docker (Linux). For local Windows dev the standalone
// output is skipped because Next.js uses symlinks which Windows may block.
const isWindows = process.platform === "win32";

const nextConfig: NextConfig = {
  output: isWindows ? undefined : "standalone",
  turbopack: {
    root: __dirname,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'api.dicebear.com',
      },
      {
        protocol: 'https',
        hostname: 'upload.wikimedia.org',
      },
    ],
  },
};

export default nextConfig;
