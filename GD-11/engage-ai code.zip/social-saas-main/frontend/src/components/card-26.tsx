import React from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { cn } from '@/lib/utils';

// Props interface - use only the custom props, motion.a will handle the rest
interface LinkCardProps {
  title: string;
  description: string;
  imageUrl: string | any;
  href: string;
  icon?: React.ElementType;
  color?: string;
  className?: string;
}

const LinkCard = React.forwardRef<HTMLAnchorElement, LinkCardProps>(
  ({ className, title, description, imageUrl, href, icon: Icon, color }, ref) => {
    // Animation variants for framer-motion
    const cardVariants = {
      initial: { scale: 1, y: 0 },
      hover: {
        scale: 1.03,
        y: -5,
        transition: {
          type: 'spring' as const,
          stiffness: 300,
          damping: 15,
        },
      },
    };

    const imgSrc = typeof imageUrl === 'string' ? imageUrl : (imageUrl as any).src;

    return (
      <Link
        ref={ref}
        href={href}
        className={cn(
          'group relative flex h-full min-h-[300px] w-full flex-col justify-between overflow-hidden',
          'rounded-2xl border border-slate-200 bg-white p-6 shadow-sm',
          'hover:border-[#F6571F]/30 hover:shadow-2xl hover:shadow-[#F6571F]/10 transition-all duration-500',
          className
        )}
        aria-label={`Link to ${title}`}
      >
        <motion.div variants={cardVariants} initial="initial" whileHover="hover" className="contents">
          {/* Text content */}
          <div className="z-10 relative">
            {Icon && (
              <div className={`w-10 h-10 rounded-lg mb-4 ${color ? color : 'bg-slate-100'} flex items-center justify-center`}>
                <Icon className="w-5 h-5 text-slate-700" />
              </div>
            )}
            <h3 className="mb-2 text-xl font-black tracking-tight text-slate-900 group-hover:text-[#F6571F] transition-colors">
              {title}
            </h3>
            <p className="max-w-[90%] text-sm font-medium text-slate-500 leading-relaxed">
              {description}
            </p>
          </div>

          {/* Image container with a subtle scale effect on hover */}
          <div className="absolute bottom-0 right-0 h-60 mr-16 mb-8 w-60 transform translate-x-8 translate-y-8">
            <motion.img
              src={imgSrc}
              alt={`${title} illustration`}
              className="h-full w-full object-contain opacity-90 group-hover:opacity-100 transition-all duration-300 ease-out group-hover:scale-110"
            />
          </div>
        </motion.div>
      </Link>
    );
  }
);

LinkCard.displayName = 'LinkCard';

export { LinkCard };
