"use client";

import { useCreateRole, useGetAvailablePermissions } from "@/lib/queries/roles";
import { useState } from "react";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Plus, Loader2 } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";

export function CreateRoleDialog() {
    const [open, setOpen] = useState(false);
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");
    const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);

    const { mutate: createRole, isPending } = useCreateRole();
    const { data: permissionsData, isLoading: isLoadingPermissions } = useGetAvailablePermissions();

    const permissions = permissionsData?.permissions || [];
    const metadata = permissionsData?.metadata || {};

    // Group permissions by group
    const groupedPermissions: Record<string, string[]> = {};
    permissions.forEach(p => {
        const group = metadata[p]?.group || "Other";
        if (!groupedPermissions[group]) groupedPermissions[group] = [];
        groupedPermissions[group].push(p);
    });

    const togglePermission = (perm: string) => {
        setSelectedPermissions(prev =>
            prev.includes(perm) ? prev.filter(p => p !== perm) : [...prev, perm]
        );
    };

    const handleGroupToggle = (group: string, perms: string[]) => {
        const allSelected = perms.every(p => selectedPermissions.includes(p));
        if (allSelected) {
            setSelectedPermissions(prev => prev.filter(p => !perms.includes(p)));
        } else {
            setSelectedPermissions(prev => [...new Set([...prev, ...perms])]);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        createRole(
            { name, description, permissions: selectedPermissions },
            {
                onSuccess: () => {
                    setOpen(false);
                    setName("");
                    setDescription("");
                    setSelectedPermissions([]);
                },
            }
        );
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button size="sm" className="gap-2">
                    <Plus className="h-4 w-4" />
                    Create Role
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px] max-h-[80vh] flex flex-col">
                <DialogHeader>
                    <DialogTitle>Create Role</DialogTitle>
                    <DialogDescription>
                        Create a new custom role with specific permissions.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="flex-1 flex flex-col min-h-0 space-y-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="name">Role Name</Label>
                            <Input
                                id="name"
                                placeholder="e.g. Support Agent"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                required
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="description">Description</Label>
                            <Input
                                id="description"
                                placeholder="Brief description..."
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                            />
                        </div>
                    </div>

                    <div className="space-y-2 flex-1 flex flex-col min-h-0">
                        <div className="flex items-center justify-between">
                            <Label>Permissions</Label>
                            <Badge variant="outline">{selectedPermissions.length} selected</Badge>
                        </div>

                        {isLoadingPermissions ? (
                            <div className="h-40 flex items-center justify-center">
                                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                            </div>
                        ) : (
                            <ScrollArea className="flex-1 border rounded-md p-4">
                                <div className="space-y-6">
                                    {Object.entries(groupedPermissions).map(([group, perms]) => (
                                        <div key={group} className="space-y-3">
                                            <div className="flex items-center justify-between bg-muted/50 p-2 rounded-sm">
                                                <Label className="font-semibold text-sm">{group}</Label>
                                                <Button
                                                    type="button"
                                                    variant="ghost"

                                                    className="h-6 text-xs"
                                                    onClick={() => handleGroupToggle(group, perms)}
                                                >
                                                    {perms.every(p => selectedPermissions.includes(p)) ? "Deselect All" : "Select All"}
                                                </Button>
                                            </div>
                                            <div className="grid grid-cols-2 gap-2 pl-2">
                                                {perms.map(perm => (
                                                    <div key={perm} className="flex items-start space-x-2">
                                                        <Checkbox
                                                            id={perm}
                                                            checked={selectedPermissions.includes(perm)}
                                                            onCheckedChange={() => togglePermission(perm)}
                                                        />
                                                        <div className="grid gap-1.5 leading-none">
                                                            <label
                                                                htmlFor={perm}
                                                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                                                            >
                                                                {metadata[perm]?.label || perm}
                                                            </label>
                                                            <p className="text-[10px] text-muted-foreground">{perm}</p>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </ScrollArea>
                        )}
                    </div>

                    <DialogFooter className="pt-2">
                        <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                            Cancel
                        </Button>
                        <Button type="submit" disabled={isPending}>
                            {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Create Role
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
