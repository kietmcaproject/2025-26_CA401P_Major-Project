"use client";

import * as React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useCreateOrganisation, useCheckSlug } from "@/lib/queries/organisations";
import { useOrgStore } from "@/hooks/use-org-store";
import { Loader2, Plus } from "lucide-react";
import { useDebounce } from "@/hooks/use-debounce";
import { useAuthSession } from "@/hooks/use-auth-session";

const formSchema = z.object({
    name: z.string().min(2, {
        message: "Name must be at least 2 characters.",
    }),
    slug: z.string().min(2, {
        message: "Slug must be at least 2 characters.",
    }).regex(/^[a-z0-9-]+$/, {
        message: "Slug must be lowercase, alphanumeric, and can contain hyphens.",
    }),
    logo: z.string().url().optional().or(z.literal("")),
});

interface CreateOrgDialogProps {
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    children?: React.ReactNode;
}

export function CreateOrgDialog({ open, onOpenChange, children }: CreateOrgDialogProps) {
    const [internalOpen, setInternalOpen] = React.useState(false);
    const isControlled = open !== undefined;
    const finalOpen = isControlled ? open : internalOpen;
    const finalOnOpenChange = isControlled ? onOpenChange : setInternalOpen;

    const createOrg = useCreateOrganisation();
    const setActiveOrganisation = useOrgStore((state) => state.setActiveOrganisation);
    const { user } = useAuthSession();

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            name: "",
            slug: "",
            logo: "",
        },
    });

    const slugValue = form.watch("slug");

    // Manual debounce since I don't want to assume useDebounce exists for sure yet
    // Actually, I'll just check slug on submit or let the user type. 
    // Real-time check is better but let's stick to simple first for robustness.

    async function onSubmit(values: z.infer<typeof formSchema>) {
        /*
        try {
            const result = await createOrg.mutateAsync({
                ...values,
                userName: user?.name,
                userEmail: user?.email
            });
            if (result.success && result.data.organisation) {
                const newOrg = {
                    ...result.data.organisation,
                    role: result.data.member, // Map member details to role structure expected by store
                    isOwner: true,
                    memberId: result.data.member._id
                };
                // Fix role structure mapping if needed. 
                // The API returns { organisation: {...}, member: { roleId: "...", isOwner: true } }
                // My Store expects Organisation interface which has specific role object. 
                // I might need to refresh list to get full object or hack it here. 
                // Creating org returns minimal data. Best to rely on invalidation and switching.

                finalOnOpenChange?.(false);
                form.reset();
            }
        } catch (error) {
            console.error("Failed to create org", error);
        }
        */
        console.log("Org creation disabled");
    }

    return (
        <Dialog open={finalOpen} onOpenChange={finalOnOpenChange}>
            <DialogTrigger asChild>
                {children}
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Create Organization</DialogTitle>
                    <DialogDescription>
                        Add a new organization to manage your projects and team.
                    </DialogDescription>
                </DialogHeader>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Organization Name</FormLabel>
                                    <FormControl>
                                        <Input placeholder="Acme Inc." {...field} onChange={(e) => {
                                            field.onChange(e);
                                            // Auto-generate slug from name if slug is untouched
                                            if (!form.formState.dirtyFields.slug) {
                                                const generated = e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
                                                form.setValue("slug", generated);
                                            }
                                        }} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="slug"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Slug</FormLabel>
                                    <FormControl>
                                        <Input placeholder="acme-inc" {...field} />
                                    </FormControl>
                                    <FormDescription>
                                        This will be your unique URL identifier.
                                    </FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <DialogFooter>
                            <Button type="submit" disabled={createOrg.isPending}>
                                {createOrg.isPending && (
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                )}
                                Create Organization
                            </Button>
                        </DialogFooter>
                    </form>
                </Form>
            </DialogContent>
        </Dialog>
    );
}
