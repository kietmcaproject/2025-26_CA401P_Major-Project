"use client";

import { useListMembers, useRemoveMember, useGetMyMembership } from "@/lib/queries/members";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MoreHorizontal, UserX, Shield } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useState } from "react";

export function MembersList() {
    const { data: members, isLoading } = useListMembers();
    const { data: myMembership } = useGetMyMembership();

    const { mutate: removeMember } = useRemoveMember();

    const [memberToRemove, setMemberToRemove] = useState<string | null>(null);

    if (isLoading) {
        return (
            <div className="flex justify-center p-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
        );
    }

    // Permission: member:remove
    const canRemove = myMembership?.isOwner || myMembership?.permissions?.includes("member:remove");

    const handleRemove = () => {
        if (memberToRemove) {
            removeMember({ memberId: memberToRemove });
            setMemberToRemove(null);
        }
    }

    return (
        <>
            <div className="rounded-md border">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>User</TableHead>
                            <TableHead>Role</TableHead>
                            <TableHead>Created At</TableHead>
                            <TableHead className="w-[80px]"></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {members?.map((member) => (
                            <TableRow key={member._id}>
                                <TableCell className="flex items-center gap-3">
                                    <Avatar className="h-9 w-9">
                                        <AvatarImage src={`https://ui-avatars.com/api/?name=${encodeURIComponent(member.metadata?.name || "U")}&background=random`} alt={member.metadata?.name} />
                                        <AvatarFallback>{member.metadata?.name?.charAt(0) || "U"}</AvatarFallback>
                                    </Avatar>
                                    <div className="flex flex-col">
                                        <span className="font-medium text-sm">{member.metadata?.name || "Unknown"}</span>
                                        <span className="text-xs text-muted-foreground">{member.metadata?.email}</span>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <div className="flex flex-col gap-1">
                                        <div className="flex items-center gap-2">
                                            <Badge variant="outline" className="capitalize">
                                                {member.role?.name || "Member"}
                                            </Badge>
                                            {member.isOwner && (
                                                <Badge variant="default" className="text-[10px] h-5 px-1 bg-amber-500 hover:bg-amber-600">Owner</Badge>
                                            )}
                                        </div>
                                        {member.extraPermissions?.length > 0 && (
                                            <div className="flex flex-wrap gap-1">
                                                {member.extraPermissions.map(p => (
                                                    <Badge key={p} variant="secondary" className="text-[10px] px-1 h-4">{p}</Badge>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </TableCell>
                                <TableCell className="text-muted-foreground text-sm">
                                    {member.createdAt ? format(new Date(member.createdAt), "PP") : "-"}
                                </TableCell>
                                <TableCell>
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                            <Button variant="ghost" className="h-8 w-8 p-0">
                                                <span className="sr-only">Open menu</span>
                                                <MoreHorizontal className="h-4 w-4" />
                                            </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent align="end">
                                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                            <DropdownMenuItem onClick={() => navigator.clipboard.writeText(member.userId)}>
                                                Copy User ID
                                            </DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => navigator.clipboard.writeText(member.role?._id || "")}>
                                                Copy Role ID
                                            </DropdownMenuItem>
                                            <DropdownMenuSeparator />
                                            {canRemove && !member.isOwner && (
                                                <DropdownMenuItem
                                                    className="text-red-600 focus:text-red-600"
                                                    onClick={() => setMemberToRemove(member._id)}
                                                >
                                                    <UserX className="mr-2 h-4 w-4" />
                                                    Remove Member
                                                </DropdownMenuItem>
                                            )}
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </TableCell>
                            </TableRow>
                        ))}
                        {!members?.length && (
                            <TableRow>
                                <TableCell colSpan={4} className="h-24 text-center">
                                    No members found.
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            <AlertDialog open={!!memberToRemove} onOpenChange={(open) => !open && setMemberToRemove(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This will remove the user from the organisation. They will lose access immediately.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleRemove} className="bg-red-600 hover:bg-red-700">
                            Remove
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
}
