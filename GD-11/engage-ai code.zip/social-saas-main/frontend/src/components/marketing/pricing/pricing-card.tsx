import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"
import { cn } from "@/lib/utils"

interface PricingCardProps {
    title: string
    description: string
    price: string
    features: string[]
    isPopular?: boolean
    buttonText?: string
    billingPeriod?: string
    className?: string
}

export function PricingCard({
    title,
    description,
    price,
    features,
    isPopular = false,
    buttonText = "Start free trial",
    billingPeriod = "/month",
    className,
}: PricingCardProps) {
    return (
        <Card
            className={cn(
                "relative flex flex-col h-full border-2 transition-all duration-200 hover:shadow-lg",
                isPopular ? "border-primary shadow-md scale-105 z-10" : "border-border",
                isPopular && "bg-[#0B0E14] text-white", // Dark theme for popular card matching functionality
                className
            )}
        >
            {isPopular && (
                <div className="absolute -top-4 left-0 right-0 flex justify-center">
                    <span className="bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">
                        Most Popular
                    </span>
                </div>
            )}

            <CardHeader>
                <CardTitle className={cn("text-xl font-bold", isPopular ? "text-white" : "text-foreground")}>
                    {title}
                </CardTitle>
                <CardDescription className={cn(isPopular ? "text-gray-400" : "text-muted-foreground")}>
                    {description}
                </CardDescription>
            </CardHeader>

            <CardContent className="flex-1">
                <div className="mb-6">
                    <span className={cn("text-4xl font-extrabold", isPopular ? "text-white" : "text-foreground")}>{price}</span>
                    {price !== "Custom" && (
                        <span className={cn("text-sm ml-1", isPopular ? "text-gray-400" : "text-muted-foreground")}>
                            {billingPeriod}
                        </span>
                    )}
                    {price !== "Custom" && (
                        <div className={cn("text-xs mt-1", isPopular ? "text-gray-400" : "text-muted-foreground")}>
                            billed annually
                        </div>
                    )}
                </div>

                <Button
                    className={cn(
                        "w-full mb-6 font-semibold",
                        isPopular
                            ? "bg-primary text-white hover:bg-primary/90 hover:scale-105 transition-transform"
                            : "bg-white text-black border-2 border-slate-200 hover:bg-slate-50 hover:border-slate-300"
                    )}
                    variant={isPopular ? "default" : "outline"}
                >
                    {buttonText}
                </Button>

                <ul className="space-y-3">
                    {features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-3 text-sm">
                            <Check className={cn("h-4 w-4 mt-0.5 shrink-0", isPopular ? "text-green-500" : "text-green-600")} />
                            <span className={isPopular ? "text-gray-300" : "text-muted-foreground"}>{feature}</span>
                        </li>
                    ))}
                </ul>
            </CardContent>
        </Card>
    )
}
