"use client";

import React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import {
    Facebook,
    Twitter,
    Linkedin,
    Instagram,
    Youtube,
    ArrowRight,
} from "lucide-react";
import { motion } from "framer-motion";

const floatingElements = [
    { type: 'avatar', src: 'https://i.pravatar.cc/150?u=1', size: 60, top: '20%', left: '10%' },
    { type: 'avatar', src: 'https://i.pravatar.cc/150?u=2', size: 50, top: '60%', left: '15%' },
    { type: 'avatar', src: 'https://i.pravatar.cc/150?u=3', size: 70, top: '40%', left: '5%' },
    { type: 'avatar', src: 'https://i.pravatar.cc/150?u=4', size: 65, top: '30%', right: '12%' },
    { type: 'avatar', src: 'https://i.pravatar.cc/150?u=5', size: 80, top: '55%', right: '8%' },
    { type: 'avatar', src: 'https://i.pravatar.cc/150?u=6', size: 55, top: '15%', right: '20%' },
    { type: 'emoji', content: '👍', size: 30, top: '15%', left: '25%' },
    { type: 'emoji', content: '😊', size: 35, top: '75%', left: '8%' },
    { type: 'emoji', content: '😍', size: 40, top: '70%', right: '22%' },
    { type: 'emoji', content: '🙄', size: 35, top: '10%', right: '25%' },
];

const footerLinks = {
    product: {
        title: "Product",
        links: [
            { label: "Features", href: "/features" },
            { label: "Publishing & Scheduling", href: "/features/scheduling" },
            { label: "Analytics & Reports", href: "/features/analytics" },
            { label: "Social Inbox", href: "/features/inbox" },
            { label: "Social Listening", href: "/features/listening" },
            { label: "Collaboration", href: "/features/collaboration" },
            { label: "Ads Management", href: "/features/ads" },
            { label: "Content Library", href: "/features/content-library" },
            { label: "Pricing", href: "/pricing" },
        ],
    },
    solutions: {
        title: "Solutions",
        links: [
            { label: "For Agencies", href: "/solutions/agencies" },
            { label: "For Enterprise", href: "/solutions/enterprise" },
            { label: "For Creators", href: "/solutions/creators" },
        ],
    },
    resources: {
        title: "Resources",
        links: [
            { label: "Blog", href: "/resources/blog" },
            { label: "Help Center", href: "/resources/help" },
            { label: "Case Studies", href: "#" },
            { label: "Community", href: "#" },
        ],
    },
    company: {
        title: "Company",
        links: [
            { label: "About", href: "/about" },
            { label: "Careers", href: "/careers" },
            { label: "Contact", href: "/contact" },
            { label: "Press", href: "/press" },
        ],
    },
    legal: {
        title: "Legal",
        links: [
            { label: "Privacy Policy", href: "/privacy" },
            { label: "Terms of Service", href: "/terms" },
            { label: "Cookie Policy", href: "/cookies" },
            { label: "Security", href: "/security" },
        ],
    },
};

const defaultSocialLinks = [
    { icon: Twitter, href: "https://twitter.com/veblika", label: "Twitter" },
    { icon: Linkedin, href: "https://linkedin.com/company/veblika", label: "LinkedIn" },
    { icon: Instagram, href: "https://instagram.com/veblika", label: "Instagram" },
    { icon: Youtube, href: "https://youtube.com/@veblika", label: "YouTube" },
    { icon: Facebook, href: "https://facebook.com/veblika", label: "Facebook" },
];

import { useBranding } from "@/providers/branding-provider";

export default function MarketingFooter() {
    const branding = useBranding();
    console.log(branding,'brading from marketing footer index.tsx')
    const { companyName, logo } = branding;

    const normalizeSocialUrl = (url: string) => {
        if (!url) return "";
        return /^https?:\/\//i.test(url) ? url : `https://${url}`;
    };

    const socialLinks = [
        { icon: Twitter, href: normalizeSocialUrl(branding.social?.twitter || defaultSocialLinks[0].href), label: "Twitter" },
        { icon: Linkedin, href: normalizeSocialUrl(branding.social?.linkedin || defaultSocialLinks[1].href), label: "LinkedIn" },
        { icon: Instagram, href: normalizeSocialUrl(branding.social?.instagram || defaultSocialLinks[2].href), label: "Instagram" },
        { icon: Youtube, href: defaultSocialLinks[3].href, label: "YouTube" },
        { icon: Facebook, href: normalizeSocialUrl(branding.social?.facebook || defaultSocialLinks[4].href), label: "Facebook" },
    ];

    return (
        <footer className="bg-slate-900 text-white">
            {/* Premium CTA Section with Floating Elements */}
            <div className="relative border-b border-slate-800 bg-white py-24 md:py-32 overflow-hidden">
                {/* Floating Elements Background */}
                <div className="absolute inset-0 pointer-events-none hidden md:block">
                    {floatingElements.map((el, i) => (
                        <motion.div
                            key={i}
                            initial={{ opacity: 0, scale: 0.5 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            animate={{
                                y: [0, -20, 0],
                                rotate: [0, 5, -5, 0],
                                x: [0, 10, 0]
                            }}
                            transition={{
                                duration: 5 + Math.random() * 5,
                                repeat: Infinity,
                                delay: Math.random() * 2,
                                ease: "easeInOut"
                            }}
                            style={{
                                position: 'absolute',
                                top: el.top,
                                left: el.left,
                                right: el.right,
                                width: el.size,
                                height: el.size,
                                zIndex: 1,
                            }}
                        >
                            {el.type === 'avatar' ? (
                                <div className="w-full h-full rounded-full border-4 border-white shadow-xl overflow-hidden grayscale hover:grayscale-0 transition-all duration-500">
                                    <img src={el.src} alt="" className="w-full h-full object-cover" />
                                </div>
                            ) : (
                                <div className="text-4xl drop-shadow-lg">{el.content}</div>
                            )}
                        </motion.div>
                    ))}
                </div>

                <div className="container mx-auto px-4 relative z-10">
                    <div className="max-w-4xl mx-auto text-center">
                        <motion.h2
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            className="text-4xl md:text-6xl font-black tracking-tight mb-8 text-slate-900 leading-[1.1]"
                        >
                            {branding.content?.cta?.title || "Grow your brand presence on social media."}
                        </motion.h2>
                        <motion.p
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.1 }}
                            className="text-slate-500 text-lg md:text-xl mb-12 font-medium max-w-2xl mx-auto"
                        >
                            {branding.content?.cta?.subtitle || `Try ${companyName || "Veblika"} free for 14 days. No credit card required.`}
                        </motion.p>
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.2 }}
                            className="flex flex-col sm:flex-row items-center justify-center gap-6"
                        >
                            <Button
                                asChild
                                size="lg"
                                className="h-16 px-12 text-xl font-black rounded-2xl bg-[#F6571F] hover:bg-[#E44D1B] text-white shadow-2xl shadow-[#F6571F]/40 transition-all hover:scale-[1.05] active:scale-95 border-0"
                            >
                                <Link href="/signup">
                                    {branding.content?.cta?.buttonText || "Sign Up for Free Trial"}
                                    <ArrowRight size={24} className="ml-3" />
                                </Link>
                            </Button>
                        </motion.div>
                    </div>
                </div>
            </div>

            {/* Links Section */}
            <div className="container mx-auto px-4 py-16">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
                    {/* Logo & Description */}
                    <div className="col-span-2 md:col-span-3 lg:col-span-1">
                        <Link href="/" className="flex items-center gap-2 mb-4">
                            {logo ? (
                                <img
                                    src={logo}
                                    className="h-8 w-8 object-contain"
                                    alt={companyName}
                                />
                            ) : (
                                <img
                                    src="https://cloudmediastorage.s3.ap-south-1.amazonaws.com/white-label/logo/veblika.com/e745e554-ebb2-44d5-979e-7ceb20f6918e-favicon2.png"
                                    className="h-8 w-8"
                                    alt="Veblika"
                                />
                            )}
                            <span className="text-white font-semibold text-xl">{companyName || "Veblika"}</span>
                        </Link>
                        <p className="text-slate-400 text-sm leading-relaxed mb-6">
                            The all-in-one social media management platform for teams that want to grow.
                        </p>
                        {/* Social Links */}
                        <div className="flex items-center gap-3">
                            {socialLinks.map((social) => (
                                <a
                                    key={social.label}
                                    href={social.href}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
                                    aria-label={social.label}
                                >
                                    <social.icon size={18} />
                                </a>
                            ))}
                        </div>
                    </div>

                    {/* Link Columns */}
                    {Object.values(footerLinks).map((section) => (
                        <div key={section.title}>
                            <h4 className="text-white font-semibold text-sm mb-4">
                                {section.title}
                            </h4>
                            <ul className="space-y-3">
                                {section.links.map((link) => (
                                    <li key={link.href}>
                                        <Link
                                            href={link.href}
                                            className="text-slate-400 hover:text-white text-sm transition-colors"
                                        >
                                            {link.label}
                                        </Link>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>
            </div>

            {/* Bottom Bar */}
            <div className="border-t border-slate-800">
                <div className="container mx-auto px-4 py-6">
                    <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                        <p className="text-slate-500 text-sm">
                            © {new Date().getFullYear()} {companyName || "Veblika"}. All rights reserved.
                        </p>
                        <div className="flex items-center gap-6">
                            <Link
                                href="/privacy"
                                className="text-slate-500 hover:text-slate-300 text-sm transition-colors"
                            >
                                Privacy
                            </Link>
                            <Link
                                href="/terms"
                                className="text-slate-500 hover:text-slate-300 text-sm transition-colors"
                            >
                                Terms
                            </Link>
                            <Link
                                href="/cookies"
                                className="text-slate-500 hover:text-slate-300 text-sm transition-colors"
                            >
                                Cookies
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    );
}
