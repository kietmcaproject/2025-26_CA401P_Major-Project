"use client";

import React, { useState, useRef } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ChevronDown, Menu, X, ArrowRight, Calendar, MessageSquare, BarChart3, Ear, Users, FolderOpen, Megaphone, Heart, Shield, Building2, Sparkles, BookOpen, HelpCircle, FileCode } from "lucide-react";
import {
    featuresNavigation,
    solutionsNavigation,
    resourcesNavigation,
} from "@/lib/constants/navigation";

import { useBranding } from "@/providers/branding-provider";

const Logo = () => {
    const { companyName, logo } = useBranding();

    return (
        <Link href="/" className="flex items-center gap-2">
            {logo ? (
                <img
                    src={logo}
                    className="h-8 w-8 object-contain"
                    alt={companyName}
                />
            ) : (
                <img
                    src="https://cloudmediastorage.s3.ap-south-1.amazonaws.com/white-label/logo/veblika.com/e745e554-ebb2-44d5-979e-7ceb20f6918e-favicon2.png"
                    className="h-8 w-8"
                    alt="Veblika"
                />
            )}
            <span className="text-slate-900 font-semibold text-xl">{companyName || "Veblika"}</span>
        </Link>
    );
};

const iconMap: Record<string, any> = {
    Calendar,
    MessageSquare,
    BarChart3,
    Ear,
    Users,
    FolderOpen,
    Megaphone,
    Heart,
    Shield,
    Building2,
    Sparkles,
    BookOpen,
    HelpCircle,
    FileCode,
};

// Mega Menu for Features - Positioned absolutely relative to the header
const FeaturesMegaMenu = ({ isOpen, onClose, onMouseEnter, onMouseLeave }: { isOpen: boolean; onClose: () => void; onMouseEnter: () => void; onMouseLeave: () => void }) => {
    return (
        <AnimatePresence>
            {isOpen && (
                <>
                    {/* Backdrop */}
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 top-[65px] bg-black/5 z-40"
                        onClick={onClose}
                        onMouseEnter={onMouseEnter}
                    />

                    {/* Menu Content */}
                    <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.2 }}
                        className="absolute left-0 right-0 top-full bg-white border-b border-slate-200 shadow-xl z-50 origin-top"
                        onMouseEnter={onMouseEnter}
                        onMouseLeave={onMouseLeave}
                    >
                        <div className="container mx-auto px-4 py-8">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
                                {/* Feature Sections */}
                                {featuresNavigation.sections?.map((section, idx) => (
                                    <div key={idx} className="min-w-0">
                                        <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">
                                            {section.title}
                                        </h4>
                                        <ul className="space-y-1">
                                            {section.items.map((item) => {
                                                const Icon = item.icon ? (iconMap[item.icon] || HelpCircle) : null;
                                                return (
                                                    <li key={item.href}>
                                                        <Link
                                                            href={item.href}
                                                            onClick={onClose}
                                                            className="group flex items-start gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors"
                                                        >
                                                            <div className="w-10 h-10 shrink-0 rounded-lg bg-[#FFF5F1] group-hover:bg-white group-hover:shadow-md flex items-center justify-center text-[#F6571F] group-hover:text-[#F6571F] transition-all">
                                                                {Icon && <Icon size={20} />}
                                                            </div>
                                                            <div className="flex-1 min-w-0">
                                                                <p className="text-sm font-semibold text-slate-900 group-hover:text-[#F6571F] transition-colors truncate">
                                                                    {item.title}
                                                                </p>
                                                                <p className="text-xs text-slate-500 mt-0.5 leading-relaxed line-clamp-2">
                                                                    {item.description}
                                                                </p>
                                                            </div>
                                                        </Link>
                                                    </li>
                                                );
                                            })}
                                        </ul>
                                    </div>
                                ))}

                                {/* Featured CTA */}
                                <div className="hidden lg:flex bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl p-6 flex-col justify-between h-full min-h-[250px] shadow-lg">
                                    <div>
                                        <h4 className="text-white font-bold text-lg mb-2">
                                            {featuresNavigation.featured?.title}
                                        </h4>
                                        <p className="text-slate-400 text-sm leading-relaxed">
                                            {featuresNavigation.featured?.description}
                                        </p>
                                    </div>
                                    <Link
                                        href={featuresNavigation.featured?.href || "/features"}
                                        onClick={onClose}
                                        className="inline-flex items-center gap-2 text-white font-semibold text-sm mt-6 hover:gap-3 transition-all"
                                    >
                                        Explore all features
                                        <ArrowRight size={16} />
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </>
            )}
        </AnimatePresence>
    );
};

// Simple Dropdown for Solutions/Resources
const SimpleDropdown = ({
    items,
    isOpen,
    onClose,
}: {
    items: typeof solutionsNavigation.items;
    isOpen: boolean;
    onClose: () => void;
}) => {
    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.15 }}
                    className="absolute top-full left-0 mt-2 w-72 bg-white rounded-xl border border-slate-200 shadow-xl z-50 overflow-hidden"
                >
                    <div className="p-2">
                        {items?.map((item) => (
                            <Link
                                key={item.href}
                                href={item.href}
                                onClick={onClose}
                                className="group flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors"
                            >
                                <div className="w-9 h-9 rounded-lg bg-[#FFF5F1] group-hover:bg-[#FFF5F1] flex items-center justify-center text-[#F6571F] group-hover:text-[#F6571F] transition-all">
                                    {item.icon && React.createElement(iconMap[item.icon] || HelpCircle, { size: 18 })}
                                </div>
                                <div className="flex-1">
                                    <p className="text-sm font-semibold text-slate-900 group-hover:text-[#F6571F] transition-colors">
                                        {item.title}
                                    </p>
                                    <p className="text-xs text-slate-500 mt-0.5">
                                        {item.description}
                                    </p>
                                </div>
                            </Link>
                        ))}
                    </div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

// Nav Item that controls a dropdown (or just acts as a trigger)
const NavItemWithDropdown = ({
    title,
    children,
    isOpen,
    onToggle,
    onMouseEnter,
    onMouseLeave,
}: {
    title: string;
    children?: React.ReactNode;
    isOpen: boolean;
    onToggle: () => void;
    onMouseEnter: () => void;
    onMouseLeave: () => void;
}) => {
    return (
        <div
            className="relative h-full flex items-center"
            onMouseEnter={onMouseEnter}
            onMouseLeave={onMouseLeave}
        >
            <button
                onClick={onToggle}
                className={`flex items-center gap-1 text-sm font-medium transition-colors ${isOpen ? "text-[#F6571F]" : "text-slate-600 hover:text-slate-900"
                    }`}
            >
                {title}
                <ChevronDown
                    size={14}
                    className={`transition-transform ${isOpen ? "rotate-180" : ""}`}
                />
            </button>
            {children}
        </div>
    );
};

export default function MarketingNavbar() {
    const [openMenu, setOpenMenu] = useState<string | null>(null);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const timeoutRef = useRef<NodeJS.Timeout | null>(null);

    const handleMouseEnter = (menu: string) => {
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }
        setOpenMenu(menu);
    };

    const handleMouseLeave = () => {
        timeoutRef.current = setTimeout(() => {
            setOpenMenu(null);
        }, 100); // 100ms delay to allow moving to the menu
    };

    const handleToggle = (menu: string) => {
        setOpenMenu(openMenu === menu ? null : menu);
    };

    const closeMenu = () => {
        setOpenMenu(null);
        setMobileMenuOpen(false);
    };

    return (
        <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    {/* Logo */}
                    <Logo />

                    {/* Desktop Navigation */}
                    <nav className="hidden lg:flex items-center gap-8 h-full">
                        {/* Features Trigger - Mega Menu rendred outside */}
                        <NavItemWithDropdown
                            title="Features"
                            isOpen={openMenu === "features"}
                            onToggle={() => handleToggle("features")}
                            onMouseEnter={() => handleMouseEnter("features")}
                            onMouseLeave={handleMouseLeave}
                        >
                            {/* No children here, mega menu is hoisted */}
                        </NavItemWithDropdown>

                        {/* Solutions Dropdown */}
                        <NavItemWithDropdown
                            title="Solutions"
                            isOpen={openMenu === "solutions"}
                            onToggle={() => handleToggle("solutions")}
                            onMouseEnter={() => handleMouseEnter("solutions")}
                            onMouseLeave={handleMouseLeave}
                        >
                            <SimpleDropdown
                                items={solutionsNavigation.items}
                                isOpen={openMenu === "solutions"}
                                onClose={closeMenu}
                            />
                        </NavItemWithDropdown>

                        {/* Pricing Link */}
                        <Link
                            href="/pricing"
                            className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors"
                        >
                            Pricing
                        </Link>

                        {/* Resources Dropdown */}
                        <NavItemWithDropdown
                            title="Resources"
                            isOpen={openMenu === "resources"}
                            onToggle={() => handleToggle("resources")}
                            onMouseEnter={() => handleMouseEnter("resources")}
                            onMouseLeave={handleMouseLeave}
                        >
                            <SimpleDropdown
                                items={resourcesNavigation.items}
                                isOpen={openMenu === "resources"}
                                onClose={closeMenu}
                            />
                        </NavItemWithDropdown>
                    </nav>

                    {/* CTA Buttons */}
                    <div className="hidden lg:flex items-center gap-3">
                        <Link
                            href="/login"
                            className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors px-4 py-2"
                        >
                            Log in
                        </Link>
                        <Button
                            asChild
                            className="h-10 px-5 text-sm font-bold rounded-full bg-[#F6571F] hover:bg-[#E44D1B] text-white border-0 shadow-lg shadow-[#F6571F]/10"
                        >
                            <Link href="/signup">
                                Get started free
                                <ArrowRight size={16} className="ml-1" />
                            </Link>
                        </Button>
                    </div>

                    {/* Mobile Menu Toggle */}
                    <button
                        className="lg:hidden p-2 text-slate-600"
                        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                    >
                        {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </div>
            </div>

            {/* Mega Menu Rendered Directly in Header for Full Width */}
            <div onMouseEnter={() => handleMouseEnter("features")} onMouseLeave={handleMouseLeave}>
                <FeaturesMegaMenu
                    isOpen={openMenu === "features"}
                    onClose={closeMenu}
                    onMouseEnter={() => handleMouseEnter("features")}
                    onMouseLeave={handleMouseLeave}
                />
            </div>

            {/* Mobile Menu */}
            <AnimatePresence>
                {mobileMenuOpen && (
                    <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="lg:hidden bg-white border-t border-slate-100 overflow-hidden max-h-[calc(100vh-64px)] overflow-y-auto"
                    >
                        <div className="container mx-auto px-4 py-6 space-y-4">
                            {/* Mobile Features List */}
                            <div className="space-y-3">
                                <div className="font-semibold text-slate-900">Features</div>
                                {featuresNavigation.sections?.map((section, idx) => (
                                    <div key={idx} className="pl-4 border-l-2 border-slate-100">
                                        <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">{section.title}</div>
                                        <div className="flex flex-col gap-2">
                                            {section.items.map((item) => (
                                                <Link
                                                    key={item.title}
                                                    href={item.href}
                                                    className="text-sm text-slate-600 block py-1"
                                                    onClick={() => setMobileMenuOpen(false)}
                                                >
                                                    {item.title}
                                                </Link>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <hr className="border-slate-100" />

                            <Link
                                href="/solutions/agencies"
                                className="block text-base font-medium text-slate-900 py-2"
                                onClick={() => setMobileMenuOpen(false)}
                            >
                                Solutions
                            </Link>
                            <Link
                                href="/pricing"
                                className="block text-base font-medium text-slate-900 py-2"
                                onClick={() => setMobileMenuOpen(false)}
                            >
                                Pricing
                            </Link>
                            <Link
                                href="/resources/blog"
                                className="block text-base font-medium text-slate-900 py-2"
                                onClick={() => setMobileMenuOpen(false)}
                            >
                                Resources
                            </Link>

                            <div className="pt-4 border-t border-slate-100 space-y-3">
                                <Link
                                    href="/login"
                                    className="block text-center text-base font-medium text-slate-600 py-2"
                                    onClick={() => setMobileMenuOpen(false)}
                                >
                                    Log in
                                </Link>
                                <Button
                                    asChild
                                    className="w-full h-12 text-base font-semibold rounded-full bg-[#bbf7d0] hover:bg-[#a6efc1] text-[#064e3b]"
                                >
                                    <Link href="/signup" onClick={() => setMobileMenuOpen(false)}>
                                        Get started free
                                    </Link>
                                </Button>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </header>
    );
}
