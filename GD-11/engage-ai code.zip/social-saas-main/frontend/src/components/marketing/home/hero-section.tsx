"use client";

import React, { useRef } from 'react';
import Image from 'next/image';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Check, Sparkles } from 'lucide-react';
import { useBranding } from "@/providers/branding-provider";

// Brand Logos
const BrandLogos: Record<string, React.ReactNode> = {
    facebook: (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
        </svg>
    ),
    instagram: (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.622 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
        </svg>
    ),
    twitter: (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
        </svg>
    ),
    linkedin: (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
        </svg>
    ),
    youtube: (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
        </svg>
    ),
    tiktok: (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.59-5.71-.29-2.63.85-5.21 2.86-6.91 1.62-1.4 3.81-1.93 5.92-1.62V11.7c-1.42-.14-2.86.35-3.72 1.53-.48.65-.72 1.48-.68 2.29.13.91.56 1.78 1.25 2.38.8.76 1.88 1.05 2.9 1.02 1.39-.02 2.72-.88 3.32-2.14.33-.67.45-1.43.43-2.18-.04-4.86-.02-9.72-.03-14.58z" />
        </svg>
    ),
    pinterest: (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.966 1.406-5.966s-.359-.72-.359-1.781c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.252 7.929-7.252 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.631-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12.017 24c6.621 0 12-5.378 12-12S18.638 0 12.017 0z" />
        </svg>
    ),
    threads: (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M12.186 24h-.007c-3.581-.024-6.334-1.205-8.184-3.509C2.35 18.44 1.5 15.586 1.472 12.01v-.017c.03-3.579.879-6.43 2.525-8.482C5.845 1.205 8.6.024 12.18 0h.014c2.746.02 5.043.725 6.826 2.098 1.677 1.29 2.858 3.13 3.509 5.467l-2.04.569c-1.104-3.96-3.898-5.984-8.304-6.015-2.91.022-5.11.936-6.54 2.717C4.307 6.504 3.616 8.914 3.589 12c.027 3.086.718 5.496 2.057 7.164 1.43 1.783 3.631 2.698 6.54 2.717 2.623-.02 4.358-.631 5.8-2.045 1.647-1.613 1.618-3.593 1.09-4.798-.31-.71-.873-1.3-1.634-1.75-.192 1.352-.622 2.446-1.284 3.272-.886 1.102-2.14 1.704-3.73 1.79-1.202.065-2.361-.218-3.259-.801-1.063-.689-1.685-1.74-1.752-2.96-.065-1.182.408-2.256 1.33-3.022.858-.713 2.024-1.129 3.378-1.209 1.106-.065 2.134.043 3.063.32.026-.544.014-1.076-.035-1.588-.18-1.871-.96-2.785-2.382-2.785-1.96 0-2.705 1.166-2.832 2.645l-2.112-.194c.196-2.518 1.839-4.449 4.944-4.449 1.59 0 2.86.538 3.672 1.556.713.894 1.093 2.134 1.128 3.69.017.77-.01 1.61-.083 2.505 1.01.585 1.833 1.399 2.394 2.378.864 1.51 1.017 3.883-.85 5.574-1.727 1.564-3.852 2.401-6.942 2.428z" />
        </svg>
    ),
};

// Social icons for parallax effect
const socialIcons = [
    { name: 'facebook', color: "text-blue-600", top: "18%", left: "8%", size: 32, delay: 0, blur: "0px" },
    { name: 'instagram', color: "text-pink-600", top: "22%", right: "10%", size: 28, delay: 0.2, blur: "2px" },
    { name: 'twitter', color: "text-slate-900", bottom: "42%", left: "12%", size: 24, delay: 0.4, blur: "1px" },
    { name: 'linkedin', color: "text-blue-700", top: "38%", right: "8%", size: 30, delay: 0.1, blur: "0px" },
    { name: 'youtube', color: "text-red-600", bottom: "28%", right: "14%", size: 34, delay: 0.3, blur: "3px" },
    { name: 'tiktok', color: "text-slate-900", top: "58%", left: "10%", size: 26, delay: 0.5, blur: "0px" },
    { name: 'pinterest', color: "text-red-700", top: "48%", right: "12%", size: 28, delay: 0.25, blur: "4px" },
    { name: 'threads', color: "text-slate-900", bottom: "18%", left: "22%", size: 24, delay: 0.45, blur: "0px" },
];

// Optimized Parallax Icon
const ParallaxIcon = ({ name, color, style, mouseX, mouseY }: any) => {
    // Reduce spring calculations by lowering stiffness/damping or just using linear transform for performance
    const x = useTransform(mouseX, [0, 1], [style.xRange[0], style.xRange[1]]);
    const y = useTransform(mouseY, [0, 1], [style.yRange[0], style.yRange[1]]);
    // Using simple formatting for spring to avoid heavy physics calculation if not strictly needed, 
    // but Keeping spring for smoothness as requested. 
    const springX = useSpring(x, { stiffness: 40, damping: 15 });
    const springY = useSpring(y, { stiffness: 40, damping: 15 });

    return (
        <motion.div
            style={{
                position: 'absolute',
                top: style.top,
                left: style.left,
                right: style.right,
                bottom: style.bottom,
                x: springX,
                y: springY,
                zIndex: 5,
                filter: `blur(${style.blur})`,
            }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: style.blur === "0px" ? 0.7 : 0.35, scale: 1 }}
            transition={{ delay: style.delay, duration: 0.5 }}
        >
            <div className={`p-2.5 bg-white rounded-xl shadow-[0_4px_20px_rgb(0,0,0,0.06)] border border-slate-100/80 flex items-center justify-center ${color}`}>
                <div style={{ width: style.size, height: style.size }}>
                    {BrandLogos[name]}
                </div>
            </div>
        </motion.div>
    );
};

export default function HeroSection() {
    const branding = useBranding();
    const { companyName, domain } = branding;
    const containerRef = useRef<HTMLDivElement>(null);
    const mouseX = useMotionValue(0.5);
    const mouseY = useMotionValue(0.5);

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width;
        const y = (e.clientY - rect.top) / rect.height;
        mouseX.set(x);
        mouseY.set(y);
    };

    const dashboardUrl = domain ? `app.${domain}/dashboard` : "app.veblika.com/dashboard";

    return (
        <section
            ref={containerRef}
            onMouseMove={handleMouseMove}
            className="relative w-full h-[100vh] min-h-[600px] flex flex-col bg-white overflow-hidden"
        >
            {/* Optimized Gradient Background - Brighter & More Opaque */}
            <div className="absolute inset-0 z-0 pointer-events-none opacity-100">
                <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-[#F6571F]/15 blur-[120px] rounded-full mix-blend-multiply filter animate-pulse" />
                <div className="absolute top-[10%] right-[-10%] w-[50%] h-[50%] bg-[#FF8A5B]/15 blur-[100px] rounded-full mix-blend-multiply filter" />
                <div className="absolute bottom-[-10%] left-[10%] w-[40%] h-[40%] bg-slate-200/60 blur-[110px] rounded-full mix-blend-multiply filter" />
            </div>

            {/* Pattern & Grid Overlay */}
            <div className="absolute inset-0 z-0 pointer-events-none fun-pattern" />
            <div
                className="absolute inset-0 z-0 pointer-events-none opacity-[0.03]"
                style={{
                    backgroundImage: 'linear-gradient(#F6571F 1px, transparent 1px), linear-gradient(90deg, #F6571F 1px, transparent 1px)',
                    backgroundSize: '40px 40px',
                }}
            />

            {/* Floating Parallax Icons - Hidden on mobile */}
            <div className="absolute inset-0 pointer-events-none hidden lg:block">
                {socialIcons.map((item, idx) => (
                    <ParallaxIcon
                        key={idx}
                        {...item}
                        mouseX={mouseX}
                        mouseY={mouseY}
                        style={{
                            ...item,
                            xRange: [idx % 2 === 0 ? -20 : 20, idx % 2 === 0 ? 20 : -20],
                            yRange: [idx % 3 === 0 ? -20 : 20, idx % 3 === 0 ? 20 : -20],
                        }}
                    />
                ))}
            </div>

            {/* Main Content */}
            <div className="container mx-auto px-4 relative z-10 flex-1 flex flex-col pt-12 md:pt-20">
                <div className="flex-1 flex flex-col items-center text-center max-w-4xl mx-auto">
                    {/* Badge */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5 }}
                    >
                        <Badge variant="secondary" className="mb-6 px-4 py-1.5 text-sm font-semibold bg-[#FFF5F1] text-[#F6571F] border-[#F6571F]/10 hover:bg-[#FFF5F1] shadow-sm">
                            <Sparkles className="w-3.5 h-3.5 mr-1.5 fill-[#F6571F]/20" />
                            Trusted by 10,000+ teams
                        </Badge>
                    </motion.div>

                    {/* Headline */}
                    <motion.h1
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.1 }}
                        className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black tracking-[-0.02em] text-slate-900 leading-[1.1] mb-6"
                    >
                        {branding.content?.hero?.title || "Your social media command center"}
                    </motion.h1>

                    {/* Subheadline */}
                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.2 }}
                        className="text-lg md:text-xl text-slate-500 font-medium max-w-2xl mb-8 leading-relaxed"
                    >
                        {branding.content?.hero?.subtitle || "Schedule, publish, analyze, and engage — all from one beautiful dashboard. The complete toolkit for social media success."}
                    </motion.p>

                    {/* CTA Form */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.3 }}
                        className="w-full max-w-md mb-6"
                    >
                        <form
                            onSubmit={(e) => {
                                e.preventDefault();
                                const email = (e.currentTarget.elements.namedItem('email') as HTMLInputElement).value;
                                window.location.href = `/signup?email=${encodeURIComponent(email)}`;
                            }}
                            className="flex flex-col sm:flex-row gap-3 p-1.5 bg-white border border-slate-200 rounded-2xl shadow-xl shadow-slate-200/40 focus-within:border-[#F6571F]/30 transition-all"
                        >
                            <input
                                name="email"
                                type="email"
                                required
                                placeholder="Enter your work email"
                                className="flex-1 bg-transparent border-none outline-none px-5 py-3 text-slate-900 placeholder:text-slate-400 text-sm font-medium"
                            />
                            <Button
                                type="submit"
                                size="lg"
                                className="h-12 px-8 text-sm font-bold rounded-xl bg-[#F6571F] hover:bg-[#E44D1B] text-white shadow-lg shadow-[#F6571F]/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
                            >
                                Get started free
                                <ArrowRight className="w-4 h-4 ml-2" />
                            </Button>
                        </form>
                    </motion.div>

                    {/* Trust indicators */}
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.6, delay: 0.4 }}
                        className="flex flex-wrap items-center justify-center gap-6 text-sm text-slate-500"
                    >
                        <span className="flex items-center gap-1.5">
                            <Check className="w-4 h-4 text-green-500" />
                            Free 14-day trial
                        </span>
                        <span className="flex items-center gap-1.5">
                            <Check className="w-4 h-4 text-green-500" />
                            No credit card required
                        </span>
                        <span className="flex items-center gap-1.5">
                            <Check className="w-4 h-4 text-green-500" />
                            Cancel anytime
                        </span>
                    </motion.div>
                </div>
            </div>

            {/* Dashboard Preview - Clipped at the bottom */}
            <motion.div
                initial={{ opacity: 0, y: 100 }}
                animate={{ opacity: 1, y: 40 }}
                transition={{ type: "spring", stiffness: 45, damping: 20, delay: 0.5 }}
                className="relative w-full max-w-5xl mx-auto px-4 mt-auto mb-[-15vh] md:mb-[-20vh]"
            >
                <div className="relative rounded-t-3xl bg-slate-900 p-2 md:p-3 shadow-[0_-20px_50px_rgba(0,0,0,0.1)] border-x border-t border-slate-800/50">
                    {/* Browser chrome */}
                    <div className="flex items-center gap-2 mb-2 md:mb-3 px-4 py-1">
                        <div className="flex gap-1.5">
                            <div className="w-2.5 h-2.5 rounded-full bg-red-400" />
                            <div className="w-2.5 h-2.5 rounded-full bg-yellow-400" />
                            <div className="w-2.5 h-2.5 rounded-full bg-green-400" />
                        </div>
                        <div className="flex-1 bg-slate-800/50 rounded-lg h-6 md:h-8 flex items-center justify-center border border-white/5">
                            <span className="text-[10px] md:text-xs text-slate-400 font-medium tracking-wide">{dashboardUrl}</span>
                        </div>
                    </div>
                    {/* Dashboard content */}
                    <div className="rounded-xl overflow-hidden bg-slate-100 aspect-[16/10] shadow-inner">
                        <Image
                            src="/hero.png"
                            alt={`${companyName || "Veblika"} Dashboard`}
                            width={1920}
                            height={1080}
                            className="w-full h-full object-cover object-top"
                            priority
                        />
                    </div>
                </div>
            </motion.div>
        </section>
    );
}
