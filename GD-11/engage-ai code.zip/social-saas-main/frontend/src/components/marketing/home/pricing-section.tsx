"use client";

import React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Check, ArrowRight } from "lucide-react";
import { useBranding } from "@/providers/branding-provider";

export default function PricingPreviewSection() {
    const branding = useBranding();
    // Default fallback plans
    const defaultPlans = [
        {
            name: "Starter",
            price: "$29",
            period: "/mo",
            description: "Perfect for individuals and small teams.",
            features: ["5 social profiles", "50 scheduled posts/mo", "Basic analytics"],
            buttonText: "Start free trial",
            isPopular: false,
            order: 0
        },
        {
            name: "Professional",
            price: "$79",
            period: "/mo",
            description: "For growing teams that need more power.",
            features: ["15 social profiles", "Unlimited scheduling", "Advanced analytics", "Team collaboration"],
            buttonText: "Start free trial",
            isPopular: true,
            order: 1
        },
        {
            name: "Agency",
            price: "$199",
            period: "/mo",
            description: "For agencies managing multiple brands.",
            features: ["50 social profiles", "White-label reports", "Client portals", "Approval workflows"],
            buttonText: "Start free trial",
            isPopular: false,
            order: 2
        }
    ];

    // Use dynamic pricing if available, otherwise use defaults
    const plans = (branding.content?.pricing && branding.content.pricing.length > 0)
        ? branding.content.pricing.sort((a, b) => a.order - b.order)
        : defaultPlans;

    return (
        <section className="py-20 md:py-28 bg-slate-50">
            <div className="container mx-auto px-4">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="max-w-3xl mx-auto text-center mb-16"
                >
                    <Badge variant="secondary" className="mb-4 bg-[#FFF5F1] text-[#F6571F] border-[#F6571F]/10">
                        Pricing
                    </Badge>
                    <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 tracking-tight mb-4">
                        Simple, transparent pricing
                    </h2>
                    <p className="text-lg text-slate-500 mb-8">
                        Start free, scale as you grow. No hidden fees, no surprises.
                    </p>
                </motion.div>

                <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-16">
                    {plans.map((plan, idx) => (
                        <motion.div
                            key={plan.name}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: idx * 0.1 }}
                            className="relative"
                        >
                            <Card className={`h-full flex flex-col border-2 transition-all hover:shadow-2xl ${plan.isPopular ? 'border-[#F6571F] shadow-xl ring-1 ring-[#F6571F]/20' : 'border-slate-200 hover:border-[#F6571F]/30'}`}>
                                {plan.isPopular && (
                                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                                        <span className="bg-[#F6571F] text-white text-xs font-black uppercase tracking-wider px-3 py-1 rounded-full shadow-lg">
                                            Most Popular
                                        </span>
                                    </div>
                                )}
                                <CardHeader>
                                    <CardTitle className="text-xl font-bold text-slate-900">{plan.name}</CardTitle>
                                    <div className="mt-2 mb-2">
                                        <span className="text-4xl font-bold text-slate-900">{plan.price}</span>
                                        <span className="text-slate-500">{plan.period || '/mo'}</span>
                                    </div>
                                    <CardDescription>{plan.description}</CardDescription>
                                </CardHeader>
                                <CardContent className="flex-1 flex flex-col">
                                    <ul className="space-y-3 mb-8 flex-1">
                                        {plan.features.map(feat => (
                                            <li key={feat} className="flex items-center gap-2 text-sm text-slate-600">
                                                <Check className="w-4 h-4 text-green-500 shrink-0" />
                                                {feat}
                                            </li>
                                        ))}
                                    </ul>
                                    <Button
                                        asChild
                                        className={`w-full rounded-xl font-bold transition-all ${plan.isPopular
                                            ? 'bg-[#F6571F] hover:bg-[#E44D1B] text-white shadow-lg shadow-[#F6571F]/20 active:scale-95'
                                            : 'bg-white border-2 border-slate-200 text-slate-900 hover:border-[#F6571F] hover:text-[#F6571F] hover:bg-[#FFF5F1]/30'
                                            }`}
                                    >
                                        <Link href="/signup">{plan.buttonText || 'Start free trial'}</Link>
                                    </Button>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>

                <div className="text-center">
                    <Link href="/pricing" className="text-[#F6571F] font-bold hover:underline inline-flex items-center gap-2 group">
                        See full pricing details <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                </div>
            </div>
        </section>
    );
}
