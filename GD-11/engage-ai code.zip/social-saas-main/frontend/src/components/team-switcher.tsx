"use client"

import * as React from "react"

export function TeamSwitcher() {
  return null;
}
