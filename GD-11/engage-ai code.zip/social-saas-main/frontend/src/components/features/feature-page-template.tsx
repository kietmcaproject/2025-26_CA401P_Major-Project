"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Check, ArrowLeft, Calendar, MessageSquare, BarChart3, Ear, Users, FolderOpen, Megaphone, Heart, Shield, HelpCircle } from "lucide-react";
import { FeaturePageData } from "@/lib/constants/features";

// Import SVGs from the assets folder
import AdManagementSVG from "../homePage/assets/Ad-management.svg";
import AnalyticsSVG from "../homePage/assets/Analytics-&-Reports.svg";
import UGCInfluencersSVG from "../homePage/assets/UGC-&-influencers.svg";
import ContentLibrarySVG from "../homePage/assets/content-library.svg";
import SchedulingSVG from "../homePage/assets/publishing&scheduling.svg";
import SecuritySVG from "../homePage/assets/security-&-compliance.svg";
import SocialInboxSVG from "../homePage/assets/social-inbox.svg";
import SocialListeningSVG from "../homePage/assets/social-listening.svg";
import TeamCollaborationSVG from "../homePage/assets/team-collaboration.svg";

const mockupMap: Record<string, any> = {
    scheduling: SchedulingSVG,
    inbox: SocialInboxSVG,
    analytics: AnalyticsSVG,
    listening: SocialListeningSVG,
    collaboration: TeamCollaborationSVG,
    "content-library": ContentLibrarySVG,
    ads: AdManagementSVG,
    ugc: UGCInfluencersSVG,
    security: SecuritySVG,
};

interface FeaturePageTemplateProps {
    feature: FeaturePageData;
    mockupImage?: string;
}

const colorClasses: Record<string, { bg: string; text: string; light: string; gradient: string }> = {
    blue: {
        bg: "bg-blue-600",
        text: "text-blue-600",
        light: "bg-blue-50",
        gradient: "from-blue-600 to-blue-500",
    },
    green: {
        bg: "bg-green-600",
        text: "text-green-600",
        light: "bg-green-50",
        gradient: "from-green-600 to-emerald-500",
    },
    purple: {
        bg: "bg-purple-600",
        text: "text-purple-600",
        light: "bg-purple-50",
        gradient: "from-purple-600 to-violet-500",
    },
    orange: {
        bg: "bg-[#F6571F]",
        text: "text-[#F6571F]",
        light: "bg-[#FFF5F1]",
        gradient: "from-[#F6571F] to-[#FF8A5B]",
    },
    cyan: {
        bg: "bg-cyan-600",
        text: "text-cyan-600",
        light: "bg-cyan-50",
        gradient: "from-cyan-600 to-teal-500",
    },
    pink: {
        bg: "bg-pink-600",
        text: "text-pink-600",
        light: "bg-pink-50",
        gradient: "from-pink-600 to-rose-500",
    },
    red: {
        bg: "bg-red-600",
        text: "text-red-600",
        light: "bg-red-50",
        gradient: "from-red-600 to-rose-500",
    },
    rose: {
        bg: "bg-rose-600",
        text: "text-rose-600",
        light: "bg-rose-50",
        gradient: "from-rose-600 to-pink-500",
    },
    slate: {
        bg: "bg-slate-700",
        text: "text-slate-700",
        light: "bg-slate-100",
        gradient: "from-slate-700 to-slate-600",
    },
};

const iconMap: Record<string, any> = {
    Calendar,
    MessageSquare,
    BarChart3,
    Ear,
    Users,
    FolderOpen,
    Megaphone,
    Heart,
    Shield,
};

// Hero Section
const FeatureHero = ({ feature }: { feature: FeaturePageData }) => {
    const Icon = iconMap[feature.icon] || HelpCircle;
    const colors = colorClasses[feature.color] || colorClasses.blue;

    return (
        <section className="relative py-20 md:py-28 overflow-hidden">
            {/* Background */}
            <div className="absolute inset-0 bg-gradient-to-b from-[#FFF5F1]/50 to-white" />
            <div className="absolute inset-0 opacity-[0.03] fun-pattern" />
            <div
                className="absolute inset-0 opacity-[0.05]"
                style={{
                    backgroundImage:
                        "linear-gradient(#F6571F 1px, transparent 1px), linear-gradient(90deg, #F6571F 1px, transparent 1px)",
                    backgroundSize: "48px 48px",
                }}
            />

            <div className="container mx-auto px-4 relative z-10">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6 }}
                >
                    {/* Breadcrumb */}
                    <Link
                        href="/features"
                        className="inline-flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-[#F6571F] mb-10 transition-colors group"
                    >
                        <ArrowLeft size={16} className="transition-transform group-hover:-translate-x-1" />
                        Back to Features
                    </Link>

                    <div className="grid lg:grid-cols-2 gap-12 items-center">
                        {/* Content */}
                        <div>
                            <div
                                className={`inline-flex items-center gap-2 ${colors.light} ${colors.text} px-4 py-2 rounded-full mb-6`}
                            >
                                <Icon size={18} />
                                <span className="text-sm font-semibold">{feature.title}</span>
                            </div>

                            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-slate-900 leading-[1.1] mb-6">
                                {feature.tagline}
                            </h1>

                            <p className="text-lg md:text-xl text-slate-500 leading-relaxed mb-8">
                                {feature.description}
                            </p>

                            <div className="flex flex-col sm:flex-row items-start gap-4">
                                <Button
                                    asChild
                                    size="lg"
                                    className="h-12 px-8 text-base font-bold rounded-xl bg-[#F6571F] hover:bg-[#E44D1B] text-white shadow-xl shadow-[#F6571F]/10 border-0"
                                >
                                    <Link href="/signup">
                                        Start free trial
                                        <ArrowRight size={18} className="ml-2" />
                                    </Link>
                                </Button>
                                <Button
                                    asChild
                                    variant="outline"
                                    size="lg"
                                    className="h-12 px-8 text-base font-bold rounded-xl border-2 hover:bg-[#FFF5F1] hover:text-[#F6571F] hover:border-[#F6571F]/20"
                                >
                                    <Link href="/demo">Watch demo</Link>
                                </Button>
                            </div>
                        </div>

                        {/* Raw SVG Mockup with "Living" Animations */}
                        <motion.div
                            initial={{ opacity: 0, x: 50, scale: 0.95 }}
                            animate={{ opacity: 1, x: 0, scale: 1 }}
                            transition={{ duration: 1, type: "spring", bounce: 0.3 }}
                            className="relative flex justify-center items-center"
                        >
                            <motion.div
                                animate={{
                                    y: [0, -20, 0],
                                    rotate: [0, 1, -1, 0]
                                }}
                                transition={{
                                    duration: 8,
                                    repeat: Infinity,
                                    ease: "easeInOut"
                                }}
                                className="relative z-20 w-full drop-shadow-[0_20px_50px_rgba(0,0,0,0.05)]"
                            >
                                <Image
                                    src={mockupMap[feature.slug] || SchedulingSVG}
                                    alt={feature.title}
                                    width={1000}
                                    height={800}
                                    className="w-full h-auto object-contain"
                                    priority
                                />
                            </motion.div>
                        </motion.div>
                    </div>
                </motion.div>
            </div>
        </section>
    );
};

// Benefits Section
const BenefitsSection = ({ feature }: { feature: FeaturePageData }) => {
    const colors = colorClasses[feature.color] || colorClasses.blue;

    return (
        <section className="py-16 md:py-24">
            <div className="container mx-auto px-4">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="text-center mb-12"
                >
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                        Why you'll love it
                    </h2>
                    <p className="text-lg text-slate-500 max-w-2xl mx-auto">
                        See how {feature.title.toLowerCase()} transforms the way you work.
                    </p>
                </motion.div>

                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {feature.benefits.map((benefit, index) => (
                        <motion.div
                            key={benefit.title}
                            initial={{ opacity: 0, scale: 0.9, y: 30 }}
                            whileInView={{ opacity: 1, scale: 1, y: 0 }}
                            viewport={{ once: true, margin: "-50px" }}
                            transition={{ duration: 0.5, delay: index * 0.1, type: "spring", stiffness: 100 }}
                            whileHover={{ y: -8, transition: { duration: 0.2 } }}
                            className="p-8 rounded-[2rem] bg-white border border-slate-100 shadow-sm hover:shadow-2xl hover:border-[#F6571F]/10 transition-all duration-300 group"
                        >
                            <div className={`w-14 h-14 rounded-2xl ${colors.light} ${colors.text} flex items-center justify-center mb-6 shadow-inner group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500`}>
                                <Check size={24} className="stroke-[3px]" />
                            </div>
                            <h3 className="text-xl font-black text-slate-900 mb-3 tracking-tight">
                                {benefit.title}
                            </h3>
                            <p className="text-slate-500 text-sm leading-relaxed font-medium">
                                {benefit.description}
                            </p>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

// Capabilities Section
const CapabilitiesSection = ({ feature }: { feature: FeaturePageData }) => {
    const colors = colorClasses[feature.color] || colorClasses.blue;

    return (
        <section className="py-16 md:py-24 bg-slate-50">
            <div className="container mx-auto px-4">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="text-center mb-12"
                >
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                        Key capabilities
                    </h2>
                    <p className="text-lg text-slate-500 max-w-2xl mx-auto">
                        Everything included to help you succeed.
                    </p>
                </motion.div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
                    {feature.capabilities.map((capability, index) => (
                        <motion.div
                            key={capability.title}
                            initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.5, delay: index * 0.1 }}
                            className="flex gap-6 p-4 rounded-2xl hover:bg-white hover:shadow-xl hover:shadow-[#F6571F]/5 transition-all duration-300 group"
                        >
                            <div className={`w-3 h-3 rounded-full ${colors.bg} mt-2 flex-shrink-0 group-hover:scale-150 transition-transform shadow-[0_0_10px_rgba(0,0,0,0)] group-hover:shadow-[0_0_15px_var(--primary)]`} />
                            <div>
                                <h3 className="font-black text-slate-900 mb-2 text-lg tracking-tight">
                                    {capability.title}
                                </h3>
                                <p className="text-sm text-slate-500 leading-relaxed font-medium">
                                    {capability.description}
                                </p>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

// CTA Section
const CTASection = ({ feature }: { feature: FeaturePageData }) => {
    return (
        <section className="py-16 md:py-24">
            <div className="container mx-auto px-4">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="max-w-3xl mx-auto text-center"
                >
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                        Ready to get started?
                    </h2>
                    <p className="text-lg text-slate-500 mb-8">
                        Try {feature.title.toLowerCase()} free for 14 days. No credit card required.
                    </p>
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                        <Button
                            asChild
                            size="lg"
                            className="h-12 px-8 text-base font-bold rounded-xl bg-[#F6571F] hover:bg-[#E44D1B] text-white shadow-xl shadow-[#F6571F]/10 border-0"
                        >
                            <Link href="/signup">
                                Start free trial
                                <ArrowRight size={18} className="ml-2" />
                            </Link>
                        </Button>
                        <Link
                            href="/pricing"
                            className="text-slate-600 hover:text-[#F6571F] font-bold transition-colors"
                        >
                            View pricing →
                        </Link>
                    </div>
                </motion.div>
            </div>
        </section>
    );
};

// Main Template
export default function FeaturePageTemplate({
    feature,
    mockupImage,
}: FeaturePageTemplateProps) {
    return (
        <>
            <FeatureHero feature={feature} />
            <BenefitsSection feature={feature} />
            <CapabilitiesSection feature={feature} />
            <CTASection feature={feature} />
        </>
    );
}
