"use client";

import * as React from "react";
import {
  AudioWaveform,
  BookOpen,
  Bot,
  Building2,
  Calendar,
  ChartLine,
  Command,
  CreditCard,
  FileText,
  Frame,
  GalleryVerticalEnd,
  Globe,
  Key,
  Mail,
  LayoutPanelTop,
  Map,
  MessageCircle,
  Microscope,
  PackageSearch,
  PieChart,
  Settings2,
  SquareTerminal,
  User,
  Users,
  Home,
  Info,
  Shield,
  FileCheck,
  Phone,
  LogOut,
} from "lucide-react";
import Link from "next/link";

import { NavMain } from "@/components/nav-main";
import { NavProjects } from "@/components/nav-projects";
import { NavUser } from "@/components/nav-user";
// import { TeamSwitcher } from "@/components/team-switcher";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarRail,
} from "@/components/ui/sidebar";
import { Separator } from "@radix-ui/react-separator";
import { useAuthSession } from "@/hooks/use-auth-session";
import { authClient } from "@/lib/auth.client";
import { useRouter } from "next/navigation";
import { Button } from "./ui/button";
import { useBranding } from "@/providers/branding-provider";
// import { useOrgStore } from "@/hooks/use-org-store";

// This is sample data.
const data = {
  teams: [
    {
      name: "Acme Inc",
      logo: GalleryVerticalEnd,
      plan: "Enterprise",
    },
    {
      name: "Acme Corp.",
      logo: AudioWaveform,
      plan: "Startup",
    },
    {
      name: "Evil Corp.",
      logo: Command,
      plan: "Free",
    },
  ],
  normal_link: [
    // {
    //   name: "Dashboard",
    //   url: "/dashboard",
    //   icon: LayoutPanelTop,
    // },
    {
      name: "Integrations",
      url: "/integrations",
      icon: Map,
    },
  ],
  navMain: [
    {
      title: "Playground",
      url: "#",
      icon: SquareTerminal,
      isActive: true,
      items: [
        {
          title: "History",
          url: "#",
        },
        {
          title: "Starred",
          url: "#",
        },
        {
          title: "Settings",
          url: "#",
        },
      ],
    },
    {
      title: "Models",
      url: "#",
      icon: Bot,
      items: [
        {
          title: "Genesis",
          url: "#",
        },
        {
          title: "Explorer",
          url: "#",
        },
        {
          title: "Quantum",
          url: "#",
        },
      ],
    },
    {
      title: "Documentation",
      url: "#",
      icon: BookOpen,
      items: [
        {
          title: "Introduction",
          url: "#",
        },
        {
          title: "Get Started",
          url: "#",
        },
        {
          title: "Tutorials",
          url: "#",
        },
        {
          title: "Changelog",
          url: "#",
        },
      ],
    },
    {
      title: "Settings",
      url: "#",
      icon: Settings2,
      items: [
        {
          title: "General",
          url: "#",
        },
        {
          title: "Team",
          url: "#",
        },
        {
          title: "Billing",
          url: "#",
        },
        {
          title: "Limits",
          url: "#",
        },
      ],
    },
  ],
  social_media: [
    {
      name: "Post ",
      url: "/social_media/post",
      icon: Microscope,
    },
    {
      name: "Scheduled Posts",
      url: "/scheduled-posts",
      icon: Calendar,
    },
    {
      name: "Cloud Gallery",
      url: "/media-library",
      icon: GalleryVerticalEnd,
    },
    {
      name: "Analytics",
      url: "/social_media/analytics",
      icon: ChartLine,
    },
    {
      name: "Engage",
      url: "/social_media/engage",
      icon: MessageCircle,
    },
    {
      name: "Analyze",
      url: "/social_media/analyze",
      icon: PackageSearch,
    },

    {
      name: "Profile Settings",
      url: "/settings/profile",
      icon: User,
    },
  ],
  settings: [
    // {
    //   name: "Profile",
    //   url: "/settings/profile",
    //   icon: User,
    // },
    // {
    //   name: "Team",
    //   url: "/settings/team",
    //   icon: Users,
    // },
    // {
    //   name: "Billing",
    //   url: "/settings/billing",
    //   icon: CreditCard,
    // },
    {
      name: "Organizations",
      url: "/settings/organization",
      icon: Building2,
    },
    // {
    //   name: "Roles",
    //   url: "/settings/organization/roles",
    //   icon: User,
    // },
    {
      name: "Members Management",
      url: "/settings/organization/members",
      icon: Users,
    },
  ],
  adminManagement: [
    {
      title: "Manage Credentials",
      url: "/settings/credentials",
      icon: Key,
      items: [],
    },
    {
      title: "SMTP Credentials",
      url: "/settings/smtp-credentials",
      icon: Mail,
      items: [],
    },
    {
      title: "User Management",
      url: "/settings/user-management",
      icon: Users,
      items: [],
    },
    {
      title: "Website Builder",
      url: "#",
      icon: Globe,
      isActive: true,
      items: [
        // {
        //   title: "Branding",
        //   url: "/settings/branding",
        // },
        // {
        //   title: "Home Page",
        //   url: "/settings/website/home",
        // },
        // {
        //   title: "About Us",
        //   url: "/settings/website/about",
        // },
        // {
        //   title: "Contact",
        //   url: "/settings/website/contact",
        // },
        // {
        //   title: "Privacy Policy",
        //   url: "/settings/website/privacy",
        // },
        // {
        //   title: "Pricing",
        //   url: "/settings/website/pricing",
        // },
        // {
        //   title: "Terms of Service",
        //   url: "/settings/website/terms",
        // },
      ],
    },
  ],
};

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const { user, isLoading, role } = useAuthSession();
  const router = useRouter();

  const handleLogout = async () => {
    try {
      await authClient.signOut();
      router.push("/login");
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  // Get user data with fallbacks
  const userData = {
    avatar: user?.image || "https://i.pinimg.com/736x/4a/94/7f/4a947f329636ebfb8505fb16ca5ae25c.jpg",
    name: user?.name || "User",
    email: user?.email || "",
  };

  const isReseller = role === "reseller";

  // const { activeOrganisation } = useOrgStore();



  //   // Filter based on organisation role
  //   const currentOrgRole = activeOrganisation?.role?.slug || "member";
  //   const isOwner = activeOrganisation?.isOwner || currentOrgRole === "owner";
  //   const isAdmin = currentOrgRole === "admin";

  //   // Owner sees everything (except maybe reseller specific if any)
  //   if (isOwner) {
  //     return data.settings.filter((item) => item.url !== "/settings/credentials");
  //   }

  //   // Admin can only invite members (Members Management)
  //   // Checking "Members Management" by name or URL. URL is safer.
  //   if (isAdmin) {
  //     return data.settings.filter((item) => item.url === "/settings/organization/members");
  //   }

  //   // Member sees nothing
  //   return [];
  // }, [isReseller, activeOrganisation]);

  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    setMounted(true);
  }, []);

  // Hydration mismatch fix: ensure server and initial client render match (fallback state)
  // If not mounted, or if mounted but no logo, show the fallback icon.
  // If mounted and has logo, show the logo.
  // const showLogo = mounted && activeOrganisation?.logo;
  // const orgName = mounted ? (activeOrganisation?.name || "Veblika") : "Veblika";

  const branding = useBranding();
  const showLogo = mounted && !!branding.logo;
  const orgName = mounted ? (branding.companyName || "Veblika") : "Veblika";

  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader>
        <Link href="/" className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            {showLogo ? (
              <img
                src={branding.logo}
                className="h-8 w-8 rounded-lg object-contain bg-white"
                alt={orgName}
              />
            ) : (
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground border">
                <Building2 className="h-4 w-4" />
              </div>
            )}
          </div>
          <span className="text-black-600 font-medium text-xl truncate max-w-[150px]">
            {orgName}
          </span>
        </Link>

      </SidebarHeader>
      <SidebarContent>
        {/* <NavMain items={data.navMain} /> */}
        <NavProjects projects={data.normal_link} />
        <NavProjects heading="Social Media" projects={data.social_media} />
        {isReseller && <NavMain heading="Admin Management" items={data.adminManagement} />}
      </SidebarContent>
      <SidebarFooter>
        {/* {!isLoading && (
          <NavUser
            user={userData}
            onLogout={handleLogout}
          />
          // <TeamSwitcher />
        )} */}
        <Button variant="outline" size="lg" onClick={handleLogout} className="w-full bg-red-600 text-white">Logout <LogOut className="ml-2 h-4 w-4" /></Button>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
