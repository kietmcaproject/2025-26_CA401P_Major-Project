"use client"

import * as React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Image as ImageIcon, Search, Trash2, Eye, Copy, Link as LinkIcon } from "lucide-react"
import api, { ImageApi } from "@/utils/api"
import { toast } from "sonner"
import { cn } from "@/lib/utils"
import { format } from "date-fns"

interface MediaItem {
  _id: string
  userId: string
  resellerId: string | null
  url: string
  name: string
  type: "image" | "video"
  size: number
  createdAt: string
  updatedAt: string
}

interface GalleryResponse {
  success: boolean
  items: MediaItem[]
}

interface UploadResponse {
  success: boolean
  media?: MediaItem
}

interface MediaGalleryProps {
  onSelect?: (media: MediaItem) => void
  selectable?: boolean
}

export function MediaGallery({ onSelect, selectable = false }: MediaGalleryProps) {
  const [mediaItems, setMediaItems] = React.useState<MediaItem[]>([])
  const [filteredItems, setFilteredItems] = React.useState<MediaItem[]>([])
  const [isUploading, setIsUploading] = React.useState(false)
  const [isLoading, setIsLoading] = React.useState(true)
  const [isDragging, setIsDragging] = React.useState(false)
  const [searchQuery, setSearchQuery] = React.useState("")
  const [activeFilter, setActiveFilter] = React.useState<"all" | "images" | "videos">("all")
  const [previewItem, setPreviewItem] = React.useState<MediaItem | null>(null)
  const [deleteItem, setDeleteItem] = React.useState<MediaItem | null>(null)
  const [uploadProgress, setUploadProgress] = React.useState<Record<string, number>>({})
  const fileInputRef = React.useRef<HTMLInputElement>(null)

  const fetchGallery = React.useCallback(async () => {
    setIsLoading(true)
    try {
      const { data } = await api.get<GalleryResponse>("/social-media/media-gallery")
      setMediaItems(data?.items || [])
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Failed to load media gallery")
    } finally {
      setIsLoading(false)
    }
  }, [])

  React.useEffect(() => {
    fetchGallery()
  }, [fetchGallery])

  React.useEffect(() => {
    let filtered = mediaItems

    if (activeFilter === "images") {
      filtered = filtered.filter((item) => item.type === "image")
    } else if (activeFilter === "videos") {
      filtered = filtered.filter((item) => item.type === "video")
    }

    if (searchQuery) {
      filtered = filtered.filter((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    setFilteredItems(filtered)
  }, [mediaItems, activeFilter, searchQuery])

  const handleFileUpload = async (files: FileList | null) => {
    if (!files || files.length === 0) return

    setIsUploading(true)
    const newlyUploaded: MediaItem[] = []

    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      const isImage = file.type.startsWith("image/")
      const isVideo = file.type.startsWith("video/")

      if (!isImage && !isVideo) {
        toast.error(`${file.name} is not a valid image or video file`)
        continue
      }

      try {
        const formData = new FormData()
        formData.append(isImage ? "image" : "video", file)

        const { data } = await ImageApi.post<UploadResponse>("/social-media/upload-media", formData, {
          onUploadProgress: (progressEvent) => {
            const progress = progressEvent.total
              ? Math.round((progressEvent.loaded * 100) / progressEvent.total)
              : 0
            setUploadProgress((prev) => ({ ...prev, [file.name]: progress }))
          },
        })

        if (data?.media) {
          newlyUploaded.push(data.media)
        }
      } catch (error: any) {
        toast.error(error?.response?.data?.message || `Failed to upload ${file.name}`)
      }
    }

    if (newlyUploaded.length > 0) {
      setMediaItems((prev) => [...newlyUploaded, ...prev])
      toast.success(`Successfully uploaded ${newlyUploaded.length} file(s)`)
    }

    setIsUploading(false)
    setUploadProgress({})
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
    handleFileUpload(e.dataTransfer.files)
  }

  const handleDelete = async (item: MediaItem) => {
    try {
      await api.delete(`/social-media/media-gallery/${item._id}`)
      setMediaItems((prev) => prev.filter((m) => m._id !== item._id))
      setDeleteItem(null)
      toast.success("Media deleted successfully")
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Failed to delete media")
    }
  }

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url)
    toast.success("S3 URL copied to clipboard")
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`
  }

  return (
    <div className="space-y-6">
      <Card
        className={cn(
          "border-2 border-dashed transition-colors cursor-pointer",
          isDragging ? "border-primary bg-primary/5" : "border-slate-300 hover:border-primary"
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Upload className={cn("h-12 w-12 mb-4", isDragging ? "text-primary" : "text-slate-400")} />
          <p className="text-lg font-medium text-slate-700 mb-2">{isDragging ? "Drop files here" : "Drag & drop files here"}</p>
          <p className="text-sm text-slate-500 mb-4">or click to browse</p>
          <Badge variant="secondary">Images & Videos supported</Badge>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,video/*"
            onChange={(e) => handleFileUpload(e.target.files)}
            className="hidden"
            disabled={isUploading}
          />
        </CardContent>
      </Card>

      {Object.keys(uploadProgress).length > 0 && (
        <Card>
          <CardContent className="py-4 space-y-2">
            {Object.entries(uploadProgress).map(([name, progress]) => (
              <div key={name} className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="truncate">{name}</span>
                  <span>{progress}%</span>
                </div>
                <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <Tabs value={activeFilter} onValueChange={(v) => setActiveFilter(v as "all" | "images" | "videos")} className="w-full sm:w-auto">
          <TabsList>
            <TabsTrigger value="all">All ({mediaItems.length})</TabsTrigger>
            <TabsTrigger value="images">Images ({mediaItems.filter((m) => m.type === "image").length})</TabsTrigger>
            <TabsTrigger value="videos">Videos ({mediaItems.filter((m) => m.type === "video").length})</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input placeholder="Search media..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9" />
        </div>
      </div>

      {isLoading ? (
        <Card className="p-12 text-center">
          <p className="text-slate-500">Loading gallery...</p>
        </Card>
      ) : filteredItems.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="flex flex-col items-center gap-4">
            <ImageIcon className="h-16 w-16 text-slate-300" />
            <div>
              <h3 className="text-xl font-semibold text-slate-700">No Media Found</h3>
              <p className="text-slate-500 mt-2">{searchQuery ? "No media matches your search" : "Upload your first image or video to get started"}</p>
            </div>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredItems.map((item) => (
            <Card key={item._id} className="group overflow-hidden hover:shadow-lg transition-shadow cursor-pointer" onClick={() => selectable && onSelect?.(item)}>
              <div className="relative aspect-square bg-slate-100">
                {item.type === "image" ? (
                  <img src={item.url} alt={item.name} className="w-full h-full object-cover" />
                ) : (
                  <video src={item.url} className="w-full h-full object-cover" muted playsInline preload="metadata" />
                )}

                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <Button
                    size="icon"
                    variant="secondary"
                    className="h-8 w-8"
                    onClick={(e) => {
                      e.stopPropagation()
                      setPreviewItem(item)
                    }}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="secondary"
                    className="h-8 w-8"
                    onClick={(e) => {
                      e.stopPropagation()
                      handleCopyUrl(item.url)
                    }}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="destructive"
                    className="h-8 w-8"
                    onClick={(e) => {
                      e.stopPropagation()
                      setDeleteItem(item)
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <CardContent className="p-3 space-y-2">
                <p className="text-sm font-medium truncate">{item.name}</p>
                <div className="flex justify-between text-xs text-slate-500">
                  <span>{formatFileSize(item.size)}</span>
                  <span>{format(new Date(item.createdAt), "MMM d")}</span>
                </div>
                <div className="rounded-md border bg-slate-50 px-2 py-1 text-xs text-slate-600">
                  <div className="mb-1 flex items-center gap-1 font-medium text-slate-700">
                    <LinkIcon className="h-3 w-3" />
                    Live S3 URL
                  </div>
                  <p className="truncate" title={item.url}>{item.url}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!previewItem} onOpenChange={() => setPreviewItem(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{previewItem?.name}</DialogTitle>
          </DialogHeader>
          <div className="mt-2 space-y-3">
            {previewItem?.type === "image" ? (
              <img src={previewItem.url} alt={previewItem.name} className="w-full h-auto max-h-[70vh] object-contain" />
            ) : previewItem?.type === "video" ? (
              <video src={previewItem.url} controls className="w-full h-auto max-h-[70vh]" />
            ) : null}
            <div className="text-xs text-slate-600 break-all">
              <span className="font-medium">S3 URL:</span> {previewItem?.url}
            </div>
            <div className="text-xs text-slate-600">
              <span className="font-medium">Size:</span> {previewItem ? formatFileSize(previewItem.size) : "-"}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteItem} onOpenChange={() => setDeleteItem(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Media?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove "{deleteItem?.name}" from your gallery record. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteItem && handleDelete(deleteItem)} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
