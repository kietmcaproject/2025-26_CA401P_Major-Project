"use client"

import * as React from "react"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useAuthSession } from "@/hooks/use-auth-session"
import { Spinner } from "@/components/ui/spinner"
import { toast } from "sonner";
import api from "@/utils/api";
import { useColorTheme, type Color } from "@/providers/color-theme-provider"
import { Check } from "lucide-react"
import { cn } from "@/lib/utils"
import { QRCodeSVG } from "qrcode.react"

export function ProfileSettings() {
  const { user, isLoading } = useAuthSession();
  const { color, setColor } = useColorTheme()
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = React.useState(false);
  const [isMfaStatusLoading, setIsMfaStatusLoading] = React.useState(false);
  const [isMfaSetupLoading, setIsMfaSetupLoading] = React.useState(false);
  const [isMfaVerifyLoading, setIsMfaVerifyLoading] = React.useState(false);
  const [isMfaDisableLoading, setIsMfaDisableLoading] = React.useState(false);
  const [mfaEnabled, setMfaEnabled] = React.useState(false);
  const [mfaPreferred, setMfaPreferred] = React.useState(false);
  const [mfaSecret, setMfaSecret] = React.useState("");
  const [mfaCode, setMfaCode] = React.useState("");

  if (isLoading) {
    return (
      <div className="p-6 flex items-center justify-center min-h-[400px]">
        <Spinner />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="p-6">
        <div className="rounded-md border border-destructive bg-destructive/5 px-4 py-3 text-sm text-destructive">
          No user session found. Please login.
        </div>
      </div>
    );
  }

  const getInitials = (name: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }

    // Validate file size (e.g., 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image size should be less than 5MB");
      return;
    }

    try {
      setIsUploading(true);
      const formData = new FormData();
      formData.append("image", file);

      const { data } = await api.post("/user/profile-photo", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      if (data.success) {
        toast.success("Profile photo updated!");
        setTimeout(() => window.location.reload(), 400);
      }
    } catch (error: any) {
      console.error("Error uploading photo:", error);
      toast.error(error.response?.data?.message || "Failed to update profile photo");
    } finally {
      setIsUploading(false);
      // Reset input
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const displayName = user.name || user.email || "User";
  const displayEmail = user.email || "No email";
  const profileData = user as any;
  const addressLine = profileData?.addressline || "N/A";
  const state = profileData?.state || "N/A";
  const city = profileData?.city || "N/A";
  const country = profileData?.country || "N/A";
  const pincode = profileData?.pincode || "N/A";
  const phone = profileData?.phone || "N/A";

  const colors: { value: Color; class: string }[] = [
    { value: "orange", class: "bg-[#F6571F]" },
    { value: "pink", class: "bg-[#EC4899]" },
    { value: "green", class: "bg-[#22C55E]" },
    { value: "blue", class: "bg-[#3B82F6]" },
    { value: "slate", class: "bg-[#1E293B]" },
  ]

  const mfaIssuer = process.env.NEXT_PUBLIC_MFA_ISSUER || "Veblika";
  const otpAuthUrl = React.useMemo(() => {
    if (!mfaSecret || !displayEmail || displayEmail === "No email") return "";
    const label = encodeURIComponent(`${mfaIssuer}:${displayEmail}`);
    const issuer = encodeURIComponent(mfaIssuer);
    const secret = encodeURIComponent(mfaSecret);
    return `otpauth://totp/${label}?secret=${secret}&issuer=${issuer}`;
  }, [displayEmail, mfaIssuer, mfaSecret]);

  const fetchMfaStatus = React.useCallback(async () => {
    try {
      setIsMfaStatusLoading(true);
      const { data } = await api.get("/user/mfa/status");
      const payload = data?.data || {};
      setMfaEnabled(Boolean(payload?.enabled));
      setMfaPreferred(Boolean(payload?.preferred));
    } catch (error: any) {
      console.error("Error fetching MFA status:", error);
      setMfaEnabled(false);
      setMfaPreferred(false);
    } finally {
      setIsMfaStatusLoading(false);
    }
  }, []);

  React.useEffect(() => {
    if (!user) return;
    fetchMfaStatus();
  }, [user, fetchMfaStatus]);

  const handleStartMfaSetup = async () => {
    try {
      setIsMfaSetupLoading(true);
      const { data } = await api.post("/user/mfa/setup");
      const secretCode = String(data?.data?.secretCode || "").trim();
      if (!secretCode) {
        toast.error("Unable to start MFA setup");
        return;
      }
      setMfaSecret(secretCode);
      setMfaCode("");
      toast.success("Scan the QR code and enter the authenticator code");
    } catch (error: any) {
      console.error("Error starting MFA setup:", error);
      toast.error(error.response?.data?.message || "Failed to start MFA setup");
    } finally {
      setIsMfaSetupLoading(false);
    }
  };

  const handleVerifyMfaSetup = async () => {
    const normalizedCode = mfaCode.replace(/\D/g, "").slice(0, 6);
    if (!/^\d{6}$/.test(normalizedCode)) {
      toast.error("Enter a valid 6-digit code");
      return;
    }

    try {
      setIsMfaVerifyLoading(true);
      await api.post("/user/mfa/verify", { code: normalizedCode });
      toast.success("MFA enabled successfully");
      setMfaSecret("");
      setMfaCode("");
      await fetchMfaStatus();
    } catch (error: any) {
      console.error("Error verifying MFA setup:", error);
      toast.error(error.response?.data?.message || "Failed to verify MFA setup");
    } finally {
      setIsMfaVerifyLoading(false);
    }
  };

  const handleDisableMfa = async () => {
    try {
      setIsMfaDisableLoading(true);
      await api.post("/user/mfa/disable");
      toast.success("MFA disabled");
      setMfaSecret("");
      setMfaCode("");
      await fetchMfaStatus();
    } catch (error: any) {
      console.error("Error disabling MFA:", error);
      toast.error(error.response?.data?.message || "Failed to disable MFA");
    } finally {
      setIsMfaDisableLoading(false);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Profile Settings</h1>
      <p className="text-sm text-muted-foreground">Update your personal information</p>

      <Card className="mt-6 p-6">
        <h3 className="text-lg font-semibold">Profile details</h3>

        <div className="mt-6 space-y-4">
          {/* Profile row */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div className="flex items-center gap-4">
              <Avatar className="h-12 w-12">
                <AvatarImage
                  src={
                    user.image ||
                    profileData?.profilePicture ||
                    profileData?.profile_pic ||
                    ""
                  }
                  alt={displayName}
                />
                <AvatarFallback>{getInitials(displayName)}</AvatarFallback>
              </Avatar>
                <div>
                  <div className="font-medium">{displayName}</div>
                  <div className="text-sm text-muted-foreground">
                    Verified account
                  </div>
                </div>
              </div>
            <div className="md:flex md:justify-end">
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept="image/*"
                onChange={handleFileChange}
              />
              <Button
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
              >
                {isUploading ? (
                  <>
                    <Spinner className="mr-2 h-4 w-4" />
                    Uploading...
                  </>
                ) : (
                  "Change photo"
                )}
              </Button>
            </div>
          </div>

          {/* Email row */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div className="text-sm">Email Address</div>
            <div className="flex flex-col items-start gap-3 md:flex-row md:items-center md:justify-end md:gap-4">
              <div className="text-sm text-muted-foreground">{displayEmail}</div>
            </div>
          </div>

          {/* Name row */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div className="text-sm">Full Name</div>
            <div className="flex flex-col items-start gap-3 md:flex-row md:items-center md:justify-end md:gap-4">
              <div className="text-sm text-muted-foreground">{displayName}</div>
            </div>
          </div>

          {/* Phone row */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div className="text-sm">Phone Number</div>
            <div className="flex flex-col items-start gap-3 md:flex-row md:items-center md:justify-end md:gap-4">
              <div className="text-sm text-muted-foreground">{phone}</div>
            </div>
          </div>

          {/* Address row */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div className="text-sm">Address Line</div>
            <div className="flex flex-col items-start gap-3 md:flex-row md:items-center md:justify-end md:gap-4">
              <div className="text-sm text-muted-foreground">{addressLine}</div>
            </div>
          </div>

          {/* State row */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div className="text-sm">State</div>
            <div className="flex flex-col items-start gap-3 md:flex-row md:items-center md:justify-end md:gap-4">
              <div className="text-sm text-muted-foreground">{state}</div>
            </div>
          </div>

          {/* City row */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div className="text-sm">City</div>
            <div className="flex flex-col items-start gap-3 md:flex-row md:items-center md:justify-end md:gap-4">
              <div className="text-sm text-muted-foreground">{city}</div>
            </div>
          </div>

          {/* Country row */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div className="text-sm">Country</div>
            <div className="flex flex-col items-start gap-3 md:flex-row md:items-center md:justify-end md:gap-4">
              <div className="text-sm text-muted-foreground">{country}</div>
            </div>
          </div>

          {/* Pincode row */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div className="text-sm">Pincode</div>
            <div className="flex flex-col items-start gap-3 md:flex-row md:items-center md:justify-end md:gap-4">
              <div className="text-sm text-muted-foreground">{pincode}</div>
            </div>
          </div>

          {/* Account Created row */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div className="text-sm">Account Created</div>
            <div className="flex flex-col items-start gap-3 md:flex-row md:items-center md:justify-end md:gap-4">
              <div className="text-sm text-muted-foreground">
                {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "N/A"}
              </div>
            </div>
          </div>

          {/* Theme row */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div className="text-sm">Theme</div>
            <div className="flex flex-wrap items-center gap-2 md:justify-end">
              {colors.map((c) => (
                <button
                  key={c.value}
                  onClick={() => setColor(c.value)}
                  className={cn(
                    "h-6 w-6 rounded-full flex items-center justify-center transition-all hover:scale-110 focus:outline-none ring-offset-background focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                    c.class,
                    color === c.value && "ring-2 ring-offset-2 ring-ring"
                  )}
                  aria-label={`Set theme to ${c.value}`}
                >
                  {color === c.value && <Check className="h-3 w-3 text-white" />}
                </button>
              ))}
              <div className="ml-2">
                <Button variant="outline" size="sm" onClick={() => setColor("orange")}>Reset</Button>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <Card className="mt-6 p-6">
        <h3 className="text-lg font-semibold">Two-factor authentication (MFA)</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Protect your account with a time-based code from an authenticator app.
        </p>

        <div className="mt-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-3 border-b pb-4">
            <div>
              <div className="text-sm font-medium">Current status</div>
              <div className="text-sm text-muted-foreground">
                {isMfaStatusLoading
                  ? "Checking..."
                  : mfaEnabled
                    ? mfaPreferred
                      ? "Enabled and preferred"
                      : "Enabled"
                    : "Disabled"}
              </div>
            </div>
            <div className="flex items-center gap-2">
              {!mfaEnabled ? (
                <Button onClick={handleStartMfaSetup} disabled={isMfaSetupLoading || isMfaStatusLoading}>
                  {isMfaSetupLoading ? "Preparing..." : "Enable MFA"}
                </Button>
              ) : (
                <Button
                  variant="destructive"
                  onClick={handleDisableMfa}
                  disabled={isMfaDisableLoading || isMfaStatusLoading}
                >
                  {isMfaDisableLoading ? "Disabling..." : "Disable MFA"}
                </Button>
              )}
            </div>
          </div>

          {mfaSecret && (
            <div className="space-y-4">
              <div className="text-sm text-muted-foreground">
                1. Scan this QR code in Google Authenticator, Microsoft Authenticator, or Authy.
              </div>
              <div className="flex justify-center rounded-md border bg-background p-4">
                <QRCodeSVG value={otpAuthUrl} size={220} includeMargin />
              </div>

              <div className="space-y-2">
                <div className="text-sm text-muted-foreground">
                  2. If you cannot scan, add this secret manually:
                </div>
                <div className="rounded-md border bg-muted/30 p-3 font-mono text-sm break-all">
                  {mfaSecret}
                </div>
                <div className="text-xs text-muted-foreground break-all">
                  OTP URL: {otpAuthUrl}
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-sm text-muted-foreground">
                  3. Enter the 6-digit code from your authenticator app to complete setup.
                </div>
                <Input
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  autoComplete="one-time-code"
                  value={mfaCode}
                  onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="123456"
                />
                <div className="flex items-center gap-2">
                  <Button onClick={handleVerifyMfaSetup} disabled={isMfaVerifyLoading}>
                    {isMfaVerifyLoading ? "Verifying..." : "Verify and Enable"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setMfaSecret("");
                      setMfaCode("");
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </Card>
    </div>
  )
}

export default ProfileSettings
