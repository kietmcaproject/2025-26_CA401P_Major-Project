"use client"

import * as React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Play, Eye } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface YouTubePreviewProps {
    channelName?: string
    channelAvatar?: string
    videoUrl?: string
    thumbnailUrl?: string
    title?: string
    description?: string
}

export function YouTubePreview({
    channelName = "Your Channel",
    channelAvatar,
    videoUrl,
    thumbnailUrl,
    title = "",
    description = ""
}: YouTubePreviewProps) {
    return (
        <Card className="max-w-md mx-auto border-slate-200">
            {/* Thumbnail */}
            <div className="relative bg-black aspect-video">
                {thumbnailUrl || videoUrl ? (
                    <>
                        <img
                            src={thumbnailUrl || videoUrl}
                            alt="Video thumbnail"
                            className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                            <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-700 transition-colors cursor-pointer">
                                <Play className="h-8 w-8 text-white fill-white ml-1" />
                            </div>
                        </div>
                        {/* Duration badge */}
                        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded">
                            0:00
                        </div>
                    </>
                ) : (
                    <div className="flex items-center justify-center h-full text-slate-400">
                        <div className="text-center">
                            <div className="text-4xl mb-2">🎥</div>
                            <p className="text-sm">Your video thumbnail will appear here</p>
                        </div>
                    </div>
                )}
            </div>

            {/* Video Info */}
            <div className="p-3">
                <div className="flex gap-3">
                    <Avatar className="h-9 w-9 flex-shrink-0">
                        <AvatarImage src={channelAvatar} />
                        <AvatarFallback className="bg-red-600 text-white text-sm">
                            {channelName.charAt(0).toUpperCase()}
                        </AvatarFallback>
                    </Avatar>

                    <div className="flex-1 min-w-0">
                        {/* Title */}
                        <h3 className="font-semibold text-sm line-clamp-2 text-slate-900">
                            {title || "Your video title will appear here"}
                        </h3>

                        {/* Channel name and stats */}
                        <div className="mt-1 text-xs text-slate-600">
                            <div>{channelName}</div>
                            <div className="flex items-center gap-1">
                                <span>0 views</span>
                                <span>•</span>
                                <span>Just now</span>
                            </div>
                        </div>

                        {/* Description preview */}
                        {description && (
                            <div className="mt-2 text-xs text-slate-600 line-clamp-2">
                                {description}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </Card>
    )
}
