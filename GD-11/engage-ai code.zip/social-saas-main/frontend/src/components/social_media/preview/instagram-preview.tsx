"use client"

import * as React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Heart, MessageCircle, Send, Bookmark, MoreHorizontal } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface InstagramPreviewProps {
    username?: string
    userAvatar?: string
    imageUrl?: string
    videoUrl?: string
    caption?: string
}

export function InstagramPreview({
    username = "your_account",
    userAvatar,
    imageUrl,
    videoUrl,
    caption = ""
}: InstagramPreviewProps) {
    // Format caption with hashtags highlighted
    const formatCaption = (text: string) => {
        if (!text) return null

        const parts = text.split(/(\s+)/)
        return parts.map((part, index) => {
            if (part.startsWith('#')) {
                return (
                    <span key={index} className="text-blue-600 font-normal">
                        {part}
                    </span>
                )
            }
            if (part.startsWith('@')) {
                return (
                    <span key={index} className="text-blue-600 font-normal">
                        {part}
                    </span>
                )
            }
            return <span key={index}>{part}</span>
        })
    }

    return (
        <Card className="max-w-md mx-auto border-slate-200">
            {/* Header */}
            <div className="flex items-center justify-between p-3 border-b">
                <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                        <AvatarImage src={userAvatar} />
                        <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white text-xs">
                            {username.charAt(0).toUpperCase()}
                        </AvatarFallback>
                    </Avatar>
                    <span className="font-semibold text-sm">{username}</span>
                </div>
                <MoreHorizontal className="h-5 w-5 text-slate-600" />
            </div>

            {/* Image/Video */}
            <div className="relative bg-slate-100 aspect-square">
                {imageUrl ? (
                    <img
                        src={imageUrl}
                        alt="Post"
                        className="w-full h-full object-cover"
                    />
                ) : videoUrl ? (
                    <video
                        src={videoUrl}
                        className="w-full h-full object-cover"
                        controls={false}
                    />
                ) : (
                    <div className="flex items-center justify-center h-full text-slate-400">
                        <div className="text-center">
                            <div className="text-4xl mb-2">📷</div>
                            <p className="text-sm">Your image will appear here</p>
                        </div>
                    </div>
                )}
            </div>

            {/* Actions */}
            <div className="p-3 space-y-2">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <Heart className="h-6 w-6" />
                        <MessageCircle className="h-6 w-6" />
                        <Send className="h-6 w-6" />
                    </div>
                    <Bookmark className="h-6 w-6" />
                </div>

                {/* Likes */}
                <div className="font-semibold text-sm">0 likes</div>

                {/* Caption */}
                {caption && (
                    <div className="text-sm">
                        <span className="font-semibold mr-2">{username}</span>
                        <span className="text-slate-800">{formatCaption(caption)}</span>
                    </div>
                )}

                {/* Timestamp */}
                <div className="text-xs text-slate-500 uppercase">Just now</div>
            </div>
        </Card>
    )
}
