"use client"

import * as React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { ThumbsUp, MessageCircle, Share2, Globe, MoreHorizontal } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface FacebookPreviewProps {
    pageName?: string
    pageAvatar?: string
    imageUrl?: string
    videoUrl?: string
    content?: string
}

export function FacebookPreview({
    pageName = "Your Page",
    pageAvatar,
    imageUrl,
    videoUrl,
    content = ""
}: FacebookPreviewProps) {
    return (
        <Card className="max-w-md mx-auto border-slate-200">
            {/* Header */}
            <div className="p-4 border-b">
                <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                        <Avatar className="h-10 w-10">
                            <AvatarImage src={pageAvatar} />
                            <AvatarFallback className="bg-blue-600 text-white">
                                {pageName.charAt(0).toUpperCase()}
                            </AvatarFallback>
                        </Avatar>
                        <div>
                            <div className="font-semibold text-sm">{pageName}</div>
                            <div className="flex items-center gap-1 text-xs text-slate-500">
                                <span>Just now</span>
                                <span>·</span>
                                <Globe className="h-3 w-3" />
                            </div>
                        </div>
                    </div>
                    <MoreHorizontal className="h-5 w-5 text-slate-600" />
                </div>

                {/* Content */}
                {content && (
                    <div className="mt-3 text-sm text-slate-800 whitespace-pre-wrap">
                        {content}
                    </div>
                )}
            </div>

            {/* Image/Video */}
            {(imageUrl || videoUrl) && (
                <div className="relative bg-slate-100">
                    {imageUrl ? (
                        <img
                            src={imageUrl}
                            alt="Post"
                            className="w-full object-cover"
                        />
                    ) : videoUrl ? (
                        <video
                            src={videoUrl}
                            className="w-full object-cover"
                            controls={false}
                        />
                    ) : null}
                </div>
            )}

            {!imageUrl && !videoUrl && !content && (
                <div className="bg-slate-50 p-12 text-center text-slate-400">
                    <div className="text-4xl mb-2">📝</div>
                    <p className="text-sm">Your post will appear here</p>
                </div>
            )}

            {/* Stats */}
            <div className="px-4 py-2 border-b text-xs text-slate-500">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                        <div className="flex -space-x-1">
                            <div className="w-4 h-4 rounded-full bg-blue-500 flex items-center justify-center text-white text-[10px]">
                                👍
                            </div>
                            <div className="w-4 h-4 rounded-full bg-red-500 flex items-center justify-center text-white text-[10px]">
                                ❤️
                            </div>
                        </div>
                        <span>0</span>
                    </div>
                    <div className="flex items-center gap-3">
                        <span>0 comments</span>
                        <span>0 shares</span>
                    </div>
                </div>
            </div>

            {/* Actions */}
            <div className="px-4 py-2">
                <div className="flex items-center justify-around">
                    <button className="flex items-center gap-2 px-4 py-2 hover:bg-slate-50 rounded-lg transition-colors">
                        <ThumbsUp className="h-5 w-5 text-slate-600" />
                        <span className="text-sm font-medium text-slate-600">Like</span>
                    </button>
                    <button className="flex items-center gap-2 px-4 py-2 hover:bg-slate-50 rounded-lg transition-colors">
                        <MessageCircle className="h-5 w-5 text-slate-600" />
                        <span className="text-sm font-medium text-slate-600">Comment</span>
                    </button>
                    <button className="flex items-center gap-2 px-4 py-2 hover:bg-slate-50 rounded-lg transition-colors">
                        <Share2 className="h-5 w-5 text-slate-600" />
                        <span className="text-sm font-medium text-slate-600">Share</span>
                    </button>
                </div>
            </div>
        </Card>
    )
}
