"use client"

import * as React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { ThumbsUp, MessageCircle, Repeat2, Send, MoreHorizontal } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface LinkedInPreviewProps {
    companyName?: string
    companyLogo?: string
    imageUrl?: string
    videoUrl?: string
    content?: string
}

export function LinkedInPreview({
    companyName = "Your Company",
    companyLogo,
    imageUrl,
    videoUrl,
    content = ""
}: LinkedInPreviewProps) {
    return (
        <Card className="max-w-md mx-auto border-slate-200">
            {/* Header */}
            <div className="p-4">
                <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                        <Avatar className="h-12 w-12 rounded-sm">
                            <AvatarImage src={companyLogo} />
                            <AvatarFallback className="bg-blue-700 text-white rounded-sm">
                                {companyName.charAt(0).toUpperCase()}
                            </AvatarFallback>
                        </Avatar>
                        <div>
                            <div className="font-semibold text-sm">{companyName}</div>
                            <div className="text-xs text-slate-500">Company · Just now</div>
                            <div className="text-xs text-slate-500 flex items-center gap-1">
                                <span>🌐</span>
                            </div>
                        </div>
                    </div>
                    <MoreHorizontal className="h-5 w-5 text-slate-600" />
                </div>

                {/* Content */}
                {content && (
                    <div className="mt-3 text-sm text-slate-800 whitespace-pre-wrap leading-relaxed">
                        {content}
                    </div>
                )}
            </div>

            {/* Image/Video */}
            {(imageUrl || videoUrl) && (
                <div className="relative bg-slate-100">
                    {imageUrl ? (
                        <img
                            src={imageUrl}
                            alt="Post"
                            className="w-full object-cover"
                        />
                    ) : videoUrl ? (
                        <video
                            src={videoUrl}
                            className="w-full object-cover"
                            controls={false}
                        />
                    ) : null}
                </div>
            )}

            {!imageUrl && !videoUrl && !content && (
                <div className="bg-slate-50 p-12 text-center text-slate-400">
                    <div className="text-4xl mb-2">💼</div>
                    <p className="text-sm">Your professional post will appear here</p>
                </div>
            )}

            {/* Stats */}
            <div className="px-4 py-2 border-t border-b text-xs text-slate-600">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                        <div className="flex -space-x-1">
                            <div className="w-4 h-4 rounded-full bg-blue-600 flex items-center justify-center text-white text-[10px]">
                                👍
                            </div>
                            <div className="w-4 h-4 rounded-full bg-green-600 flex items-center justify-center text-white text-[10px]">
                                💡
                            </div>
                        </div>
                        <span>0</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <span>0 comments</span>
                    </div>
                </div>
            </div>

            {/* Actions */}
            <div className="px-2 py-1">
                <div className="flex items-center justify-around">
                    <button className="flex items-center gap-2 px-3 py-2 hover:bg-slate-50 rounded transition-colors">
                        <ThumbsUp className="h-5 w-5 text-slate-600" />
                        <span className="text-sm font-medium text-slate-600">Like</span>
                    </button>
                    <button className="flex items-center gap-2 px-3 py-2 hover:bg-slate-50 rounded transition-colors">
                        <MessageCircle className="h-5 w-5 text-slate-600" />
                        <span className="text-sm font-medium text-slate-600">Comment</span>
                    </button>
                    <button className="flex items-center gap-2 px-3 py-2 hover:bg-slate-50 rounded transition-colors">
                        <Repeat2 className="h-5 w-5 text-slate-600" />
                        <span className="text-sm font-medium text-slate-600">Repost</span>
                    </button>
                    <button className="flex items-center gap-2 px-3 py-2 hover:bg-slate-50 rounded transition-colors">
                        <Send className="h-5 w-5 text-slate-600" />
                        <span className="text-sm font-medium text-slate-600">Send</span>
                    </button>
                </div>
            </div>
        </Card>
    )
}
