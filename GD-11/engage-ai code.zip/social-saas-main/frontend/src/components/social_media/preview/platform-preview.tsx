"use client"

import * as React from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { InstagramPreview } from "./instagram-preview"
import { FacebookPreview } from "./facebook-preview"
import { LinkedInPreview } from "./linkedin-preview"
import { YouTubePreview } from "./youtube-preview"

interface PlatformPreviewProps {
    selectedPlatforms?: string[]
    content?: string
    imageUrl?: string
    videoUrl?: string
    username?: string
    userAvatar?: string
    pageName?: string
    pageAvatar?: string
    companyName?: string
    companyLogo?: string
    channelName?: string
    channelAvatar?: string
    videoTitle?: string
}

export function PlatformPreview({
    selectedPlatforms = [],
    content = "",
    imageUrl,
    videoUrl,
    username,
    userAvatar,
    pageName,
    pageAvatar,
    companyName,
    companyLogo,
    channelName,
    channelAvatar,
    videoTitle
}: PlatformPreviewProps) {
    // Determine which platforms to show
    const platforms = selectedPlatforms.length > 0
        ? selectedPlatforms
        : ["INSTAGRAM", "FACEBOOK", "LINKEDIN", "YOUTUBE"]

    const [activeTab, setActiveTab] = React.useState(platforms[0] || "INSTAGRAM")

    // Update active tab when selected platforms change
    React.useEffect(() => {
        if (platforms.length > 0 && !platforms.includes(activeTab)) {
            setActiveTab(platforms[0])
        }
    }, [platforms, activeTab])

    const platformConfig = {
        INSTAGRAM: {
            label: "Instagram",
            icon: "📷",
            component: (
                <InstagramPreview
                    username={username}
                    userAvatar={userAvatar}
                    imageUrl={imageUrl}
                    videoUrl={videoUrl}
                    caption={content}
                />
            )
        },
        FACEBOOK: {
            label: "Facebook",
            icon: "📘",
            component: (
                <FacebookPreview
                    pageName={pageName}
                    pageAvatar={pageAvatar}
                    imageUrl={imageUrl}
                    videoUrl={videoUrl}
                    content={content}
                />
            )
        },
        LINKEDIN: {
            label: "LinkedIn",
            icon: "💼",
            component: (
                <LinkedInPreview
                    companyName={companyName}
                    companyLogo={companyLogo}
                    imageUrl={imageUrl}
                    videoUrl={videoUrl}
                    content={content}
                />
            )
        },
        YOUTUBE: {
            label: "YouTube",
            icon: "🎥",
            component: (
                <YouTubePreview
                    channelName={channelName}
                    channelAvatar={channelAvatar}
                    videoUrl={videoUrl}
                    thumbnailUrl={imageUrl}
                    title={videoTitle || content.split('\n')[0] || ""}
                    description={content}
                />
            )
        }
    }

    return (
        <div className="w-full">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-4 mb-4">
                    {platforms.map((platform) => {
                        const config = platformConfig[platform as keyof typeof platformConfig]
                        if (!config) return null

                        return (
                            <TabsTrigger
                                key={platform}
                                value={platform}
                                className="flex items-center gap-2"
                            >
                                <span>{config.icon}</span>
                                <span className="hidden sm:inline">{config.label}</span>
                            </TabsTrigger>
                        )
                    })}
                </TabsList>

                {platforms.map((platform) => {
                    const config = platformConfig[platform as keyof typeof platformConfig]
                    if (!config) return null

                    return (
                        <TabsContent key={platform} value={platform} className="mt-0">
                            {config.component}
                        </TabsContent>
                    )
                })}
            </Tabs>
        </div>
    )
}
