"use client"

export type CropPreset = {
  id: string
  label: string
  description: string
  aspect: number
  outputWidth: number
}

export const CROP_PRESETS: CropPreset[] = [
  {
    id: "square",
    label: "1:1",
    description: "Square",
    aspect: 1,
    outputWidth: 1080,
  },
  {
    id: "portrait",
    label: "4:5",
    description: "Portrait",
    aspect: 4 / 5,
    outputWidth: 1080,
  },
  {
    id: "landscape",
    label: "1.91:1",
    description: "Landscape",
    aspect: 1.91,
    outputWidth: 1080,
  },
]

export const DEFAULT_CROP_PRESET = CROP_PRESETS[0]

type CropImageFileOptions = {
  file: File
  preset: CropPreset
  offsetX?: number
  offsetY?: number
  zoom?: number
  imageSize?: { width: number; height: number }
  frameSize?: { width: number; height: number }
}

export async function cropImageFile({
  file,
  preset,
  offsetX = 0,
  offsetY = 0,
  zoom = 1,
  imageSize,
  frameSize,
}: CropImageFileOptions) {
  const sourceUrl = URL.createObjectURL(file)

  try {
    const image = await loadImageElement(sourceUrl)
    const sourceSize = imageSize || {
      width: image.naturalWidth,
      height: image.naturalHeight,
    }

    const outputWidth = preset.outputWidth
    const outputHeight = Math.round(outputWidth / preset.aspect)
    const mimeType = getOutputMimeType(file.type)

    const cropArea =
      frameSize && frameSize.width && frameSize.height
        ? getViewportCropArea({
            imageSize: sourceSize,
            frameSize,
            offsetX,
            offsetY,
            zoom,
          })
        : getCenteredCropArea({
            imageSize: sourceSize,
            aspect: preset.aspect,
            zoom,
          })

    const canvas = document.createElement("canvas")
    canvas.width = outputWidth
    canvas.height = outputHeight

    const context = canvas.getContext("2d")
    if (!context) {
      throw new Error("Could not create image crop")
    }

    context.drawImage(
      image,
      cropArea.x,
      cropArea.y,
      cropArea.width,
      cropArea.height,
      0,
      0,
      outputWidth,
      outputHeight
    )

    const blob = await canvasToBlob(canvas, mimeType, 0.92)
    return new File([blob], buildCroppedFileName(file.name, mimeType), {
      type: mimeType,
    })
  } finally {
    URL.revokeObjectURL(sourceUrl)
  }
}

export function readFileAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader()
    reader.onloadend = () => resolve(String(reader.result || ""))
    reader.onerror = () => reject(new Error("Failed to read file"))
    reader.readAsDataURL(file)
  })
}

export function getImageDimensions(src: string) {
  return new Promise<{ width: number; height: number }>((resolve, reject) => {
    const image = new window.Image()
    image.onload = () => resolve({ width: image.naturalWidth, height: image.naturalHeight })
    image.onerror = () => reject(new Error("Failed to load image dimensions"))
    image.src = src
  })
}

function getCenteredCropArea({
  imageSize,
  aspect,
  zoom,
}: {
  imageSize: { width: number; height: number }
  aspect: number
  zoom: number
}) {
  const imageAspect = imageSize.width / imageSize.height

  let cropWidth = imageSize.width
  let cropHeight = imageSize.height

  if (imageAspect > aspect) {
    cropHeight = imageSize.height
    cropWidth = cropHeight * aspect
  } else {
    cropWidth = imageSize.width
    cropHeight = cropWidth / aspect
  }

  cropWidth = cropWidth / zoom
  cropHeight = cropHeight / zoom

  return {
    x: (imageSize.width - cropWidth) / 2,
    y: (imageSize.height - cropHeight) / 2,
    width: cropWidth,
    height: cropHeight,
  }
}

function getViewportCropArea({
  imageSize,
  frameSize,
  offsetX,
  offsetY,
  zoom,
}: {
  imageSize: { width: number; height: number }
  frameSize: { width: number; height: number }
  offsetX: number
  offsetY: number
  zoom: number
}) {
  const baseScale = Math.max(
    frameSize.width / imageSize.width,
    frameSize.height / imageSize.height
  )
  const scale = baseScale * zoom
  const renderedWidth = imageSize.width * scale
  const renderedHeight = imageSize.height * scale

  const imageLeft = frameSize.width / 2 - renderedWidth / 2 + offsetX
  const imageTop = frameSize.height / 2 - renderedHeight / 2 + offsetY

  const x = clamp((0 - imageLeft) / scale, 0, imageSize.width)
  const y = clamp((0 - imageTop) / scale, 0, imageSize.height)
  const width = clamp(frameSize.width / scale, 1, imageSize.width - x)
  const height = clamp(frameSize.height / scale, 1, imageSize.height - y)

  return { x, y, width, height }
}

function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max)
}

function getOutputMimeType(type: string) {
  if (type === "image/jpeg" || type === "image/png" || type === "image/webp") {
    return type
  }

  return "image/png"
}

function buildCroppedFileName(originalName: string, mimeType: string) {
  const extension = mimeType.split("/")[1] || "png"
  const baseName = originalName.replace(/\.[^.]+$/, "")
  return `${baseName}-cropped.${extension}`
}

function loadImageElement(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new window.Image()
    image.onload = () => resolve(image)
    image.onerror = () => reject(new Error("Failed to load image"))
    image.src = src
  })
}

function canvasToBlob(canvas: HTMLCanvasElement, mimeType: string, quality: number) {
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (!blob) {
        reject(new Error("Failed to export cropped image"))
        return
      }

      resolve(blob)
    }, mimeType, quality)
  })
}
