"use client"

import * as React from "react"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { cn } from "@/lib/utils"
import { CROP_PRESETS, cropImageFile, type CropPreset } from "./image-crop-utils"

type ImageCropDialogProps = {
  open: boolean
  file: File | null
  onOpenChange: (open: boolean) => void
  onApply: (file: File) => void
}

export function ImageCropDialog({
  open,
  file,
  onOpenChange,
  onApply,
}: ImageCropDialogProps) {
  const frameRef = React.useRef<HTMLDivElement | null>(null)
  const dragStateRef = React.useRef<{
    pointerId: number
    startX: number
    startY: number
    originX: number
    originY: number
  } | null>(null)

  const [selectedPresetId, setSelectedPresetId] = React.useState(CROP_PRESETS[0].id)
  const [zoom, setZoom] = React.useState(1)
  const [offsetX, setOffsetX] = React.useState(0)
  const [offsetY, setOffsetY] = React.useState(0)
  const [imageUrl, setImageUrl] = React.useState("")
  const [imageSize, setImageSize] = React.useState({ width: 0, height: 0 })
  const [frameSize, setFrameSize] = React.useState({ width: 0, height: 0 })
  const [isApplying, setIsApplying] = React.useState(false)

  const selectedPreset = React.useMemo(
    () => CROP_PRESETS.find((preset) => preset.id === selectedPresetId) || CROP_PRESETS[0],
    [selectedPresetId]
  )

  React.useEffect(() => {
    if (!file || !open) {
      return
    }

    const objectUrl = URL.createObjectURL(file)
    const img = new window.Image()
    img.onload = () => {
      setImageSize({ width: img.naturalWidth, height: img.naturalHeight })
    }
    img.src = objectUrl

    setImageUrl(objectUrl)
    setZoom(1)
    setOffsetX(0)
    setOffsetY(0)

    return () => {
      URL.revokeObjectURL(objectUrl)
      setImageUrl("")
    }
  }, [file, open])

  React.useEffect(() => {
    if (open) {
      setSelectedPresetId(CROP_PRESETS[0].id)
    }
  }, [open])

  React.useEffect(() => {
    if (!open || !frameRef.current) {
      return
    }

    const node = frameRef.current
    const updateSize = () => {
      const rect = node.getBoundingClientRect()
      setFrameSize({ width: rect.width, height: rect.height })
    }

    updateSize()

    const observer = new ResizeObserver(updateSize)
    observer.observe(node)

    return () => observer.disconnect()
  }, [open, selectedPreset.aspect])

  const baseScale = React.useMemo(() => {
    if (!imageSize.width || !imageSize.height || !frameSize.width || !frameSize.height) {
      return 1
    }

    return Math.max(frameSize.width / imageSize.width, frameSize.height / imageSize.height)
  }, [imageSize, frameSize])

  const renderedWidth = imageSize.width * baseScale * zoom
  const renderedHeight = imageSize.height * baseScale * zoom

  const clampOffsets = React.useCallback(
    (nextX: number, nextY: number) => {
      const maxX = Math.max(0, (renderedWidth - frameSize.width) / 2)
      const maxY = Math.max(0, (renderedHeight - frameSize.height) / 2)

      return {
        x: clamp(nextX, -maxX, maxX),
        y: clamp(nextY, -maxY, maxY),
      }
    },
    [frameSize.height, frameSize.width, renderedHeight, renderedWidth]
  )

  React.useEffect(() => {
    const clamped = clampOffsets(offsetX, offsetY)
    if (clamped.x !== offsetX) {
      setOffsetX(clamped.x)
    }
    if (clamped.y !== offsetY) {
      setOffsetY(clamped.y)
    }
  }, [clampOffsets, offsetX, offsetY])

  const handlePointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!imageUrl) {
      return
    }

    dragStateRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      originX: offsetX,
      originY: offsetY,
    }

    event.currentTarget.setPointerCapture(event.pointerId)
  }

  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!dragStateRef.current || dragStateRef.current.pointerId !== event.pointerId) {
      return
    }

    const deltaX = event.clientX - dragStateRef.current.startX
    const deltaY = event.clientY - dragStateRef.current.startY
    const clamped = clampOffsets(
      dragStateRef.current.originX + deltaX,
      dragStateRef.current.originY + deltaY
    )

    setOffsetX(clamped.x)
    setOffsetY(clamped.y)
  }

  const handlePointerUp = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!dragStateRef.current || dragStateRef.current.pointerId !== event.pointerId) {
      return
    }

    dragStateRef.current = null
    event.currentTarget.releasePointerCapture(event.pointerId)
  }

  const handleReset = () => {
    setZoom(1)
    setOffsetX(0)
    setOffsetY(0)
  }

  const handleApply = async () => {
    if (!file || !imageUrl || !frameSize.width || !frameSize.height || !imageSize.width || !imageSize.height) {
      return
    }

    setIsApplying(true)

    try {
      const croppedFile = await cropImageFile({
        file,
        preset: selectedPreset,
        offsetX,
        offsetY,
        zoom,
        imageSize,
        frameSize,
      })

      onApply(croppedFile)
      onOpenChange(false)
    } catch (error) {
      console.error("Failed to crop image:", error)
    } finally {
      setIsApplying(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Crop Image</DialogTitle>
          <DialogDescription>
            Drag to reposition and export the crop you want to use for your post.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_260px]">
          <div className="space-y-4">
            <div
              ref={frameRef}
              className="relative mx-auto w-full max-w-2xl overflow-hidden rounded-2xl border border-slate-200 bg-slate-950 shadow-inner"
              style={{ aspectRatio: selectedPreset.aspect }}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerUp}
            >
              {imageUrl ? (
                <>
                  <img
                    src={imageUrl}
                    alt="Crop preview"
                    draggable={false}
                    className="absolute left-1/2 top-1/2 max-w-none select-none"
                    style={{
                      width: imageSize.width ? `${imageSize.width}px` : "auto",
                      height: imageSize.height ? `${imageSize.height}px` : "auto",
                      transform: `translate(calc(-50% + ${offsetX}px), calc(-50% + ${offsetY}px)) scale(${baseScale * zoom})`,
                      transformOrigin: "center center",
                    }}
                  />
                  <div className="pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/20" />
                </>
              ) : (
                <div className="flex h-full items-center justify-center text-sm text-slate-300">
                  Loading image...
                </div>
              )}
            </div>

            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
              <div className="mb-2 flex items-center justify-between text-sm">
                <span className="font-medium text-slate-700">Zoom</span>
                <span className="text-slate-500">{zoom.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="1"
                max="3"
                step="0.01"
                value={zoom}
                onChange={(event) => setZoom(Number(event.target.value))}
                className="w-full accent-blue-600"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
              <p className="text-sm font-medium text-slate-800">Aspect ratios</p>
              <p className="mt-1 text-xs text-slate-500">
                `1:1` is applied by default, and you can switch to other crops anytime.
              </p>

              <div className="mt-4 grid gap-2">
                {CROP_PRESETS.map((preset) => {
                  const isActive = preset.id === selectedPresetId
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setSelectedPresetId(preset.id)
                        handleReset()
                      }}
                      className={cn(
                        "rounded-xl border px-3 py-3 text-left transition-colors",
                        isActive
                          ? "border-blue-500 bg-blue-50 text-blue-700"
                          : "border-slate-200 bg-white text-slate-700 hover:border-slate-300"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{preset.label}</span>
                        <span className="text-xs text-slate-500">{preset.description}</span>
                      </div>
                    </button>
                  )
                })}
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-4 text-sm text-slate-600">
              <p className="font-medium text-slate-800">Tips</p>
              <ul className="mt-2 space-y-2">
                <li>Drag the image inside the frame to choose the crop.</li>
                <li>Use `1:1` for the default square crop or switch to portrait or landscape.</li>
                <li>The exported image is resized to social-friendly dimensions.</li>
              </ul>
            </div>

            <Button variant="outline" onClick={handleReset} className="w-full">
              Reset Position
            </Button>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isApplying}>
            Cancel
          </Button>
          <Button onClick={handleApply} disabled={!file || isApplying}>
            {isApplying ? "Applying..." : "Apply Crop"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max)
}
