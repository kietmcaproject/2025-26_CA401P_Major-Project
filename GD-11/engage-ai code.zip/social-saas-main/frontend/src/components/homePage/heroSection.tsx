"use client";

import React, { useRef, useState, useEffect } from 'react';
// import Navbar from './navbar';
import Container from './container';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from "@/components/ui/card";
import Image from 'next/image';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { ThumbsUp } from 'lucide-react';

const BrandLogos: Record<string, React.ReactNode> = {
  facebook: (
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
    </svg>
  ),
  instagram: (
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.622 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
    </svg>
  ),
  twitter: (
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  ),
  linkedin: (
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  ),
  youtube: (
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
    </svg>
  ),
  tiktok: (
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.59-5.71-.29-2.63.85-5.21 2.86-6.91 1.62-1.4 3.81-1.93 5.92-1.62V11.7c-1.42-.14-2.86.35-3.72 1.53-.48.65-.72 1.48-.68 2.29.13.91.56 1.78 1.25 2.38.8.76 1.88 1.05 2.9 1.02 1.39-.02 2.72-.88 3.32-2.14.33-.67.45-1.43.43-2.18-.04-4.86-.02-9.72-.03-14.58z" />
    </svg>
  ),
  pinterest: (
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.966 1.406-5.966s-.359-.72-.359-1.781c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.252 7.929-7.252 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.631-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12.017 24c6.621 0 12-5.378 12-12S18.638 0 12.017 0z" />
    </svg>
  ),
  whatsapp: (
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
    </svg>
  ),
  threads: (
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M15.422 10.373c-.563-.075-1.125-.113-1.688-.113h-.113c-.938 0-1.725.338-2.325.975-.563.638-.863 1.5-.863 2.513 0 1.013.263 1.8.825 2.4.525.563 1.2.825 1.988.825.563 0 1.05-.075 1.5-.225 1.463-.488 2.438-1.913 2.438-3.713 0-2.363-1.538-4.125-3.9-4.125-1.125 0-2.175.45-2.925 1.238-.75.825-1.125 1.95-1.125 3.338 0 1.463.375 2.625 1.125 3.413.788.825 1.875 1.238 3.113 1.238 1.125 0 2.325-.375 3.413-1.088l1.163 1.8c-1.35.975-2.925 1.463-4.575 1.463-1.875 0-3.45-.638-4.65-1.875-1.163-1.238-1.725-3-1.725-5.213 0-2.175.6-3.938 1.838-5.213 1.2-.263 2.813-1.913 4.763-1.913 3.6 0 6.075 2.588 6.075 6.3 0 2.775-1.5 5.063-3.938 5.775-.675.225-1.388.338-2.138.338-1.238 0-2.325-.375-3.188-1.125-.825-.713-1.238-1.688-1.238-2.813l.038.225.038-.225c0-1.5.488-2.738 1.425-3.675 1.013-.975 2.325-1.463 3.825-1.463.713 0 1.425.075 2.138.225l-.338 1.95z" />
    </svg>
  ),
  snapchat: (
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 0c-1.666 0-3.264.444-4.62 1.2-1.356.756-2.43 1.83-3.186 3.186C3.438 5.742 3 7.334 3 9c0 1.332.336 2.58.918 3.666-.072.048-.156.102-.246.162-.648.432-1.392.93-1.986 1.344-.54.378-.9.69-.9 1.164 0 .342.234.582.6.726 1.47.582 3.102 1.134 4.542 1.134.12 0 .234-.006.354-.018.156.402.396.792.732 1.128.9.9 2.22 1.2 3.984 1.2s3.084-.3 3.984-1.2c.336-.336.576-.726.732-1.128.12.012.234.018.354.018 1.44 0 3.072-.552 4.542-1.134.366-.144.6-.384.6-.726 0-.474-.36-.786-.9-1.164-.594-.414-1.338-.912-1.986-1.344-.09-.06-.174-.114-.246-.162.582-1.086.918-2.334.918-3.666 0-1.666-.438-3.258-1.194-4.614-.756-1.356-1.83-2.43-3.186-3.186C15.264.444 13.666 0 12 0z" />
    </svg>
  ),
  reddit: (
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.051l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.056 1.597.04.282.058.569.058.852 0 2.483-3.523 4.491-7.86 4.491-4.338 0-7.862-2.008-7.862-4.491 0-.283.02-.57.06-.852a1.735 1.735 0 0 1-1.058-1.597c0-.968.786-1.754 1.754-1.754.463 0 .875.18 1.179.465 1.209-.846 2.87-1.4 4.7-.1.465l1.012-4.746 3.481.733zM9.03 13c-.708 0-1.288.58-1.288 1.288 0 .708.58 1.288 1.288 1.288.708 0 1.288-.58 1.288-1.288 0-.708-.58-1.288-1.288-1.288zm5.94 0c-.708 0-1.288.58-1.288 1.288 0 .708.58 1.288 1.288 1.288.708 0 1.288-.58 1.288-1.288 0-.708-.58-1.288-1.288-1.288zm-5.94 4c-.11 0-.196.086-.196.196 0 .11.086.196.196.196.11 0 .196-.086.196-.196 0-.11-.086-.196-.196-.196zm5.94 0c-.11 0-.196.086-.196.196 0 .11.086.196.196.196.11 0 .196-.086.196-.196 0-.11-.086-.196-.196-.196z" />
    </svg>
  ),
};

const socialIcons = [
  { name: 'facebook', color: "text-blue-600", top: "15%", left: "10%", size: 40, delay: 0, blur: "0px" },
  { name: 'instagram', color: "text-pink-600", top: "25%", right: "15%", size: 32, delay: 0.2, blur: "2px" },
  { name: 'twitter', color: "text-slate-900", bottom: "35%", left: "15%", size: 28, delay: 0.4, blur: "1px" },
  { name: 'linkedin', color: "text-blue-700", top: "40%", right: "10%", size: 36, delay: 0.1, blur: "0px" },
  { name: 'youtube', color: "text-red-600", bottom: "20%", right: "20%", size: 44, delay: 0.3, blur: "3px" },
  { name: 'tiktok', color: "text-slate-900", top: "70%", left: "12%", size: 30, delay: 0.5, blur: "0px" },
  { name: 'pinterest', color: "text-red-700", top: "60%", right: "18%", size: 34, delay: 0.25, blur: "4px" },
  { name: 'whatsapp', color: "text-green-600", top: "10%", right: "30%", size: 32, delay: 0.15, blur: "1px" },
  { name: 'threads', color: "text-slate-900", bottom: "10%", left: "30%", size: 28, delay: 0.45, blur: "0px" },
  { name: 'snapchat', color: "text-yellow-500", bottom: "45%", right: "25%", size: 30, delay: 0.35, blur: "2px" },
  { name: 'reddit', color: "text-orange-600", bottom: "15%", left: "45%", size: 32, delay: 0.55, blur: "1px" },
];

const ParallaxIcon = ({ name, color, style, mouseX, mouseY }: any) => {
  const x = useTransform(mouseX, [0, 1], [style.xRange[0], style.xRange[1]]);
  const y = useTransform(mouseY, [0, 1], [style.yRange[0], style.yRange[1]]);
  const springX = useSpring(x, { stiffness: 50, damping: 20 });
  const springY = useSpring(y, { stiffness: 50, damping: 20 });

  return (
    <motion.div
      style={{
        position: 'absolute',
        top: style.top,
        left: style.left,
        right: style.right,
        bottom: style.bottom,
        x: springX,
        y: springY,
        zIndex: 5,
        filter: `blur(${style.blur})`,
      }}
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: style.blur === "0px" ? 0.8 : 0.4, scale: 1 }}
      transition={{ delay: style.delay, duration: 0.5 }}
      whileHover={{ opacity: 1, scale: 1.15, rotate: 5, filter: 'blur(0px)' }}
    >
      <div className={`p-3 bg-white rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-slate-100 flex items-center justify-center ${color}`}>
        <div style={{ width: style.size, height: style.size }}>
          {BrandLogos[name]}
        </div>
      </div>
    </motion.div>
  );
};

const FloatingCard = ({ children, title, initial, animate, delay, className }: any) => (
  <motion.div
    initial={{ scale: 0.5, opacity: 0, ...initial }}
    animate={{ scale: 1, opacity: 1, ...animate }}
    transition={{
      type: "spring",
      stiffness: 100,
      damping: 15,
      delay: delay + 0.8
    }}
    className={`absolute z-30 ${className}`}
  >
    <Card className="shadow-[0_25px_60px_-15px_rgba(0,0,0,0.15)] border-none bg-white/95 backdrop-blur-md rounded-xl md:rounded-2xl overflow-hidden">
      <CardContent className="p-3 md:p-4">
        {title && <p className="text-slate-900 font-bold text-[10px] md:text-xs text-center">{title}</p>}
        <div className={title ? "mt-3" : ""}>
          {children}
        </div>
      </CardContent>
    </Card>
  </motion.div>
);

// Bouncy Popup: Post Type Chart
const PostTypePopup = () => (
  <motion.div
    initial={{ scale: 0.8, opacity: 0, y: 20 }}
    animate={{ scale: 1, opacity: 1, y: 0 }}
    transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.8 }}
    className="absolute -left-4 md:-left-8 lg:-left-20 top-[60px] md:top-[80px] z-30"
  >
    <Card className="w-32 md:w-48 shadow-[0_20px_50px_rgba(0,0,0,0.12)] border-none bg-white rounded-2xl">
      <CardContent className="p-3 md:p-5">
        <p className="text-slate-900 font-bold text-[10px] md:text-sm mb-3">Post Type</p>
        <div className="relative w-16 h-16 md:w-24 md:h-24 mx-auto mb-3">
          <svg viewBox="0 0 36 36" className="w-full h-full transform -rotate-90">
            <path
              className="text-cyan-400 stroke-current"
              strokeWidth="4"
              strokeDasharray="75, 100"
              strokeLinecap="round"
              fill="none"
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            />
            <path
              className="text-blue-600 stroke-current"
              strokeWidth="4"
              strokeDasharray="25, 100"
              strokeDashoffset="-75"
              strokeLinecap="round"
              fill="none"
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            />
          </svg>
        </div>
        <div className="flex justify-between text-[8px] md:text-[10px] font-bold text-slate-400">
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-600" />
            <span>Videos</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            <span>Images</span>
          </div>
        </div>
      </CardContent>
    </Card>
  </motion.div>
);

// Bouncy Popup: Total Likes Stats
const TotalLikesPopup = () => (
  <motion.div
    initial={{ scale: 0.8, opacity: 0, x: 20 }}
    animate={{ scale: 1, opacity: 1, x: 0 }}
    transition={{ type: "spring", stiffness: 200, damping: 15, delay: 1.1 }}
    className="absolute -right-4 md:-right-8 lg:-right-20 top-[140px] md:top-[180px] z-30"
  >
    <Card className="shadow-[0_20px_50px_rgba(0,0,0,0.12)] border-none bg-white rounded-2xl">
      <CardContent className="p-3 md:p-5 flex items-center gap-3">
        <div className="w-8 h-8 md:w-12 md:h-12 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
          <ThumbsUp size={18} fill="currentColor" />
        </div>
        <div>
          <p className="text-lg md:text-2xl font-black text-slate-900 leading-none">398K</p>
          <p className="text-[8px] md:text-[10px] font-bold text-slate-400 uppercase tracking-wide mt-1">Total Likes</p>
        </div>
      </CardContent>
    </Card>
  </motion.div>
);

export default function HeroSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const mouseX = useMotionValue(0.5);
  const mouseY = useMotionValue(0.5);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    mouseX.set(x);
    mouseY.set(y);
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="relative w-full h-auto md:h-screen min-h-[900px] flex flex-col bg-white overflow-hidden"
    >
      {/* Animated Gradient Background */}
      <motion.div
        animate={{
          background: [
            "radial-gradient(circle at 20% 30%, rgba(59, 130, 246, 0.2) 0%, transparent 70%), radial-gradient(circle at 80% 70%, rgba(249, 115, 22, 0.15) 0%, transparent 70%)",
            "radial-gradient(circle at 70% 20%, rgba(139, 92, 246, 0.25) 0%, transparent 70%), radial-gradient(circle at 30% 80%, rgba(234, 88, 12, 0.2) 0%, transparent 70%)",
            "radial-gradient(circle at 50% 50%, rgba(168, 85, 247, 0.22) 0%, transparent 70%), radial-gradient(circle at 20% 20%, rgba(249, 115, 22, 0.18) 0%, transparent 70%)",
            "radial-gradient(circle at 20% 30%, rgba(59, 130, 246, 0.2) 0%, transparent 70%), radial-gradient(circle at 80% 70%, rgba(249, 115, 22, 0.15) 0%, transparent 70%)",
          ],
        }}
        transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        className="absolute inset-0 z-0 pointer-events-none"
      />

      {/* Grid Overlay */}
      <div className="absolute inset-0 z-0 opacity-[0.03] pointer-events-none bg-[url('https://grainy-gradients.vercel.app/noise.svg')] bg-repeat" />
      <div
        className="absolute inset-0 z-0 pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(#1a365d 1px, transparent 1px), linear-gradient(90deg, #1a365d 1px, transparent 1px)',
          backgroundSize: '40px 40px',
          opacity: 0.05
        }}
      />

      {/* Floating Parallax Icons */}
      <div className="absolute inset-0 pointer-events-none hidden md:block">
        {socialIcons.map((item, idx) => (
          <ParallaxIcon
            key={idx}
            {...item}
            mouseX={mouseX}
            mouseY={mouseY}
            style={{
              ...item,
              xRange: [idx % 2 === 0 ? -30 : 30, idx % 2 === 0 ? 30 : -30],
              yRange: [idx % 3 === 0 ? -30 : 30, idx % 3 === 0 ? 30 : -30],
            }}
          />
        ))}
      </div>

      <Container className="relative z-10 flex flex-col h-full">
        {/* <Navbar /> */}

        <div className="flex-1 flex flex-col items-center pt-8 md:pt-12 lg:pt-16 text-center px-4">
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-xs md:text-xs xl:text-[64px]  tracking-[-0.04em] text-slate-900 max-w-5xl leading-[1] mb-6"
          >
            The social media <br className="hidden md:block" /> performance workspace
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="text-xs md:text-xs xl:text-[24px] text-slate-500 font-medium max-w-6xl mb-12"
          >
            Analyze, grow, and manage your social presence without the chaos.
          </motion.p>

          {/* Sign-up Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
            className="w-full max-w-lg mb-12 relative z-20"
          >
            <form className="flex flex-col md:flex-row gap-0 p-1 bg-white border border-slate-200 rounded-full shadow-[0_10px_40px_-10px_rgba(0,0,0,0.08)] overflow-hidden">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 bg-transparent border-none outline-none px-6 py-4 text-slate-900 placeholder:text-slate-400 font-medium"
              />
              <Button size="lg" className="h-[52px] px-8 text-base font-bold rounded-full bg-[#bbf7d0] hover:bg-[#a6efc1] text-[#064e3b] transition-all whitespace-nowrap group">
                Get started for free <span className="ml-2 group-hover:translate-x-1 transition-transform">→</span>
              </Button>
            </form>
            <p className="text-[12px] text-slate-400 mt-4 font-medium flex items-center justify-center gap-4">
              <span className="flex items-center gap-1">✅ No credit card required</span>
              <span className="flex items-center gap-1">✅ 14-day free trial</span>
            </p>
          </motion.div>
        </div>
      </Container>

      <div className="relative w-full flex justify-center mt-[-40px] md:mt-auto md:absolute md:bottom-[-10%] lg:bottom-[-15%] left-0 right-0 z-10">
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: "spring", stiffness: 100, damping: 20, delay: 0.6 }}
          className="relative w-full max-w-6xl px-4"
        >
          {/* The Dashboard Card (Main Container) */}
          <div className="relative rounded-[1.5rem] md:rounded-[2.5rem] bg-white border-[8px] md:border-[12px] border-white shadow-[0_50px_100px_-20px_rgba(0,0,0,0.15)] overflow-visible">
            <div className="relative rounded-[1rem] md:rounded-[2rem] overflow-hidden">
              <Image
                src="/hero.png"
                alt="Veblika Performance Dashboard"
                width={1200}
                height={700}
                className="w-full h-auto object-cover"
                priority
              />
              {/* Subtle activation overlay inside crop */}
              <motion.div
                initial={{ opacity: 1 }}
                animate={{ opacity: 0 }}
                transition={{ duration: 1.5, delay: 1 }}
                className="absolute inset-0 bg-white/10 backdrop-blur-[0.5px] pointer-events-none"
              />
            </div>

            {/* Popping Out Feature Cards */}

            {/* 1. Engagement Overview */}
            <FloatingCard
              title="Real-time Analytics"
              initial={{ x: 0, y: 50 }}
              animate={{ x: -60, y: -40 }}
              delay={0.2}
              className="-left-4 md:-left-20 top-[10%] w-40 md:w-52"
            >
              <div className="flex items-center justify-center gap-3">
                <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 shadow-inner">
                  <ThumbsUp size={16} fill="currentColor" />
                </div>
                <div>
                  <p className="text-lg md:text-xl font-black text-slate-900 leading-none">398K</p>
                  <p className="text-[7px] md:text-[8px] font-bold text-slate-400 uppercase mt-1">Total Likes</p>
                </div>
              </div>
            </FloatingCard>

            {/* 2. Content Mix */}
            <FloatingCard
              title="Content Mix"
              initial={{ x: 0, y: 50 }}
              animate={{ x: 80, y: -60 }}
              delay={0.4}
              className="-right-4 md:-right-24 top-[15%] w-36 md:w-48"
            >
              <div className="relative w-12 h-12 md:w-16 md:h-16 mx-auto">
                <svg viewBox="0 0 36 36" className="w-full h-full transform -rotate-90">
                  <path className="text-cyan-400 stroke-current" strokeWidth="4" strokeDasharray="75, 100" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                  <path className="text-blue-600 stroke-current" strokeWidth="4" strokeDasharray="25, 100" strokeDashoffset="-75" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                </svg>
              </div>
              <div className="flex justify-center gap-2 mt-3 text-[7px] md:text-[8px] font-bold text-slate-400">
                <div className="flex items-center gap-1"><div className="w-1 h-1 rounded-full bg-blue-600" />Video</div>
                <div className="flex items-center gap-1"><div className="w-1 h-1 rounded-full bg-cyan-400" />Image</div>
              </div>
            </FloatingCard>

            {/* 3. Scheduling Insight */}
            <FloatingCard
              title="Optimal Timing"
              initial={{ x: 0, y: 20 }}
              animate={{ x: -40, y: 60 }}
              delay={0.6}
              className="-left-2 md:-left-12 top-[60%] w-40 md:w-52"
            >
              <div className="bg-green-50/50 p-2 rounded-lg flex items-center justify-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                <span className="text-[9px] md:text-[10px] font-bold text-green-700 uppercase tracking-tight">Live: Saturday, 8pm</span>
              </div>
            </FloatingCard>

            {/* 4. Audience Growth Badge */}
            <FloatingCard
              title="Audience Growth"
              initial={{ scale: 0.5 }}
              animate={{ x: 50, y: 40 }}
              delay={0.8}
              className="-right-6 md:-right-16 bottom-[10%] w-44 md:w-56"
            >
              <div className="flex items-center justify-center gap-3">
                <div className="flex -space-x-2">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="w-5 h-5 md:w-7 md:h-7 rounded-full border-2 border-white overflow-hidden bg-slate-100 shadow-sm">
                      <Image src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${i * 123}`} alt="user" width={28} height={28} />
                    </div>
                  ))}
                </div>
                <p className="text-slate-900 font-black text-xs md:text-sm leading-none">+1.2k</p>
              </div>
            </FloatingCard>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
