"use client";

import React from "react";
import Container from "./container";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { motion } from "framer-motion";

/**
 * AudienceSection
 * Goals:
 * 1. Fit to 100vh (h-screen).
 * 2. Improve blue heatmap pattern (intent-based clusters).
 * 3. Clean flexbox layout with Shadcn spacing.
 */

const HeatMapBlock = ({ opacity = 1, delay = 0 }: { opacity?: number; delay?: number }) => (
    <motion.div
        initial={{ scale: 0, opacity: 0 }}
        whileInView={{ scale: 1, opacity: opacity }}
        viewport={{ once: true }}
        transition={{ duration: 0.4, delay }}
        className="w-10 h-10 md:w-14 md:h-14 rounded-xl bg-blue-500 shadow-sm"
        style={{ opacity }}
    />
);

export default function AudienceSection() {
    // Define columns of the heatmap cluster to mimic the image
    // Each array represents opacities in a column [bottom, ..., top]
    const clusters = [
        [1],
        [0.4, 0.7, 1],
        [0.6, 0.3],
        [0.8, 1],
        [0.7, 0.5, 0.9],
        [1, 0.4],
        [0.3, 0.8],
        [1, 0.5, 1, 0.6], // Under the card
        [0.7, 0.9, 0.4],
        [0.5, 0.7],
        [1, 0.3, 0.6],
        [0.8],
        [1, 0.4]
    ];

    return (
        <section className="h-screen min-h-[750px] flex flex-col justify-between py-8 md:py-16 bg-white overflow-hidden">
            <Container className="flex-1 flex flex-col justify-center">

                {/* Top: Visual Visualization Area (Heatmap + Card) */}
                <div className="relative flex-1 flex flex-col items-center justify-center py-10">

                    {/* Heat Map Pattern */}
                    <div className="flex items-end gap-3 md:gap-5 justify-center w-full">
                        {clusters.map((col, colIdx) => (
                            <div key={colIdx} className="flex flex-col-reverse gap-3 md:gap-5">
                                {col.map((op, rowIdx) => (
                                    <HeatMapBlock key={rowIdx} opacity={op} delay={colIdx * 0.05 + rowIdx * 0.1} />
                                ))}
                            </div>
                        ))}
                    </div>

                    {/* Floating 'Saturday, 8pm' Card - Hovering over a cluster */}
                    <motion.div
                        initial={{ y: 20, opacity: 0 }}
                        whileInView={{ y: 0, opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ type: "spring", stiffness: 260, damping: 20, delay: 0.6 }}
                        className="absolute top-[5%] md:top-[10%] left-1/2 -translate-x-1/2 md:translate-x-0 md:left-[55%] z-20"
                    >
                        <Card className="w-64 md:w-72 shadow-2xl border-none rounded-[2rem] bg-white">
                            <CardContent className="p-6 flex flex-col items-center text-center">
                                {/* Avatars Overlapping */}
                                <div className="flex items-center -space-x-3 mb-5">
                                    {[1, 2, 3, 4, 5].map((i) => (
                                        <Avatar key={i} className="w-10 h-10 border-4 border-white shadow-sm">
                                            <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${i * 77}`} />
                                            <AvatarFallback>U</AvatarFallback>
                                        </Avatar>
                                    ))}
                                </div>

                                {/* Event Details */}
                                <div className="mb-6">
                                    <h4 className="text-[#1a365d] font-black text-xl">Saturday, 8pm</h4>
                                    <p className="text-slate-400 text-xs font-bold mt-1">Time most followers online</p>
                                </div>

                                {/* Interactive Buttons */}
                                <div className="flex gap-3 w-full">
                                    <Button className="flex-1 bg-[#26A69A] hover:bg-[#1f8a7e] text-white font-bold h-11 text-xs rounded-xl shadow-lg transition-transform hover:scale-105">
                                        Schedule Post
                                    </Button>
                                    <Button variant="outline" className="flex-1 border-teal-50 bg-teal-50/50 text-[#26A69A] hover:bg-teal-100 font-bold h-11 text-xs rounded-xl border-none">
                                        See Insight
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>

                {/* Bottom: Information Row (Title/Desc + Stats) */}
                <div className="w-full flex flex-col md:flex-row justify-between items-end gap-12 mt-auto">

                    {/* Left Side: Editorial Content */}
                    <div className="max-w-xl text-left">
                        <h2 className="text-4xl md:text-5xl font-black text-[#0A0A0A] leading-tight mb-6 tracking-tighter">
                            Audience Activity
                        </h2>
                        <p className="text-slate-500 text-lg leading-relaxed font-medium">
                            You can check your audience activity by click data above. You can access in apps too and website with your Veblika Account.
                        </p>
                    </div>

                    {/* Right Side: High-impact Stats Grid */}
                    <div className="grid grid-cols-2 gap-x-16 gap-y-12 shrink-0">
                        {[
                            { label: "Impressions", value: "81" },
                            { label: "Engagements", value: "286" },
                            { label: "Reach Post", value: "381" },
                            { label: "Previous Week", value: "635" }
                        ].map((stat, idx) => (
                            <div key={idx}>
                                <div className="text-5xl font-black text-[#FF9800] mb-2">{stat.value}</div>
                                <div className="text-slate-400 text-xs uppercase tracking-[0.2em] font-black">{stat.label}</div>
                            </div>
                        ))}
                    </div>

                </div>
            </Container>
        </section>
    );
}
