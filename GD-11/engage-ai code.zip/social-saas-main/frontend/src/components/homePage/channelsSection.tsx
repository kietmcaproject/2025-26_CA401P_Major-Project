"use client";

import React from "react";
import Container from "./container";
import { motion } from "framer-motion";
import {
    Facebook,
    Instagram,
    Linkedin,
    Twitter,
    Youtube,
    Music, // For TikTok
    Globe, // For Google Business
    Pin // For Pinterest
} from "lucide-react";

const channels = [
    { name: "Facebook", icon: Facebook, color: "text-blue-600", bg: "bg-blue-50" },
    { name: "Instagram", icon: Instagram, color: "text-pink-600", bg: "bg-pink-50" },
    { name: "LinkedIn", icon: Linkedin, color: "text-blue-700", bg: "bg-blue-50" },
    { name: "Twitter", icon: Twitter, color: "text-sky-500", bg: "bg-sky-50" },
    { name: "YouTube", icon: Youtube, color: "text-red-600", bg: "bg-red-50" },
    { name: "TikTok", icon: Music, color: "text-black", bg: "bg-slate-50" },
    { name: "Google Business", icon: Globe, color: "text-blue-500", bg: "bg-blue-50" },
    { name: "Pinterest", icon: Pin, color: "text-red-700", bg: "bg-red-50" },
];

export default function ChannelsSection() {
    return (
        <section className="py-20 bg-slate-50">
            <Container>
                <div className="text-center max-w-3xl mx-auto mb-16">
                    <motion.h2
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="text-3xl md:text-5xl font-bold text-slate-900 mb-6"
                    >
                        Manage all your social channels <br className="hidden md:block" /> from one place
                    </motion.h2>
                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.1 }}
                        className="text-lg text-slate-600"
                    >
                        Veblika supports all the major social media platforms, so you can focus on building your brand everywhere.
                    </motion.p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    {channels.map((channel, index) => (
                        <motion.div
                            key={channel.name}
                            initial={{ opacity: 0, scale: 0.9 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.05 }}
                            whileHover={{ y: -5 }}
                            className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center justify-center text-center transition-all hover:shadow-md"
                        >
                            <div className={`${channel.bg} ${channel.color} p-4 rounded-xl mb-4`}>
                                <channel.icon size={32} />
                            </div>
                            <h3 className="font-bold text-slate-900">{channel.name}</h3>
                        </motion.div>
                    ))}
                </div>
            </Container>
        </section>
    );
}
