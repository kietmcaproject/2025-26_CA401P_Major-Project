"use client";

import React, { useState } from "react";
import Container from "./container";
import { motion, AnimatePresence } from "framer-motion";
import { Calendar, Clock, BarChart3, Users, MessageSquare, Layout } from "lucide-react";
import Image from "next/image";

const capabilities = [
    {
        id: "scheduling",
        title: "Flexible Scheduling",
        description: "Schedule posts for when your audience is most active. Use our bulk scheduler to plan weeks of content in minutes.",
        icon: Calendar,
        image: "/hero.png", // Reusing existing assets or placeholders
        accent: "bg-blue-600"
    },
    {
        id: "optimal",
        title: "Optimal Timing",
        description: "Our SmartQ technology predicts the best time to post based on your audience's engagement patterns.",
        icon: Clock,
        image: "/Graph-1.png",
        accent: "bg-cyan-500"
    },
    {
        id: "calendar",
        title: "Visual Calendar",
        description: "Get a bird's-eye view of your social media strategy. Drag and drop to reschedule posts on the fly.",
        icon: Layout,
        image: "/Graph-2.png",
        accent: "bg-indigo-600"
    },
    {
        id: "analytics",
        title: "Deep Analytics",
        description: "Track performance across all channels with custom reports. Understand what works and why.",
        icon: BarChart3,
        image: "/hero.png",
        accent: "bg-blue-800"
    }
];

export default function KeyCapabilities() {
    const [activeTab, setActiveTab] = useState(capabilities[0].id);

    const activeCapability = capabilities.find(c => c.id === activeTab)!;

    return (
        <section className="py-24 bg-white">
            <Container>
                <div className="text-center max-w-3xl mx-auto mb-16">
                    <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 font-primary">
                        Everything you need to <br /> scale your social presence
                    </h2>
                    <p className="text-lg text-slate-600 font-medium">
                        Powerful tools designed to simplify your workflow and maximize your impact on every platform.
                    </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
                    {/* Vertical Tabs */}
                    <div className="lg:col-span-4 space-y-4">
                        {capabilities.map((cap) => (
                            <button
                                key={cap.id}
                                onClick={() => setActiveTab(cap.id)}
                                className={`w-full text-left p-6 rounded-2xl transition-all duration-300 flex items-start gap-4 ${activeTab === cap.id
                                        ? "bg-slate-50 shadow-sm border-l-4 border-blue-600"
                                        : "hover:bg-slate-200/50 border-l-4 border-transparent"
                                    }`}
                            >
                                <div className={`p-2 rounded-lg ${activeTab === cap.id ? cap.accent + " text-white" : "bg-slate-100 text-slate-500"}`}>
                                    <cap.icon size={24} />
                                </div>
                                <div>
                                    <h3 className={`font-bold text-lg ${activeTab === cap.id ? "text-slate-900" : "text-slate-600"}`}>
                                        {cap.title}
                                    </h3>
                                    {activeTab === cap.id && (
                                        <motion.p
                                            initial={{ opacity: 0, height: 0 }}
                                            animate={{ opacity: 1, height: "auto" }}
                                            className="text-slate-500 mt-2 text-sm leading-relaxed"
                                        >
                                            {cap.description}
                                        </motion.p>
                                    )}
                                </div>
                            </button>
                        ))}
                    </div>

                    {/* Visual Side */}
                    <div className="lg:col-span-8">
                        <AnimatePresence mode="wait">
                            <motion.div
                                key={activeTab}
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                transition={{ duration: 0.4 }}
                                className="relative bg-slate-100 rounded-[2rem] overflow-hidden aspect-[16/10] shadow-inner p-4 md:p-8"
                            >
                                <div className="w-full h-full bg-white rounded-xl shadow-2xl overflow-hidden relative border border-slate-200">
                                    <Image
                                        src={activeCapability.image}
                                        alt={activeCapability.title}
                                        fill
                                        className="object-cover"
                                    />
                                    {/* Glassmorphic overlay for extra premium feel */}
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent pointer-events-none" />
                                </div>
                            </motion.div>
                        </AnimatePresence>
                    </div>
                </div>
            </Container>
        </section>
    );
}
