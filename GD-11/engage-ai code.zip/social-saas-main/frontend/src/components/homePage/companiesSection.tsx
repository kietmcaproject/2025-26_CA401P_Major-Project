"use client";

import React from "react";
import Container from "./container";
import { motion } from "framer-motion";

const companies = [
    { name: "Company 1", logo: "/company-logo-1.png" },
    { name: "Company 2", logo: "/company-logo-2.png" },
    { name: "Company 3", logo: "/company-logo-3.png" },
    { name: "Company 4", logo: "/company-logo-4.png" },
    { name: "Company 5", logo: "/company-logo-5.png" },
];

export default function CompaniesSection() {
    return (
        <section className="py-16 md:py-24 bg-white">
            <Container>
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6 }}
                    className="text-center mb-12"
                >
                    <p className="text-sm md:text-base text-slate-500 font-medium">
                        Trusted by leading companies worldwide
                    </p>
                </motion.div>

                <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12 lg:gap-16">
                    {companies.map((company, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, scale: 0.8 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.5, delay: index * 0.1 }}
                            className="grayscale hover:grayscale-0 transition-all duration-300 opacity-60 hover:opacity-100"
                        >
                            <div className="w-32 h-12 md:w-40 md:h-16 bg-slate-100 rounded-lg flex items-center justify-center">
                                <span className="text-slate-400 font-bold text-sm">{company.name}</span>
                            </div>
                        </motion.div>
                    ))}
                </div>

                {/* Ratings Row */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.5 }}
                    className="mt-20 pt-12 border-t border-slate-100 flex flex-wrap justify-center gap-12 md:gap-24"
                >
                    {[
                        { label: "Trustpilot", rating: "4.8/5", text: "Excellent" },
                        { label: "Capterra", rating: "4.7/5", text: "Top Rated" },
                        { label: "G2 Crowd", rating: "4.9/5", text: "Leader" }
                    ].map((rating, i) => (
                        <div key={i} className="flex flex-col items-center">
                            <div className="flex text-yellow-400 mb-2">
                                {[...Array(5)].map((_, j) => (
                                    <svg key={j} className="w-5 h-5 fill-current" viewBox="0 0 20 20">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                ))}
                            </div>
                            <span className="font-bold text-slate-900 text-lg">{rating.rating}</span>
                            <span className="text-slate-500 text-sm font-medium">{rating.label} {rating.text}</span>
                        </div>
                    ))}
                </motion.div>
            </Container>
        </section>
    );
}
