"use client";

import React from "react";
import Container from "./container";
import { motion } from "framer-motion";
import Image from "next/image";
import { Smartphone, Download, Star } from "lucide-react";

export default function MobileSection() {
    return (
        <section className="py-24 bg-white overflow-hidden">
            <Container>
                <div className="bg-slate-900 rounded-[3rem] p-12 md:p-20 relative overflow-hidden">
                    {/* Decorative glows */}
                    <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-600/20 rounded-full blur-[120px] -mr-64 -mt-64" />
                    <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-cyan-600/10 rounded-full blur-[120px] -ml-64 -mb-64" />

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                        <div className="space-y-8 relative z-10">
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                            >
                                <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/10 rounded-full text-blue-400 border border-blue-500/20 mb-6">
                                    <Smartphone size={16} />
                                    <span className="text-sm font-bold uppercase tracking-wider">Mobile App</span>
                                </div>
                                <h2 className="text-4xl md:text-5xl font-bold text-white leading-tight mb-6">
                                    Manage Social on the go <br /> with Veblika Mobile
                                </h2>
                                <p className="text-xl text-slate-400 leading-relaxed">
                                    The Veblika mobile app helps you stay on top of your social media strategy from anywhere. Draft, monitor, and publish content right from your pocket.
                                </p>
                            </motion.div>

                            <div className="flex flex-wrap gap-6 pt-4">
                                <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-2 rounded-xl">
                                    <div className="flex text-yellow-500">
                                        {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
                                    </div>
                                    <span className="text-white font-medium">4.9 Rating</span>
                                </div>
                            </div>

                            <div className="flex flex-wrap gap-4">
                                <button className="flex items-center gap-3 bg-white text-slate-900 px-6 py-4 rounded-2xl font-bold transition-transform hover:scale-105">
                                    <Image src="https://upload.wikimedia.org/wikipedia/commons/3/3c/Apple_logo_black.svg" alt="Apple" width={20} height={20} />
                                    <div className="text-left leading-none">
                                        <p className="text-[10px] uppercase opacity-60">Download on the</p>
                                        <p className="text-lg">App Store</p>
                                    </div>
                                </button>
                                <button className="flex items-center gap-3 bg-white text-slate-900 px-6 py-4 rounded-2xl font-bold transition-transform hover:scale-105">
                                    <Image src="https://upload.wikimedia.org/wikipedia/commons/d/d7/Google_Play_Store_badge_EN.svg" alt="Play Store" width={100} height={20} className="h-6 w-auto" />
                                </button>
                            </div>
                        </div>

                        <div className="relative">
                            <motion.div
                                initial={{ opacity: 0, x: 50 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.8, type: "spring" }}
                                className="relative z-10 flex justify-center lg:justify-end"
                            >
                                {/* iPhone Mockup (simplified with CSS) */}
                                <div className="relative w-[300px] h-[600px] bg-slate-800 rounded-[3rem] border-[8px] border-slate-700 shadow-2xl overflow-hidden">
                                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/3 h-6 bg-slate-700 rounded-b-xl z-20" />
                                    <Image
                                        src="/hero.png"
                                        alt="Mobile App View"
                                        fill
                                        className="object-cover opacity-90"
                                    />
                                    {/* Glass overlay */}
                                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent" />
                                </div>
                            </motion.div>
                        </div>
                    </div>
                </div>
            </Container>
        </section>
    );
}
