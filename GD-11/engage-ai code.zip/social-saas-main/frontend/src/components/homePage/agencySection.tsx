"use client";

import React from "react";
import Container from "./container";
import { motion } from "framer-motion";
import { Check, Shield, Users, Briefcase } from "lucide-react";
import Image from "next/image";

export default function AgencySection() {
    return (
        <section className="py-24 bg-[#1a365d] text-white overflow-hidden">
            <Container>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                    <div className="order-2 lg:order-1 relative">
                        {/* Decorative background element */}
                        <div className="absolute -top-20 -left-20 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl" />

                        <motion.div
                            initial={{ opacity: 0, scale: 0.9 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            className="relative z-10 bg-[#2a4a7d] p-4 rounded-[2.5rem] shadow-2xl border border-white/10"
                        >
                            <Image
                                src="/hero.png"
                                alt="Agency Dashboard"
                                width={800}
                                height={500}
                                className="rounded-[1.5rem]"
                            />

                            {/* Floating badge */}
                            <motion.div
                                animate={{ y: [0, -10, 0] }}
                                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                                className="absolute -bottom-6 -right-6 md:right-10 bg-white text-slate-900 p-6 rounded-2xl shadow-xl z-20"
                            >
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                                        <Shield size={24} />
                                    </div>
                                    <div>
                                        <p className="font-bold text-lg">100% Brand Safety</p>
                                        <p className="text-sm text-slate-500">Trusted by 500+ Agencies</p>
                                    </div>
                                </div>
                            </motion.div>
                        </motion.div>
                    </div>

                    <div className="order-1 lg:order-2 space-y-8">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                        >
                            <h2 className="text-3xl md:text-5xl font-bold leading-tight mb-6">
                                Built for Agencies <br /> and Large Teams
                            </h2>
                            <p className="text-xl text-blue-100 opacity-80 leading-relaxed">
                                Manage multiple brands, collaborate with clients, and generate white-labeled reports all from a single dashboard.
                            </p>
                        </motion.div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {[
                                { title: "Multi-Brand Management", desc: "Separate workspaces for each client.", icon: Briefcase },
                                { title: "Team Collaboration", desc: "Role-based access and approval workflows.", icon: Users },
                                { title: "Client Approval", desc: "Let clients review and approve posts.", icon: Check },
                                { title: "White-Label Reports", desc: "Brand your analytics with your agency logo.", icon: Shield }
                            ].map((feature, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ opacity: 0, y: 15 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: i * 0.1 }}
                                    className="flex gap-4 items-start"
                                >
                                    <div className="p-2 bg-blue-500/20 rounded-lg text-blue-300">
                                        <feature.icon size={20} />
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-white mb-1">{feature.title}</h4>
                                        <p className="text-sm text-blue-200/70">{feature.desc}</p>
                                    </div>
                                </motion.div>
                            ))}
                        </div>

                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.4 }}
                            className="pt-4"
                        >
                            <button className="bg-white text-[#1a365d] px-8 py-4 rounded-xl font-bold text-lg hover:bg-blue-50 transition-colors">
                                Explore Agency Solutions
                            </button>
                        </motion.div>
                    </div>
                </div>
            </Container>
        </section>
    );
}
