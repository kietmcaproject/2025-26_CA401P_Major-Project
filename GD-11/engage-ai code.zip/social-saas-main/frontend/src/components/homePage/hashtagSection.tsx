"use client";

import React from "react";
import Container from "./container";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Hash, TrendingUp, Users, BarChart3 } from "lucide-react";

export default function HashtagSection() {
    return (
        <section className="py-20 md:py-32 bg-gradient-to-br from-slate-50 to-white">
            <Container>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                    {/* Left Content */}
                    <motion.div
                        initial={{ opacity: 0, x: -30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                        className="space-y-8"
                    >
                        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 text-blue-600">
                            <Hash size={20} />
                            <span className="text-sm font-bold">Hashtag Analytics</span>
                        </div>

                        <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-slate-900 leading-tight tracking-tight">
                            Track Any Hashtag Performance
                        </h2>

                        <p className="text-lg text-slate-600 leading-relaxed">
                            Monitor hashtag reach, engagement, and trending patterns across all your social media platforms. Get real-time insights to optimize your content strategy.
                        </p>

                        <div className="flex gap-4">
                            <Input
                                placeholder="Enter hashtag..."
                                className="h-14 text-lg border-slate-200 focus:border-blue-500 rounded-xl"
                            />
                            <Button size="lg" className="h-14 px-8 bg-[#1a365d] hover:bg-[#2a4a7d] rounded-xl font-bold">
                                Track
                            </Button>
                        </div>

                        {/* Stats Grid */}
                        <div className="grid grid-cols-3 gap-6 pt-8">
                            <div className="text-center">
                                <div className="text-3xl font-black text-slate-900 mb-1">2.5M+</div>
                                <div className="text-sm text-slate-500 font-medium">Hashtags Tracked</div>
                            </div>
                            <div className="text-center">
                                <div className="text-3xl font-black text-slate-900 mb-1">98%</div>
                                <div className="text-sm text-slate-500 font-medium">Accuracy</div>
                            </div>
                            <div className="text-center">
                                <div className="text-3xl font-black text-slate-900 mb-1">24/7</div>
                                <div className="text-sm text-slate-500 font-medium">Monitoring</div>
                            </div>
                        </div>
                    </motion.div>

                    {/* Right Visual */}
                    <motion.div
                        initial={{ opacity: 0, x: 30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                        className="relative"
                    >
                        <Card className="border-none shadow-2xl overflow-hidden">
                            <CardContent className="p-8 bg-gradient-to-br from-blue-50 to-white">
                                <div className="space-y-6">
                                    {/* Trending Hashtags */}
                                    <div className="flex items-center justify-between">
                                        <h3 className="text-lg font-bold text-slate-900">Trending Now</h3>
                                        <TrendingUp className="text-green-500" size={24} />
                                    </div>

                                    {[
                                        { tag: "#SocialMedia", count: "1.2M", trend: "+15%" },
                                        { tag: "#Marketing", count: "890K", trend: "+12%" },
                                        { tag: "#Business", count: "750K", trend: "+8%" },
                                    ].map((item, idx) => (
                                        <div key={idx} className="flex items-center justify-between p-4 bg-white rounded-xl shadow-sm">
                                            <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                                                    <Hash className="text-blue-600" size={20} />
                                                </div>
                                                <div>
                                                    <div className="font-bold text-slate-900">{item.tag}</div>
                                                    <div className="text-sm text-slate-500">{item.count} posts</div>
                                                </div>
                                            </div>
                                            <div className="text-green-500 font-bold">{item.trend}</div>
                                        </div>
                                    ))}

                                    {/* Chart Placeholder */}
                                    <div className="h-48 bg-gradient-to-t from-blue-100 to-transparent rounded-xl flex items-end justify-around p-4">
                                        {[60, 80, 70, 90, 85, 95, 100].map((height, idx) => (
                                            <div
                                                key={idx}
                                                className="w-8 bg-blue-500 rounded-t-lg transition-all hover:bg-blue-600"
                                                style={{ height: `${height}%` }}
                                            />
                                        ))}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>
            </Container>
        </section>
    );
}
