import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/utils/api";
import { toast } from "sonner";
import {
    buildSocialBrandingApiUrl,
    buildSocialContentApiUrl,
    mapSocialBrandingResponse,
    mapSocialContentResponse,
} from "@/lib/branding";

export interface FAQ {
    question: string;
    answer: string;
    order: number;
}

export interface Feature {
    title: string;
    description: string;
    icon: string;
    order: number;
}

export interface Stat {
    label: string;
    value: string;
    order: number;
}

export interface Testimonial {
    name: string;
    role?: string;
    company?: string;
    content: string;
    avatar?: string;
    rating: number;
    order: number;
}

export interface PricingPlan {
    name: string;
    price: string;
    period: string;
    description: string;
    features: string[];
    isPopular: boolean;
    buttonText: string;
    order: number;
}

export interface AboutPageStat {
    label: string;
    value: string;
    icon?: string;
}

export interface AboutPageContent {
    tagline: string;
    headline: string;
    story: string;
    stats: AboutPageStat[];
    industries: string[];
}

export interface ResellerContent {
    hero: {
        title: string;
        subtitle: string;
    };
    about: {
        title: string;
        description: string;
    };
    contact: {
        address: string;
        phone: string;
        email: string;
    };
    cta: {
        title: string;
        subtitle: string;
        buttonText: string;
    };
    faqs: FAQ[];
    features: Feature[];
    stats: Stat[];
    testimonials: Testimonial[];
    pricing: PricingPlan[];
    aboutPage: AboutPageContent;
    privacyPolicy: string;
    termsOfService: string;
}

export interface ResellerConfig {
    resellerId: string;
    logo: string;
    favicon?: string;
    companyName: string;
    domain?: string;
    colors?: {
        primary: string;
        secondary: string;
        accent: string;
        dark: string;
    };
    contact?: {
        address?: string;
        phone?: string;
        email?: string;
    };
    social?: {
        twitter?: string;
        linkedin?: string;
        facebook?: string;
        instagram?: string;
    };
    content?: Partial<ResellerContent>;
}

const fetchDomainContentConfig = async (originDomain: string): Promise<ResellerConfig | null> => {
    const brandingApiUrl = buildSocialBrandingApiUrl(originDomain);
    const contentApiUrl = buildSocialContentApiUrl(originDomain);

    if (!brandingApiUrl && !contentApiUrl) {
        return null;
    }

    const token = process.env["X_API_TOKEN"] || process.env["NEXT_PUBLIC_X_API_TOKEN"] || "";

    const [brandingPayload, contentPayload] = await Promise.all([
        brandingApiUrl
            ? fetch(brandingApiUrl, { 
                method: "GET",
                headers: {
                    "x-api-token": token,
                    "Content-Type": "application/json",
                },
                cache: "no-store",
                signal: AbortSignal.timeout(5000) 
            })
                .then((response) => (response.ok ? response.json() : null))
                .catch(() => null)
            : Promise.resolve(null),
        contentApiUrl
            ? fetch(contentApiUrl, { 
                method: "GET",
                headers: {
                    "x-api-token": token,
                    "Content-Type": "application/json",
                },
                cache: "no-store",
                signal: AbortSignal.timeout(5000) 
            })
                .then((response) => (response.ok ? response.json() : null))
                .catch(() => null)
            : Promise.resolve(null),
    ]);
    
    const branding = brandingPayload
        ? mapSocialBrandingResponse(brandingPayload, originDomain)
        : null;
    const content = contentPayload ? mapSocialContentResponse(contentPayload) : null;
    if (!branding && !content) {
        return null;
    }
    return {
        resellerId: "",
        companyName: branding?.companyName || "Veblika",
        logo: branding?.logo || "",
        favicon: branding?.favicon || "",
        domain: branding?.domain || originDomain,
        colors: branding?.colors,
        contact: branding?.contact || {},
        social: branding?.social || {},
        content: (content || undefined) as Partial<ResellerContent> | undefined,
    } as ResellerConfig;
};

export const useGetResellerConfig = () => {
    return useQuery({
        queryKey: ["reseller-config"],
        queryFn: async () => {
            const originDomain = typeof window !== "undefined" ? window.location.hostname : "";
            return fetchDomainContentConfig(originDomain);
        },
    });
};

export const useUpdateResellerConfig = () => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: async ({
            file,
            companyName,
            domain,
            content
        }: {
            file?: File;
            companyName?: string;
            domain?: string;
            content?: Partial<ResellerContent>;
        }) => {
            const formData = new FormData();
            if (file) formData.append("logo", file);
            if (companyName) formData.append("companyName", companyName);
            if (domain) formData.append("domain", domain);
            if (content) formData.append("content", JSON.stringify(content));

            const { data } = await api.post("/reseller-config/update", formData, {
                headers: {
                    "Content-Type": "multipart/form-data",
                },
            });

            return data;

        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["reseller-config"] });
            toast.success("Configuration updated successfully");
        },
        onError: (error: any) => {
            toast.error(error.response?.data?.message || "Failed to update configuration");
        }
    });
};

export const useGetPublicResellerConfig = () => {
    return useQuery({
        queryKey: ["public-reseller-config"],
        queryFn: async () => {
            const originDomain = typeof window !== "undefined" ? window.location.hostname : "";
            return fetchDomainContentConfig(originDomain);
        },
    });
};
