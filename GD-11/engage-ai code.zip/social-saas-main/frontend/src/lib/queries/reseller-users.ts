import { useQuery } from "@tanstack/react-query";
import api from "@/utils/api";

export interface ResellerManagedUser {
  id: string;
  authUserId: string;
  appRole: string;
  status?: "active" | "suspended" | "blocked" | "inactive";
  name: string;
  email: string;
  resellerId?: string | null;
  mediaStorageGb?: number;
  createdAt?: string;
  updatedAt?: string;
}

interface ResellerUsersResponse {
  success: boolean;
  data: ResellerManagedUser[];
}

export const useResellerManagedUsers = () => {
  return useQuery({
    queryKey: ["reseller-managed-users"],
    queryFn: async () => {
      const { data } = await api.get<ResellerUsersResponse>("/user/reseller-users");
      return data.data || [];
    },
  });
};
