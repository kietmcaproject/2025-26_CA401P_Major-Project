import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/utils/api";
import { toast } from "sonner";
import { useOrgStore } from "@/hooks/use-org-store";

export interface Invitation {
    _id: string;
    email: string;
    orgId: string;
    roleId: string; // or object if populated
    invitedBy: string;
    status: "pending" | "accepted" | "rejected" | "expired";
    expiresAt: string;
    createdAt: string;
}

export const useCreateInvitation = () => {
    const queryClient = useQueryClient();
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);

    return useMutation({
        mutationFn: async ({ email, roleId }: { email: string; roleId: string }) => {
            if (!activeOrgId) throw new Error("No active org");
            const { data } = await api.post(`/organisations/${activeOrgId}/invitations`, { email, roleId });
            return data.data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["invitations", activeOrgId] });
            toast.success("Invitation sent");
        },
        onError: (error: any) => {
            toast.error(error.response?.data?.message || "Failed to invite");
        }
    });
};

export const useListInvitations = () => {
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);
    return useQuery({
        queryKey: ["invitations", activeOrgId],
        queryFn: async () => {
            if (!activeOrgId) return [];
            const { data } = await api.get<{ success: boolean; data: Invitation[] }>(`/organisations/${activeOrgId}/invitations`);
            return data.data;
        },
        enabled: !!activeOrgId
    });
};

export const useCancelInvitation = () => {
    const queryClient = useQueryClient();
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);

    return useMutation({
        mutationFn: async (invitationId: string) => {
            if (!activeOrgId) throw new Error("No active org");
            await api.delete(`/organisations/${activeOrgId}/invitations/${invitationId}`);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["invitations", activeOrgId] });
            toast.success("Invitation cancelled");
        },
        onError: (error: any) => {
            toast.error(error.response?.data?.message || "Failed to cancel");
        }
    });
};
