import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/utils/api";
import { toast } from "sonner";
import { useOrgStore } from "@/hooks/use-org-store";

export interface Role {
    _id: string;
    name: string;
    slug: string;
    description?: string;
    permissions: string[];
    isDefault: boolean;
    isSystem: boolean;
    organisationId: string;
}

export interface Permission {
    group: string;
    label: string;
}

export const useListRoles = (orgId?: string) => {
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);
    const id = orgId || activeOrgId;

    return useQuery({
        queryKey: ["roles", id],
        queryFn: async () => {
            if (!id) return [];
            const { data } = await api.get<{ success: boolean; data: Role[] }>(`/organisations/${id}/roles`);
            return data.data;
        },
        enabled: !!id,
    });
};

export const useGetAvailablePermissions = (orgId?: string) => {
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);
    const id = orgId || activeOrgId;

    return useQuery({
        queryKey: ["permissions", id],
        queryFn: async () => {
            if (!id) return null;
            const { data } = await api.get<{ success: boolean; data: { permissions: string[], metadata: Record<string, Permission> } }>(`/organisations/${id}/roles/permissions`);
            return data.data;
        },
        enabled: !!id,
    });
}

export const useCreateRole = () => {
    const queryClient = useQueryClient();
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);

    return useMutation({
        mutationFn: async ({ name, description, permissions, orgId }: { name: string; description: string; permissions: string[]; orgId?: string }) => {
            const id = orgId || activeOrgId;
            if (!id) throw new Error("No organisation selected");

            const { data } = await api.post<{ success: boolean; data: Role }>(`/organisations/${id}/roles`, { name, description, permissions });
            return data.data;
        },
        onSuccess: (_, variables) => {
            const id = variables.orgId || activeOrgId;
            queryClient.invalidateQueries({ queryKey: ["roles", id] });
            toast.success("Role created successfully");
        },
        onError: (error: any) => {
            toast.error(error.response?.data?.message || "Failed to create role");
        }
    });
};

export const useUpdateRole = () => {
    const queryClient = useQueryClient();
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);

    return useMutation({
        mutationFn: async ({ roleId, name, description, permissions, orgId }: { roleId: string; name?: string; description?: string; permissions?: string[]; orgId?: string }) => {
            const id = orgId || activeOrgId;
            if (!id) throw new Error("No organisation selected");

            const { data } = await api.put<{ success: boolean; data: Role }>(`/organisations/${id}/roles/${roleId}`, { name, description, permissions });
            return data.data;
        },
        onSuccess: (_, variables) => {
            const id = variables.orgId || activeOrgId;
            queryClient.invalidateQueries({ queryKey: ["roles", id] });
            toast.success("Role updated successfully");
        },
        onError: (error: any) => {
            toast.error(error.response?.data?.message || "Failed to update role");
        }
    });
};

export const useDeleteRole = () => {
    const queryClient = useQueryClient();
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);

    return useMutation({
        mutationFn: async ({ roleId, orgId }: { roleId: string; orgId?: string }) => {
            const id = orgId || activeOrgId;
            if (!id) throw new Error("No organisation selected");

            await api.delete(`/organisations/${id}/roles/${roleId}`);
        },
        onSuccess: (_, variables) => {
            const id = variables.orgId || activeOrgId;
            queryClient.invalidateQueries({ queryKey: ["roles", id] });
            toast.success("Role deleted");
        },
        onError: (error: any) => {
            toast.error(error.response?.data?.message || "Failed to delete role");
        }
    });
}
