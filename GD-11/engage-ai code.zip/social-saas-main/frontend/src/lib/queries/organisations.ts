import { useQuery, useMutation } from "@tanstack/react-query";

export interface Organisation {
    _id: string;
    name: string;
    slug: string;
    logo: string;
    resellerId?: string;
    role?: any;
    isOwner?: boolean;
    memberId?: string;
}

export const useGetMyOrganisations = () => { return { data: [], isLoading: false } };
export const useCreateOrganisation = () => { return { mutationFn: async () => { }, isPending: false } };
export const useCheckSlug = (slug: string) => { return { data: { available: false }, isLoading: false } };
export const useUploadOrgLogo = () => { return { mutationFn: async () => { }, isPending: false } };
export const useUpdateOrganisation = () => { return { mutationFn: async () => { }, isPending: false } };
export const useDeleteOrganisation = () => { return { mutationFn: async () => { }, isPending: false } };
