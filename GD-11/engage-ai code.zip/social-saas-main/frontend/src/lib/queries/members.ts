import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/utils/api";
import { toast } from "sonner";
import { useOrgStore } from "@/hooks/use-org-store";

export interface Member {
    _id: string;
    userId: string;

    metadata: {
        name: string;
        email: string;
    };
    role: {
        _id: string;
        name: string;
        slug: string;
    };
    isOwner: boolean;
    extraPermissions: string[];
    createdAt: string;
    updatedAt: string;
}

export interface MyMembership {
    memberId: string;
    role: string;
    permissions: string[];
    isOwner: boolean;
}

export const useListMembers = (orgId?: string) => {
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);
    const id = orgId || activeOrgId;

    return useQuery({
        queryKey: ["members", id],
        queryFn: async () => {
            if (!id) return [];
            const { data } = await api.get<{ success: boolean; data: Member[] }>(`/organisations/${id}/members`);
            return data.data;
        },
        enabled: !!id,
    });
};

export const useGetMemberCount = (orgId?: string) => {
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);
    const id = orgId || activeOrgId;

    return useQuery({
        queryKey: ["members-count", id],
        queryFn: async () => {
            if (!id) return { count: 0 };
            const { data } = await api.get<{ success: boolean; data: { count: number } }>(`/organisations/${id}/members/count`);
            return data.data;
        },
        enabled: !!id,
    });
};

export const useGetSingleMember = (memberId: string, orgId?: string) => {
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);
    const id = orgId || activeOrgId;

    return useQuery({
        queryKey: ["member", id, memberId],
        queryFn: async () => {
            if (!id || !memberId) return null;
            const { data } = await api.get<{ success: boolean; data: Member }>(`/organisations/${id}/members/${memberId}`);
            return data.data;
        },
        enabled: !!id && !!memberId,
    });
}

export const useGetMyMembership = (orgId?: string) => {
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);
    const id = orgId || activeOrgId;

    return useQuery({
        queryKey: ["membership", id],
        queryFn: async () => {
            if (!id) return null;
            const { data } = await api.get<MyMembership>(`/organisations/${id}/members/me`);
            return data;
        },
        enabled: !!id,
        retry: false,
    });
};

export const useInviteMember = () => {
    const queryClient = useQueryClient();
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);

    return useMutation({
        mutationFn: async ({ userId, roleId, orgId }: { userId: string; roleId: string; orgId?: string }) => {
            const id = orgId || activeOrgId;
            if (!id) throw new Error("No organisation selected");

            const { data } = await api.post<{ success: boolean; data: Member }>(`/organisations/${id}/members`, { userId, roleId });
            return data.data;
        },
        onSuccess: (_, variables) => {
            const id = variables.orgId || activeOrgId;
            queryClient.invalidateQueries({ queryKey: ["members", id] });
            queryClient.invalidateQueries({ queryKey: ["members-count", id] });
            toast.success("Member added successfully");
        },
        onError: (error: any) => {
            toast.error(error.response?.data?.message || "Failed to add member");
        }
    });
};

export const useUpdateMemberRole = () => {
    const queryClient = useQueryClient();
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);

    return useMutation({
        mutationFn: async ({ memberId, roleId, orgId }: { memberId: string; roleId: string; orgId?: string }) => {
            const id = orgId || activeOrgId;
            if (!id) throw new Error("No organisation selected");

            // Changed to PUT per new spec
            const { data } = await api.put<{ success: boolean }>(`/organisations/${id}/members/${memberId}/role`, { roleId });
            return data;
        },
        onSuccess: (_, variables) => {
            const id = variables.orgId || activeOrgId;
            queryClient.invalidateQueries({ queryKey: ["members", id] });
            toast.success("Member role updated successfully");
        },
        onError: (error: any) => {
            toast.error(error.response?.data?.message || "Failed to update member role");
        }
    });
};

export const useUpdateMemberPermissions = () => {
    const queryClient = useQueryClient();
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);

    return useMutation({
        mutationFn: async ({ memberId, extraPermissions, orgId }: { memberId: string; extraPermissions: string[]; orgId?: string }) => {
            const id = orgId || activeOrgId;
            if (!id) throw new Error("No organisation selected");

            const { data } = await api.put<{ success: boolean; data: Member }>(`/organisations/${id}/members/${memberId}/permissions`, { extraPermissions });
            return data;
        },
        onSuccess: (_, variables) => {
            const id = variables.orgId || activeOrgId;
            queryClient.invalidateQueries({ queryKey: ["members", id] });
            toast.success("Member permissions updated");
        },
        onError: (error: any) => {
            toast.error(error.response?.data?.message || "Failed to update permissions");
        }
    })
}

export const useRemoveMember = () => {
    const queryClient = useQueryClient();
    const activeOrgId = useOrgStore(state => state.activeOrganisation?._id);

    return useMutation({
        mutationFn: async ({ memberId, orgId }: { memberId: string; orgId?: string }) => {
            const id = orgId || activeOrgId;
            if (!id) throw new Error("No organisation selected");

            await api.delete<{ success: boolean }>(`/organisations/${id}/members/${memberId}`);
        },
        onSuccess: (_, variables) => {
            const id = variables.orgId || activeOrgId;
            queryClient.invalidateQueries({ queryKey: ["members", id] });
            queryClient.invalidateQueries({ queryKey: ["members-count", id] });
            toast.success("Member removed successfully");
        },
        onError: (error: any) => {
            toast.error(error.response?.data?.message || "Failed to remove member");
        }
    });
};
