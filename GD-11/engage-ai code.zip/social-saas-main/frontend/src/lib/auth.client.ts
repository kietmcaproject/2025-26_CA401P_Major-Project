import { useQuery } from "@tanstack/react-query";
import { getApiBaseURL } from "./api";

type AuthError = { message: string };

type AuthResponse<T = unknown> = {
  data?: T;
  error?: AuthError | null;
};

type SessionData = {
  user: {
    id: string;
    name: string;
    email: string;
    image?: string | null;
    role?: string | null;
    resellerId?: string | null;
    addressline?: string | null;
    state?: string | null;
    city?: string | null;
    country?: string | null;
    phone?: string | null;
    pincode?: string | null;
    profilePicture?: string | null;
    missingProfileFields?: string[];
    profileCompletionRequired?: boolean;
    createdAt?: string | null;
    updatedAt?: string | null;
  } | null;
  session: {
    userId: string | null;
    token: null;
  } | null;
} | null;

const baseUrl = getApiBaseURL().replace(/\/$/, "");

function getCurrentDomain(): string | undefined {
  if (typeof window === "undefined") return undefined;
  const hostname = String(window.location.hostname || "").toLowerCase().trim();
  return hostname || undefined;
}

async function request<T = unknown>(path: string, init?: RequestInit): Promise<AuthResponse<T>> {
  try {
    const response = await fetch(`${baseUrl}/api${path}`, {
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        ...(init?.headers || {}),
      },
      signal: AbortSignal.timeout(10000),
      ...init,
    });

    const payload = await response.json().catch(() => null);

    if (!response.ok) {
      return { error: { message: payload?.message || "Request failed" } };
    }

    return { data: payload as T, error: null };
  } catch (error) {
    return { error: { message: error instanceof Error ? error.message : "Network error" } };
  }
}

function normalizeProfile(payload: any): SessionData {
  const profile = payload?.data || {};
  const userId = profile?.userId || profile?._id || null;

  if (!userId) {
    return null;
  }

  const requiredFields = [
    { key: "custom:addressline", value: profile?.addressline },
    { key: "custom:state", value: profile?.state },
    { key: "custom:city", value: profile?.city },
    { key: "custom:country", value: profile?.country },
    { key: "custom:phone", value: profile?.phone },
    { key: "custom:pincode", value: profile?.pincode },
    { key: "custom:profilePicture", value: profile?.profilePicture || profile?.profile_pic },
  ];

  const missingProfileFields = requiredFields
    .filter((f) => !String(f.value || "").trim())
    .map((f) => f.key);

  return {
    user: {
      id: String(userId),
      name: String(profile?.full_name || ""),
      email: String(profile?.email || ""),
      image: profile?.profile_pic || null,
      role: profile?.role || null,
      resellerId: profile?.resellerId || null,
      addressline: profile?.addressline || null,
      state: profile?.state || null,
      city: profile?.city || null,
      country: profile?.country || null,
      phone: profile?.phone || null,
      pincode: profile?.pincode || null,
      profilePicture: profile?.profilePicture || profile?.profile_pic || null,
      missingProfileFields,
      profileCompletionRequired: missingProfileFields.length > 0,
      createdAt: profile?.createdAt || null,
      updatedAt: profile?.updatedAt || null,
    },
    session: {
      userId: String(userId),
      token: null,
    },
  };
}

export const authClient = {
  useSession() {
    const sessionQuery = useQuery({
      queryKey: ["auth", "session"],
      queryFn: async () => {
        const res = await request<any>("/user/profile", { method: "GET" });
        if (res.error) {
          throw new Error(res.error.message || "Failed to fetch profile");
        }
        return normalizeProfile(res.data);
      },
      staleTime: 5 * 60 * 1000,
      gcTime: 15 * 60 * 1000,
      refetchOnWindowFocus: false,
      retry: false,
    });

    return {
      data: sessionQuery.data ?? null,
      isPending: sessionQuery.isPending,
      error: sessionQuery.error ? { message: (sessionQuery.error as Error).message } : null,
      refetch: async () => {
        await sessionQuery.refetch();
      },
    };
  },

  signIn: {
    async email({
      email,
      password,
    }: {
      email: string;
      password: string;
      callbackURL?: string;
    }) {
      return request("/user/login", {
        method: "POST",
        body: JSON.stringify({
          email,
          password,
          originDomain: getCurrentDomain(),
        }),
      });
    },

    async social(_: { provider: string; callbackURL?: string; additionalData?: Record<string, unknown> }) {
      return { error: { message: "Social login is not enabled in Cognito flow." } };
    },
  },

  async verifyMfaLogin({
    email,
    session,
    code,
  }: {
    email: string;
    session: string;
    code: string;
  }) {
    return request("/user/verify-mfa-login", {
      method: "POST",
      body: JSON.stringify({
        email,
        session,
        code,
        originDomain: getCurrentDomain(),
      }),
    });
  },

  signUp: {
    async email({
      name,
      email,
      password,
      role,
      callbackURL,
    }: {
      name: string;
      email: string;
      password: string;
      role?: string;
      callbackURL?: string;
    }) {
      void callbackURL;
      return request("/user/signup", {
        method: "POST",
        body: JSON.stringify({
          full_name: name,
          name,
          email,
          password,
          role,
          originDomain: getCurrentDomain(),
        }),
      });
    },
  },

  async signOut() {
    return request("/user/logout", { method: "POST" });
  },

  async updateUser() {
    return { error: { message: "Profile updates are handled by backend profile endpoint." } };
  },

  async requestPasswordReset({ email }: { email: string; redirectTo?: string }) {
    return request("/user/forgot-password", {
      method: "POST",
      body: JSON.stringify({ email }),
    });
  },

  async resetPassword({
    newPassword,
    token,
  }: {
    newPassword: string;
    token: string;
  }) {
    return request("/user/confirm-forgot-password", {
      method: "POST",
      body: JSON.stringify({
        token,
        newPassword,
      }),
    });
  },
};
