import axios from "axios"

/**
 * Detects the API Base URL at runtime.
 * During development, it can fall back to env if needed, 
 * but prioritizes window.location.origin in the browser.
 */
export const getApiBaseURL = (): string => {
    const publicApiUrl = (process.env.NEXT_PUBLIC_API_URL || "").replace(/\/$/, "")

    if (typeof window !== "undefined") {
        return publicApiUrl || window.location.origin
    }

    return (
        process.env.API_URL ||
        publicApiUrl ||
        ""
    ).replace(/\/$/, "")
}
const apiBaseURL = getApiBaseURL()

export const api = axios.create({
    baseURL: apiBaseURL ? `${apiBaseURL}/api` : "/api",
    withCredentials: true,
    timeout: 10000,
    headers: {
        "Content-Type": "application/json",
    },
})
