import { cache } from "react";
import type { ResellerContent } from "@/lib/queries/reseller-config";

export interface BrandingColors {
    primary: string;
    secondary: string;
    accent: string;
    dark: string;
}

export interface BrandingContact {
    address?: string;
    phone?: string;
    email?: string;
}

export interface BrandingSocial {
    twitter?: string;
    linkedin?: string;
    facebook?: string;
    instagram?: string;
}

export interface AppBranding {
    companyName: string;
    logo: string;
    favicon: string;
    domain?: string;
    colors?: BrandingColors;
    contact?: BrandingContact;
    social?: BrandingSocial;
    isDefault?: boolean;
    content?: Partial<ResellerContent>;
}

interface SocialContentResponse {
    success?: boolean;
    data?: Record<string, unknown>;
}

const normalizeDomain = (domain: string) =>
    String(domain || "")
        .toLowerCase()
        .trim()
        .split(":")[0];

const isLocalDomain = (domain: string) =>
    !domain ||
    domain === "localhost" ||
    domain.endsWith(".localhost") ||
    domain === "127.0.0.1" ||
    domain === "::1";

const buildSocialConfigApiUrl = (originDomain: string, path: "branding" | "content"): string | null => {
    const normalizedOrigin = normalizeDomain(originDomain);

    if (isLocalDomain(normalizedOrigin)) {
        return null;
    }

    const parts = normalizedOrigin.split(".").filter(Boolean);
    const parentDomain = parts.length > 2 ? parts.slice(1).join(".") : normalizedOrigin;
    if (!parentDomain) {
        return null;
    }

    const url = new URL(`https://reseller.${parentDomain}/api/social-config/${path}`);

    url.searchParams.set("originDomain", normalizedOrigin);

    return url.toString();
};

export const buildSocialContentApiUrl = (originDomain: string): string | null =>
    buildSocialConfigApiUrl(originDomain, "content");

export const buildSocialBrandingApiUrl = (originDomain: string): string | null =>
    buildSocialConfigApiUrl(originDomain, "branding");

const toRecord = (value: unknown): Record<string, unknown> =>
    typeof value === "object" && value !== null ? (value as Record<string, unknown>) : {};

const toStringValue = (value: unknown): string => (typeof value === "string" ? value : "");

const normalizeContact = (raw: Record<string, unknown>): BrandingContact => ({
    address: toStringValue(raw.address || raw.location),
    phone: toStringValue(raw.phone || raw.contactNumber || raw.number || raw.mobile),
    email: toStringValue(raw.email || raw.supportEmail),
});

const normalizeSocial = (raw: Record<string, unknown>): BrandingSocial => ({
    twitter: toStringValue(raw.twitter),
    linkedin: toStringValue(raw.linkedin),
    facebook: toStringValue(raw.facebook),
    instagram: toStringValue(raw.instagram),
});

export const mapSocialContentResponse = (
    payload: SocialContentResponse
): Record<string, unknown> | null => {
    if (!payload?.success || !payload?.data) {
        return null;
    }
    return payload.data;
};

const extractBrandingRecord = (data: Record<string, unknown>) => {
    const nestedBranding = toRecord(data.branding);
    return Object.keys(nestedBranding).length > 0 ? nestedBranding : data;
};

const mapSocialPayloadToBranding = (
    payload: SocialContentResponse,
    originDomain: string
): AppBranding | null => {
    const data = mapSocialContentResponse(payload);
    if (!data) {
        return null;
    }

    const brandingRaw = extractBrandingRecord(data);
    const colorsRaw = toRecord(brandingRaw.colors);
    const contactRaw = toRecord(data.contact);
    const socialRaw = toRecord(data.social);
    const primary = toStringValue(colorsRaw.primary);
    const secondary = toStringValue(colorsRaw.secondary);
    const accent = toStringValue(colorsRaw.accent);
    const dark = toStringValue(colorsRaw.dark);
    const colors =
        primary || secondary || accent || dark
            ? { primary, secondary, accent, dark }
            : undefined;

    return {
        companyName: toStringValue(brandingRaw.platformName || brandingRaw.companyName) || "Veblika",
        logo: toStringValue(brandingRaw.logo || brandingRaw.favicon),
        favicon: toStringValue(brandingRaw.favicon || brandingRaw.logo),
        domain: normalizeDomain(originDomain),
        colors,
        contact: normalizeContact(contactRaw),
        social: normalizeSocial(socialRaw),
        // Keep raw content payload available for marketing pages.
        content: data as Partial<ResellerContent>,
    } as AppBranding;
};

export const mapSocialContentToBranding = (
    payload: SocialContentResponse,
    originDomain: string
): AppBranding | null => mapSocialPayloadToBranding(payload, originDomain);

export const mapSocialBrandingResponse = (
    payload: SocialContentResponse,
    originDomain: string
): AppBranding | null => mapSocialPayloadToBranding(payload, originDomain);

export const getResellerBranding = cache(async (domain: string) => {
    try {
        const normalizedDomain = normalizeDomain(domain);
        const brandingUrl = buildSocialBrandingApiUrl(normalizedDomain);
        const contentUrl = buildSocialContentApiUrl(normalizedDomain);

    

        if (!brandingUrl && !contentUrl) {
            console.log('[getResellerBranding] no URLs built — skipping fetch');
            return null;
        }

        const token = process.env["X_API_TOKEN"] || "";

        const fetchOptions = (url: string) =>
            fetch(url, {
                method: "GET",
                headers: {
                    "x-api-token": token,
                    "Content-Type": "application/json",
                },
                next: { revalidate: 60 },
                signal: AbortSignal.timeout(5000),
            });

        const [brandingResponse, contentResponse] = await Promise.all([
            brandingUrl ? fetchOptions(brandingUrl).catch((e) => { console.error('[getResellerBranding] branding fetch error:', e); return null; }) : Promise.resolve(null),
            contentUrl  ? fetchOptions(contentUrl).catch((e)  => { console.error('[getResellerBranding] content fetch error:', e); return null; })  : Promise.resolve(null),
        ]);

       
        const brandingPayload = brandingResponse?.ok ? (await brandingResponse.json()) as SocialContentResponse : null;
        const contentPayload  = contentResponse?.ok  ? (await contentResponse.json())  as SocialContentResponse : null;

      
        const branding = brandingPayload ? mapSocialBrandingResponse(brandingPayload, normalizedDomain) : null;
        const content  = contentPayload  ? mapSocialContentResponse(contentPayload)  : null;

       
        if (!branding && !content) {
            return null;
        }

        return {
            ...(branding || { companyName: "Veblika", logo: "", favicon: "" }),
            content: (content ?? undefined) as Partial<ResellerContent> | undefined,
        } as AppBranding;

    } catch (err) {
        console.error('[getResellerBranding] unexpected error:', err);
        return null;
    }
});

// Backward-compatible exports for existing imports.
export const buildSocialThemeApiUrl = buildSocialContentApiUrl;
export const mapSocialThemeResponse = mapSocialContentToBranding;
