export const OAUTH_POPUP_MESSAGE_TYPE = "social-saas:oauth-result";

export type OAuthPopupResult = {
  provider: string;
  connected?: boolean;
  error?: string | null;
};

export function openOAuthPopup(url: string, _title: string) {
  const popup = window.open(url, "_blank");

  if (popup) {
    popup.focus();
  }

  return popup;
}

export function isOAuthPopupWindow() {
  return typeof window !== "undefined" && !!window.opener && window.opener !== window;
}

export function notifyOAuthOpener(result: OAuthPopupResult) {
  if (!isOAuthPopupWindow() || window.opener.closed) {
    return false;
  }

  window.opener.postMessage(
    {
      type: OAUTH_POPUP_MESSAGE_TYPE,
      ...result,
    },
    window.location.origin
  );

  return true;
}
