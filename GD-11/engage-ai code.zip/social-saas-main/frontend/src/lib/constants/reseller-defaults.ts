
import { ResellerContent } from "@/lib/queries/reseller-config";

export const DEFAULT_RESELLER_CONTENT: ResellerContent = {
    hero: {
        title: "Your social media command center",
        subtitle: "Schedule, publish, analyze, and engage — all from one beautiful dashboard. The complete toolkit for social media success.",
    },
    about: {
        title: "About Us",
        description: "We help businesses manage their social media presence with powerful tools and analytics.",
    },
    contact: {
        address: "123 Tech Street, San Francisco, CA",
        phone: "+1 (555) 123-4567",
        email: "contact@example.com",
    },
    cta: {
        title: "Grow your brand presence on social media.",
        subtitle: "Try Veblika free for 14 days. No credit card required.",
        buttonText: "Sign Up for Free Trial",
    },
    features: [
        {
            icon: "Calendar",
            title: "Smart Scheduling",
            description: "Schedule posts across all platforms with AI-powered best-time suggestions.",
            order: 0,
        },
        {
            icon: "MessageSquare",
            title: "Unified Inbox",
            description: "Manage all comments, DMs, and mentions from one centralized inbox.",
            order: 1,
        },
        {
            icon: "BarChart3",
            title: "Advanced Analytics",
            description: "Track performance with beautiful dashboards and custom reports.",
            order: 2,
        },
        {
            icon: "Users",
            title: "Team Collaboration",
            description: "Approval workflows, role-based access, and seamless teamwork.",
            order: 3,
        },
        {
            icon: "Globe",
            title: "Social Listening",
            description: "Monitor brand mentions, trends, and competitor activity in real-time.",
            order: 4,
        },
        {
            icon: "Shield",
            title: "Enterprise Security",
            description: "SSO, 2FA, audit logs, and compliance workflows for large teams.",
            order: 5,
        },
    ],
    stats: [
        { value: "10K+", label: "Teams worldwide", order: 0 },
        { value: "50M+", label: "Posts scheduled", order: 1 },
        { value: "99.9%", label: "Uptime SLA", order: 2 },
        { value: "4.9", label: "Customer rating", order: 3 },
    ],
    testimonials: [
        {
            name: "Sarah Chen",
            content: "Veblika has completely transformed how we manage social media. The scheduling and analytics alone have saved us 10+ hours per week.",
            role: "Marketing Director",
            company: "TechFlow",
            rating: 5,
            order: 0
        },
        {
            name: "Michael Torres",
            content: "The unified inbox is a game-changer. We never miss a customer message now, and response times have dropped by 60%.",
            role: "Customer Success Lead",
            company: "StartupHub",
            rating: 5,
            order: 1
        },
        {
            name: "Emily Watson",
            content: "Finally, a social media tool that's as beautiful as it is powerful. My team actually enjoys using it.",
            role: "CEO",
            company: "Creative Co",
            rating: 5,
            order: 2
        },
    ],
    faqs: [
        {
            question: "What social platforms do you support?",
            answer: "Veblika supports Facebook, Instagram, X (Twitter), LinkedIn, TikTok, Pinterest, YouTube, and Threads. We're constantly adding new platforms.",
            order: 0
        },
        {
            question: "Is there a free trial?",
            answer: "Yes! All paid plans include a 14-day free trial. No credit card required to start.",
            order: 1
        },
        {
            question: "Can I cancel anytime?",
            answer: "Absolutely. You can upgrade, downgrade, or cancel your subscription at any time. No long-term contracts.",
            order: 2
        },
        {
            question: "Do you offer team plans?",
            answer: "Yes, we have plans designed for teams of all sizes, from small agencies to large enterprises.",
            order: 3
        },
    ],
    pricing: [
        {
            name: "Starter",
            price: "$29",
            period: "/mo",
            description: "Perfect for individuals and small teams.",
            features: ["5 social profiles", "50 scheduled posts/mo", "Basic analytics"],
            buttonText: "Start free trial",
            isPopular: false,
            order: 0
        },
        {
            name: "Professional",
            price: "$79",
            period: "/mo",
            description: "For growing teams that need more power.",
            features: ["15 social profiles", "Unlimited scheduling", "Advanced analytics", "Team collaboration"],
            buttonText: "Start free trial",
            isPopular: true,
            order: 1
        },
        {
            name: "Agency",
            price: "$199",
            period: "/mo",
            description: "For agencies managing multiple brands.",
            features: ["50 social profiles", "White-label reports", "Client portals", "Approval workflows"],
            buttonText: "Start free trial",
            isPopular: false,
            order: 2
        }
    ],
    aboutPage: {
        tagline: "Established 2023",
        headline: "We are Veblika",
        story: "We started with a simple mission: to make social media management easy and accessible for everyone.",
        stats: [
            { value: "50+", label: "Team Members", icon: "Users" },
            { value: "100K+", label: "Happy Users", icon: "Smile" },
        ],
        industries: ["Marketing", "Technology", "E-commerce"],
    },
    privacyPolicy: "Privacy Policy Content",
    termsOfService: "Terms of Service Content",
};
