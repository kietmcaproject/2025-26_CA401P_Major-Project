import {
    Calendar,
    Send,
    MessageSquare,
    BarChart3,
    Ear,
    Users,
    FolderOpen,
    Megaphone,
    Shield,
    Heart,
} from "lucide-react";

export interface FeaturePageData {
    slug: string;
    title: string;
    tagline: string;
    description: string;
    icon: string;
    color: string;
    benefits: {
        title: string;
        description: string;
    }[];
    capabilities: {
        title: string;
        description: string;
        icon?: string;
    }[];
}

export const featuresData: Record<string, FeaturePageData> = {
    scheduling: {
        slug: "scheduling",
        title: "Publishing & Scheduling",
        tagline: "Plan, schedule, and publish with precision",
        description:
            "Take control of your content calendar. Schedule posts across all platforms, optimize timing with AI-powered suggestions, and never miss the perfect moment to engage your audience.",
        icon: "Calendar",
        color: "blue",
        benefits: [
            {
                title: "Save hours every week",
                description: "Batch-create and schedule content in advance, freeing up time for strategy.",
            },
            {
                title: "Consistent posting",
                description: "Maintain a steady presence across all platforms without manual effort.",
            },
            {
                title: "Optimal timing",
                description: "AI suggests the best times to post based on your audience's activity.",
            },
            {
                title: "Campaign support",
                description: "Plan and execute multi-platform campaigns from a single dashboard.",
            },
        ],
        capabilities: [
            {
                title: "Visual Calendar",
                description: "Drag-and-drop content planning for days, weeks, or months ahead.",
            },
            {
                title: "Multi-Platform Publishing",
                description: "Post to Facebook, Instagram, LinkedIn, X, TikTok, and Pinterest simultaneously.",
            },
            {
                title: "Bulk Scheduling",
                description: "Upload multiple posts at once via CSV or Excel for efficient planning.",
            },
            {
                title: "Content Queuing",
                description: "Auto-fill time slots with evergreen content to maintain consistency.",
            },
            {
                title: "Post Previews",
                description: "See exactly how your posts will appear on each platform before publishing.",
            },
            {
                title: "Hashtag Suggestions",
                description: "Get smart hashtag recommendations based on content and trends.",
            },
        ],
    },

    inbox: {
        slug: "inbox",
        title: "Social Inbox",
        tagline: "Every message, one powerful inbox",
        description:
            "Never miss a comment, mention, or DM again. Unify all your social conversations in one place and respond faster with smart tools built for teams.",
        icon: "MessageSquare",
        color: "green",
        benefits: [
            {
                title: "Faster response times",
                description: "Reply to messages across all platforms from a single interface.",
            },
            {
                title: "Better customer service",
                description: "Track conversations and never lose context with unified threads.",
            },
            {
                title: "Team efficiency",
                description: "Assign messages to team members and track resolution.",
            },
            {
                title: "Sentiment awareness",
                description: "Quickly identify urgent or negative messages that need attention.",
            },
        ],
        capabilities: [
            {
                title: "Unified Inbox",
                description: "View all comments, mentions, DMs, and replies in one centralized dashboard.",
            },
            {
                title: "Message Assignment",
                description: "Tag and assign messages to specific team members for follow-up.",
            },
            {
                title: "Quick Replies",
                description: "Use saved response templates to reply faster to common questions.",
            },
            {
                title: "Sentiment Tagging",
                description: "Automatically identify positive, neutral, or negative messages.",
            },
            {
                title: "Conversation History",
                description: "See full conversation context without switching between platforms.",
            },
            {
                title: "Real-time Notifications",
                description: "Get instant alerts for high-priority messages and mentions.",
            },
        ],
    },

    analytics: {
        slug: "analytics",
        title: "Analytics & Reports",
        tagline: "Data that drives decisions",
        description:
            "Understand what's working and why. Get deep insights into your social performance with beautiful, actionable reports that prove your ROI.",
        icon: "BarChart3",
        color: "purple",
        benefits: [
            {
                title: "Data-driven strategy",
                description: "Make informed decisions based on real performance metrics.",
            },
            {
                title: "Clear ROI metrics",
                description: "Demonstrate the value of your social efforts to stakeholders.",
            },
            {
                title: "Content optimization",
                description: "Discover what content resonates most with your audience.",
            },
            {
                title: "Competitive edge",
                description: "Benchmark your performance against competitors and industry standards.",
            },
        ],
        capabilities: [
            {
                title: "Post Performance",
                description: "Track likes, comments, shares, clicks, and saves for every post.",
            },
            {
                title: "Audience Insights",
                description: "Understand growth trends, demographics, and peak activity times.",
            },
            {
                title: "Engagement Rates",
                description: "Measure what content types drive the most interaction.",
            },
            {
                title: "Custom Reports",
                description: "Create white-label PDF reports tailored for clients or stakeholders.",
            },
            {
                title: "Benchmarking",
                description: "Compare your metrics against competitors or industry averages.",
            },
            {
                title: "Export & Share",
                description: "Download data or share live dashboards with your team.",
            },
        ],
    },

    listening: {
        slug: "listening",
        title: "Social Listening",
        tagline: "Hear what the world is saying",
        description:
            "Monitor conversations that matter. Track brand mentions, industry trends, and competitor activity to stay ahead and engage proactively.",
        icon: "Ear",
        color: "orange",
        benefits: [
            {
                title: "Brand protection",
                description: "Catch and address negative mentions before they escalate.",
            },
            {
                title: "Trend awareness",
                description: "Stay on top of emerging topics relevant to your audience.",
            },
            {
                title: "Competitive intelligence",
                description: "Monitor what competitors are doing and how people react.",
            },
            {
                title: "Proactive engagement",
                description: "Join conversations and connect with potential customers organically.",
            },
        ],
        capabilities: [
            {
                title: "Keyword Tracking",
                description: "Monitor brand mentions, hashtags, and industry-specific terms.",
            },
            {
                title: "Trending Topics",
                description: "Discover emerging trends relevant to your audience and niche.",
            },
            {
                title: "Competitive Monitoring",
                description: "Track competitor mentions, campaigns, and audience sentiment.",
            },
            {
                title: "Sentiment Analysis",
                description: "Gauge public perception with AI-powered sentiment scoring.",
            },
            {
                title: "Alert System",
                description: "Get notified instantly when important keywords are mentioned.",
            },
            {
                title: "Historical Data",
                description: "Analyze trends over time to identify patterns and opportunities.",
            },
        ],
    },

    collaboration: {
        slug: "collaboration",
        title: "Team Collaboration",
        tagline: "Work together, win together",
        description:
            "Streamline your team's workflow with powerful collaboration tools. From content approvals to task assignments, keep everyone aligned and productive.",
        icon: "Users",
        color: "cyan",
        benefits: [
            {
                title: "Efficient workflows",
                description: "Eliminate email chains and scattered feedback with centralized tools.",
            },
            {
                title: "Fewer mistakes",
                description: "Approval processes ensure content is reviewed before publishing.",
            },
            {
                title: "Clear accountability",
                description: "Know who's responsible for what with task assignments and tracking.",
            },
            {
                title: "Scalable operations",
                description: "Grow your team without losing efficiency or quality control.",
            },
        ],
        capabilities: [
            {
                title: "Team Roles & Permissions",
                description: "Define admin, editor, and viewer access levels for security.",
            },
            {
                title: "Approval Workflows",
                description: "Set up multi-stage approvals for clients or stakeholders.",
            },
            {
                title: "Draft Commenting",
                description: "Leave internal notes and feedback directly on content drafts.",
            },
            {
                title: "Task Assignments",
                description: "Assign content creation tasks to writers, designers, or team members.",
            },
            {
                title: "Activity Logs",
                description: "Track who made changes and when with full audit history.",
            },
            {
                title: "Client Portals",
                description: "Give clients read-only access to review and approve content.",
            },
        ],
    },

    "content-library": {
        slug: "content-library",
        title: "Content Library",
        tagline: "Your creative assets, organized",
        description:
            "Keep all your media assets in one searchable, organized space. Save time finding the right image, video, or caption when you need it most.",
        icon: "FolderOpen",
        color: "pink",
        benefits: [
            {
                title: "Save time",
                description: "Find assets instantly with smart search and tagging.",
            },
            {
                title: "Consistent branding",
                description: "Ensure everyone uses approved, on-brand assets.",
            },
            {
                title: "Easy reuse",
                description: "Repurpose evergreen content without recreating from scratch.",
            },
            {
                title: "Version control",
                description: "Track changes and access previous versions when needed.",
            },
        ],
        capabilities: [
            {
                title: "Central Media Storage",
                description: "Store and organize images, videos, GIFs, and captions.",
            },
            {
                title: "Smart Search",
                description: "Find assets quickly with tags, filters, and text search.",
            },
            {
                title: "Asset Tagging",
                description: "Categorize content by campaign, platform, or custom labels.",
            },
            {
                title: "Version History",
                description: "Access previous edits and restore older versions as needed.",
            },
            {
                title: "Usage Tracking",
                description: "See where and when assets have been used across campaigns.",
            },
            {
                title: "Team Sharing",
                description: "Share approved assets with team members and collaborators.",
            },
        ],
    },

    ads: {
        slug: "ads",
        title: "Ad Management",
        tagline: "Campaigns that convert",
        description:
            "Create, manage, and optimize social ads from one dashboard. Track spend, test creatives, and maximize your return on ad investment.",
        icon: "Megaphone",
        color: "red",
        benefits: [
            {
                title: "Centralized control",
                description: "Manage ads across platforms without switching tools.",
            },
            {
                title: "Better ROI",
                description: "Track spend and performance to optimize campaigns.",
            },
            {
                title: "Faster testing",
                description: "A/B test creatives and audiences to find winners quickly.",
            },
            {
                title: "Saved audiences",
                description: "Reuse high-performing audience segments across campaigns.",
            },
        ],
        capabilities: [
            {
                title: "Ad Creation",
                description: "Build and launch ads directly from your dashboard.",
            },
            {
                title: "Budget Tracking",
                description: "Monitor spend and ROI across all campaigns in real-time.",
            },
            {
                title: "A/B Testing",
                description: "Compare creatives, copy, and audiences to optimize performance.",
            },
            {
                title: "Audience Targeting",
                description: "Create and save custom audiences for precise targeting.",
            },
            {
                title: "Performance Reports",
                description: "Get detailed breakdowns of ad performance and conversions.",
            },
            {
                title: "Cross-Platform Sync",
                description: "Run coordinated campaigns across Facebook, Instagram, and LinkedIn.",
            },
        ],
    },

    ugc: {
        slug: "ugc",
        title: "UGC & Influencers",
        tagline: "Authentic content at scale",
        description:
            "Harness the power of user-generated content and influencer partnerships. Collect, curate, and amplify authentic brand stories.",
        icon: "Heart",
        color: "rose",
        benefits: [
            {
                title: "Boost authenticity",
                description: "Leverage real customer content for genuine brand stories.",
            },
            {
                title: "Expand reach",
                description: "Tap into influencer audiences to grow your community.",
            },
            {
                title: "Save on content",
                description: "Curate UGC instead of creating everything from scratch.",
            },
            {
                title: "Build trust",
                description: "Social proof from real users increases credibility.",
            },
        ],
        capabilities: [
            {
                title: "UGC Collection",
                description: "Aggregate branded content from hashtags and mentions.",
            },
            {
                title: "Content Curation",
                description: "Review, approve, and organize user-submitted content.",
            },
            {
                title: "Influencer Tracking",
                description: "Identify and manage influencer partnerships in one place.",
            },
            {
                title: "Rights Management",
                description: "Request and track usage rights for user content.",
            },
            {
                title: "Performance Analytics",
                description: "Measure the impact of UGC and influencer campaigns.",
            },
            {
                title: "Repost Tools",
                description: "Easily share curated content with proper attribution.",
            },
        ],
    },

    security: {
        slug: "security",
        title: "Security & Compliance",
        tagline: "Enterprise-grade protection",
        description:
            "Keep your social accounts and data secure with robust security features. Meet compliance requirements with audit logs and governance tools.",
        icon: "Shield",
        color: "slate",
        benefits: [
            {
                title: "Account protection",
                description: "Secure social accounts with SSO and two-factor authentication.",
            },
            {
                title: "Compliance ready",
                description: "Meet regulatory requirements with built-in governance tools.",
            },
            {
                title: "Full visibility",
                description: "Track every action with comprehensive audit logs.",
            },
            {
                title: "Peace of mind",
                description: "Enterprise-grade security for sensitive brand accounts.",
            },
        ],
        capabilities: [
            {
                title: "SSO Integration",
                description: "Single sign-on with your existing identity provider.",
            },
            {
                title: "Two-Factor Auth",
                description: "Add an extra layer of security to all user accounts.",
            },
            {
                title: "Audit Logs",
                description: "Track who did what with detailed activity history.",
            },
            {
                title: "Role-Based Access",
                description: "Control permissions based on user roles and responsibilities.",
            },
            {
                title: "Compliance Workflows",
                description: "Built-in processes for regulated industries.",
            },
            {
                title: "Data Encryption",
                description: "End-to-end encryption for all sensitive data.",
            },
        ],
    },
};

// Feature categories for overview page
export const featureCategories = [
    {
        title: "Plan & Publish",
        features: ["scheduling", "content-library"],
    },
    {
        title: "Engage & Monitor",
        features: ["inbox", "listening"],
    },
    {
        title: "Analyze & Report",
        features: ["analytics"],
    },
    {
        title: "Collaborate & Scale",
        features: ["collaboration", "ads", "ugc", "security"],
    },
];
