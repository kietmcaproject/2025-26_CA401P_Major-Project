import {
    Calendar,
    Send,
    MessageSquare,
    BarChart3,
    Ear,
    Users,
    FolderOpen,
    Megaphone,
    Shield,
    Heart,
    Building2,
    Sparkles,
    BookOpen,
    HelpCircle,
    FileCode,
} from "lucide-react";

export interface NavItem {
    title: string;
    href: string;
    description?: string;
    icon?: string;
}

export interface NavSection {
    title: string;
    items: NavItem[];
}

export interface NavDropdown {
    title: string;
    sections?: NavSection[];
    items?: NavItem[];
    featured?: {
        title: string;
        description: string;
        href: string;
        image?: string;
    };
}

// Features Mega Menu Structure
export const featuresNavigation: NavDropdown = {
    title: "Features",
    sections: [
        {
            title: "Core Features",
            items: [
                {
                    title: "Publishing & Scheduling",
                    href: "/features/scheduling",
                    description: "Schedule posts across all platforms with smart timing",
                    icon: "Calendar",
                },
                {
                    title: "Social Inbox",
                    href: "/features/inbox",
                    description: "Manage all messages, comments & mentions in one place",
                    icon: "MessageSquare",
                },
                {
                    title: "Analytics & Reports",
                    href: "/features/analytics",
                    description: "Track performance with powerful insights & custom reports",
                    icon: "BarChart3",
                },
            ],
        },
        {
            title: "Advanced",
            items: [
                {
                    title: "Social Listening",
                    href: "/features/listening",
                    description: "Monitor brand mentions, trends & competitor activity",
                    icon: "Ear",
                },
                {
                    title: "Team Collaboration",
                    href: "/features/collaboration",
                    description: "Workflows, approvals & team management tools",
                    icon: "Users",
                },
                {
                    title: "Content Library",
                    href: "/features/content-library",
                    description: "Centralized media storage & asset management",
                    icon: "FolderOpen",
                },
            ],
        },
        {
            title: "More",
            items: [
                {
                    title: "Ad Management",
                    href: "/features/ads",
                    description: "Create and manage social ads from one dashboard",
                    icon: "Megaphone",
                },
                {
                    title: "UGC & Influencers",
                    href: "/features/ugc",
                    description: "Track influencers and collect user-generated content",
                    icon: "Heart",
                },
                {
                    title: "Security & Compliance",
                    href: "/features/security",
                    description: "Enterprise-grade security and audit controls",
                    icon: "Shield",
                },
            ],
        },
    ],
    featured: {
        title: "See All Features",
        description: "Explore everything our platform can do for your social media success",
        href: "/features",
    },
};

// Solutions Navigation
export const solutionsNavigation: NavDropdown = {
    title: "Solutions",
    items: [
        {
            title: "For Agencies",
            href: "/solutions/agencies",
            description: "Manage multiple clients with white-label dashboards",
            icon: "Building2",
        },
        {
            title: "For Enterprise",
            href: "/solutions/enterprise",
            description: "Scale your social presence with advanced controls",
            icon: "Shield",
        },
        {
            title: "For Creators",
            href: "/solutions/creators",
            description: "Grow your personal brand across platforms",
            icon: "Sparkles",
        },
    ],
};

// Resources Navigation
export const resourcesNavigation: NavDropdown = {
    title: "Resources",
    items: [
        {
            title: "Blog",
            href: "/resources/blog",
            description: "Tips, strategies & social media insights",
            icon: "BookOpen",
        },
        {
            title: "Help Center",
            href: "/resources/help",
            description: "Guides, tutorials & FAQs",
            icon: "HelpCircle",
        },
    ],
};

// Main Navigation Config
export const mainNavigation = {
    features: featuresNavigation,
    solutions: solutionsNavigation,
    pricing: {
        title: "Pricing",
        href: "/pricing",
    },
    resources: resourcesNavigation,
};

// Supported Social Platforms
export const socialPlatforms = [
    { name: "Facebook", icon: "facebook", color: "#1877F2" },
    { name: "Instagram", icon: "instagram", color: "#E4405F" },
    { name: "X (Twitter)", icon: "twitter", color: "#000000" },
    { name: "LinkedIn", icon: "linkedin", color: "#0A66C2" },
    { name: "TikTok", icon: "tiktok", color: "#000000" },
    { name: "Pinterest", icon: "pinterest", color: "#E60023" },
    { name: "YouTube", icon: "youtube", color: "#FF0000" },
    { name: "Threads", icon: "threads", color: "#000000" },
];
