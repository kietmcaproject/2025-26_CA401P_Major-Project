import { NextRequest, NextResponse } from "next/server"

const authRoutes = ["/login", "/signup", "/forget-password", "/reset-password"]

const publicRoutes: string[] = [
  "/",
  "/about",
  "/contact",
  "/privacy",
  "/terms",
  "/features",
  "/pricing",
  "/solutions",
  "/resources",
  "/oauth/callback",
  "/accept-invite"
]

function decodeJwtPayload(token: string): Record<string, unknown> | null {
  try {
    const parts = token.split(".")
    if (parts.length < 2) return null

    const payload = parts[1]
    const normalized = payload.replace(/-/g, "+").replace(/_/g, "/")
    const padded = normalized.padEnd(normalized.length + ((4 - (normalized.length % 4)) % 4), "=")
    const decoded = atob(padded)

    return JSON.parse(decoded)
  } catch {
    return null
  }
}

function isValidIdToken(token: string | null): boolean {
  if (!token) return false
  const payload = decodeJwtPayload(token)
  if (!payload) return false

  const exp = Number(payload.exp)
  if (!Number.isFinite(exp)) return false

  const nowInSeconds = Math.floor(Date.now() / 1000)
  return exp > nowInSeconds
}

export async function middleware(request: NextRequest) {
  const idToken = request.cookies.get("idToken")?.value || null
  const isAuthenticated = isValidIdToken(idToken)
  const { pathname } = request.nextUrl

  // Allow all API routes to pass through
  if (pathname.startsWith("/api")) {
    return NextResponse.next()
  }

  const isAuthRoute = authRoutes.some((route) => pathname.startsWith(route))
  const isPublicRoute = publicRoutes.some((route) => pathname.startsWith(route))

  if (isAuthenticated && isAuthRoute) {
    // Get all cookies from the request
    const response = NextResponse.redirect(new URL("/", request.url))
    return response
  }

  if (!isAuthenticated && !isAuthRoute && !isPublicRoute) {
    const loginUrl = new URL("/login", request.url)
    const response = NextResponse.redirect(loginUrl)

    return response
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    // Skip Next.js internals and all static files
    "/((?!_next/static|_next/image|favicon.ico|sitemap.xml|robots.txt|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)).*)",
  ],
}
