"use client"

import * as React from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Spinner } from "@/components/ui/spinner"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Calendar, Clock, Trash2, Image as ImageIcon, Video } from "lucide-react"
import { ImageApi } from "@/utils/api"
import { toast } from "sonner"
import { format } from "date-fns"

const PLATFORM_INFO: Record<string, { name: string; icon: string; color: string }> = {
    INSTAGRAM: { name: "Instagram", icon: "/icons/instagram.png", color: "bg-gradient-to-r from-purple-500 to-pink-500" },
    FACEBOOK: { name: "Facebook", icon: "/icons/facebook.png", color: "bg-blue-600" },
    LINKEDIN: { name: "LinkedIn", icon: "/icons/linkedin.png", color: "bg-blue-700" },
    YOUTUBE: { name: "YouTube", icon: "/icons/youtube.png", color: "bg-red-600" },
}

interface ScheduledPost {
    _id: string
    platform: string
    postType: string
    content: string
    scheduledFor: string
    imageUrl?: string
    videoUrl?: string
    createdAt: string
}

export default function ScheduledPostsPage() {
    const [posts, setPosts] = React.useState<ScheduledPost[]>([])
    const [isLoading, setIsLoading] = React.useState(true)
    const [deleteDialogOpen, setDeleteDialogOpen] = React.useState(false)
    const [postToDelete, setPostToDelete] = React.useState<string | null>(null)
    const [isDeleting, setIsDeleting] = React.useState(false)

    // Fetch scheduled posts
    const fetchScheduledPosts = async () => {
        try {
            setIsLoading(true)
            const response = await ImageApi.get("/scheduled-posts")

            if (response.data.success) {
                setPosts(response.data.posts || [])
            } else {
                toast.error("Failed to fetch scheduled posts")
            }
        } catch (error: any) {
            console.error("Error fetching scheduled posts:", error)
            toast.error(error?.response?.data?.message || "Failed to fetch scheduled posts")
        } finally {
            setIsLoading(false)
        }
    }

    React.useEffect(() => {
        fetchScheduledPosts()
    }, [])

    // Handle delete
    const handleDeleteClick = (postId: string) => {
        setPostToDelete(postId)
        setDeleteDialogOpen(true)
    }

    const confirmDelete = async () => {
        if (!postToDelete) return

        try {
            setIsDeleting(true)
            const response = await ImageApi.delete(`/scheduled-posts/${postToDelete}`)

            if (response.data.success) {
                toast.success("Scheduled post deleted successfully")
                setPosts(posts.filter(p => p._id !== postToDelete))
            } else {
                toast.error(response.data.message || "Failed to delete post")
            }
        } catch (error: any) {
            console.error("Error deleting post:", error)
            toast.error(error?.response?.data?.message || "Failed to delete post")
        } finally {
            setIsDeleting(false)
            setDeleteDialogOpen(false)
            setPostToDelete(null)
        }
    }

    if (isLoading) {
        return (
            <div className="flex items-center justify-center min-h-[400px]">
                <Spinner className="h-8 w-8" />
            </div>
        )
    }

    return (
        <div className="container mx-auto p-6 max-w-6xl">
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-slate-900">Scheduled Posts</h1>
                <p className="text-slate-500 mt-2">Manage your upcoming social media posts</p>
            </div>

            {posts.length === 0 ? (
                <Card className="p-12 text-center">
                    <div className="flex flex-col items-center gap-4">
                        <Calendar className="h-16 w-16 text-slate-300" />
                        <div>
                            <h3 className="text-xl font-semibold text-slate-700">No Scheduled Posts</h3>
                            <p className="text-slate-500 mt-2">You don't have any posts scheduled yet.</p>
                        </div>
                    </div>
                </Card>
            ) : (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {posts.map((post) => {
                        const platformInfo = PLATFORM_INFO[post.platform] || { name: post.platform, icon: "", color: "bg-gray-500" }
                        const scheduledDate = new Date(post.scheduledFor)
                        const isVideo = post.postType === "video" || post.postType === "reel" || post.postType === "short"

                        return (
                            <Card key={post._id} className="overflow-hidden hover:shadow-lg transition-shadow">
                                <CardHeader className="pb-3">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            {platformInfo.icon && (
                                                <img src={platformInfo.icon} alt={platformInfo.name} className="w-6 h-6" />
                                            )}
                                            <span className="font-semibold text-slate-900">{platformInfo.name}</span>
                                        </div>
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                                            onClick={() => handleDeleteClick(post._id)}
                                        >
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </CardHeader>

                                <CardContent className="space-y-3">
                                    {/* Media Preview */}
                                    {(post.imageUrl || post.videoUrl) && (
                                        <div className="relative rounded-lg overflow-hidden bg-slate-100 h-40">
                                            {isVideo && post.videoUrl ? (
                                                <div className="flex items-center justify-center h-full">
                                                    <Video className="h-12 w-12 text-slate-400" />
                                                </div>
                                            ) : post.imageUrl ? (
                                                <img
                                                    src={post.imageUrl}
                                                    alt="Post preview"
                                                    className="w-full h-full object-cover"
                                                />
                                            ) : null}
                                        </div>
                                    )}

                                    {/* Content */}
                                    <p className="text-sm text-slate-700 line-clamp-3">
                                        {post.content || "No caption"}
                                    </p>

                                    {/* Post Type Badge */}
                                    <Badge variant="secondary" className="text-xs">
                                        {post.postType}
                                    </Badge>

                                    {/* Scheduled Time */}
                                    <div className="flex items-center gap-2 text-sm text-slate-600 pt-2 border-t">
                                        <Clock className="h-4 w-4" />
                                        <span className="font-medium">
                                            {format(scheduledDate, "MMM d, yyyy 'at' h:mm a")}
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        )
                    })}
                </div>
            )}

            {/* Delete Confirmation Dialog */}
            <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Delete Scheduled Post?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete the scheduled post.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                            onClick={confirmDelete}
                            disabled={isDeleting}
                            className="bg-red-600 hover:bg-red-700"
                        >
                            {isDeleting ? (
                                <>
                                    <Spinner className="mr-2 h-4 w-4" />
                                    Deleting...
                                </>
                            ) : (
                                "Delete"
                            )}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    )
}
