"use client"

import * as React from "react"
import {
  AlertCircle,
  BarChart3,
  CalendarClock,
  CheckCircle2,
  Clock3,
  Globe2,
  Loader2,
  Plus,
  Search,
  TrendingUp,
  Trash2,
  Users,
} from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import useGetConnectedAccounts from "@/lib/queries/appconfig/use-get-connected-accounts"
import { cn } from "@/lib/utils"

type Timeframe = "7d" | "30d" | "90d"
type PlatformKey = "instagram" | "facebook" | "linkedin" | "youtube" | "x"

type FrequencyByPlatform = Partial<Record<PlatformKey, number>>

interface CompetitorProfile {
  id: string
  name: string
  website: string
  industry: string
  region: string
  trackingStatus: "active" | "watchlist"
  lastObservedAt: string
  handles: Partial<Record<PlatformKey, string>>
  weeklyPostsByPlatform: FrequencyByPlatform
  contentMix: {
    shortVideo: number
    carouselImage: number
    textOrLink: number
  }
  trendDeltaPercent: number
  notes: string
}

interface ManualCompetitorInput {
  id: string
  platform: PlatformKey
  username: string
}

interface ConnectedAccount {
  connected?: boolean
  accountName?: string
}

interface ConnectedAccountsResponse {
  data?: Record<string, ConnectedAccount>
  status?: boolean
  message?: string
}

const PLATFORM_META: Record<
  PlatformKey,
  { label: string; chipClass: string; barClass: string }
> = {
  instagram: {
    label: "Instagram",
    chipClass:
      "border-pink-200 bg-pink-50 text-pink-700 dark:border-pink-900 dark:bg-pink-950/50 dark:text-pink-300",
    barClass: "bg-pink-500",
  },
  facebook: {
    label: "Facebook",
    chipClass:
      "border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-900 dark:bg-blue-950/50 dark:text-blue-300",
    barClass: "bg-blue-500",
  },
  linkedin: {
    label: "LinkedIn",
    chipClass:
      "border-cyan-200 bg-cyan-50 text-cyan-700 dark:border-cyan-900 dark:bg-cyan-950/50 dark:text-cyan-300",
    barClass: "bg-cyan-500",
  },
  youtube: {
    label: "YouTube",
    chipClass:
      "border-red-200 bg-red-50 text-red-700 dark:border-red-900 dark:bg-red-950/50 dark:text-red-300",
    barClass: "bg-red-500",
  },
  x: {
    label: "X",
    chipClass:
      "border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300",
    barClass: "bg-slate-600 dark:bg-slate-400",
  },
}

const TIMEFRAME_DAYS: Record<Timeframe, number> = {
  "7d": 7,
  "30d": 30,
  "90d": 90,
}

const TRACKED_BRAND: CompetitorProfile = {
  id: "you",
  name: "Your Brand",
  website: "veblika.example",
  industry: "SaaS / Social Media",
  region: "Global",
  trackingStatus: "active",
  lastObservedAt: "2026-02-24T08:30:00.000Z",
  handles: {
    instagram: "@yourbrand",
    linkedin: "company/yourbrand",
    youtube: "@yourbrand",
  },
  weeklyPostsByPlatform: {
    instagram: 8,
    linkedin: 4,
    youtube: 2,
    facebook: 3,
  },
  contentMix: {
    shortVideo: 45,
    carouselImage: 35,
    textOrLink: 20,
  },
  trendDeltaPercent: 12,
  notes: "Baseline profile generated from your current publishing plan.",
}

const INITIAL_COMPETITORS: CompetitorProfile[] = [
  {
    id: "comp-bufferly",
    name: "Bufferly",
    website: "bufferly.com",
    industry: "Social Media Tools",
    region: "North America",
    trackingStatus: "active",
    lastObservedAt: "2026-02-23T17:20:00.000Z",
    handles: {
      instagram: "@bufferlyhq",
      linkedin: "company/bufferly",
      x: "@bufferly",
      youtube: "@bufferly",
    },
    weeklyPostsByPlatform: {
      instagram: 10,
      linkedin: 6,
      x: 18,
      youtube: 1,
    },
    contentMix: {
      shortVideo: 34,
      carouselImage: 28,
      textOrLink: 38,
    },
    trendDeltaPercent: 8,
    notes: "High cadence on X and LinkedIn; mostly educational content.",
  },
  {
    id: "comp-sproutful",
    name: "Sproutful",
    website: "sproutful.io",
    industry: "Marketing SaaS",
    region: "Global",
    trackingStatus: "active",
    lastObservedAt: "2026-02-24T03:10:00.000Z",
    handles: {
      instagram: "@sproutfulsocial",
      linkedin: "company/sproutful",
      facebook: "sproutfulsocial",
      youtube: "@sproutfulsocial",
    },
    weeklyPostsByPlatform: {
      instagram: 14,
      linkedin: 7,
      facebook: 5,
      youtube: 3,
    },
    contentMix: {
      shortVideo: 52,
      carouselImage: 31,
      textOrLink: 17,
    },
    trendDeltaPercent: 16,
    notes: "Video-first strategy; strong short-form volume and weekly tutorials.",
  },
  {
    id: "comp-laterstack",
    name: "LaterStack",
    website: "laterstack.co",
    industry: "Creator Tools",
    region: "EMEA",
    trackingStatus: "watchlist",
    lastObservedAt: "2026-02-22T22:45:00.000Z",
    handles: {
      instagram: "@laterstack",
      linkedin: "company/laterstack",
      youtube: "@laterstack",
      x: "@laterstack",
    },
    weeklyPostsByPlatform: {
      instagram: 7,
      linkedin: 5,
      youtube: 2,
      x: 9,
    },
    contentMix: {
      shortVideo: 29,
      carouselImage: 49,
      textOrLink: 22,
    },
    trendDeltaPercent: -4,
    notes: "Lower volume but consistent product-led educational carousels.",
  },
  {
    id: "comp-socialpilotx",
    name: "SocialPilot X",
    website: "socialpilotx.com",
    industry: "Agency Workflow",
    region: "APAC",
    trackingStatus: "active",
    lastObservedAt: "2026-02-24T11:40:00.000Z",
    handles: {
      facebook: "socialpilotx",
      linkedin: "company/socialpilotx",
      youtube: "@socialpilotx",
      x: "@socialpilotx",
    },
    weeklyPostsByPlatform: {
      facebook: 8,
      linkedin: 6,
      youtube: 4,
      x: 12,
    },
    contentMix: {
      shortVideo: 41,
      carouselImage: 19,
      textOrLink: 40,
    },
    trendDeltaPercent: 3,
    notes: "Balanced distribution; strongest push on thought leadership threads.",
  },
]

let competitorInputId = 0

function createCompetitorInput(
  platform: PlatformKey = "instagram",
  username = ""
): ManualCompetitorInput {
  competitorInputId += 1
  return {
    id: `competitor-input-${competitorInputId}`,
    platform,
    username,
  }
}

function normalizeUsername(value: string) {
  return value.trim().replace(/^@+/, "").toLowerCase()
}

function hashString(input: string) {
  let hash = 0
  for (let index = 0; index < input.length; index += 1) {
    hash = (hash << 5) - hash + input.charCodeAt(index)
    hash |= 0
  }
  return Math.abs(hash)
}

function generateCompetitorProfileFromPublicInputs(
  entry: ManualCompetitorInput
): CompetitorProfile {
  const normalizedUsername = normalizeUsername(entry.username)
  const seed = hashString(`${entry.platform}:${normalizedUsername}`)
  const platformBoost: Record<PlatformKey, number> = {
    instagram: 4,
    facebook: 3,
    linkedin: 2,
    youtube: 1,
    x: 5,
  }

  const weeklyBase = 2 + (seed % 6)
  const weeklyPostsByPlatform: FrequencyByPlatform = {
    [entry.platform]: weeklyBase + platformBoost[entry.platform],
  }

  const includeSecondPlatform = seed % 2 === 0
  const includeThirdPlatform = seed % 5 === 0
  const otherPlatforms = (Object.keys(PLATFORM_META) as PlatformKey[]).filter(
    (platform) => platform !== entry.platform
  )

  if (includeSecondPlatform) {
    const secondPlatform = otherPlatforms[seed % otherPlatforms.length]
    weeklyPostsByPlatform[secondPlatform] = 1 + ((seed >> 2) % 5)
  }
  if (includeThirdPlatform) {
    const thirdPlatform = otherPlatforms[(seed >> 3) % otherPlatforms.length]
    weeklyPostsByPlatform[thirdPlatform] = Math.max(
      weeklyPostsByPlatform[thirdPlatform] ?? 0,
      1 + ((seed >> 4) % 4)
    )
  }

  const shortVideo = 20 + (seed % 45)
  const carouselImage = 15 + ((seed >> 3) % 40)
  const textOrLink = Math.max(100 - shortVideo - carouselImage, 8)
  const adjustedCarousel = Math.max(10, 100 - shortVideo - textOrLink)

  const regionOptions = ["Global", "North America", "EMEA", "APAC", "LATAM"]
  const industries = [
    "Social Media Tools",
    "Marketing SaaS",
    "Creator Tools",
    "Agency Services",
    "B2B SaaS",
  ]

  const displayName = normalizedUsername
    .split(/[._-]/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ")

  return {
    id: `manual-${entry.platform}-${normalizedUsername}`,
    name: displayName || normalizedUsername || "Competitor",
    website: `${normalizedUsername || "competitor"}.example`,
    industry: industries[seed % industries.length],
    region: regionOptions[seed % regionOptions.length],
    trackingStatus: "active",
    lastObservedAt: new Date(
      Date.now() - (seed % (36 * 60 * 60 * 1000))
    ).toISOString(),
    handles: {
      [entry.platform]: `@${normalizedUsername}`,
    },
    weeklyPostsByPlatform,
    contentMix: {
      shortVideo,
      carouselImage: adjustedCarousel,
      textOrLink: 100 - shortVideo - adjustedCarousel,
    },
    trendDeltaPercent: (seed % 31) - 10,
    notes:
      "Public metrics snapshot based on observed posting cadence and visible content formats.",
  }
}

function scaleWeeklyPosts(weeklyPosts: number, timeframe: Timeframe) {
  return Number(((weeklyPosts * TIMEFRAME_DAYS[timeframe]) / 7).toFixed(1))
}

function getPlatformVolume(
  profile: CompetitorProfile,
  platform: "all" | PlatformKey,
  timeframe: Timeframe
) {
  if (platform === "all") {
    return (
      Object.values(profile.weeklyPostsByPlatform).reduce(
        (total, weeklyPosts) => total + (weeklyPosts ?? 0),
        0
      ) *
      (TIMEFRAME_DAYS[timeframe] / 7)
    )
  }

  return scaleWeeklyPosts(profile.weeklyPostsByPlatform[platform] ?? 0, timeframe)
}

function getBreakdown(profile: CompetitorProfile, timeframe: Timeframe) {
  return (Object.keys(PLATFORM_META) as PlatformKey[]).map((platform) => ({
    platform,
    posts: scaleWeeklyPosts(profile.weeklyPostsByPlatform[platform] ?? 0, timeframe),
  }))
}

function getMostActivePlatform(profile: CompetitorProfile) {
  const entries = Object.entries(profile.weeklyPostsByPlatform) as Array<
    [PlatformKey, number]
  >
  if (entries.length === 0) return null

  const [platform] = entries.sort((a, b) => (b[1] ?? 0) - (a[1] ?? 0))[0]
  return platform
}

function formatObservedDate(date: string) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(new Date(date))
}

export default function AnalyzePage() {
  const { data: connectedAccountsResponse, isLoading: isLoadingConnections } =
    useGetConnectedAccounts() as { data?: ConnectedAccountsResponse; isLoading: boolean }

  const [profiles, setProfiles] = React.useState<CompetitorProfile[]>(INITIAL_COMPETITORS)
  const [search, setSearch] = React.useState("")
  const [timeframe, setTimeframe] = React.useState<Timeframe>("30d")
  const [platformFilter, setPlatformFilter] = React.useState<"all" | PlatformKey>("all")
  const [manualCompetitors, setManualCompetitors] = React.useState<ManualCompetitorInput[]>(
    [
      createCompetitorInput("instagram"),
      createCompetitorInput("linkedin"),
      createCompetitorInput("youtube"),
    ]
  )
  const [isFetchingCompetitorMetrics, setIsFetchingCompetitorMetrics] =
    React.useState(false)
  const [compareFeedback, setCompareFeedback] = React.useState<string | null>(null)

  const connectedAccounts = connectedAccountsResponse?.data ?? {}
  const connectedPlatforms = Object.entries(connectedAccounts)
    .filter(([, account]) => account?.connected)
    .map(([key]) => key.replace("app/", ""))
  const isAccountConnected = connectedPlatforms.length > 0

  const normalizedManualEntries = manualCompetitors
    .map((entry) => ({
      ...entry,
      username: normalizeUsername(entry.username),
    }))
    .filter((entry) => entry.username.length > 0)

  const uniqueManualEntryKeys = new Set(
    normalizedManualEntries.map((entry) => `${entry.platform}:${entry.username}`)
  )
  const hasDuplicateManualEntries =
    uniqueManualEntryKeys.size !== normalizedManualEntries.length
  const canCompareCompetitors =
    isAccountConnected &&
    normalizedManualEntries.length >= 3 &&
    normalizedManualEntries.length <= 5 &&
    !hasDuplicateManualEntries

  const normalizedSearch = search.trim().toLowerCase()

  const filteredProfiles = profiles.filter((profile) => {
    const matchesSearch =
      normalizedSearch.length === 0 ||
      profile.name.toLowerCase().includes(normalizedSearch) ||
      profile.website.toLowerCase().includes(normalizedSearch) ||
      Object.values(profile.handles)
        .filter(Boolean)
        .some((handle) => handle!.toLowerCase().includes(normalizedSearch))

    const matchesPlatform =
      platformFilter === "all" ||
      (profile.weeklyPostsByPlatform[platformFilter] ?? 0) > 0

    return matchesSearch && matchesPlatform
  })

  const comparisonRows = [TRACKED_BRAND, ...filteredProfiles].map((profile) => {
    const breakdown = getBreakdown(profile, timeframe)
    const filteredBreakdown =
      platformFilter === "all"
        ? breakdown.filter((segment) => segment.posts > 0)
        : breakdown.filter((segment) => segment.platform === platformFilter)

    const totalPosts = Number(
      filteredBreakdown.reduce((sum, segment) => sum + segment.posts, 0).toFixed(1)
    )

    return {
      profile,
      breakdown: filteredBreakdown,
      totalPosts,
      avgPerDay: Number((totalPosts / TIMEFRAME_DAYS[timeframe]).toFixed(2)),
      dominantPlatform: getMostActivePlatform(profile),
    }
  })

  const maxComparisonPosts =
    comparisonRows.reduce((max, row) => Math.max(max, row.totalPosts), 0) || 1

  const averageCompetitorPosts = filteredProfiles.length
    ? Number(
        (
          filteredProfiles.reduce(
            (sum, profile) => sum + getPlatformVolume(profile, platformFilter, timeframe),
            0
          ) / filteredProfiles.length
        ).toFixed(1)
      )
    : 0

  const mostActiveCompetitor =
    filteredProfiles.length > 0
      ? [...filteredProfiles].sort(
          (a, b) =>
            getPlatformVolume(b, platformFilter, timeframe) -
            getPlatformVolume(a, platformFilter, timeframe)
        )[0]
      : null

  const trackedPlatforms = new Set(
    filteredProfiles.flatMap((profile) =>
      (Object.keys(profile.weeklyPostsByPlatform) as PlatformKey[]).filter(
        (platform) => (profile.weeklyPostsByPlatform[platform] ?? 0) > 0
      )
    )
  ).size

  const addManualCompetitorRow = () => {
    if (manualCompetitors.length >= 5) return
    setManualCompetitors((current) => [...current, createCompetitorInput("instagram")])
  }

  const removeManualCompetitorRow = (id: string) => {
    setManualCompetitors((current) => current.filter((entry) => entry.id !== id))
    setCompareFeedback(null)
  }

  const updateManualCompetitor = (
    id: string,
    patch: Partial<ManualCompetitorInput>
  ) => {
    setManualCompetitors((current) =>
      current.map((entry) => (entry.id === id ? { ...entry, ...patch } : entry))
    )
    setCompareFeedback(null)
  }

  const loadDemoCompetitors = () => {
    setManualCompetitors([
      createCompetitorInput("instagram", "sproutfulsocial"),
      createCompetitorInput("linkedin", "bufferlyhq"),
      createCompetitorInput("youtube", "socialpilotx"),
    ])
    setProfiles(INITIAL_COMPETITORS)
    setCompareFeedback("Loaded demo competitor usernames and comparison data.")
  }

  const handleCompareCompetitors = async () => {
    if (!canCompareCompetitors) return

    setIsFetchingCompetitorMetrics(true)
    setCompareFeedback(null)

    try {
      await new Promise((resolve) => setTimeout(resolve, 900))

      const generatedProfiles = normalizedManualEntries.map((entry) =>
        generateCompetitorProfileFromPublicInputs(entry)
      )

      setProfiles(generatedProfiles)
      setCompareFeedback(
        `Fetched allowed public metrics for ${generatedProfiles.length} competitor accounts and updated comparison.`
      )
    } finally {
      setIsFetchingCompetitorMetrics(false)
    }
  }

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#eef6ff,_#f8fafc_35%,_#fefaf2_100%)] p-4 md:p-6">
      <div className="mx-auto max-w-7xl space-y-6">
        <section className="rounded-2xl border border-slate-200/80 bg-white/80 p-5 shadow-sm backdrop-blur md:p-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-xs font-medium text-indigo-700">
                <PackageDot />
                Competitor Tracking
              </div>
              <h1 className="text-2xl font-semibold tracking-tight text-slate-900 md:text-3xl">
                Competitor profiles and publishing cadence intelligence
              </h1>
              <p className="mt-2 max-w-3xl text-sm text-slate-600 md:text-base">
                Track competitor profiles, compare content frequency, and spot which
                brands are increasing output across channels.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {(["7d", "30d", "90d"] as Timeframe[]).map((option) => (
                <Button
                  key={option}
                  type="button"
                  size="sm"
                  variant={timeframe === option ? "default" : "outline"}
                  onClick={() => setTimeframe(option)}
                  className={cn(
                    timeframe === option &&
                      "bg-slate-900 text-white hover:bg-slate-800"
                  )}
                >
                  {option.toUpperCase()}
                </Button>
              ))}
            </div>
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <MetricCard
            icon={Users}
            label="Tracked Competitors"
            value={String(filteredProfiles.length)}
            subtext={
              platformFilter === "all"
                ? "Across all channels"
                : `Filtered by ${PLATFORM_META[platformFilter].label}`
            }
          />
          <MetricCard
            icon={CalendarClock}
            label="Avg Posts / Competitor"
            value={String(averageCompetitorPosts)}
            subtext={`In the last ${TIMEFRAME_DAYS[timeframe]} days`}
          />
          <MetricCard
            icon={TrendingUp}
            label="Most Active"
            value={mostActiveCompetitor?.name ?? "N/A"}
            subtext={
              mostActiveCompetitor
                ? `${getPlatformVolume(
                    mostActiveCompetitor,
                    platformFilter,
                    timeframe
                  ).toFixed(1)} posts`
                : "No competitors match filter"
            }
          />
          <MetricCard
            icon={Globe2}
            label="Tracked Platforms"
            value={String(trackedPlatforms)}
            subtext="Platforms with observed activity"
          />
        </section>

        <Card className="border-slate-200/80 bg-white/85 shadow-sm">
          <CardHeader>
            <CardTitle>Manual Competitor Setup</CardTitle>
            <CardDescription>
              Flow: connect your account, add 3–5 public business usernames, then fetch
              allowed public metrics for comparison.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="grid gap-4 lg:grid-cols-[1.1fr_1.9fr]">
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <div className="mb-3 flex items-center gap-2">
                  {isAccountConnected ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-amber-600" />
                  )}
                  <p className="text-sm font-medium text-slate-900">
                    1. User connects their account
                  </p>
                </div>
                {isLoadingConnections ? (
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Checking connected accounts...
                  </div>
                ) : isAccountConnected ? (
                  <div className="space-y-2">
                    <p className="text-sm text-slate-600">
                      Connected platforms detected. Competitor comparison can proceed.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {connectedPlatforms.map((platform) => (
                        <Badge key={platform} variant="outline" className="capitalize">
                          {platform}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-slate-600">
                    No connected social account found. Connect at least one platform in
                    Integrations before comparing competitors.
                  </p>
                )}
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-4">
                <div className="mb-3 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium text-slate-900">
                      2. Add competitor usernames
                    </p>
                    <p className="text-xs text-slate-600">
                      Public business accounts only. Add 3–5 usernames.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">
                      {normalizedManualEntries.length}/5 valid
                    </Badge>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={loadDemoCompetitors}
                    >
                      Load Demo
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  {manualCompetitors.map((entry, index) => (
                    <div
                      key={entry.id}
                      className="grid gap-2 rounded-lg border border-slate-200 bg-slate-50 p-3 md:grid-cols-[170px_1fr_auto]"
                    >
                      <label className="sr-only" htmlFor={`${entry.id}-platform`}>
                        Platform
                      </label>
                      <select
                        id={`${entry.id}-platform`}
                        value={entry.platform}
                        onChange={(event) =>
                          updateManualCompetitor(entry.id, {
                            platform: event.target.value as PlatformKey,
                          })
                        }
                        className="h-9 rounded-md border border-slate-300 bg-white px-3 text-sm outline-none focus:ring-2 focus:ring-slate-300"
                      >
                        {(Object.keys(PLATFORM_META) as PlatformKey[]).map((platform) => (
                          <option key={`${entry.id}-${platform}`} value={platform}>
                            {PLATFORM_META[platform].label}
                          </option>
                        ))}
                      </select>

                      <div className="space-y-1">
                        <label className="sr-only" htmlFor={`${entry.id}-username`}>
                          Username
                        </label>
                        <Input
                          id={`${entry.id}-username`}
                          value={entry.username}
                          onChange={(event) =>
                            updateManualCompetitor(entry.id, {
                              username: event.target.value,
                            })
                          }
                          placeholder={`Username ${index + 1} (e.g. brandname)`}
                        />
                        <p className="text-[11px] text-slate-500">
                          We compare allowed public metrics only (posting cadence, visible
                          activity, content format mix).
                        </p>
                      </div>

                      <Button
                        type="button"
                        size="icon"
                        variant="ghost"
                        onClick={() => removeManualCompetitorRow(entry.id)}
                        disabled={manualCompetitors.length <= 1}
                        aria-label="Remove competitor row"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>

                <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap gap-2 text-xs">
                    {!isAccountConnected && (
                      <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">
                        Connect an account first
                      </Badge>
                    )}
                    {hasDuplicateManualEntries && (
                      <Badge className="bg-rose-100 text-rose-800 hover:bg-rose-100">
                        Duplicate usernames detected
                      </Badge>
                    )}
                    {normalizedManualEntries.length > 0 &&
                      normalizedManualEntries.length < 3 && (
                        <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
                          Add at least {3 - normalizedManualEntries.length} more
                        </Badge>
                      )}
                    {normalizedManualEntries.length > 5 && (
                      <Badge className="bg-rose-100 text-rose-800 hover:bg-rose-100">
                        Maximum 5 competitors
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={addManualCompetitorRow}
                      disabled={manualCompetitors.length >= 5}
                    >
                      <Plus className="h-4 w-4" />
                      Add Row
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      onClick={handleCompareCompetitors}
                      disabled={!canCompareCompetitors || isFetchingCompetitorMetrics}
                      className="bg-slate-900 text-white hover:bg-slate-800"
                    >
                      {isFetchingCompetitorMetrics ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Fetching Public Metrics...
                        </>
                      ) : (
                        "3. Fetch & Compare"
                      )}
                    </Button>
                  </div>
                </div>

                {compareFeedback && (
                  <div className="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
                    {compareFeedback}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200/80 bg-white/85 shadow-sm">
          <CardHeader className="gap-4">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <CardTitle>Competitor Profiles</CardTitle>
                <CardDescription>
                  Public profile snapshots with posting cadence and content mix estimates.
                </CardDescription>
              </div>
              <div className="flex w-full flex-col gap-2 sm:flex-row lg:w-auto">
                <div className="relative min-w-64">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <Input
                    value={search}
                    onChange={(event) => setSearch(event.target.value)}
                    placeholder="Search name, website, or handle"
                    className="pl-9"
                  />
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant={platformFilter === "all" ? "default" : "outline"}
                    onClick={() => setPlatformFilter("all")}
                    className={cn(
                      platformFilter === "all" &&
                        "bg-slate-900 text-white hover:bg-slate-800"
                    )}
                  >
                    All Platforms
                  </Button>
                  {(Object.keys(PLATFORM_META) as PlatformKey[]).map((platform) => (
                    <Button
                      key={platform}
                      type="button"
                      size="sm"
                      variant={platformFilter === platform ? "default" : "outline"}
                      onClick={() => setPlatformFilter(platform)}
                      className={cn(
                        "px-3",
                        platformFilter === platform &&
                          "bg-slate-900 text-white hover:bg-slate-800"
                      )}
                    >
                      {PLATFORM_META[platform].label}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {filteredProfiles.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/80 p-8 text-center">
                <div className="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-full bg-white shadow-sm">
                  <Search className="h-4 w-4 text-slate-500" />
                </div>
                <p className="font-medium text-slate-900">No competitors match the current filters</p>
                <p className="mt-1 text-sm text-slate-600">
                  Try clearing the search or switching to a different platform filter.
                </p>
              </div>
            ) : (
              <div className="grid gap-4 xl:grid-cols-2">
                {filteredProfiles.map((profile) => {
                  const postsInWindow = getPlatformVolume(profile, platformFilter, timeframe)
                  const dominantPlatform = getMostActivePlatform(profile)
                  const activePlatforms = (Object.keys(profile.handles) as PlatformKey[]).filter(
                    (platform) => Boolean(profile.handles[platform])
                  )

                  return (
                    <Card
                      key={profile.id}
                      className="gap-4 border-slate-200/70 bg-gradient-to-br from-white to-slate-50/70 py-5"
                    >
                      <CardHeader className="px-5 pb-0">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <CardTitle className="text-base">{profile.name}</CardTitle>
                              <Badge
                                variant="outline"
                                className={cn(
                                  "capitalize",
                                  profile.trackingStatus === "active"
                                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                                    : "border-amber-200 bg-amber-50 text-amber-700"
                                )}
                              >
                                {profile.trackingStatus}
                              </Badge>
                            </div>
                            <p className="mt-1 text-sm text-slate-600">{profile.website}</p>
                            <p className="mt-1 text-xs text-slate-500">
                              {profile.industry} • {profile.region}
                            </p>
                          </div>
                          <div className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-right">
                            <div className="text-xs text-slate-500">Observed cadence</div>
                            <div className="text-lg font-semibold text-slate-900">
                              {postsInWindow.toFixed(1)}
                            </div>
                            <div className="text-xs text-slate-500">
                              posts / {TIMEFRAME_DAYS[timeframe]}d
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4 px-5">
                        <div className="flex flex-wrap gap-2">
                          {activePlatforms.map((platform) => (
                            <Badge
                              key={`${profile.id}-${platform}`}
                              variant="outline"
                              className={PLATFORM_META[platform].chipClass}
                            >
                              {PLATFORM_META[platform].label}
                              {profile.handles[platform] ? ` • ${profile.handles[platform]}` : ""}
                            </Badge>
                          ))}
                        </div>

                        <div className="grid gap-3 sm:grid-cols-3">
                          <InlineStat
                            label="Avg / day"
                            value={(postsInWindow / TIMEFRAME_DAYS[timeframe]).toFixed(2)}
                          />
                          <InlineStat
                            label="Most active"
                            value={
                              dominantPlatform ? PLATFORM_META[dominantPlatform].label : "N/A"
                            }
                          />
                          <InlineStat
                            label="Trend"
                            value={`${profile.trendDeltaPercent > 0 ? "+" : ""}${profile.trendDeltaPercent}%`}
                            positive={profile.trendDeltaPercent >= 0}
                          />
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-xs text-slate-500">
                            <span>Content mix estimate</span>
                            <span>Last observed {formatObservedDate(profile.lastObservedAt)}</span>
                          </div>
                          <div className="overflow-hidden rounded-md border border-slate-200 bg-white">
                            <div className="flex h-2">
                              <div
                                className="bg-violet-500"
                                style={{ width: `${profile.contentMix.shortVideo}%` }}
                                title={`Short video ${profile.contentMix.shortVideo}%`}
                              />
                              <div
                                className="bg-amber-400"
                                style={{ width: `${profile.contentMix.carouselImage}%` }}
                                title={`Carousel/Image ${profile.contentMix.carouselImage}%`}
                              />
                              <div
                                className="bg-slate-400"
                                style={{ width: `${profile.contentMix.textOrLink}%` }}
                                title={`Text/Link ${profile.contentMix.textOrLink}%`}
                              />
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2 text-xs text-slate-600">
                            <span className="inline-flex items-center gap-1">
                              <span className="h-2 w-2 rounded-full bg-violet-500" />
                              Short video {profile.contentMix.shortVideo}%
                            </span>
                            <span className="inline-flex items-center gap-1">
                              <span className="h-2 w-2 rounded-full bg-amber-400" />
                              Carousel/Image {profile.contentMix.carouselImage}%
                            </span>
                            <span className="inline-flex items-center gap-1">
                              <span className="h-2 w-2 rounded-full bg-slate-400" />
                              Text/Link {profile.contentMix.textOrLink}%
                            </span>
                          </div>
                        </div>

                        <div className="rounded-lg border border-slate-200/80 bg-white p-3 text-sm text-slate-600">
                          {profile.notes}
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-slate-200/80 bg-white/85 shadow-sm">
          <CardHeader>
            <CardTitle>Content Frequency Comparison</CardTitle>
            <CardDescription>
              Compare posting volume vs your brand using stacked platform cadence for the
              selected window.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
              {(Object.keys(PLATFORM_META) as PlatformKey[])
                .filter((platform) => platformFilter === "all" || platformFilter === platform)
                .map((platform) => (
                  <span key={`legend-${platform}`} className="inline-flex items-center gap-1">
                    <span
                      className={cn("h-2.5 w-2.5 rounded-full", PLATFORM_META[platform].barClass)}
                    />
                    {PLATFORM_META[platform].label}
                  </span>
                ))}
            </div>

            <div className="space-y-3">
              {comparisonRows.map((row) => (
                <div
                  key={row.profile.id}
                  className={cn(
                    "rounded-xl border p-4",
                    row.profile.id === "you"
                      ? "border-indigo-200 bg-indigo-50/60"
                      : "border-slate-200 bg-white"
                  )}
                >
                  <div className="mb-3 flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-slate-900">{row.profile.name}</span>
                      {row.profile.id === "you" && (
                        <Badge className="bg-indigo-600 text-white">Baseline</Badge>
                      )}
                      <Badge
                        variant="outline"
                        className={cn(
                          row.profile.trendDeltaPercent >= 0
                            ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                            : "border-rose-200 bg-rose-50 text-rose-700"
                        )}
                      >
                        {row.profile.trendDeltaPercent > 0 ? "+" : ""}
                        {row.profile.trendDeltaPercent}% vs prior window
                      </Badge>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600">
                      <span className="inline-flex items-center gap-1">
                        <BarChart3 className="h-3.5 w-3.5" />
                        {row.totalPosts.toFixed(1)} posts
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <Clock3 className="h-3.5 w-3.5" />
                        {row.avgPerDay.toFixed(2)} / day
                      </span>
                      <span>
                        Peak:{" "}
                        {row.dominantPlatform
                          ? PLATFORM_META[row.dominantPlatform].label
                          : "N/A"}
                      </span>
                    </div>
                  </div>

                  <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                    <div className="h-4 w-full overflow-hidden rounded bg-white">
                      <div
                        className="flex h-full overflow-hidden rounded"
                        style={{
                          width: `${Math.max(
                            (row.totalPosts / maxComparisonPosts) * 100,
                            row.totalPosts > 0 ? 2 : 0
                          )}%`,
                        }}
                      >
                        {row.breakdown.length === 0 ? (
                          <div className="h-full w-full bg-slate-200" />
                        ) : (
                          row.breakdown.map((segment) => (
                            <div
                              key={`${row.profile.id}-${segment.platform}`}
                              className={cn("h-full", PLATFORM_META[segment.platform].barClass)}
                              style={{
                                width: `${
                                  row.totalPosts > 0
                                    ? (segment.posts / row.totalPosts) * 100
                                    : 0
                                }%`,
                              }}
                              title={`${PLATFORM_META[segment.platform].label}: ${segment.posts.toFixed(1)} posts`}
                            />
                          ))
                        )}
                      </div>
                    </div>

                    <div className="mt-3 grid gap-2 text-xs text-slate-600 sm:grid-cols-2 xl:grid-cols-4">
                      {row.breakdown.map((segment) => (
                        <div
                          key={`${row.profile.id}-meta-${segment.platform}`}
                          className="flex items-center justify-between rounded-md border border-slate-200 bg-white px-2 py-1"
                        >
                          <span className="inline-flex items-center gap-1">
                            <span
                              className={cn(
                                "h-2 w-2 rounded-full",
                                PLATFORM_META[segment.platform].barClass
                              )}
                            />
                            {PLATFORM_META[segment.platform].label}
                          </span>
                          <span className="font-medium text-slate-800">
                            {segment.posts.toFixed(1)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function MetricCard({
  icon: Icon,
  label,
  value,
  subtext,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
  subtext: string
}) {
  return (
    <Card className="border-slate-200/80 bg-white/85 py-5 shadow-sm">
      <CardContent className="px-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
              {label}
            </p>
            <p className="mt-2 text-xl font-semibold text-slate-900">{value}</p>
            <p className="mt-1 text-xs text-slate-500">{subtext}</p>
          </div>
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-2">
            <Icon className="h-4 w-4 text-slate-700" />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function InlineStat({
  label,
  value,
  positive,
}: {
  label: string
  value: string
  positive?: boolean
}) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white px-3 py-2">
      <div className="text-xs text-slate-500">{label}</div>
      <div
        className={cn(
          "mt-1 text-sm font-semibold text-slate-900",
          label === "Trend" && positive === true && "text-emerald-700",
          label === "Trend" && positive === false && "text-rose-700"
        )}
      >
        {value}
      </div>
    </div>
  )
}

function PackageDot() {
  return (
    <span className="relative inline-flex h-2.5 w-2.5">
      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-indigo-400 opacity-75" />
      <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-indigo-600" />
    </span>
  )
}
