"use client";

import React from "react";
import { motion } from "framer-motion";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Activity,
  ArrowUpRight,
  CalendarCheck2,
  MessageSquareMore,
  Sparkles,
  Users,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";

const engagementTrend = [
  { day: "Mon", reach: 1800, engagement: 420, clicks: 190 },
  { day: "Tue", reach: 2400, engagement: 640, clicks: 250 },
  { day: "Wed", reach: 2100, engagement: 520, clicks: 230 },
  { day: "Thu", reach: 2800, engagement: 760, clicks: 310 },
  { day: "Fri", reach: 3250, engagement: 930, clicks: 390 },
  { day: "Sat", reach: 2900, engagement: 840, clicks: 360 },
  { day: "Sun", reach: 3400, engagement: 980, clicks: 420 },
];

const channelSplit = [
  { name: "Instagram", value: 36, fill: "#ff6b6b" },
  { name: "Facebook", value: 24, fill: "#4dabf7" },
  { name: "LinkedIn", value: 18, fill: "#845ef7" },
  { name: "YouTube", value: 22, fill: "#ffa94d" },
];

const campaignProgress = [
  { label: "Launch Week Teaser", progress: 82 },
  { label: "UGC Push Campaign", progress: 64 },
  { label: "Influencer Referral", progress: 49 },
];

const statCards = [
  {
    title: "Total Reach",
    value: "124.8K",
    delta: "+18.2%",
    icon: Users,
    color: "from-pink-500 via-orange-500 to-amber-400",
  },
  {
    title: "Engagement Rate",
    value: "8.74%",
    delta: "+1.1%",
    icon: Activity,
    color: "from-cyan-500 via-blue-500 to-indigo-500",
  },
  {
    title: "Messages Replied",
    value: "1,296",
    delta: "+13.6%",
    icon: MessageSquareMore,
    color: "from-violet-500 via-fuchsia-500 to-pink-500",
  },
  {
    title: "Scheduled Posts",
    value: "42",
    delta: "+7.0%",
    icon: CalendarCheck2,
    color: "from-emerald-500 via-teal-500 to-cyan-500",
  },
];

const activityFeed = [
  "Instagram reel 'Product Walkthrough' crossed 10K plays.",
  "New lead captured from Facebook CTA campaign.",
  "LinkedIn carousel gained 232 saves in 4 hours.",
  "YouTube short hit top 3% channel performance.",
];

export default function Dashboard() {
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50 p-4 md:p-6">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-24 -top-24 h-72 w-72 rounded-full bg-pink-300/30 blur-3xl" />
        <div className="absolute right-10 top-16 h-60 w-60 rounded-full bg-cyan-300/30 blur-3xl" />
      </div>

      <motion.div
        className="relative mx-auto flex max-w-7xl flex-col gap-6"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: "easeOut" }}
      >
        {/* <section className="rounded-3xl border bg-white/80 p-6 shadow-sm backdrop-blur-sm">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="mb-2 inline-flex items-center gap-2 rounded-full border bg-orange-50 px-3 py-1 text-xs font-medium text-orange-700">
                <Sparkles className="h-3.5 w-3.5" />
                Live performance summary
              </p>
              <h1 className="text-2xl font-semibold tracking-tight text-slate-900 md:text-3xl">
                Social Media Command Center
              </h1>
              <p className="mt-2 max-w-2xl text-sm text-slate-600">
                Track growth, monitor engagement, and optimize campaigns from one dashboard.
              </p>
            </div>
            <Button className="w-full rounded-xl bg-orange-500 text-white hover:bg-orange-600 md:w-auto">
              Export Weekly Report
            </Button>
          </div>
        </section> */}

        <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {statCards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, delay: idx * 0.06 }}
              >
                <Card className="overflow-hidden border-0 shadow-md">
                  <div className={`h-1.5 w-full bg-gradient-to-r ${card.color}`} />
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center justify-between text-sm font-medium text-slate-600">
                      {card.title}
                      <Icon className="h-4 w-4 text-slate-500" />
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-end justify-between">
                      <p className="text-2xl font-bold text-slate-900">{card.value}</p>
                      <Badge className="rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                        <ArrowUpRight className="mr-1 h-3 w-3" />
                        {card.delta}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </section>

        <section className="grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-lg text-slate-900">Engagement Trend</CardTitle>
            </CardHeader>
            <CardContent className="h-[320px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={engagementTrend} margin={{ left: 8, right: 8, top: 12, bottom: 0 }}>
                  <defs>
                    <linearGradient id="reachGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ff6b6b" stopOpacity={0.55} />
                      <stop offset="95%" stopColor="#ff6b6b" stopOpacity={0.05} />
                    </linearGradient>
                    <linearGradient id="engagementGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4dabf7" stopOpacity={0.5} />
                      <stop offset="95%" stopColor="#4dabf7" stopOpacity={0.06} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="4 4" stroke="#e2e8f0" />
                  <XAxis dataKey="day" tick={{ fill: "#64748b", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#64748b", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="reach" stroke="#ff6b6b" fill="url(#reachGradient)" strokeWidth={2.2} />
                  <Area
                    type="monotone"
                    dataKey="engagement"
                    stroke="#4dabf7"
                    fill="url(#engagementGradient)"
                    strokeWidth={2.2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-slate-900">Channel Split</CardTitle>
            </CardHeader>
            <CardContent className="h-[320px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={channelSplit}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={55}
                    outerRadius={95}
                    paddingAngle={3}
                  />
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </section>

        <section className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-slate-900">Campaign Progress</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {campaignProgress.map((campaign) => (
                <div key={campaign.label}>
                  <div className="mb-2 flex items-center justify-between text-sm">
                    <span className="text-slate-700">{campaign.label}</span>
                    <span className="font-medium text-slate-900">{campaign.progress}%</span>
                  </div>
                  <Progress value={campaign.progress} className="h-2.5 bg-slate-100" />
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-0 bg-gradient-to-br from-slate-900 via-indigo-900 to-blue-900 text-white shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg">Live Activity Feed</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {activityFeed.map((item, idx) => (
                <motion.div
                  key={item}
                  className="rounded-lg border border-white/20 bg-white/10 px-3 py-2 text-sm"
                  initial={{ opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.25, delay: idx * 0.08 }}
                >
                  {item}
                </motion.div>
              ))}
            </CardContent>
          </Card>
        </section>
      </motion.div>
    </div>
  );
}
