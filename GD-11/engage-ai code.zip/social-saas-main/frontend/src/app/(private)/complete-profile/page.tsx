"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import api from "@/utils/api";
import { useAuthSession } from "@/hooks/use-auth-session";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Country, State, City } from "country-state-city";

type RequiredProfileFormValues = {
  addressline: string;
  state: string;
  city: string;
  country: string;
  phone: string;
  pincode: string;
};

export default function CompleteProfilePage() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [profilePictureUrl, setProfilePictureUrl] = useState<string | null>(null);
  const { user, isLoading, profileCompletionRequired, refetch } = useAuthSession();
  const [selectedCountry, setSelectedCountry] = useState<string>("");
  const [selectedState, setSelectedState] = useState<string>("");
  const [selectedCity, setSelectedCity] = useState<string>("");
  const didInitLocationRef = useRef(false);

  const { register, setValue, handleSubmit } = useForm<RequiredProfileFormValues>({
    defaultValues: {
      addressline: (user as any)?.addressline || "",
      state: (user as any)?.state || "",
      city: (user as any)?.city || "",
      country: (user as any)?.country || "",
      phone: (user as any)?.phone || "",
      pincode: (user as any)?.pincode || "",
    },
  });

  const countryOptions = useMemo(() => Country.getAllCountries(), []);
  const stateOptions = useMemo(
    () => (selectedCountry ? State.getStatesOfCountry(selectedCountry) : []),
    [selectedCountry]
  );
  const cityOptions = useMemo(() => {
    if (selectedCountry && selectedState) {
      return City.getCitiesOfState(selectedCountry, selectedState);
    }
    if (selectedCity) {
      return [
        {
          name: selectedCity,
          countryCode: selectedCountry || "NA",
          stateCode: selectedState || "NA",
          latitude: "0",
          longitude: "0",
        },
      ];
    }
    return [];
  }, [selectedCountry, selectedState, selectedCity]);

  const selectedCountryName =
    countryOptions.find((c) => c.isoCode === selectedCountry)?.name || "";
  const selectedStateName =
    stateOptions.find((s) => s.isoCode === selectedState)?.name || "";

  const uploadProfilePicture = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image size should be less than 5MB");
      return;
    }

    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append("image", file);
      const { data } = await api.post("/user/profile-photo", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      const uploadedUrl = data?.data?.imageUrl || null;
      if (uploadedUrl) {
        setProfilePictureUrl(String(uploadedUrl));
        toast.success("Profile picture uploaded");
      } else {
        toast.error("Profile picture upload failed");
      }
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Failed to upload profile picture");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const onSubmit = async (values: RequiredProfileFormValues) => {
    setIsSubmitting(true);
    try {
      await api.post("/user/profile/required-details", {
        ...values,
        ...(profilePictureUrl ? { profilePicture: profilePictureUrl } : {}),
      });

      const isProfileComplete = async () => {
        const { data } = await api.get("/user/profile");
        const profile = data?.data || {};
        const required = [
          profile?.addressline,
          profile?.state,
          profile?.city,
          profile?.country,
          profile?.phone,
          profile?.pincode,
          profile?.profilePicture || profile?.profile_pic,
        ];
        return required.every((value) => String(value || "").trim().length > 0);
      };

      let completed = false;
      for (let i = 0; i < 5; i += 1) {
        completed = await isProfileComplete();
        if (completed) break;
        await new Promise((resolve) => setTimeout(resolve, 250));
      }

      if (!completed) {
        toast.error("Profile update is still syncing. Please try once more.");
        return;
      }

      if (refetch) {
        await refetch();
      }

      toast.success("Profile completed successfully");
      router.replace("/integrations");
      router.refresh();
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Failed to save profile details");
    } finally {
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
    if (!isLoading && !profileCompletionRequired) {
      router.push("/integrations");
    }
  }, [isLoading, profileCompletionRequired, router]);

  useEffect(() => {
    if (didInitLocationRef.current || !user) return;

    const userCountry = String((user as any)?.country || "");
    const userState = String((user as any)?.state || "");
    const userCity = String((user as any)?.city || "");

    const countryCode = countryOptions.find((c) => c.name === userCountry)?.isoCode || "";
    const statesForCountry = countryCode ? State.getStatesOfCountry(countryCode) : [];
    const stateCode = statesForCountry.find((s) => s.name === userState)?.isoCode || "";

    if (countryCode) {
      setSelectedCountry(countryCode);
      setValue("country", userCountry, { shouldValidate: true });
    }
    if (stateCode) {
      setSelectedState(stateCode);
      setValue("state", userState, { shouldValidate: true });
    }
    if (userCity) {
      setSelectedCity(userCity);
      setValue("city", userCity, { shouldValidate: true });
    }

    didInitLocationRef.current = true;
  }, [user, setValue, countryOptions]);

  if (isLoading) {
    return <div className="p-6">Loading...</div>;
  }

  if (!profileCompletionRequired) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/35 backdrop-blur-sm p-4">
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader>
          <CardTitle>Complete Your Profile</CardTitle>
          <CardDescription>
            Please fill required details before accessing private routes.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={handleSubmit(onSubmit)}>
            <input type="hidden" {...register("country", { required: true })} />
            <input type="hidden" {...register("state", { required: true })} />
            <input type="hidden" {...register("city", { required: true })} />
            <div className="space-y-2">
              <Label htmlFor="addressline">Address Line</Label>
              <Input id="addressline" {...register("addressline", { required: true })} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="country">Country</Label>
              <Select
                value={selectedCountry}
                onValueChange={(value) => {
                  setSelectedCountry(value);
                  setSelectedState("");
                  setSelectedCity("");
                  const countryName = countryOptions.find((c) => c.isoCode === value)?.name || "";
                  setValue("country", countryName, { shouldValidate: true });
                  setValue("state", "", { shouldValidate: true });
                  setValue("city", "", { shouldValidate: true });
                }}
              >
                <SelectTrigger id="country">
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent className="z-[200]">
                  {countryOptions.map((country) => (
                    <SelectItem key={country.isoCode} value={country.isoCode}>
                      {country.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="state">State</Label>
              <Select
                value={selectedState}
                onValueChange={(value) => {
                  setSelectedState(value);
                  setSelectedCity("");
                  const stateName = stateOptions.find((s) => s.isoCode === value)?.name || "";
                  setValue("state", stateName, { shouldValidate: true });
                  setValue("city", "", { shouldValidate: true });
                }}
                disabled={!selectedCountry}
              >
                <SelectTrigger id="state">
                  <SelectValue placeholder={selectedCountryName ? "Select state" : "Select country first"} />
                </SelectTrigger>
                <SelectContent className="z-[200]">
                  {stateOptions.map((state) => (
                    <SelectItem key={state.isoCode} value={state.isoCode}>
                      {state.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="city">City</Label>
              <Select
                value={selectedCity}
                onValueChange={(value) => {
                  setSelectedCity(value);
                  setValue("city", value, { shouldValidate: true });
                }}
                disabled={!selectedState}
              >
                <SelectTrigger id="city">
                  <SelectValue placeholder={selectedStateName ? "Select city" : "Select state first"} />
                </SelectTrigger>
                <SelectContent className="z-[200]">
                  {cityOptions.map((city) => (
                    <SelectItem key={`${city.countryCode}-${city.stateCode}-${city.name}`} value={city.name}>
                      {city.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" {...register("phone", { required: true })} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="pincode">Pincode</Label>
              <Input id="pincode" {...register("pincode", { required: true })} />
            </div>

            <div className="space-y-2">
              <Label>Profile Picture</Label>
              <div className="flex gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) void uploadProfilePicture(file);
                  }}
                />
                <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()} disabled={isUploading}>
                  {isUploading ? "Uploading..." : "Upload Photo"}
                </Button>
                {profilePictureUrl ? <span className="text-sm text-muted-foreground">Uploaded</span> : null}
              </div>
            </div>

            <Button className="w-full" type="submit" disabled={isSubmitting || isUploading}>
              {isSubmitting ? "Saving..." : "Save and Continue"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
