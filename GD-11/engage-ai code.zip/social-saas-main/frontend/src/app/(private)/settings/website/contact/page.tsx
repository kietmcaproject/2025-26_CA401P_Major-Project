"use client";

import React from "react";
import { useGetResellerConfig, useUpdateResellerConfig } from "@/lib/queries/reseller-config";
import { DEFAULT_RESELLER_CONTENT } from "@/lib/constants/reseller-defaults";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Save } from "lucide-react";

export default function ContactPageEditor() {
    const { data: config, isLoading } = useGetResellerConfig();
    const updateConfig = useUpdateResellerConfig();

    const [contactAddress, setContactAddress] = React.useState("");
    const [contactPhone, setContactPhone] = React.useState("");
    const [contactEmail, setContactEmail] = React.useState("");

    React.useEffect(() => {
        if (config) {
            const content = config.content || DEFAULT_RESELLER_CONTENT;
            if (content.contact) {
                setContactAddress(content.contact.address || DEFAULT_RESELLER_CONTENT.contact.address);
                setContactPhone(content.contact.phone || DEFAULT_RESELLER_CONTENT.contact.phone);
                setContactEmail(content.contact.email || DEFAULT_RESELLER_CONTENT.contact.email);
            } else {
                setContactAddress(DEFAULT_RESELLER_CONTENT.contact.address);
                setContactPhone(DEFAULT_RESELLER_CONTENT.contact.phone);
                setContactEmail(DEFAULT_RESELLER_CONTENT.contact.email);
            }
        } else if (!isLoading && !config) {
            setContactAddress(DEFAULT_RESELLER_CONTENT.contact.address);
            setContactPhone(DEFAULT_RESELLER_CONTENT.contact.phone);
            setContactEmail(DEFAULT_RESELLER_CONTENT.contact.email);
        }
    }, [config, isLoading]);

    const handleSave = async () => {
        try {
            await updateConfig.mutateAsync({
                content: {
                    ...(config?.content || {}),
                    contact: {
                        address: contactAddress,
                        phone: contactPhone,
                        email: contactEmail,
                    },
                },
            });
        } catch (error) {
            console.error("Failed to save:", error);
        }
    };

    if (isLoading) {
        return <div className="p-8">Loading...</div>;
    }

    return (
        <div className="flex flex-1 flex-col gap-6 p-6 overflow-y-auto">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold">Contact Page Editor</h1>
                    <p className="text-muted-foreground">Manage your contact information</p>
                </div>
                <Button onClick={handleSave} disabled={updateConfig.isPending}>
                    <Save className="mr-2 h-4 w-4" />
                    {updateConfig.isPending ? "Saving..." : "Save Changes"}
                </Button>
            </div>

            {/* Contact Information */}
            <Card>
                <CardHeader>
                    <CardTitle>Contact Information</CardTitle>
                    <CardDescription>
                        Contact details displayed on your website
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="contact-address">Address</Label>
                        <Textarea
                            id="contact-address"
                            value={contactAddress}
                            onChange={(e) => setContactAddress(e.target.value)}
                            placeholder="Metro Gate NO. 2, S-2, 2nd floor, Savitri Market Complex..."
                            rows={3}
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="contact-phone">Phone Number</Label>
                        <Input
                            id="contact-phone"
                            value={contactPhone}
                            onChange={(e) => setContactPhone(e.target.value)}
                            placeholder="+91 7599808080"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="contact-email">Email Address</Label>
                        <Input
                            id="contact-email"
                            type="email"
                            value={contactEmail}
                            onChange={(e) => setContactEmail(e.target.value)}
                            placeholder="care@veblika.com"
                        />
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
