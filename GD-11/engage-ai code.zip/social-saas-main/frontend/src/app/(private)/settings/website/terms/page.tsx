"use client";

import React from "react";
import { useGetResellerConfig, useUpdateResellerConfig } from "@/lib/queries/reseller-config";
import { DEFAULT_RESELLER_CONTENT } from "@/lib/constants/reseller-defaults";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Save } from "lucide-react";

export default function TermsOfServiceEditor() {
    const { data: config, isLoading } = useGetResellerConfig();
    const updateConfig = useUpdateResellerConfig();

    const [termsOfService, setTermsOfService] = React.useState("");

    React.useEffect(() => {
        if (config) {
            const content = config.content || DEFAULT_RESELLER_CONTENT;
            setTermsOfService(content.termsOfService || DEFAULT_RESELLER_CONTENT.termsOfService);
        } else if (!isLoading && !config) {
            setTermsOfService(DEFAULT_RESELLER_CONTENT.termsOfService);
        }
    }, [config, isLoading]);

    const handleSave = async () => {
        try {
            await updateConfig.mutateAsync({
                content: {
                    ...(config?.content || {}),
                    termsOfService,
                },
            });
        } catch (error) {
            console.error("Failed to save:", error);
        }
    };

    if (isLoading) {
        return <div className="p-8">Loading...</div>;
    }

    return (
        <div className="flex flex-1 flex-col gap-6 p-6 overflow-y-auto">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold">Terms of Service Editor</h1>
                    <p className="text-muted-foreground">Edit your terms of service content</p>
                </div>
                <Button onClick={handleSave} disabled={updateConfig.isPending}>
                    <Save className="mr-2 h-4 w-4" />
                    {updateConfig.isPending ? "Saving..." : "Save Changes"}
                </Button>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Terms of Service Content</CardTitle>
                    <CardDescription>
                        Enter your terms of service text. You can use HTML for formatting.
                        Leave empty to use the default Veblika terms of service.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Textarea
                        value={termsOfService}
                        onChange={(e) => setTermsOfService(e.target.value)}
                        placeholder="Enter your terms of service content here...

You can include sections like:
- Agreement to Terms
- Description of Service
- User Accounts
- Fees and Payment
- Intellectual Property
- Prohibited Activities
- Limitation of Liability
- Termination
- Governing Law
- Contact Information"
                        className="min-h-[500px] font-mono text-sm"
                    />
                </CardContent>
            </Card>
        </div>
    );
}
