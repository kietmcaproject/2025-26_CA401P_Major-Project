"use client";

import * as React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuthSession } from "@/hooks/use-auth-session";
import { useGetResellerConfig, useUpdateResellerConfig } from "@/lib/queries/reseller-config";
import { Loader2, Upload, Image as ImageIcon, Save } from "lucide-react";
import { toast } from "sonner";
import { Spinner } from "@/components/ui/spinner";

export default function BrandingSettingsPage() {
    const { isAuthenticated, isLoading: isSessionLoading, role } = useAuthSession();
    const { data: config, isLoading: isConfigLoading } = useGetResellerConfig();
    const updateConfig = useUpdateResellerConfig();
    const fileInputRef = React.useRef<HTMLInputElement>(null);
    const [companyName, setCompanyName] = React.useState("");
    const [domain, setDomain] = React.useState("");
    const [currentHost, setCurrentHost] = React.useState("");

    const isReseller = role === "reseller";

    React.useEffect(() => {
        if (!isSessionLoading && isAuthenticated && !isReseller) {
            toast.error("Access denied. Resellers only.");
            // Redirect or handle appropriately
        }
    }, [isSessionLoading, isAuthenticated, isReseller]);

    React.useEffect(() => {
        if (config?.companyName) {
            setCompanyName(config.companyName);
        }
        if (config?.domain) {
            setDomain(config.domain);
        }
    }, [config]);

    React.useEffect(() => {
        if (typeof window !== 'undefined') {
            setCurrentHost(window.location.hostname);
        }
    }, []);

    const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        // Simple validation
        if (file.size > 2 * 1024 * 1024) { // 2MB
            toast.error("File size must be less than 2MB");
            return;
        }

        try {
            await updateConfig.mutateAsync({ file });
            if (fileInputRef.current) fileInputRef.current.value = "";
        } catch (error) {
            console.error("Failed to upload logo", error);
        }
    };

    const handleSaveName = async () => {
        if (!companyName.trim()) {
            toast.error("Company name cannot be empty");
            return;
        }

        try {
            await updateConfig.mutateAsync({ companyName: companyName.trim() });
        } catch (error) {
            console.error("Failed to update company name", error);
        }
    };



    if (isSessionLoading || isConfigLoading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <Spinner />
            </div>
        );
    }

    if (!isReseller) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <Card className="max-w-md">
                    <CardHeader>
                        <CardTitle>Access Denied</CardTitle>
                        <CardDescription>This page is only available for resellers.</CardDescription>
                    </CardHeader>
                </Card>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-zinc-100">
            <div className="mx-auto max-w-4xl px-4 py-8">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-gray-900">Website Branding</h1>
                    <p className="text-gray-600 mt-2">
                        Customize the look and feel of your portal based on your domain.
                    </p>
                </div>

                <div className="grid gap-6">
                    {/* General Settings */}
                    <Card>
                        <CardHeader>
                            <CardTitle>General Settings</CardTitle>
                            <CardDescription>
                                Update your company details.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="companyName">Company Name</Label>
                                <div className="flex gap-2">
                                    <Input
                                        id="companyName"
                                        placeholder="Veblika"
                                        value={companyName}
                                        onChange={(e) => setCompanyName(e.target.value)}
                                    />
                                    <Button
                                        onClick={handleSaveName}
                                        disabled={updateConfig.isPending}
                                    >
                                        {updateConfig.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                                        <span className="ml-2">Save</span>
                                    </Button>
                                </div>
                                <p className="text-xs text-muted-foreground">
                                    This name will be displayed in the sidebar and page titles.
                                </p>
                            </div>

                            <div className="space-y-2">
                                <Label>Domain Binding</Label>
                                <div className="flex items-center gap-4 p-4 border rounded-lg bg-slate-50">
                                    <div className="flex-1">
                                        <div className="text-sm font-medium text-slate-500 mb-1">Current Domain Detected</div>
                                        <div className="text-lg font-bold text-slate-900">
                                            {currentHost || "Detecting..."}
                                        </div>
                                        {domain && domain === currentHost && (
                                            <div className="flex items-center gap-2 mt-2 text-green-600 text-sm font-medium">
                                                <div className="w-2 h-2 rounded-full bg-green-600" />
                                                Active & Bound
                                            </div>
                                        )}
                                    </div>
                                    <Button
                                        onClick={() => {
                                            if (domain === currentHost) {
                                                toast.success("Already bound to this domain");
                                                return;
                                            }
                                            if (confirm(`Are you sure you want to bind your branding to ${currentHost}? This will make your branding visible on this domain.`)) {
                                                updateConfig.mutate({ domain: currentHost }, {
                                                    onSuccess: () => {
                                                        setDomain(currentHost);
                                                        toast.success(`Branding bound to ${currentHost}`);
                                                    }
                                                });
                                            }
                                        }}
                                        disabled={updateConfig.isPending || !currentHost || domain === currentHost}
                                        variant={domain === currentHost ? "outline" : "default"}
                                    >
                                        {updateConfig.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                                        {domain === currentHost ? "Bound" : "Bind to this Domain"}
                                    </Button>
                                </div>
                                <p className="text-xs text-muted-foreground mt-2">
                                    Your branding configuration will be automatically applied when users visit this domain.
                                </p>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Logo Settings */}
                    <Card>
                        <CardHeader>
                            <CardTitle>Logo</CardTitle>
                            <CardDescription>
                                Upload your organization's logo. This will be displayed on the sidebar and other areas.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center gap-6">
                                <div className="relative flex h-24 w-24 items-center justify-center rounded-lg border bg-muted overflow-hidden">
                                    {config?.logo ? (
                                        <img
                                            src={config.logo}
                                            alt="Logo"
                                            className="h-full w-full object-contain"
                                        />
                                    ) : (
                                        <ImageIcon className="h-10 w-10 text-muted-foreground" />
                                    )}
                                </div>
                                <div className="flex flex-col gap-2">
                                    <div className="flex items-center gap-2">
                                        <Button
                                            type="button"
                                            variant="outline"
                                            disabled={updateConfig.isPending}
                                            onClick={() => fileInputRef.current?.click()}
                                        >
                                            {updateConfig.isPending ? (
                                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                            ) : (
                                                <Upload className="mr-2 h-4 w-4" />
                                            )}
                                            Upload New Logo
                                        </Button>
                                        <input
                                            type="file"
                                            ref={fileInputRef}
                                            className="hidden"
                                            accept="image/*"
                                            onChange={handleLogoUpload}
                                            disabled={updateConfig.isPending}
                                        />
                                    </div>
                                    <p className="text-xs text-muted-foreground">
                                        Recommended size: 512x512px (Square) or transparent PNG. Max 2MB.
                                    </p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
