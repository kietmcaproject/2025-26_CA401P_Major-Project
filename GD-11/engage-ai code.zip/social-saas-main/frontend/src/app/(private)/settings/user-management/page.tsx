"use client";

import * as React from "react";

import { useAuthSession } from "@/hooks/use-auth-session";
import { useResellerManagedUsers } from "@/lib/queries/reseller-users";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function UserManagementPage() {
  const { role, isLoading } = useAuthSession();
  const isReseller = role === "reseller";
  const {
    data: resellerUsers = [],
    isLoading: isLoadingResellerUsers,
    isError: isResellerUsersError,
    error: resellerUsersError,
  } = useResellerManagedUsers();

  if (isLoading) {
    return <div className="p-8">Loading...</div>;
  }

  if (!isReseller) {
    return (
      <div className="flex min-h-screen items-center justify-center p-4">
        <Card className="w-full max-w-lg">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>This page is only available for reseller users.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-linear-to-br from-slate-50 via-gray-50 to-zinc-100">
      <div className="mx-auto max-w-6xl space-y-6 px-4 py-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-gray-900">User Management</h1>
          <p className="text-sm text-muted-foreground">
            Manage users.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Reseller Users</CardTitle>
            {/* <CardDescription>
              Filtered by your reseller ID from `users` collection in social-media database.
            </CardDescription> */}
          </CardHeader>
          <CardContent>
            {isResellerUsersError && (
              <Alert className="mb-4" variant="destructive">
                <AlertTitle>Failed to load reseller users</AlertTitle>
                <AlertDescription>
                  {resellerUsersError instanceof Error
                    ? resellerUsersError.message
                    : "Unknown error while fetching reseller users."}
                </AlertDescription>
              </Alert>
            )}

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Storage (GB)</TableHead>
                    {/* <TableHead>Reseller ID</TableHead> */}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoadingResellerUsers && (
                    <TableRow>
                      <TableCell colSpan={5} className="h-20 text-center text-muted-foreground">
                        Loading reseller users...
                      </TableCell>
                    </TableRow>
                  )}

                  {!isLoadingResellerUsers &&
                    resellerUsers.map((managedUser) => (
                      <TableRow key={managedUser.authUserId}>
                        <TableCell>{managedUser.name || "-"}</TableCell>
                        <TableCell>{managedUser.email || "-"}</TableCell>
                        <TableCell>{managedUser.appRole || "-"}</TableCell>
                        <TableCell>{Number(managedUser.mediaStorageGb || 0).toFixed(4)}</TableCell>
                        {/* <TableCell>{managedUser.resellerId || "-"}</TableCell> */}
                      </TableRow>
                    ))}

                  {!isLoadingResellerUsers && !isResellerUsersError && resellerUsers.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="h-20 text-center text-muted-foreground">
                        No users found for this reseller in users collection.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
