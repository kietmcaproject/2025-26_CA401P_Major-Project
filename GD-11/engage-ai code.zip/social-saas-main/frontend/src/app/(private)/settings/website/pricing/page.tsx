"use client";

import React from "react";
import { useGetResellerConfig, useUpdateResellerConfig, type PricingPlan } from "@/lib/queries/reseller-config";
import { DEFAULT_RESELLER_CONTENT } from "@/lib/constants/reseller-defaults";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Save, GripVertical, Check } from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function PricingPageEditor() {
    const { data: config, isLoading } = useGetResellerConfig();
    const updateConfig = useUpdateResellerConfig();

    const [pricing, setPricing] = React.useState<PricingPlan[]>([]);

    React.useEffect(() => {
        if (config) {
            const content = config.content || DEFAULT_RESELLER_CONTENT;
            setPricing(content.pricing && content.pricing.length > 0 ? content.pricing : DEFAULT_RESELLER_CONTENT.pricing);
        } else if (!isLoading && !config) {
            setPricing(DEFAULT_RESELLER_CONTENT.pricing);
        }
    }, [config, isLoading]);

    const handleSave = async () => {
        try {
            await updateConfig.mutateAsync({
                content: {
                    ...config?.content,
                    pricing: pricing.map((p, i) => ({ ...p, order: i })),
                },
            });
        } catch (error) {
            console.error("Failed to save:", error);
        }
    };

    const addPricingPlan = () => {
        setPricing([...pricing, {
            name: "",
            price: "",
            period: "/mo",
            description: "",
            features: [],
            isPopular: false,
            buttonText: "Start free trial",
            order: pricing.length
        }]);
    };

    const updatePricingPlan = (index: number, field: keyof PricingPlan, value: string | boolean | string[] | number) => {
        const updated = [...pricing];
        updated[index] = { ...updated[index], [field]: value };
        setPricing(updated);
    };

    const removePricingPlan = (index: number) => {
        setPricing(pricing.filter((_, i) => i !== index));
    };

    const addPricingFeature = (planIndex: number) => {
        const updated = [...pricing];
        updated[planIndex].features = [...updated[planIndex].features, ""];
        setPricing(updated);
    };

    const updatePricingFeature = (planIndex: number, featureIndex: number, value: string) => {
        const updated = [...pricing];
        updated[planIndex].features[featureIndex] = value;
        setPricing(updated);
    };

    const removePricingFeature = (planIndex: number, featureIndex: number) => {
        const updated = [...pricing];
        updated[planIndex].features = updated[planIndex].features.filter((_, i) => i !== featureIndex);
        setPricing(updated);
    };

    if (isLoading) {
        return <div className="p-8">Loading...</div>;
    }

    return (
        <div className="flex flex-1 flex-col gap-6 p-6 overflow-y-auto">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold">Pricing Page Editor</h1>
                    <p className="text-muted-foreground">Configure your pricing tiers displayed on the landing page</p>
                </div>
                <Button onClick={handleSave} disabled={updateConfig.isPending}>
                    <Save className="mr-2 h-4 w-4" />
                    {updateConfig.isPending ? "Saving..." : "Save Changes"}
                </Button>
            </div>

            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle>Pricing Plans</CardTitle>
                            <CardDescription>
                                Manage the details of each pricing plan
                            </CardDescription>
                        </div>
                        <Button variant="outline" size="sm" onClick={addPricingPlan}>
                            <Plus className="mr-2 h-4 w-4" /> Add Plan
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="space-y-6">
                    {pricing.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                            No pricing plans added. Click "Add Plan" to get started.
                        </p>
                    )}
                    {pricing.map((plan, planIndex) => (
                        <div key={planIndex} className={`p-6 border rounded-xl space-y-6 ${plan.isPopular ? 'border-primary/50 bg-primary/5' : 'bg-card'}`}>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <GripVertical className="h-5 w-5 text-muted-foreground cursor-grab" />
                                    <span className="font-semibold text-lg">Plan {planIndex + 1}</span>
                                    {plan.isPopular && (
                                        <span className="text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full font-medium">Most Popular</span>
                                    )}
                                </div>
                                <Button variant="ghost" size="icon" onClick={() => removePricingPlan(planIndex)}>
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                            </div>

                            <div className="grid gap-6 md:grid-cols-3">
                                <div className="space-y-2">
                                    <Label>Plan Name</Label>
                                    <Input
                                        value={plan.name}
                                        onChange={(e) => updatePricingPlan(planIndex, "name", e.target.value)}
                                        placeholder="Starter"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Price</Label>
                                    <Input
                                        value={plan.price}
                                        onChange={(e) => updatePricingPlan(planIndex, "price", e.target.value)}
                                        placeholder="$29"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Period</Label>
                                    <Input
                                        value={plan.period}
                                        onChange={(e) => updatePricingPlan(planIndex, "period", e.target.value)}
                                        placeholder="/mo"
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label>Description</Label>
                                <Input
                                    value={plan.description}
                                    onChange={(e) => updatePricingPlan(planIndex, "description", e.target.value)}
                                    placeholder="Perfect for individuals and small teams."
                                />
                            </div>

                            <div className="grid gap-6 md:grid-cols-2">
                                <div className="space-y-2">
                                    <Label>Button Text</Label>
                                    <Input
                                        value={plan.buttonText}
                                        onChange={(e) => updatePricingPlan(planIndex, "buttonText", e.target.value)}
                                        placeholder="Start free trial"
                                    />
                                </div>
                                <div className="flex items-center justify-between p-4 border rounded-lg bg-background">
                                    <Label htmlFor={`popular-${planIndex}`} className="cursor-pointer">Mark as Most Popular</Label>
                                    <Switch
                                        id={`popular-${planIndex}`}
                                        checked={plan.isPopular}
                                        onCheckedChange={(checked) => updatePricingPlan(planIndex, "isPopular", checked)}
                                    />
                                </div>
                            </div>

                            <div className="space-y-3">
                                <div className="flex items-center justify-between">
                                    <Label>Features</Label>
                                    <Button variant="ghost" size="sm" onClick={() => addPricingFeature(planIndex)} className="h-8">
                                        <Plus className="h-3 w-3 mr-1" /> Add Feature
                                    </Button>
                                </div>
                                <div className="space-y-2 pl-2 border-l-2 border-muted">
                                    {plan.features.length === 0 && (
                                        <p className="text-sm text-muted-foreground py-2 pl-2">No features added yet.</p>
                                    )}
                                    {plan.features.map((feature, featureIndex) => (
                                        <div key={featureIndex} className="flex items-center gap-2">
                                            <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                                            <Input
                                                value={feature}
                                                onChange={(e) => updatePricingFeature(planIndex, featureIndex, e.target.value)}
                                                placeholder="Feature description"
                                                className="flex-1 h-9"
                                            />
                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                onClick={() => removePricingFeature(planIndex, featureIndex)}
                                                className="h-9 w-9"
                                            >
                                                <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>
        </div>
    );
}
