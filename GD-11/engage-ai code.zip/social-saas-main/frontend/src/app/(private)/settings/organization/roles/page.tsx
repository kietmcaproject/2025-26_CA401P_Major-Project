import { RolesList } from "@/components/organisations/roles-list";

export default function RolesPage() {
    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-lg font-medium">Roles</h3>
                <p className="text-sm text-muted-foreground">
                    Define roles and permissions for your team members.
                </p>
            </div>
            <RolesList />
        </div>
    );
}
