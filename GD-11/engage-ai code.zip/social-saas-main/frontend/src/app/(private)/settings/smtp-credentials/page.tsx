"use client";

import * as React from "react";
import { Mail, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { useAuthSession } from "@/hooks/use-auth-session";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import api from "@/utils/api";

type SmtpCredential = {
  host: string;
  port: string;
  username: string;
  password: string;
  fromName: string;
  fromEmail: string;
  secure: boolean;
  enabled: boolean;
  updatedAt: string;
};

type SmtpFormState = Omit<SmtpCredential, "updatedAt">;

const DEFAULT_FORM: SmtpFormState = {
  host: "",
  port: "587",
  username: "",
  password: "",
  fromName: "",
  fromEmail: "",
  secure: true,
  enabled: true,
};

export default function SmtpCredentialsPage() {
  const { role, isLoading, user, resellerId } = useAuthSession();
  const isReseller = role === "reseller";

  const [form, setForm] = React.useState<SmtpFormState>(DEFAULT_FORM);
  const [updatedAt, setUpdatedAt] = React.useState<string | null>(null);
  const [isFetchingConfig, setIsFetchingConfig] = React.useState(false);
  const [isSaving, setIsSaving] = React.useState(false);
  const [isRemoving, setIsRemoving] = React.useState(false);

  React.useEffect(() => {
    if (!isReseller || typeof window === "undefined") return;

    let mounted = true;
    const loadConfig = async () => {
      setIsFetchingConfig(true);
      try {
        const originDomain = window.location.hostname;
        const { data } = await api.get<{ success: boolean; data: SmtpCredential | null }>("/reseller-config/smtp", {
          params: { originDomain },
        });

        const config = data?.data;
        if (!mounted || !config) {
          if (mounted) {
            setForm(DEFAULT_FORM);
            setUpdatedAt(null);
          }
          return;
        }

        setForm({
          host: config.host || "",
          port: String(config.port || "587"),
          username: config.username || "",
          password: config.password || "",
          fromName: config.fromName || "",
          fromEmail: config.fromEmail || "",
          secure: config.secure ?? true,
          enabled: config.enabled ?? true,
        });
        setUpdatedAt(config.updatedAt || null);
      } catch {
        if (!mounted) return;
        setForm(DEFAULT_FORM);
        setUpdatedAt(null);
      } finally {
        if (mounted) setIsFetchingConfig(false);
      }
    };

    loadConfig();

    return () => {
      mounted = false;
    };
  }, [isReseller]);

  React.useEffect(() => {
    if (!isReseller) {
      setForm(DEFAULT_FORM);
      setUpdatedAt(null);
    }
  }, [isReseller]);

  const updateForm = <K extends keyof SmtpFormState>(key: K, value: SmtpFormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const validateForm = () => {
    if (!form.host.trim()) return "SMTP host is required.";
    if (!form.port.trim()) return "SMTP port is required.";
    if (!form.username.trim()) return "SMTP username is required.";
    if (!form.password.trim()) return "SMTP password is required.";
    if (!form.fromEmail.trim()) return "From email is required.";
    return null;
  };

  const handleSave = async () => {
    const error = validateForm();
    if (error) {
      toast.error(error);
      return;
    }

    if (typeof window === "undefined") return;

    setIsSaving(true);
    try {
      const originDomain = window.location.hostname;
      const { data } = await api.post<{ success: boolean; data: SmtpCredential }>("/reseller-config/smtp", {
        ...form,
        originDomain,
      });

      setUpdatedAt(data?.data?.updatedAt || new Date().toISOString());
      toast.success("SMTP credentials saved for this reseller and domain.");
    } catch (err: any) {
      toast.error(err?.response?.data?.message || "Failed to save SMTP configuration.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = async () => {
    if (typeof window === "undefined") return;

    setIsRemoving(true);
    try {
      const originDomain = window.location.hostname;
      await api.delete("/reseller-config/smtp", { data: { originDomain } });
      setForm(DEFAULT_FORM);
      setUpdatedAt(null);
      toast.success("SMTP credentials removed.");
    } catch (err: any) {
      toast.error(err?.response?.data?.message || "Failed to remove SMTP configuration.");
    } finally {
      setIsRemoving(false);
    }
  };

  if (isLoading) {
    return <div className="p-8">Loading...</div>;
  }

  if (!isReseller) {
    return (
      <div className="flex min-h-screen items-center justify-center p-4">
        <Card className="w-full max-w-lg">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>This page is only available for reseller users.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-zinc-100">
      <div className="mx-auto max-w-5xl space-y-6 px-4 py-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-gray-900">SMTP Credential Management</h1>
          <p className="text-sm text-muted-foreground">
            Set SMTP for this reseller domain. Auth emails will use this first, and fallback to env SMTP if no domain config exists.
          </p>
        </div>

        <Alert>
          <Mail className="h-4 w-4" />
          <AlertTitle>Reseller-Wide SMTP</AlertTitle>
          <AlertDescription>
            This SMTP credential is scoped to reseller ID <strong>{resellerId || "N/A"}</strong> and applies automatically to all users under this reseller.
          </AlertDescription>
        </Alert>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between gap-4">
              <div>
                <CardTitle>SMTP Configuration</CardTitle>
                <CardDescription>Only users with reseller role can update this global SMTP setting.</CardDescription>
              </div>
              {updatedAt ? <Badge>Configured</Badge> : <Badge variant="outline">Not Configured</Badge>}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="smtp-host">SMTP Host</Label>
                <Input
                  id="smtp-host"
                  placeholder="smtp.mailprovider.com"
                  value={form.host}
                  onChange={(e) => updateForm("host", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="smtp-port">Port</Label>
                <Input
                  id="smtp-port"
                  placeholder="587"
                  value={form.port}
                  onChange={(e) => updateForm("port", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="smtp-username">Username</Label>
                <Input
                  id="smtp-username"
                  placeholder="username"
                  value={form.username}
                  onChange={(e) => updateForm("username", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="smtp-password">Password</Label>
                <Input
                  id="smtp-password"
                  type="password"
                  placeholder="password"
                  value={form.password}
                  onChange={(e) => updateForm("password", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="smtp-from-name">From Name</Label>
                <Input
                  id="smtp-from-name"
                  placeholder="Support Team"
                  value={form.fromName}
                  onChange={(e) => updateForm("fromName", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="smtp-from-email">From Email</Label>
                <Input
                  id="smtp-from-email"
                  placeholder="support@yourdomain.com"
                  value={form.fromEmail}
                  onChange={(e) => updateForm("fromEmail", e.target.value)}
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="flex items-center justify-between rounded-md border p-3">
                <div className="space-y-0.5">
                  <Label className="text-sm">Use Secure Connection</Label>
                  <p className="text-xs text-muted-foreground">Enable TLS/SSL for SMTP connection</p>
                </div>
                <Switch checked={form.secure} onCheckedChange={(value) => updateForm("secure", value)} />
              </div>
              <div className="flex items-center justify-between rounded-md border p-3">
                <div className="space-y-0.5">
                  <Label className="text-sm">Enable SMTP</Label>
                  <p className="text-xs text-muted-foreground">Enable or disable SMTP for all reseller users</p>
                </div>
                <Switch checked={form.enabled} onCheckedChange={(value) => updateForm("enabled", value)} />
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <Button className="gap-2" onClick={handleSave} disabled={isSaving || isRemoving}>
                <Save className="h-4 w-4" />
                {isSaving ? "Saving..." : "Save SMTP Credentials"}
              </Button>
              <Button variant="outline" className="gap-2" onClick={handleReset} disabled={isSaving || isRemoving}>
                <Trash2 className="h-4 w-4" />
                {isRemoving ? "Removing..." : "Remove SMTP Credentials"}
              </Button>
            </div>

            <p className="text-xs text-muted-foreground">
              {isFetchingConfig
                ? "Loading SMTP configuration..."
                : `Last updated: ${updatedAt ? new Date(updatedAt).toLocaleString() : "Not configured"}`}
            </p>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
