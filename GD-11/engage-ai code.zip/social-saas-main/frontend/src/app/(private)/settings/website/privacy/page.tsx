"use client";

import React from "react";
import { useGetResellerConfig, useUpdateResellerConfig } from "@/lib/queries/reseller-config";
import { DEFAULT_RESELLER_CONTENT } from "@/lib/constants/reseller-defaults";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Save } from "lucide-react";

export default function PrivacyPolicyEditor() {
    const { data: config, isLoading } = useGetResellerConfig();
    const updateConfig = useUpdateResellerConfig();

    const [privacyPolicy, setPrivacyPolicy] = React.useState("");

    React.useEffect(() => {
        if (config) {
            const content = config.content || DEFAULT_RESELLER_CONTENT;
            setPrivacyPolicy(content.privacyPolicy || DEFAULT_RESELLER_CONTENT.privacyPolicy);
        } else if (!isLoading && !config) {
            setPrivacyPolicy(DEFAULT_RESELLER_CONTENT.privacyPolicy);
        }
    }, [config, isLoading]);

    const handleSave = async () => {
        try {
            await updateConfig.mutateAsync({
                content: {
                    ...(config?.content || {}),
                    privacyPolicy,
                },
            });
        } catch (error) {
            console.error("Failed to save:", error);
        }
    };

    if (isLoading) {
        return <div className="p-8">Loading...</div>;
    }

    return (
        <div className="flex flex-1 flex-col gap-6 p-6 overflow-y-auto">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold">Privacy Policy Editor</h1>
                    <p className="text-muted-foreground">Edit your privacy policy content</p>
                </div>
                <Button onClick={handleSave} disabled={updateConfig.isPending}>
                    <Save className="mr-2 h-4 w-4" />
                    {updateConfig.isPending ? "Saving..." : "Save Changes"}
                </Button>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Privacy Policy Content</CardTitle>
                    <CardDescription>
                        Enter your privacy policy text. You can use HTML for formatting.
                        Leave empty to use the default Veblika privacy policy.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Textarea
                        value={privacyPolicy}
                        onChange={(e) => setPrivacyPolicy(e.target.value)}
                        placeholder="Enter your privacy policy content here...

You can include sections like:
- Information We Collect
- How We Use Your Information
- Cookies and Tracking
- Data Sharing and Disclosure
- Your Rights
- Contact Information"
                        className="min-h-[500px] font-mono text-sm"
                    />
                </CardContent>
            </Card>
        </div>
    );
}
