"use client";

import React from "react";
import { useGetResellerConfig, useUpdateResellerConfig, Feature, Stat, Testimonial, type FAQ, type PricingPlan } from "@/lib/queries/reseller-config";
import { DEFAULT_RESELLER_CONTENT } from "@/lib/constants/reseller-defaults";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Save, GripVertical, Star, Check } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

export default function HomePageEditor() {
    const { data: config, isLoading } = useGetResellerConfig();
    const updateConfig = useUpdateResellerConfig();

    // Hero state
    const [heroTitle, setHeroTitle] = React.useState("");
    const [heroSubtitle, setHeroSubtitle] = React.useState("");
    // Features state
    const [features, setFeatures] = React.useState<Feature[]>([]);
    // Stats state
    const [stats, setStats] = React.useState<Stat[]>([]);
    // Testimonials state
    const [testimonials, setTestimonials] = React.useState<Testimonial[]>([]);
    // FAQs state
    const [faqs, setFaqs] = React.useState<FAQ[]>([]);
    // Pricing state
    const [pricing, setPricing] = React.useState<PricingPlan[]>([]);
    // CTA state
    const [ctaTitle, setCtaTitle] = React.useState("");
    const [ctaSubtitle, setCtaSubtitle] = React.useState("");
    const [ctaButtonText, setCtaButtonText] = React.useState("");

    React.useEffect(() => {
        if (config) {
            // Use config content or fallback to defaults
            const content = config.content || DEFAULT_RESELLER_CONTENT;

            setHeroTitle(content.hero?.title || DEFAULT_RESELLER_CONTENT.hero.title);
            setHeroSubtitle(content.hero?.subtitle || DEFAULT_RESELLER_CONTENT.hero.subtitle);

            setFeatures(content.features && content.features.length > 0 ? content.features : DEFAULT_RESELLER_CONTENT.features);
            setStats(content.stats && content.stats.length > 0 ? content.stats : DEFAULT_RESELLER_CONTENT.stats);
            setTestimonials(content.testimonials && content.testimonials.length > 0 ? content.testimonials : DEFAULT_RESELLER_CONTENT.testimonials);
            setFaqs(content.faqs && content.faqs.length > 0 ? content.faqs : DEFAULT_RESELLER_CONTENT.faqs);
            setPricing(content.pricing && content.pricing.length > 0 ? content.pricing : DEFAULT_RESELLER_CONTENT.pricing);

            setCtaTitle(content.cta?.title || DEFAULT_RESELLER_CONTENT.cta.title);
            setCtaSubtitle(content.cta?.subtitle || DEFAULT_RESELLER_CONTENT.cta.subtitle);
            setCtaButtonText(content.cta?.buttonText || DEFAULT_RESELLER_CONTENT.cta.buttonText);
        } else if (!isLoading && !config) {
            // If no config found (and not loading), initialize with defaults
            setHeroTitle(DEFAULT_RESELLER_CONTENT.hero.title);
            setHeroSubtitle(DEFAULT_RESELLER_CONTENT.hero.subtitle);
            setFeatures(DEFAULT_RESELLER_CONTENT.features);
            setStats(DEFAULT_RESELLER_CONTENT.stats);
            setTestimonials(DEFAULT_RESELLER_CONTENT.testimonials);
            setFaqs(DEFAULT_RESELLER_CONTENT.faqs);
            setPricing(DEFAULT_RESELLER_CONTENT.pricing);
            setCtaTitle(DEFAULT_RESELLER_CONTENT.cta.title);
            setCtaSubtitle(DEFAULT_RESELLER_CONTENT.cta.subtitle);
            setCtaButtonText(DEFAULT_RESELLER_CONTENT.cta.buttonText);
        }
    }, [config, isLoading]);

    const handleSave = async () => {
        try {
            await updateConfig.mutateAsync({
                content: {
                    ...(config?.content || {}), // Preserve other sections like about, contact, etc.
                    hero: {
                        title: heroTitle,
                        subtitle: heroSubtitle,
                    },
                    features: features.map((f, i) => ({ ...f, order: i })),
                    stats: stats.map((s, i) => ({ ...s, order: i })),
                    testimonials: testimonials.map((t, i) => ({ ...t, order: i })),
                    faqs: faqs.map((faq, index) => ({ ...faq, order: index })),
                    pricing: pricing.map((p, i) => ({ ...p, order: i })),
                    cta: {
                        title: ctaTitle,
                        subtitle: ctaSubtitle,
                        buttonText: ctaButtonText,
                    },
                },
            });
        } catch (error) {
            console.error("Failed to save:", error);
        }
    };

    // Feature handlers
    const addFeature = () => {
        setFeatures([...features, { title: "", description: "", icon: "Zap", order: features.length }]);
    };
    const updateFeature = (index: number, field: keyof Feature, value: string | number) => {
        const updated = [...features];
        updated[index] = { ...updated[index], [field]: value };
        setFeatures(updated);
    };
    const removeFeature = (index: number) => {
        setFeatures(features.filter((_, i) => i !== index));
    };

    // Stat handlers
    const addStat = () => {
        setStats([...stats, { label: "", value: "", order: stats.length }]);
    };
    const updateStat = (index: number, field: keyof Stat, value: string | number) => {
        const updated = [...stats];
        updated[index] = { ...updated[index], [field]: value };
        setStats(updated);
    };
    const removeStat = (index: number) => {
        setStats(stats.filter((_, i) => i !== index));
    };

    // Testimonial handlers
    const addTestimonial = () => {
        setTestimonials([...testimonials, {
            name: "", role: "", company: "", content: "", avatar: "", rating: 5, order: testimonials.length
        }]);
    };
    const updateTestimonial = (index: number, field: keyof Testimonial, value: string | number) => {
        const updated = [...testimonials];
        updated[index] = { ...updated[index], [field]: value };
        setTestimonials(updated);
    };
    const removeTestimonial = (index: number) => {
        setTestimonials(testimonials.filter((_, i) => i !== index));
    };

    // FAQ handlers
    const handleAddFaq = () => {
        setFaqs([...faqs, { question: "", answer: "", order: faqs.length }]);
    };
    const handleRemoveFaq = (index: number) => {
        setFaqs(faqs.filter((_, i) => i !== index));
    };
    const handleFaqChange = (index: number, field: "question" | "answer", value: string) => {
        const updated = [...faqs];
        updated[index][field] = value;
        setFaqs(updated);
    };

    // Pricing handlers
    const addPricingPlan = () => {
        setPricing([...pricing, {
            name: "",
            price: "",
            period: "/mo",
            description: "",
            features: [],
            isPopular: false,
            buttonText: "Start free trial",
            order: pricing.length
        }]);
    };
    const updatePricingPlan = (index: number, field: keyof PricingPlan, value: string | boolean | string[] | number) => {
        const updated = [...pricing];
        updated[index] = { ...updated[index], [field]: value };
        setPricing(updated);
    };
    const removePricingPlan = (index: number) => {
        setPricing(pricing.filter((_, i) => i !== index));
    };
    const addPricingFeature = (planIndex: number) => {
        const updated = [...pricing];
        updated[planIndex].features = [...updated[planIndex].features, ""];
        setPricing(updated);
    };
    const updatePricingFeature = (planIndex: number, featureIndex: number, value: string) => {
        const updated = [...pricing];
        updated[planIndex].features[featureIndex] = value;
        setPricing(updated);
    };
    const removePricingFeature = (planIndex: number, featureIndex: number) => {
        const updated = [...pricing];
        updated[planIndex].features = updated[planIndex].features.filter((_, i) => i !== featureIndex);
        setPricing(updated);
    };

    if (isLoading) {
        return <div className="p-8">Loading...</div>;
    }

    return (
        <div className="flex flex-1 flex-col gap-6 p-6 overflow-y-auto">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold">Home Page Editor</h1>
                    <p className="text-muted-foreground">Customize your landing page content</p>
                </div>
                <Button onClick={handleSave} disabled={updateConfig.isPending}>
                    <Save className="mr-2 h-4 w-4" />
                    {updateConfig.isPending ? "Saving..." : "Save Changes"}
                </Button>
            </div>

            {/* Hero Section */}
            <Card>
                <CardHeader>
                    <CardTitle>Hero Section</CardTitle>
                    <CardDescription>
                        Main headline and subtitle displayed at the top of your landing page
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="hero-title">Title</Label>
                        <Input
                            id="hero-title"
                            value={heroTitle}
                            onChange={(e) => setHeroTitle(e.target.value)}
                            placeholder="Your social media command center"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="hero-subtitle">Subtitle</Label>
                        <Textarea
                            id="hero-subtitle"
                            value={heroSubtitle}
                            onChange={(e) => setHeroSubtitle(e.target.value)}
                            placeholder="Schedule, publish, analyze, and engage..."
                            rows={3}
                        />
                    </div>
                </CardContent>
            </Card>

            {/* CTA Section */}
            <Card>
                <CardHeader>
                    <CardTitle>Call to Action</CardTitle>
                    <CardDescription>
                        Promotional banner displayed before the footer
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="cta-title">Title</Label>
                        <Input
                            id="cta-title"
                            value={ctaTitle}
                            onChange={(e) => setCtaTitle(e.target.value)}
                            placeholder="Grow your brand presence on social media."
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="cta-subtitle">Subtitle</Label>
                        <Input
                            id="cta-subtitle"
                            value={ctaSubtitle}
                            onChange={(e) => setCtaSubtitle(e.target.value)}
                            placeholder="Try Veblika free for 14 days. No credit card required."
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="cta-button">Button Text</Label>
                        <Input
                            id="cta-button"
                            value={ctaButtonText}
                            onChange={(e) => setCtaButtonText(e.target.value)}
                            placeholder="Sign Up for Free Trial"
                        />
                    </div>
                </CardContent>
            </Card>

            {/* Features Section */}
            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle>Features</CardTitle>
                            <CardDescription>Highlight your product features</CardDescription>
                        </div>
                        <Button variant="outline" size="sm" onClick={addFeature}>
                            <Plus className="mr-2 h-4 w-4" /> Add Feature
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="space-y-4">
                    {features.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                            No features added. Click "Add Feature" to get started.
                        </p>
                    )}
                    {features.map((feature, index) => (
                        <div key={index} className="flex gap-4 items-start p-4 border rounded-lg bg-muted/30">
                            <GripVertical className="h-5 w-5 text-muted-foreground mt-2 cursor-grab" />
                            <div className="flex-1 grid gap-4 md:grid-cols-2">
                                <div className="space-y-2">
                                    <Label>Title</Label>
                                    <Input
                                        value={feature.title}
                                        onChange={(e) => updateFeature(index, "title", e.target.value)}
                                        placeholder="Feature title"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Icon (Lucide name)</Label>
                                    <Input
                                        value={feature.icon}
                                        onChange={(e) => updateFeature(index, "icon", e.target.value)}
                                        placeholder="Zap, Star, Shield..."
                                    />
                                </div>
                                <div className="space-y-2 md:col-span-2">
                                    <Label>Description</Label>
                                    <Textarea
                                        value={feature.description}
                                        onChange={(e) => updateFeature(index, "description", e.target.value)}
                                        placeholder="Describe this feature"
                                        rows={2}
                                    />
                                </div>
                            </div>
                            <Button variant="ghost" size="icon" onClick={() => removeFeature(index)}>
                                <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                        </div>
                    ))}
                </CardContent>
            </Card>

            {/* Stats Section */}
            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle>Statistics</CardTitle>
                            <CardDescription>Show impressive numbers</CardDescription>
                        </div>
                        <Button variant="outline" size="sm" onClick={addStat}>
                            <Plus className="mr-2 h-4 w-4" /> Add Stat
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="space-y-4">
                    {stats.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                            No stats added. Click "Add Stat" to get started.
                        </p>
                    )}
                    {stats.map((stat, index) => (
                        <div key={index} className="flex gap-4 items-center p-4 border rounded-lg bg-muted/30">
                            <GripVertical className="h-5 w-5 text-muted-foreground cursor-grab" />
                            <div className="flex-1 grid gap-4 md:grid-cols-2">
                                <div className="space-y-2">
                                    <Label>Value</Label>
                                    <Input
                                        value={stat.value}
                                        onChange={(e) => updateStat(index, "value", e.target.value)}
                                        placeholder="100+"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Label</Label>
                                    <Input
                                        value={stat.label}
                                        onChange={(e) => updateStat(index, "label", e.target.value)}
                                        placeholder="Customers Served"
                                    />
                                </div>
                            </div>
                            <Button variant="ghost" size="icon" onClick={() => removeStat(index)}>
                                <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                        </div>
                    ))}
                </CardContent>
            </Card>

            {/* Testimonials Section */}
            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle>Testimonials</CardTitle>
                            <CardDescription>Customer reviews and feedback</CardDescription>
                        </div>
                        <Button variant="outline" size="sm" onClick={addTestimonial}>
                            <Plus className="mr-2 h-4 w-4" /> Add Testimonial
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="space-y-4">
                    {testimonials.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                            No testimonials added. Click "Add Testimonial" to get started.
                        </p>
                    )}
                    {testimonials.map((testimonial, index) => (
                        <div key={index} className="p-4 border rounded-lg bg-muted/30 space-y-4">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <GripVertical className="h-5 w-5 text-muted-foreground cursor-grab" />
                                    <span className="font-medium">Testimonial {index + 1}</span>
                                </div>
                                <Button variant="ghost" size="icon" onClick={() => removeTestimonial(index)}>
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                            </div>
                            <div className="grid gap-4 md:grid-cols-3">
                                <div className="space-y-2">
                                    <Label>Name</Label>
                                    <Input
                                        value={testimonial.name}
                                        onChange={(e) => updateTestimonial(index, "name", e.target.value)}
                                        placeholder="John Doe"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Role</Label>
                                    <Input
                                        value={testimonial.role || ""}
                                        onChange={(e) => updateTestimonial(index, "role", e.target.value)}
                                        placeholder="CEO"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Company</Label>
                                    <Input
                                        value={testimonial.company || ""}
                                        onChange={(e) => updateTestimonial(index, "company", e.target.value)}
                                        placeholder="Acme Inc"
                                    />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label>Testimonial Content</Label>
                                <Textarea
                                    value={testimonial.content}
                                    onChange={(e) => updateTestimonial(index, "content", e.target.value)}
                                    placeholder="What did they say about your product?"
                                    rows={3}
                                />
                            </div>
                            <div className="flex items-center gap-4">
                                <Label>Rating</Label>
                                <div className="flex gap-1">
                                    {[1, 2, 3, 4, 5].map((star) => (
                                        <button
                                            key={star}
                                            type="button"
                                            onClick={() => updateTestimonial(index, "rating", star)}
                                            className="focus:outline-none"
                                        >
                                            <Star
                                                className={`h-5 w-5 ${star <= testimonial.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                                            />
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>

            {/* FAQ Section */}
            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle>FAQ Section</CardTitle>
                            <CardDescription>
                                Frequently asked questions displayed on your landing page
                            </CardDescription>
                        </div>
                        <Button onClick={handleAddFaq} size="sm">
                            <Plus className="w-4 h-4 mr-2" />
                            Add FAQ
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="space-y-4">
                    {faqs.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground">
                            No FAQs yet. Click "Add FAQ" to create one.
                        </div>
                    ) : (
                        faqs.map((faq, index) => (
                            <Card key={index} className="border-2">
                                <CardContent className="pt-6 space-y-4">
                                    <div className="flex items-start justify-between gap-4">
                                        <div className="flex-1 space-y-4">
                                            <div className="space-y-2">
                                                <Label htmlFor={`faq-question-${index}`}>Question</Label>
                                                <Input
                                                    id={`faq-question-${index}`}
                                                    value={faq.question}
                                                    onChange={(e) => handleFaqChange(index, "question", e.target.value)}
                                                    placeholder="What is your question?"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor={`faq-answer-${index}`}>Answer</Label>
                                                <Textarea
                                                    id={`faq-answer-${index}`}
                                                    value={faq.answer}
                                                    onChange={(e) => handleFaqChange(index, "answer", e.target.value)}
                                                    placeholder="Provide the answer..."
                                                    rows={3}
                                                />
                                            </div>
                                        </div>
                                        <div className="flex flex-col gap-2">
                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                className="cursor-move"
                                                title="Drag to reorder"
                                            >
                                                <GripVertical className="w-4 h-4" />
                                            </Button>
                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                onClick={() => handleRemoveFaq(index)}
                                                className="text-destructive hover:text-destructive"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))
                    )}
                </CardContent>
            </Card>

            {/* Pricing Section */}
            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle>Pricing Plans</CardTitle>
                            <CardDescription>
                                Configure your pricing tiers displayed on the landing page
                            </CardDescription>
                        </div>
                        <Button variant="outline" size="sm" onClick={addPricingPlan}>
                            <Plus className="mr-2 h-4 w-4" /> Add Plan
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="space-y-4">
                    {pricing.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                            No pricing plans added. Click "Add Plan" to get started.
                        </p>
                    )}
                    {pricing.map((plan, planIndex) => (
                        <div key={planIndex} className={`p-4 border rounded-lg space-y-4 ${plan.isPopular ? 'border-primary bg-primary/5' : 'bg-muted/30'}`}>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <GripVertical className="h-5 w-5 text-muted-foreground cursor-grab" />
                                    <span className="font-medium">Plan {planIndex + 1}</span>
                                    {plan.isPopular && (
                                        <span className="text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full">Most Popular</span>
                                    )}
                                </div>
                                <Button variant="ghost" size="icon" onClick={() => removePricingPlan(planIndex)}>
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                            </div>

                            <div className="grid gap-4 md:grid-cols-3">
                                <div className="space-y-2">
                                    <Label>Plan Name</Label>
                                    <Input
                                        value={plan.name}
                                        onChange={(e) => updatePricingPlan(planIndex, "name", e.target.value)}
                                        placeholder="Starter"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Price</Label>
                                    <Input
                                        value={plan.price}
                                        onChange={(e) => updatePricingPlan(planIndex, "price", e.target.value)}
                                        placeholder="$29"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Period</Label>
                                    <Input
                                        value={plan.period}
                                        onChange={(e) => updatePricingPlan(planIndex, "period", e.target.value)}
                                        placeholder="/mo"
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label>Description</Label>
                                <Input
                                    value={plan.description}
                                    onChange={(e) => updatePricingPlan(planIndex, "description", e.target.value)}
                                    placeholder="Perfect for individuals and small teams."
                                />
                            </div>

                            <div className="grid gap-4 md:grid-cols-2">
                                <div className="space-y-2">
                                    <Label>Button Text</Label>
                                    <Input
                                        value={plan.buttonText}
                                        onChange={(e) => updatePricingPlan(planIndex, "buttonText", e.target.value)}
                                        placeholder="Start free trial"
                                    />
                                </div>
                                <div className="flex items-center justify-between p-3 border rounded-lg">
                                    <Label htmlFor={`popular-${planIndex}`}>Mark as Most Popular</Label>
                                    <Switch
                                        id={`popular-${planIndex}`}
                                        checked={plan.isPopular}
                                        onCheckedChange={(checked) => updatePricingPlan(planIndex, "isPopular", checked)}
                                    />
                                </div>
                            </div>

                            {/* Features List */}
                            <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                    <Label>Features</Label>
                                    <Button variant="ghost" size="sm" onClick={() => addPricingFeature(planIndex)}>
                                        <Plus className="h-4 w-4 mr-1" /> Add Feature
                                    </Button>
                                </div>
                                <div className="space-y-2">
                                    {plan.features.length === 0 && (
                                        <p className="text-sm text-muted-foreground py-2">No features added yet.</p>
                                    )}
                                    {plan.features.map((feature, featureIndex) => (
                                        <div key={featureIndex} className="flex items-center gap-2">
                                            <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                                            <Input
                                                value={feature}
                                                onChange={(e) => updatePricingFeature(planIndex, featureIndex, e.target.value)}
                                                placeholder="Feature description"
                                                className="flex-1"
                                            />
                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                onClick={() => removePricingFeature(planIndex, featureIndex)}
                                            >
                                                <Trash2 className="h-4 w-4 text-destructive" />
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>
        </div>
    );
}
