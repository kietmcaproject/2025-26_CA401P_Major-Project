"use client"

import * as React from "react"

export default function OrganizationSettingsPage() {
  return (
    <div className="flex h-screen items-center justify-center">
      <p className="text-muted-foreground">Organization settings are disabled.</p>
    </div>
  )
}
