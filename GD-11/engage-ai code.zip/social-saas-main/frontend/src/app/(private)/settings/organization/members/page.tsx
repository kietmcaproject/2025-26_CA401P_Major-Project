"use client"

import * as React from "react"

export default function MembersPage() {
    return (
        <div className="flex h-screen items-center justify-center">
            <p className="text-muted-foreground">Members management is disabled.</p>
        </div>
    )
}
