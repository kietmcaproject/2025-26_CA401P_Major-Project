"use client";

import React from "react";
import { useGetResellerConfig, useUpdateResellerConfig, AboutPageStat } from "@/lib/queries/reseller-config";
import { DEFAULT_RESELLER_CONTENT } from "@/lib/constants/reseller-defaults";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Save, GripVertical } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function AboutPageEditor() {
    const { data: config, isLoading } = useGetResellerConfig();
    const updateConfig = useUpdateResellerConfig();

    const [tagline, setTagline] = React.useState("");
    const [headline, setHeadline] = React.useState("");
    const [story, setStory] = React.useState("");
    const [title, setTitle] = React.useState("");
    const [description, setDescription] = React.useState("");
    const [stats, setStats] = React.useState<AboutPageStat[]>([]);
    const [industries, setIndustries] = React.useState<string[]>([]);
    const [newIndustry, setNewIndustry] = React.useState("");

    React.useEffect(() => {
        if (config) {
            const content = config.content || DEFAULT_RESELLER_CONTENT;

            if (content.aboutPage) {
                setTagline(content.aboutPage.tagline || DEFAULT_RESELLER_CONTENT.aboutPage.tagline);
                setHeadline(content.aboutPage.headline || DEFAULT_RESELLER_CONTENT.aboutPage.headline);
                setStory(content.aboutPage.story || DEFAULT_RESELLER_CONTENT.aboutPage.story);
                setStats(content.aboutPage.stats && content.aboutPage.stats.length > 0 ? content.aboutPage.stats : DEFAULT_RESELLER_CONTENT.aboutPage.stats);
                setIndustries(content.aboutPage.industries && content.aboutPage.industries.length > 0 ? content.aboutPage.industries : DEFAULT_RESELLER_CONTENT.aboutPage.industries);
            } else {
                setTagline(DEFAULT_RESELLER_CONTENT.aboutPage.tagline);
                setHeadline(DEFAULT_RESELLER_CONTENT.aboutPage.headline);
                setStory(DEFAULT_RESELLER_CONTENT.aboutPage.story);
                setStats(DEFAULT_RESELLER_CONTENT.aboutPage.stats);
                setIndustries(DEFAULT_RESELLER_CONTENT.aboutPage.industries);
            }

            if (content.about) {
                setTitle(content.about.title || DEFAULT_RESELLER_CONTENT.about.title);
                setDescription(content.about.description || DEFAULT_RESELLER_CONTENT.about.description);
            } else {
                setTitle(DEFAULT_RESELLER_CONTENT.about.title);
                setDescription(DEFAULT_RESELLER_CONTENT.about.description);
            }
        } else if (!isLoading && !config) {
            setTagline(DEFAULT_RESELLER_CONTENT.aboutPage.tagline);
            setHeadline(DEFAULT_RESELLER_CONTENT.aboutPage.headline);
            setStory(DEFAULT_RESELLER_CONTENT.aboutPage.story);
            setStats(DEFAULT_RESELLER_CONTENT.aboutPage.stats);
            setIndustries(DEFAULT_RESELLER_CONTENT.aboutPage.industries);
            setTitle(DEFAULT_RESELLER_CONTENT.about.title);
            setDescription(DEFAULT_RESELLER_CONTENT.about.description);
        }
    }, [config, isLoading]);

    const handleSave = async () => {
        try {
            await updateConfig.mutateAsync({
                content: {
                    ...(config?.content || {}),
                    about: {
                        title,
                        description,
                    },
                    aboutPage: {
                        tagline,
                        headline,
                        story,
                        stats,
                        industries,
                    },
                },
            });
        } catch (error) {
            console.error("Failed to save:", error);
        }
    };

    // Stats handlers
    const addStat = () => {
        setStats([...stats, { label: "", value: "", icon: "" }]);
    };
    const updateStat = (index: number, field: keyof AboutPageStat, value: string) => {
        const updated = [...stats];
        updated[index] = { ...updated[index], [field]: value };
        setStats(updated);
    };
    const removeStat = (index: number) => {
        setStats(stats.filter((_, i) => i !== index));
    };

    // Industry handlers
    const addIndustry = () => {
        if (newIndustry.trim() && !industries.includes(newIndustry.trim())) {
            setIndustries([...industries, newIndustry.trim()]);
            setNewIndustry("");
        }
    };
    const removeIndustry = (index: number) => {
        setIndustries(industries.filter((_, i) => i !== index));
    };

    if (isLoading) {
        return <div className="p-8">Loading...</div>;
    }

    return (
        <div className="flex flex-1 flex-col gap-6 p-6 overflow-y-auto">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold">About Us Page Editor</h1>
                    <p className="text-muted-foreground">Customize your about page content</p>
                </div>
                <Button onClick={handleSave} disabled={updateConfig.isPending}>
                    <Save className="mr-2 h-4 w-4" />
                    {updateConfig.isPending ? "Saving..." : "Save Changes"}
                </Button>
            </div>

            {/* Basic Info */}
            <Card>
                <CardHeader>
                    <CardTitle>Basic Information</CardTitle>
                    <CardDescription>Main content for your about page</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="title">Title</Label>
                        <Input
                            id="title"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            placeholder="About Us"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea
                            id="description"
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            placeholder="We help businesses manage their social media presence..."
                            rows={3}
                        />
                    </div>
                    <div className="border-t pt-4 mt-4">
                        <p className="text-sm text-muted-foreground mb-4">Advanced fields (optional)</p>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="tagline">Tagline</Label>
                        <Input
                            id="tagline"
                            value={tagline}
                            onChange={(e) => setTagline(e.target.value)}
                            placeholder="Established 2023"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="headline">Headline</Label>
                        <Input
                            id="headline"
                            value={headline}
                            onChange={(e) => setHeadline(e.target.value)}
                            placeholder="We are [Your Company]"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="story">Company Story</Label>
                        <Textarea
                            id="story"
                            value={story}
                            onChange={(e) => setStory(e.target.value)}
                            placeholder="Tell your company's story..."
                            rows={6}
                        />
                    </div>
                </CardContent>
            </Card>

            {/* Stats Section */}
            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle>Statistics</CardTitle>
                            <CardDescription>Key numbers about your company</CardDescription>
                        </div>
                        <Button variant="outline" size="sm" onClick={addStat}>
                            <Plus className="mr-2 h-4 w-4" /> Add Stat
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="space-y-4">
                    {stats.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                            No stats added. Click "Add Stat" to get started.
                        </p>
                    )}
                    {stats.map((stat, index) => (
                        <div key={index} className="flex gap-4 items-center p-4 border rounded-lg bg-muted/30">
                            <GripVertical className="h-5 w-5 text-muted-foreground cursor-grab" />
                            <div className="flex-1 grid gap-4 md:grid-cols-3">
                                <div className="space-y-2">
                                    <Label>Value</Label>
                                    <Input
                                        value={stat.value}
                                        onChange={(e) => updateStat(index, "value", e.target.value)}
                                        placeholder="50+"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Label</Label>
                                    <Input
                                        value={stat.label}
                                        onChange={(e) => updateStat(index, "label", e.target.value)}
                                        placeholder="Team Members"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Icon (optional)</Label>
                                    <Input
                                        value={stat.icon || ""}
                                        onChange={(e) => updateStat(index, "icon", e.target.value)}
                                        placeholder="Users, Rocket..."
                                    />
                                </div>
                            </div>
                            <Button variant="ghost" size="icon" onClick={() => removeStat(index)}>
                                <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                        </div>
                    ))}
                </CardContent>
            </Card>

            {/* Industries Section */}
            <Card>
                <CardHeader>
                    <CardTitle>Industries Served</CardTitle>
                    <CardDescription>Industries you work with</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex gap-2">
                        <Input
                            value={newIndustry}
                            onChange={(e) => setNewIndustry(e.target.value)}
                            placeholder="Add an industry..."
                            onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addIndustry())}
                        />
                        <Button variant="outline" onClick={addIndustry}>
                            <Plus className="h-4 w-4" />
                        </Button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                        {industries.map((industry, index) => (
                            <Badge key={index} variant="secondary" className="gap-1 px-3 py-1">
                                {industry}
                                <button
                                    onClick={() => removeIndustry(index)}
                                    className="ml-1 hover:text-destructive"
                                >
                                    ×
                                </button>
                            </Badge>
                        ))}
                        {industries.length === 0 && (
                            <p className="text-sm text-muted-foreground">No industries added yet.</p>
                        )}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
