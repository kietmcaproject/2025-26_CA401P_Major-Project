"use client"

import { MediaGallery } from "@/components/media/media-gallery"

export default function MediaLibraryPage() {
    return (
        <div className="container mx-auto p-6 max-w-7xl">
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-slate-900">Cloud Storage Gallery</h1>
                <p className="text-slate-500 mt-2">Upload and manage image/video assets with live S3 URLs and size details.</p>
            </div>

            <MediaGallery />
        </div>
    )
}
