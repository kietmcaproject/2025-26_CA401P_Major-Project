"use client";

import React from "react";
import Container from "@/components/homePage/container";

export default function CareersPage() {
    return (
        <div className="pt-32 pb-24 min-h-screen">
            <Container className="text-center">
                <h1 className="text-5xl font-black text-slate-900 mb-8 tracking-tight">
                    Join the <span className="text-[#F6571F]">Squad</span>
                </h1>
                <p className="text-xl text-slate-500 max-w-2xl mx-auto mb-12 font-medium">
                    We're always looking for talented individuals to join our growing team of 50+ professionals.
                </p>
                <div className="bg-slate-50 border border-slate-100 p-12 rounded-[2.5rem] max-w-3xl mx-auto">
                    <h2 className="text-2xl font-black text-slate-900 mb-4">No open positions currently</h2>
                    <p className="text-slate-500 mb-8">
                        But we're always happy to hear from brilliant minds. Send your resume to careers@veblika.com
                    </p>
                </div>
            </Container>
        </div>
    );
}
