import FeaturePageTemplate from "@/components/features/feature-page-template";
import { featuresData } from "@/lib/constants/features";

export const metadata = {
    title: "Publishing & Scheduling | Veblika",
    description: "Schedule posts across all platforms with smart timing. Plan, publish, and automate your social media content with Veblika.",
};

export default function SchedulingPage() {
    const feature = featuresData.scheduling;
    return <FeaturePageTemplate feature={feature} />;
}
