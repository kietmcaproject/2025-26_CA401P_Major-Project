import FeaturePageTemplate from "@/components/features/feature-page-template";
import { featuresData } from "@/lib/constants/features";

export const metadata = {
    title: "Social Listening | Veblika",
    description: "Monitor brand mentions, trends, and competitor activity. Stay ahead with real-time social listening.",
};

export default function ListeningPage() {
    const feature = featuresData.listening;
    return <FeaturePageTemplate feature={feature} />;
}
