import FeaturePageTemplate from "@/components/features/feature-page-template";
import { featuresData } from "@/lib/constants/features";

export const metadata = {
    title: "Social Inbox | Veblika",
    description: "Manage all comments, mentions, and DMs in one unified inbox. Respond faster and never miss a conversation.",
};

export default function InboxPage() {
    const feature = featuresData.inbox;
    return <FeaturePageTemplate feature={feature} />;
}
