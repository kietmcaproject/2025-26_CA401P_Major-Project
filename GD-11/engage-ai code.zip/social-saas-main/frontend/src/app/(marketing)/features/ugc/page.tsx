import FeaturePageTemplate from "@/components/features/feature-page-template";
import { featuresData } from "@/lib/constants/features";

export const metadata = {
    title: "UGC & Influencers | Veblika",
    description: "Harness user-generated content and manage influencer partnerships to boost authenticity and reach.",
};

export default function UGCPage() {
    const feature = featuresData.ugc;
    return <FeaturePageTemplate feature={feature} />;
}
