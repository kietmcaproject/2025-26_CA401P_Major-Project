import FeaturePageTemplate from "@/components/features/feature-page-template";
import { featuresData } from "@/lib/constants/features";

export const metadata = {
    title: "Ad Management | Veblika",
    description: "Create, manage, and optimize social ads from one dashboard. Track spend and maximize ROI.",
};

export default function AdsPage() {
    const feature = featuresData.ads;
    return <FeaturePageTemplate feature={feature} />;
}
