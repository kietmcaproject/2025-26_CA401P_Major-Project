import FeaturePageTemplate from "@/components/features/feature-page-template";
import { featuresData } from "@/lib/constants/features";

export const metadata = {
    title: "Team Collaboration | Veblika",
    description: "Streamline workflows with approvals, task assignments, and team management tools.",
};

export default function CollaborationPage() {
    const feature = featuresData.collaboration;
    return <FeaturePageTemplate feature={feature} />;
}
