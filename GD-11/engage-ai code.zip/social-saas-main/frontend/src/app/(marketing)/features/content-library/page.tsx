import FeaturePageTemplate from "@/components/features/feature-page-template";
import { featuresData } from "@/lib/constants/features";

export const metadata = {
    title: "Content Library | Veblika",
    description: "Keep all your media assets organized in one searchable space. Save time and maintain brand consistency.",
};

export default function ContentLibraryPage() {
    const feature = featuresData["content-library"];
    return <FeaturePageTemplate feature={feature} />;
}
