import FeaturePageTemplate from "@/components/features/feature-page-template";
import { featuresData } from "@/lib/constants/features";

export const metadata = {
    title: "Analytics & Reports | Veblika",
    description: "Track performance with powerful insights and custom reports. Understand what works and prove your ROI.",
};

export default function AnalyticsPage() {
    const feature = featuresData.analytics;
    return <FeaturePageTemplate feature={feature} />;
}
