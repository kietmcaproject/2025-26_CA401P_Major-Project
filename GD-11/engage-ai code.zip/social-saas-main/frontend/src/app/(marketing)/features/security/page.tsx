import FeaturePageTemplate from "@/components/features/feature-page-template";
import { featuresData } from "@/lib/constants/features";

export const metadata = {
    title: "Security & Compliance | Veblika",
    description: "Enterprise-grade security with SSO, 2FA, audit logs, and compliance workflows for regulated industries.",
};

export default function SecurityPage() {
    const feature = featuresData.security;
    return <FeaturePageTemplate feature={feature} />;
}
