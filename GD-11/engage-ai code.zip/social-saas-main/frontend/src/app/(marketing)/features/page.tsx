"use client";

import React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Check, Calendar, MessageSquare, BarChart3, Ear, Users, FolderOpen, Megaphone, Heart, Shield, HelpCircle } from "lucide-react";
import { featuresData, featureCategories } from "@/lib/constants/features";

// Hero Section for Features Overview
const FeaturesHero = () => (
    <section className="relative py-24 md:py-32 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#FFF5F1]/50 to-white" />
        <div className="absolute inset-0 opacity-[0.03] fun-pattern" />
        <div
            className="absolute inset-0 opacity-[0.05]"
            style={{
                backgroundImage:
                    "linear-gradient(#F6571F 1px, transparent 1px), linear-gradient(90deg, #F6571F 1px, transparent 1px)",
                backgroundSize: "40px 40px",
            }}
        />

        <div className="container mx-auto px-4 relative z-10">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="max-w-3xl mx-auto text-center"
            >
                <span className="inline-block text-sm font-black text-[#F6571F] bg-[#FFF5F1] px-4 py-1.5 rounded-full mb-6 border border-[#F6571F]/10 uppercase tracking-widest">
                    Platform Features
                </span>
                <h1 className="text-4xl md:text-6xl font-black tracking-tight text-slate-900 leading-[1.1] mb-6">
                    Everything you need to{" "}
                    <span className="text-gradient">
                        dominate social
                    </span>
                </h1>
                <p className="text-lg md:text-xl text-slate-500 leading-relaxed mb-10">
                    From scheduling to analytics, engagement to collaboration — Veblika gives you the complete toolkit to build, manage, and grow your social presence.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                    <Button
                        asChild
                        size="lg"
                        className="h-12 px-8 text-base font-bold rounded-xl bg-[#F6571F] hover:bg-[#E44D1B] text-white shadow-xl shadow-[#F6571F]/10 border-0 transition-all hover:scale-105"
                    >
                        <Link href="/signup">
                            Start free trial
                            <ArrowRight size={18} className="ml-2" />
                        </Link>
                    </Button>
                    <Link
                        href="/pricing"
                        className="text-slate-600 hover:text-[#F6571F] font-bold transition-colors underline underline-offset-4 decoration-[#F6571F]/0 hover:decoration-[#F6571F]/50"
                    >
                        View pricing details
                    </Link>
                </div>
            </motion.div>
        </div>
    </section>
);

const iconMap: Record<string, any> = {
    Calendar,
    MessageSquare,
    BarChart3,
    Ear,
    Users,
    FolderOpen,
    Megaphone,
    Heart,
    Shield,
};

// Feature Card Component
const FeatureCard = ({
    feature,
    index,
}: {
    feature: (typeof featuresData)[keyof typeof featuresData];
    index: number;
}) => {
    const Icon = iconMap[feature.icon] || HelpCircle;

    const colorClasses: Record<string, string> = {
        blue: "bg-blue-50 text-blue-600 group-hover:bg-[#F6571F] group-hover:text-white",
        green: "bg-green-50 text-green-600 group-hover:bg-[#F6571F] group-hover:text-white",
        purple: "bg-purple-50 text-purple-600 group-hover:bg-[#F6571F] group-hover:text-white",
        orange: "bg-[#FFF5F1] text-[#F6571F] group-hover:bg-[#F6571F] group-hover:text-white",
        cyan: "bg-cyan-50 text-cyan-600 group-hover:bg-[#F6571F] group-hover:text-white",
        pink: "bg-pink-50 text-pink-600 group-hover:bg-[#F6571F] group-hover:text-white",
        red: "bg-red-50 text-red-600 group-hover:bg-[#F6571F] group-hover:text-white",
        rose: "bg-rose-50 text-rose-600 group-hover:bg-[#F6571F] group-hover:text-white",
        slate: "bg-slate-100 text-slate-600 group-hover:bg-[#F6571F] group-hover:text-white",
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
        >
            <Link
                href={`/features/${feature.slug}`}
                className="group block h-full p-8 bg-white rounded-2xl border border-slate-200 hover:border-[#F6571F]/30 hover:shadow-2xl transition-all duration-500"
            >
                <div
                    className={`w-12 h-12 rounded-xl ${colorClasses[feature.color]} flex items-center justify-center mb-5 transition-colors`}
                >
                    <Icon size={24} />
                </div>
                <h3 className="text-xl font-black text-slate-900 mb-3 group-hover:text-[#F6571F] transition-colors">
                    {feature.title}
                </h3>
                <p className="text-slate-500 text-sm leading-relaxed mb-6 font-medium">
                    {feature.description}
                </p>
                <div className="flex items-center text-sm font-bold text-[#F6571F]">
                    Explore feature
                    <ArrowRight
                        size={16}
                        className="ml-1.5 group-hover:translate-x-1 transition-transform"
                    />
                </div>
            </Link>
        </motion.div>
    );
};

// Features Grid by Category
const FeaturesGrid = () => (
    <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
            {featureCategories.map((category, categoryIndex) => (
                <div key={category.title} className="mb-16 last:mb-0">
                    <motion.h2
                        initial={{ opacity: 0, y: 10 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="text-2xl md:text-3xl font-bold text-slate-900 mb-8"
                    >
                        {category.title}
                    </motion.h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {category.features.map((slug, index) => {
                            const feature = featuresData[slug];
                            if (!feature) return null;
                            return (
                                <FeatureCard
                                    key={slug}
                                    feature={feature}
                                    index={categoryIndex * 3 + index}
                                />
                            );
                        })}
                    </div>
                </div>
            ))}
        </div>
    </section>
);

// Comparison Section
const ComparisonSection = () => (
    <section className="py-16 md:py-24 bg-slate-50">
        <div className="container mx-auto px-4">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="max-w-3xl mx-auto text-center mb-12"
            >
                <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                    Why teams choose Veblika
                </h2>
                <p className="text-lg text-slate-500">
                    Everything you need to manage social media at scale, without the complexity.
                </p>
            </motion.div>

            <div className="max-w-4xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {[
                        "All platforms in one place",
                        "AI-powered scheduling",
                        "Real-time analytics",
                        "Team collaboration tools",
                        "Unlimited post scheduling",
                        "White-label reports",
                        "Priority support",
                        "No per-seat pricing surprises",
                    ].map((item, index) => (
                        <motion.div
                            key={item}
                            initial={{ opacity: 0, x: -10 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.05 }}
                            className="flex items-center gap-3"
                        >
                            <div className="w-6 h-6 rounded-lg bg-[#FFF5F1] flex items-center justify-center">
                                <Check size={14} className="text-[#F6571F]" />
                            </div>
                            <span className="text-slate-700 font-medium">{item}</span>
                        </motion.div>
                    ))}
                </div>
            </div>
        </div>
    </section>
);

// Main Features Page
export default function FeaturesPage() {
    return (
        <>
            <FeaturesHero />
            <FeaturesGrid />
            <ComparisonSection />
        </>
    );
}
