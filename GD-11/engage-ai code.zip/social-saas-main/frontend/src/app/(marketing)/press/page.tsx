"use client";

import React from "react";
import Container from "@/components/homePage/container";

export default function PressPage() {
    return (
        <div className="pt-32 pb-24 min-h-screen">
            <Container>
                <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-8 tracking-tight">
                    Press <span className="text-[#F6571F]">Room</span>
                </h1>
                <p className="text-xl text-slate-500 mb-12 font-medium">
                    Latest news, updates, and brand assets from Veblika.
                </p>
                <div className="grid md:grid-cols-2 gap-8">
                    <div className="p-8 border border-slate-100 rounded-3xl bg-slate-50">
                        <h3 className="text-xl font-bold mb-4">Media Kit</h3>
                        <p className="text-slate-500 mb-6 font-medium">Download our official logos, brand guidelines, and executive headshots.</p>
                        <button className="text-[#F6571F] font-bold">Download Kit →</button>
                    </div>
                </div>
            </Container>
        </div>
    );
}
