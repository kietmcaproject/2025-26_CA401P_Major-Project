"use client";

import React, { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Check, ArrowRight, Sparkles } from "lucide-react";
import { useGetPublicResellerConfig } from "@/lib/queries/reseller-config";
import { useBranding } from "@/providers/branding-provider";

const defaultPricingPlans = [
    {
        name: "Starter",
        description: "Perfect for individuals and small teams getting started.",
        monthlyPrice: 29,
        yearlyPrice: 24,
        features: [
            "5 social profiles",
            "50 scheduled posts/month",
            "Basic analytics",
            "Social inbox",
            "1 user",
            "Email support",
        ],
        buttonText: "Start free trial",
        isPopular: false,
        displayText: null,
    },
    {
        name: "Professional",
        description: "For growing teams that need more power and collaboration.",
        monthlyPrice: 79,
        yearlyPrice: 66,
        features: [
            "15 social profiles",
            "Unlimited scheduled posts",
            "Advanced analytics",
            "Social inbox + assignment",
            "5 users",
            "Content library",
            "Approval workflows",
            "Priority support",
        ],
        buttonText: "Start free trial",
        isPopular: true,
        displayText: null,
    },
    {
        name: "Agency",
        description: "For agencies managing multiple brands and clients.",
        monthlyPrice: 199,
        yearlyPrice: 166,
        features: [
            "50 social profiles",
            "Unlimited everything",
            "White-label reports",
            "Client portals",
            "15 users",
            "Social listening",
            "Ad management",
            "Dedicated account manager",
        ],
        buttonText: "Start free trial",
        isPopular: false,
        displayText: null,
    },
    {
        name: "Enterprise",
        description: "Custom solutions for large organizations.",
        monthlyPrice: null,
        yearlyPrice: null,
        features: [
            "Unlimited social profiles",
            "Custom integrations",
            "SSO & advanced security",
            "Custom contracts",
            "Unlimited users",
            "SLA guarantee",
            "Onboarding & training",
            "24/7 phone support",
        ],
        buttonText: "Contact sales",
        isPopular: false,
        displayText: null,
    },
];

const getDefaultFaqs = (companyName: string) => [
    {
        question: `Can I try ${companyName} for free?`,
        answer: "Yes! All paid plans include a 14-day free trial. No credit card required to start.",
    },
    {
        question: "What happens after my trial ends?",
        answer: "You'll be prompted to select a plan. If you don't, your account will be downgraded to view-only mode. Your data is never deleted.",
    },
    {
        question: "Can I change plans later?",
        answer: "Absolutely. You can upgrade, downgrade, or cancel anytime. Changes take effect immediately with prorated billing.",
    },
    {
        question: "Do you offer discounts for nonprofits?",
        answer: "Yes! We offer 50% off for registered nonprofits and educational institutions. Contact us to learn more.",
    },
    {
        question: "What payment methods do you accept?",
        answer: "We accept all major credit cards, PayPal, and bank transfers for annual plans. Enterprise customers can pay via invoice.",
    },
];

export default function PricingPage() {
    const [isYearly, setIsYearly] = useState(true);
    const { data: config } = useGetPublicResellerConfig();
    const branding = useBranding();
    const currentCompanyName = branding.companyName || config?.companyName || "Veblika";

    // Use config data if available, otherwise fallback to default
    // We need to parse the price string from the config (e.g. "$29") to numbers for the toggle logic if we want to keep it exact,
    // OR we can just use the price string directly if the editor allows setting explicit monthly/yearly strings.
    // The Editor `PricingPlan` has a single `price` field (string) and `period` string.
    // The default plans have separate `monthlyPrice` and `yearlyPrice` numbers.
    //
    // Adapting logic: The Editor currently only has ONE price field. 
    // If we want to support the Monthly/Yearly toggle with 20% discount logic dynamically, we need to handle that.
    // For now, let's assume the Editor's price is the MONTHLY price, and we calculate the yearly price (20% off) automatically if not "Custom".

    const displayPlans = (config?.content?.pricing && config.content.pricing.length > 0)
        ? config.content.pricing.map(plan => {
            // Remove currency symbol and parse to number for calculation
            const numericPrice = parseFloat(plan.price.replace(/[^0-9.]/g, ''));
            const isCustom = isNaN(numericPrice);

            return {
                name: plan.name,
                description: plan.description,
                // Calculate prices. If it's a number, apply logic. If not (e.g. "Custom"), keep as is.
                monthlyPrice: isCustom ? null : numericPrice,
                yearlyPrice: isCustom ? null : Math.round(numericPrice * 0.8), // 20% off roughly
                displayText: isCustom ? plan.price : null,
                features: plan.features,
                buttonText: plan.buttonText,
                isPopular: plan.isPopular,
            }
        })
        : defaultPricingPlans;

    const displayFaqs = (config?.content?.faqs && config.content.faqs.length > 0)
        ? config.content.faqs
        : getDefaultFaqs(currentCompanyName);

    return (
        <>
            {/* Hero */}
            <section className="relative py-20 md:py-28 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-slate-50 to-white" />
                <div
                    className="absolute inset-0 opacity-[0.03]"
                    style={{
                        backgroundImage:
                            "linear-gradient(#1a365d 1px, transparent 1px), linear-gradient(90deg, #1a365d 1px, transparent 1px)",
                        backgroundSize: "40px 40px",
                    }}
                />

                <div className="container mx-auto px-4 relative z-10">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                        className="max-w-3xl mx-auto text-center"
                    >
                        <span className="inline-block text-sm font-black text-[#F6571F] bg-[#FFF5F1] px-4 py-1.5 rounded-full mb-6 border border-[#F6571F]/10 uppercase tracking-widest">
                            Simple, transparent pricing
                        </span>
                        <h1 className="text-4xl md:text-6xl font-black tracking-tight text-slate-900 leading-[1.1] mb-6">
                            Choose your plan
                        </h1>
                        <p className="text-lg md:text-xl text-slate-500 leading-relaxed mb-10">
                            Start free, scale as you grow. All plans include a 14-day trial.
                        </p>

                        {/* Billing Toggle */}
                        <div className="inline-flex items-center gap-4 bg-slate-100 p-1.5 rounded-full">
                            <button
                                onClick={() => setIsYearly(false)}
                                className={`px-6 py-2 rounded-full text-sm font-semibold transition-all ${!isYearly
                                    ? "bg-white text-slate-900 shadow-sm"
                                    : "text-slate-600"
                                    }`}
                            >
                                Monthly
                            </button>
                            <button
                                onClick={() => setIsYearly(true)}
                                className={`px-6 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-2 ${isYearly
                                    ? "bg-white text-slate-900 shadow-sm"
                                    : "text-slate-600"
                                    }`}
                            >
                                Yearly
                                <span className="text-xs bg-orange-100 text-[#F6571F] px-2 py-0.5 rounded-full font-bold">
                                    Save 20%
                                </span>
                            </button>
                        </div>
                    </motion.div>
                </div>
            </section>

            {/* Pricing Cards */}
            <section className="pb-16 md:pb-24 -mt-8">
                <div className="container mx-auto px-4">
                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
                        {displayPlans.map((plan, index) => (
                            <motion.div
                                key={plan.name}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.5, delay: index * 0.1 }}
                                className={`relative rounded-[2rem] p-8 transition-all duration-500 hover:shadow-2xl ${plan.isPopular
                                    ? "bg-slate-900 text-white ring-4 ring-[#F6571F]/20 scale-105 z-10"
                                    : "bg-white border border-slate-200 hover:border-[#F6571F]/20"
                                    }`}
                            >
                                {plan.isPopular && (
                                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                                        <span className="inline-flex items-center gap-1.5 bg-[#F6571F] text-white text-[10px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full shadow-lg">
                                            <Sparkles size={12} fill="currentColor" />
                                            Most Popular
                                        </span>
                                    </div>
                                )}

                                <div className="mb-6">
                                    <h3
                                        className={`text-xl font-bold mb-2 ${plan.isPopular ? "text-white" : "text-slate-900"
                                            }`}
                                    >
                                        {plan.name}
                                    </h3>
                                    <p
                                        className={`text-sm ${plan.isPopular ? "text-slate-400" : "text-slate-500"
                                            }`}
                                    >
                                        {plan.description}
                                    </p>
                                </div>

                                <div className="mb-6">
                                    {plan.monthlyPrice !== null ? (
                                        <>
                                            <span
                                                className={`text-4xl font-black ${plan.isPopular ? "text-white" : "text-slate-900"
                                                    }`}
                                            >
                                                ${isYearly ? plan.yearlyPrice : plan.monthlyPrice}
                                            </span>
                                            <span
                                                className={`text-sm ${plan.isPopular ? "text-slate-400" : "text-slate-500"
                                                    }`}
                                            >
                                                /month
                                            </span>
                                            {isYearly && (
                                                <p
                                                    className={`text-xs mt-1 ${plan.isPopular ? "text-slate-500" : "text-slate-400"
                                                        }`}
                                                >
                                                    billed annually
                                                </p>
                                            )}
                                        </>
                                    ) : (
                                        <span
                                            className={`text-3xl font-bold ${plan.isPopular ? "text-white" : "text-slate-900"
                                                }`}
                                        >
                                            {plan.displayText || "Custom"}
                                        </span>
                                    )}
                                </div>

                                <Button
                                    asChild
                                    className={`w-full h-14 text-lg font-black rounded-xl mb-8 transition-all active:scale-95 ${plan.isPopular
                                        ? "bg-[#F6571F] text-white hover:bg-[#E44D1B] shadow-lg shadow-[#F6571F]/20"
                                        : plan.name === "Enterprise"
                                            ? "bg-slate-900 text-white hover:bg-slate-800"
                                            : "bg-white border-2 border-slate-200 text-slate-900 hover:border-[#F6571F] hover:text-[#F6571F] hover:bg-[#FFF5F1]/30"
                                        }`}
                                >
                                    <Link href={plan.name === "Enterprise" ? "/contact" : "/signup"}>
                                        {plan.buttonText || "Start free trial"}
                                    </Link>
                                </Button>

                                <ul className="space-y-3">
                                    {plan.features.map((feature) => (
                                        <li key={feature} className="flex items-start gap-3">
                                            <Check
                                                size={18}
                                                className={`flex-shrink-0 mt-0.5 ${plan.isPopular ? "text-green-400" : "text-green-600"
                                                    }`}
                                            />
                                            <span
                                                className={`text-sm ${plan.isPopular ? "text-slate-300" : "text-slate-600"
                                                    }`}
                                            >
                                                {feature}
                                            </span>
                                        </li>
                                    ))}
                                </ul>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* FAQ Section */}
            <section className="py-16 md:py-24 bg-slate-50">
                <div className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="max-w-3xl mx-auto"
                    >
                        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-12">
                            Frequently asked questions
                        </h2>

                        <div className="space-y-6">
                            {displayFaqs.map((faq, index) => (
                                <motion.div
                                    key={faq.question}
                                    initial={{ opacity: 0, y: 10 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: index * 0.05 }}
                                    className="bg-white rounded-xl p-6 border border-slate-200"
                                >
                                    <h3 className="text-lg font-semibold text-slate-900 mb-2">
                                        {faq.question}
                                    </h3>
                                    <p className="text-slate-500 leading-relaxed">{faq.answer}</p>
                                </motion.div>
                            ))}
                        </div>

                        <div className="text-center mt-12">
                            <p className="text-slate-500 mb-4">
                                Have more questions?
                            </p>
                            <Link
                                href="/contact"
                                className="text-[#F6571F] hover:text-[#E44D1B] font-black text-lg underline underline-offset-8 decoration-[#F6571F]/30 hover:decoration-[#F6571F]"
                            >
                                Contact our sales team
                            </Link>
                        </div>
                    </motion.div>
                </div>
            </section>
        </>
    );
}
