"use client";
import React from "react";
import Container from "@/components/homePage/container";
import { useBranding } from "@/providers/branding-provider";

export default function PrivacyPage() {
    const branding = useBranding();
    const customContent = branding.content?.privacyPolicy;
    const { companyName } = branding;
    const contact = branding.content?.contact || branding.contact;
    const lastUpdated = "January 23, 2026";

    if (customContent) {
        return (
            <div className="pt-32 pb-24 min-h-screen">
                <Container className="max-w-4xl">
                    <div className="mb-12">
                        <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-4 tracking-tight">
                            Privacy <span className="text-[#F6571F]">Policy</span>
                        </h1>
                        <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">
                            Last Updated: {lastUpdated}
                        </p>
                    </div>
                    <div
                        className="prose prose-slate prose-lg max-w-none prose-headings:font-black prose-headings:text-slate-900 prose-p:text-slate-600 prose-p:leading-relaxed prose-strong:text-slate-900 prose-strong:font-bold"
                        dangerouslySetInnerHTML={{ __html: customContent }}
                    />
                </Container>
            </div>
        );
    }

    // Default Privacy Policy
    const displayName = companyName || "Veblika";
    const email = contact?.email || "care@veblika.in";
    const address = contact?.address || "Noida, Uttar Pradesh, India";

    return (
        <div className="pt-32 pb-24 min-h-screen">
            <Container className="max-w-4xl">
                <div className="mb-12">
                    <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-4 tracking-tight">
                        Privacy <span className="text-[#F6571F]">Policy</span>
                    </h1>
                    <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">
                        Last Updated: {lastUpdated}
                    </p>
                </div>

                <div className="prose prose-slate prose-lg max-w-none prose-headings:font-black prose-headings:text-slate-900 prose-p:text-slate-600 prose-p:leading-relaxed prose-strong:text-slate-900 prose-strong:font-bold">
                    <p>
                        At {displayName}, also referred to as "we," "us," or "our," we are committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.
                    </p>

                    <h2>1. Information We Collect</h2>
                    <p>
                        We may collect personal information that you voluntarily provide to us when you:
                    </p>
                    <ul>
                        <li>Register for an account or sign up for our newsletter.</li>
                        <li>Submit inquiries through our contact forms.</li>
                        <li>Process payments or subscribe to our service plans.</li>
                        <li>Interact with our support team or provide feedback.</li>
                    </ul>
                    <p>
                        This information may include your name, email address, phone number, billing information, and social media handles.
                    </p>

                    <h2>2. How We Use Your Information</h2>
                    <p>
                        We use the collected information for various purposes, including:
                    </p>
                    <ul>
                        <li>Providing, maintaining, and improving our services.</li>
                        <li>Processing transactions and sending related information.</li>
                        <li>Responding to your comments, questions, and requests.</li>
                        <li>Communicating with you about products, services, and events.</li>
                        <li>Monitoring and analyzing trends, usage, and activities.</li>
                        <li>Detecting and preventing fraudulent transactions.</li>
                    </ul>

                    <h2>3. Cookies and Tracking Technologies</h2>
                    <p>
                        We use cookies and similar tracking technologies to track activity on our website and hold certain information. Cookies are files with small amounts of data that are stored on your device. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.
                    </p>

                    <h2>4. Data Sharing and Disclosure</h2>
                    <p>
                        We do not sell or rent your personal information to third parties. We may share your information with third-party vendors and service providers who perform services for us, provided they are bound by confidentiality agreements.
                    </p>

                    <h2>5. Data Security</h2>
                    <p>
                        We implement industry-standard security measures to protect the security of your personal information. However, no method of transmission over the internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
                    </p>

                    <h2>6. Your Data Rights</h2>
                    <p>
                        Depending on your location, you may have certain rights regarding your personal data, including the right to access, correct, or delete the information we hold about you. Please contact us at {email} to exercise these rights.
                    </p>

                    <h2>7. Changes to This Policy</h2>
                    <p>
                        We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.
                    </p>

                    <h2>8. Contact Us</h2>
                    <p>
                        If you have any questions about this Privacy Policy, please contact us at:
                    </p>
                    <div className="bg-slate-50 p-8 rounded-2xl border border-slate-100 mt-6 font-medium text-slate-700">
                        <p className="m-0"><strong>{displayName}</strong></p>
                        <p className="m-0">Email: {email}</p>
                        <p className="m-0">{address}</p>
                    </div>
                </div>
            </Container>
        </div>
    );
}

