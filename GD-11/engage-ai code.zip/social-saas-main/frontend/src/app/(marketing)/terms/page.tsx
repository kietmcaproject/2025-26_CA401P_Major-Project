"use client";

import React from "react";
import Container from "@/components/homePage/container";
import { useBranding } from "@/providers/branding-provider";

export default function TermsPage() {
    const branding = useBranding();
    const customContent = branding.content?.termsOfService;
    const { companyName } = branding;
    const contact = branding.content?.contact || branding.contact;
    const lastUpdated = "January 23, 2026";

    // If custom content is provided, render it
    if (customContent) {
        return (
            <div className="pt-32 pb-24 min-h-screen">
                <Container className="max-w-4xl">
                    <div className="mb-12">
                        <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-4 tracking-tight">
                            Terms of <span className="text-[#F6571F]">Service</span>
                        </h1>
                        <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">
                            Last Updated: {lastUpdated}
                        </p>
                    </div>
                    <div
                        className="prose prose-slate prose-lg max-w-none prose-headings:font-black prose-headings:text-slate-900 prose-p:text-slate-600 prose-p:leading-relaxed prose-strong:text-slate-900 prose-strong:font-bold"
                        dangerouslySetInnerHTML={{ __html: customContent }}
                    />
                </Container>
            </div>
        );
    }

    // Default Terms of Service
    const displayName = companyName || "Veblika";
    const email = contact?.email || "care@veblika.com";
    const address = contact?.address || "Noida, Uttar Pradesh, India";

    return (
        <div className="pt-32 pb-24 min-h-screen">
            <Container className="max-w-4xl">
                <div className="mb-12">
                    <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-4 tracking-tight">
                        Terms of <span className="text-[#F6571F]">Service</span>
                    </h1>
                    <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">
                        Last Updated: {lastUpdated}
                    </p>
                </div>

                <div className="prose prose-slate prose-lg max-w-none prose-headings:font-black prose-headings:text-slate-900 prose-p:text-slate-600 prose-p:leading-relaxed prose-strong:text-slate-900 prose-strong:font-bold">
                    <p>
                        Welcome to {displayName}. By accessing our website or using our services, you agree to be bound by these Terms of Service. Please read them carefully.
                    </p>

                    <h2>1. Agreement to Terms</h2>
                    <p>
                        By using {displayName}, you confirm that you have read, understood, and agreed to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you must not use our services.
                    </p>

                    <h2>2. Description of Service</h2>
                    <p>
                        {displayName} provides a social media management platform and digital agency services, including web development and design. We reserve the right to modify, suspend, or discontinue any aspect of the service at any time without prior notice.
                    </p>

                    <h2>3. User Accounts</h2>
                    <p>
                        To access certain features, you must register for an account. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You must notify us immediately of any unauthorized use of your account.
                    </p>

                    <h2>4. Fees and Payment</h2>
                    <p>
                        Certain services are provided for a fee. You agree to pay all applicable fees as described on the website. All fees are non-refundable unless otherwise stated. We reserve the right to change our pricing at any time.
                    </p>

                    <h2>5. Intellectual Property</h2>
                    <p>
                        All content, features, and functionality on the website, including text, graphics, logos, and software, are the exclusive property of {displayName} and are protected by international copyright, trademark, and other intellectual property laws.
                    </p>

                    <h2>6. Prohibited Activities</h2>
                    <p>
                        You agree not to use our services for any unlawful purpose or in any way that violates these Terms. Prohibited activities include, but are not limited to:
                    </p>
                    <ul>
                        <li>Interfering with the security or integrity of our systems.</li>
                        <li>Using our service to distribute malware or spam.</li>
                        <li>Attempting to gain unauthorized access to other accounts.</li>
                        <li>Reverse engineering or copying our platform's code.</li>
                    </ul>

                    <h2>7. Limitation of Liability</h2>
                    <p>
                        To the maximum extent permitted by law, {displayName} shall not be liable for any indirect, incidental, special, or consequential damages resulting from the use of or inability to use our services.
                    </p>

                    <h2>8. Termination</h2>
                    <p>
                        We may terminate or suspend your account and access to our services immediately, without prior notice, for conduct that we believe violates these Terms or is harmful to other users or our business interests.
                    </p>

                    <h2>9. Governing Law</h2>
                    <p>
                        These Terms shall be governed by and construed in accordance with the laws of India, without regard to its conflict of law provisions.
                    </p>

                    <h2>10. Contact Us</h2>
                    <p>
                        If you have any questions regarding these Terms, please reach out to us:
                    </p>
                    <div className="bg-slate-50 p-8 rounded-2xl border border-slate-100 mt-6 font-medium text-slate-700">
                        <p className="m-0"><strong>{displayName}</strong></p>
                        <p className="m-0">Email: {email}</p>
                        <p className="m-0">{address}</p>
                    </div>
                </div>
            </Container>
        </div>
    );
}

