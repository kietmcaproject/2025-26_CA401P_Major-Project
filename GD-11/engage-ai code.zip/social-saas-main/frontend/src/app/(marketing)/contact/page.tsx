"use client";

import React from "react";
import { motion } from "framer-motion";
import { MapPin, Phone, Mail, Send, MessageSquare, Clock } from "lucide-react";
import Container from "@/components/homePage/container";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useBranding } from "@/providers/branding-provider";
import { toast } from "sonner";

export default function ContactPage() {
    const branding = useBranding();
    const contact = branding.content?.contact || branding.contact;
    const contactPhone = contact?.phone || "+91 7599808080";
    const contactEmail = contact?.email || "care@veblika.com";
    const contactAddress = contact?.address || `${branding.companyName || "Veblika"} (Brainvibs Technologies Pvt Ltd.) Metro Gate NO. 2, S-2, 2nd floor, Savitri Market Complex, Noida Sector 18 Metro Station, Noida, Uttar Pradesh 201301`;
    const [isSubmitting, setIsSubmitting] = React.useState(false);
    const [formData, setFormData] = React.useState({
        name: "",
        email: "",
        subject: "",
        message: ""
    });

    // Dynamic contact info based on branding
    const contactInfo = React.useMemo(() => [
        {
            title: "Visit Us",
            details: contactAddress,
            icon: MapPin,
            action: "Get Directions",
            link: "https://goo.gl/maps/example"
        },
        {
            title: "Call Us",
            details: contactPhone,
            icon: Phone,
            action: "Call Now",
            link: `tel:${contactPhone.replace(/\s/g, "")}`
        },
        {
            title: "Email Us",
            details: contactEmail,
            icon: Mail,
            action: "Send Email",
            link: `mailto:${contactEmail}`
        },
    ], [contactAddress, contactEmail, contactPhone]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!formData.name || !formData.email || !formData.message) {
            toast.error("Please fill in all required fields.");
            return;
        }

        setIsSubmitting(true);
        try {
            const response = await fetch("/api/contact", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                toast.success(`Thank you! Your message has been sent to ${contactEmail}.`);
                setFormData({ name: "", email: "", subject: "", message: "" });
            } else {
                toast.error("Something went wrong. Please try again later.");
            }
        } catch (error) {
            toast.error("Connection error. Please check your internet.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { id, value } = e.target;
        // In the original code, id wasn't set on inputs, so let's name them.
        // I'll update the inputs below as well.
    };

    return (
        <div className="pt-20 pb-24">
            {/* Hero Section */}
            <section className="relative py-20 md:py-32 bg-white overflow-hidden">
                <div className="absolute inset-0 z-0 pointer-events-none opacity-100">
                    <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-[#F6571F]/15 blur-[120px] rounded-full mix-blend-multiply filter animate-pulse" />
                    <div className="absolute bottom-[0%] right-[-10%] w-[50%] h-[50%] bg-[#FF8A5B]/10 blur-[100px] rounded-full mix-blend-multiply filter" />
                </div>
                <div
                    className="absolute inset-0 opacity-[0.04]"
                    style={{
                        backgroundImage: 'linear-gradient(#F6571F 1px, transparent 1px), linear-gradient(90deg, #F6571F 1px, transparent 1px)',
                        backgroundSize: '40px 40px',
                    }}
                />
                <Container className="text-center relative z-10">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.5 }}
                    >
                        <h1 className="text-5xl md:text-7xl font-black text-slate-900 tracking-tight mb-8">
                            Get in <span className="text-[#F6571F]">Touch</span>
                        </h1>
                        <p className="text-xl text-slate-500 max-w-2xl mx-auto font-medium">
                            Have questions or ready to start your next project? We're here to help you navigate the digital landscape.
                        </p>
                    </motion.div>
                </Container>
            </section>

            <section className="py-24">
                <Container>
                    <div className="grid lg:grid-cols-12 gap-16">
                        {/* Contact Form */}
                        <motion.div
                            initial={{ opacity: 0, x: -20 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            className="lg:col-span-7 bg-white p-8 md:p-12 rounded-[2.5rem] border border-slate-100 shadow-2xl shadow-slate-200/50"
                        >
                            <h2 className="text-3xl font-black text-slate-900 mb-8 flex items-center gap-4">
                                Send us a message <MessageSquare className="text-[#F6571F]" />
                            </h2>
                            <form className="space-y-6" onSubmit={handleSubmit}>
                                <div className="grid md:grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-sm font-bold text-slate-700 ml-4">Full Name</label>
                                        <Input
                                            placeholder="John Doe"
                                            value={formData.name}
                                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                            className="h-14 rounded-2xl border-slate-200 focus:border-[#F6571F] focus:ring-[#F6571F]/10 px-6"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-sm font-bold text-slate-700 ml-4">Email Address</label>
                                        <Input
                                            type="email"
                                            placeholder="john@example.com"
                                            value={formData.email}
                                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                            className="h-14 rounded-2xl border-slate-200 focus:border-[#F6571F] focus:ring-[#F6571F]/10 px-6"
                                        />
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-bold text-slate-700 ml-4">Subject</label>
                                    <Input
                                        placeholder="Project Inquiry"
                                        value={formData.subject}
                                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                                        className="h-14 rounded-2xl border-slate-200 focus:border-[#F6571F] focus:ring-[#F6571F]/10 px-6"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-bold text-slate-700 ml-4">Your Message</label>
                                    <Textarea
                                        placeholder="Tell us about your project..."
                                        value={formData.message}
                                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                                        className="min-h-[160px] rounded-3xl border-slate-200 focus:border-[#F6571F] focus:ring-[#F6571F]/10 p-6"
                                    />
                                </div>
                                <Button
                                    disabled={isSubmitting}
                                    className="w-full h-14 rounded-2xl bg-[#F6571F] hover:bg-[#E44D1B] text-white font-black text-lg shadow-xl shadow-[#F6571F]/20 transition-all hover:scale-[1.02] active:scale-95 border-0"
                                >
                                    {isSubmitting ? "Sending..." : "Send Message"} <Send size={20} className="ml-2" />
                                </Button>
                            </form>
                        </motion.div>

                        {/* Contact Info */}
                        <div className="lg:col-span-5 space-y-6">
                            {contactInfo.map((info, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, x: 20 }}
                                    whileInView={{ opacity: 1, x: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: idx * 0.1 }}
                                    className="p-8 rounded-[2rem] bg-slate-50 border border-slate-100 hover:bg-white hover:shadow-xl transition-all group"
                                >
                                    <div className="flex items-start gap-6">
                                        <div className="w-14 h-14 rounded-2xl bg-white text-[#F6571F] flex items-center justify-center shadow-lg group-hover:bg-[#F6571F] group-hover:text-white transition-all duration-300">
                                            <info.icon size={24} />
                                        </div>
                                        <div className="flex-1">
                                            <h3 className="text-xl font-black text-slate-900 mb-2">{info.title}</h3>
                                            <p className="text-slate-500 font-medium leading-relaxed mb-4">{info.details}</p>
                                            <a
                                                href={info.link}
                                                className="text-[#F6571F] font-black text-sm uppercase tracking-wider hover:underline underline-offset-4"
                                            >
                                                {info.action} →
                                            </a>
                                        </div>
                                    </div>
                                </motion.div>
                            ))}

                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                className="p-8 rounded-[2rem] bg-slate-900 text-white"
                            >
                                <div className="flex items-center gap-4 mb-4 font-black">
                                    <Clock className="text-[#F6571F]" />
                                    <span>Support Hours</span>
                                </div>
                                <div className="space-y-2 text-slate-400 font-medium text-sm">
                                    <div className="flex justify-between">
                                        <span>Monday - Friday</span>
                                        <span className="text-white">10:00 AM - 7:00 PM</span>
                                    </div>
                                    <div className="flex justify-between border-t border-white/10 pt-2">
                                        <span>Saturday</span>
                                        <span className="text-white">10:00 AM - 4:00 PM</span>
                                    </div>
                                    <div className="flex justify-between border-t border-white/10 pt-2 font-bold text-[#F6571F]">
                                        <span>Sunday</span>
                                        <span>Emergency Support Only</span>
                                    </div>
                                </div>
                            </motion.div>
                        </div>
                    </div>
                </Container>
            </section>
        </div>
    );
}
