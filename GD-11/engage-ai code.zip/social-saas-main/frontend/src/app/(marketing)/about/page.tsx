"use client";

import React from "react";
import { motion } from "framer-motion";
import { Users, Target, Rocket, Award, CheckCircle2, Globe2 } from "lucide-react";
import Container from "@/components/homePage/container";
import { useBranding } from "@/providers/branding-provider";

export default function AboutPage() {
    const branding = useBranding();
    const aboutContent = branding.content?.aboutPage;

    // Icon mapping for stats
    const iconMap: Record<string, React.ComponentType<{ size?: number }>> = {
        Users, Rocket, Globe2, Award, Target
    };

    const defaultStats = [
        { label: "Highly Qualified Professionals", value: "50+", icon: "Users" },
        { label: "Successful Projects", value: "100+", icon: "Rocket" },
        { label: "Industries Served", value: "12+", icon: "Globe2" },
        { label: "Years of Excellence", value: "2+", icon: "Award" },
    ];

    const stats = aboutContent?.stats?.length ? aboutContent.stats : defaultStats;

    const defaultIndustries = [
        "Education", "Healthcare", "Banking", "Hospitality",
        "Entertainment", "eCommerce", "Travel", "Fintech"
    ];

    const industries = aboutContent?.industries?.length ? aboutContent.industries : defaultIndustries;

    return (
        <div className="pt-20 pb-24 overflow-hidden">
            {/* Hero Section */}
            <section className="relative py-20 md:py-32 bg-slate-50/50">
                <div className="absolute inset-0 z-0 pointer-events-none opacity-100">
                    <div className="absolute top-[-20%] right-[-10%] w-[60%] h-[60%] bg-[#F6571F]/15 blur-[120px] rounded-full mix-blend-multiply filter animate-pulse" />
                    <div className="absolute bottom-[10%] left-[-10%] w-[50%] h-[50%] bg-[#FF8A5B]/10 blur-[100px] rounded-full mix-blend-multiply filter" />
                </div>
                <div
                    className="absolute inset-0 opacity-[0.06]"
                    style={{
                        backgroundImage: 'linear-gradient(#F6571F 1px, transparent 1px), linear-gradient(90deg, #F6571F 1px, transparent 1px)',
                        backgroundSize: '40px 40px'
                    }}
                />

                <Container className="relative z-10 text-center">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                    >
                        <span className="inline-block text-sm font-black text-[#F6571F] bg-[#FFF5F1] px-4 py-1.5 rounded-full mb-6 border border-[#F6571F]/10 uppercase tracking-widest">
                            {aboutContent?.tagline || "Established 2023"}
                        </span>
                        <h1 className="text-5xl md:text-7xl font-black tracking-tight text-slate-900 leading-[1.1] mb-8">
                            {branding.content?.about?.title || "We are"} <span className="text-[#F6571F]">{branding.companyName || "Veblika"}</span>
                        </h1>
                        <p className="text-xl md:text-2xl text-slate-500 max-w-3xl mx-auto leading-relaxed font-medium">
                            {branding.content?.about?.description || "Digitally emerging with a squad of 50+ highly qualified professionals, aiming to provide extension and quality assurance to help your business reach the next level."}
                        </p>
                    </motion.div>
                </Container>
            </section>

            {/* Story Section */}
            <section className="py-24">
                <Container>
                    <div className="grid lg:grid-cols-2 gap-16 items-center">
                        <motion.div
                            initial={{ opacity: 0, x: -30 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.8 }}
                        >
                            <h2 className="text-4xl font-black text-slate-900 mb-6 tracking-tight">
                                {aboutContent?.headline || "Our Story & Vision"}
                            </h2>
                            <div className="space-y-6 text-lg text-slate-600 font-medium leading-relaxed">
                                {aboutContent?.story ? (
                                    <p className="whitespace-pre-line">{aboutContent.story}</p>
                                ) : (
                                    <>
                                        <p>
                                            Veblika, Veblika Care, and Veblika Support represent the same company.
                                            Since our establishment in 2023, we have focused on one thing:
                                            excellence in the digital landscape.
                                        </p>
                                        <p>
                                            We are trusted for our proficiency in innovative design and web application development.
                                            Our team isn't just a workforce; it's a squad of highly trained specialists dedicated to
                                            transforming ideas into high-impact digital solutions.
                                        </p>
                                        <p>
                                            With a delivered portfolio of 100+ projects across the country, we have proven our
                                            versatility and commitment to quality in every sector we touch.
                                        </p>
                                    </>
                                )}
                            </div>
                        </motion.div>

                        <motion.div
                            initial={{ opacity: 0, scale: 0.9 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            className="grid grid-cols-2 gap-4"
                        >
                            {stats.map((stat, idx) => (
                                <div
                                    key={idx}
                                    className="p-8 rounded-[2rem] bg-white border border-slate-100 shadow-xl shadow-slate-200/50 hover:border-[#F6571F]/20 transition-all group"
                                >
                                    <div className="w-12 h-12 rounded-2xl bg-[#FFF5F1] text-[#F6571F] flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                                        {React.createElement(iconMap[stat.icon || "Users"] || Users, { size: 24 })}
                                    </div>
                                    <div className="text-3xl font-black text-slate-900 mb-1">{stat.value}</div>
                                    <div className="text-sm font-bold text-slate-500 uppercase tracking-wider">{stat.label}</div>
                                </div>
                            ))}
                        </motion.div>
                    </div>
                </Container>
            </section>

            {/* Industries Section */}
            <section className="py-24 bg-slate-900 rounded-[3rem] mx-4 overflow-hidden relative">
                <div className="absolute top-0 right-0 w-96 h-96 bg-[#F6571F] blur-[150px] opacity-10" />
                <Container className="relative z-10">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl font-black text-white mb-6">Industries We've Empowered</h2>
                        <p className="text-slate-400 text-lg font-medium max-w-2xl mx-auto">
                            Our cross-industry expertise allows us to deliver tailored solutions that meet unique business challenges.
                        </p>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                        {industries.map((industry, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.1 }}
                                viewport={{ once: true }}
                                className="flex items-center gap-4 bg-white/5 border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-all group"
                            >
                                <CheckCircle2 className="text-[#F6571F] group-hover:scale-125 transition-transform" size={20} />
                                <span className="text-white font-bold">{industry}</span>
                            </motion.div>
                        ))}
                    </div>
                </Container>
            </section>
        </div>
    );
}
