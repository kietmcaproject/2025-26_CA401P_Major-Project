import React from "react";
import MarketingNavbar from "@/components/marketing/navbar";
import MarketingFooter from "@/components/marketing/footer";

export const metadata = {
    title: "Veblika - Social Media Management Platform",
    description: "The all-in-one social media management platform. Schedule, publish, analyze, and engage across all your social channels.",
};

export default function MarketingLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <div className="min-h-screen flex flex-col bg-white">
            <MarketingNavbar />
            <main className="flex-1">{children}</main>
            <MarketingFooter />
        </div>
    );
}
