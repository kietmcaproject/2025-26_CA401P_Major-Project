"use client";

import React from "react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Search, HelpCircle, Book, MessageCircle } from "lucide-react";

export default function HelpCenterPage() {
    const categories = [
        { icon: Book, title: "Getting Started", description: "Account setup, onboarding, and basics." },
        { icon: MessageCircle, title: "Publishing", description: "Scheduling, creating posts, and calendar." },
        { icon: HelpCircle, title: "Analytics", description: "Reports, metrics, and data export." },
        { icon: HelpCircle, title: "Account & Billing", description: "Plans, invoices, and team management." },
    ];

    return (
        <div className="py-20 md:py-28">
            <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto text-center mb-16">
                    <Badge variant="secondary" className="mb-4 bg-purple-50 text-purple-700 border-purple-100">
                        Help Center
                    </Badge>
                    <h1 className="text-4xl md:text-5xl font-black tracking-tight text-slate-900 mb-6">
                        How can we help?
                    </h1>
                    <div className="relative max-w-xl mx-auto">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                        <Input
                            type="text"
                            placeholder="Search for articles..."
                            className="pl-12 h-14 rounded-full text-base shadow-lg shadow-slate-200/50 border-slate-200"
                        />
                    </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
                    {categories.map((cat, idx) => (
                        <div key={idx} className="p-8 rounded-2xl border border-slate-200 hover:border-blue-200 hover:shadow-lg transition-all cursor-pointer bg-white">
                            <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
                                <cat.icon size={24} />
                            </div>
                            <h3 className="text-xl font-bold text-slate-900 mb-2">{cat.title}</h3>
                            <p className="text-slate-500">{cat.description}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
