"use client";

import React from "react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, ArrowRight } from "lucide-react";

export default function BlogPage() {
    const posts = [
        {
            title: "10 Social Media Trends to Watch in 2026",
            excerpt: "Discover the emerging trends that will shape the social media landscape this year.",
            category: "Trends",
            date: "Oct 24, 2025",
            readTime: "5 min read",
        },
        {
            title: "How to Build a Social Media Strategy from Scratch",
            excerpt: "A comprehensive guide to creating a winning strategy for your brand.",
            category: "Strategy",
            date: "Oct 20, 2025",
            readTime: "8 min read",
        },
        {
            title: "The Ultimate Guide to Instagram Reels",
            excerpt: "Learn how to create engaging Reels that drive reach and follower growth.",
            category: "Guides",
            date: "Oct 15, 2025",
            readTime: "6 min read",
        },
    ];

    return (
        <div className="py-20 md:py-28">
            <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto text-center mb-16">
                    <Badge variant="secondary" className="mb-4 bg-blue-50 text-blue-700 border-blue-100">
                        Blog
                    </Badge>
                    <h1 className="text-4xl md:text-5xl font-black tracking-tight text-slate-900 mb-6">
                        Insights & Ideas
                    </h1>
                    <p className="text-xl text-slate-500">
                        Latest news, tips, and strategies for social media success.
                    </p>
                </div>

                <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                    {posts.map((post, idx) => (
                        <div key={idx} className="group cursor-pointer">
                            <div className="aspect-[16/9] bg-slate-100 rounded-2xl mb-6 overflow-hidden">
                                <div className="w-full h-full bg-slate-200 group-hover:scale-105 transition-transform duration-500" />
                            </div>
                            <div className="flex items-center gap-3 text-sm text-slate-500 mb-3">
                                <span className="font-semibold text-blue-600">{post.category}</span>
                                <span>•</span>
                                <span>{post.date}</span>
                            </div>
                            <h3 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
                                {post.title}
                            </h3>
                            <p className="text-slate-500 leading-relaxed mb-4">
                                {post.excerpt}
                            </p>
                            <div className="flex items-center text-sm font-medium text-slate-900">
                                Read article <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
