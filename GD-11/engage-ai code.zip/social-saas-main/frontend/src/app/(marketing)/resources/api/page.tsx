"use client";

import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileCode, ArrowRight, Terminal } from "lucide-react";

export default function ApiDocsPage() {
    return (
        <div className="py-20 md:py-28">
            <div className="container mx-auto px-4">
                <div className="grid lg:grid-cols-2 gap-12 items-center">
                    <div>
                        <Badge variant="secondary" className="mb-4 bg-cyan-50 text-cyan-700 border-cyan-100">
                            Developers
                        </Badge>
                        <h1 className="text-4xl md:text-5xl font-black tracking-tight text-slate-900 mb-6">
                            Build with Veblika API
                        </h1>
                        <p className="text-xl text-slate-500 mb-8 leading-relaxed">
                            Integrate social media publishing and analytics directly into your application.
                            Powerful, flexible, and developer-friendly.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-4">
                            <Button size="lg" className="rounded-full bg-slate-900 hover:bg-slate-800">
                                Read Documentation
                                <ArrowRight className="w-4 h-4 ml-2" />
                            </Button>
                            <Button variant="outline" size="lg" className="rounded-full">
                                Get API Key
                            </Button>
                        </div>
                    </div>

                    <div className="relative">
                        <div className="rounded-xl bg-slate-900 p-6 shadow-2xl font-mono text-sm leading-relaxed text-slate-300">
                            <div className="flex items-center gap-2 mb-4 border-b border-slate-700 pb-4">
                                <div className="w-3 h-3 rounded-full bg-red-500" />
                                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                                <div className="w-3 h-3 rounded-full bg-green-500" />
                                <span className="ml-2 text-xs text-slate-500">bash</span>
                            </div>
                            <p className="mb-2">
                                <span className="text-purple-400">curl</span> https://api.veblika.com/v1/posts \
                            </p>
                            <p className="mb-2 pl-4">
                                -H <span className="text-green-400">"Authorization: Bearer YOUR_API_KEY"</span> \
                            </p>
                            <p className="mb-2 pl-4">
                                -d <span className="text-yellow-400">{`'{"content": "Hello World", "platforms": ["twitter"] }'`}</span>
                            </p>
                            <p className="mt-4 text-slate-500"># Output</p>
                            <p className="text-blue-400">
                                {`{
  "id": "post_123456",
  "status": "scheduled",
  "scheduled_at": "2026-01-21T18:00:00Z"
}`}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
