import React from "react";
import Container from "@/components/homePage/container";

export default function SecurityPage() {
    return (
        <div className="pt-32 pb-24 min-h-screen">
            <Container className="max-w-4xl">
                <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-8 tracking-tight">
                    Security at <span className="text-[#F6571F]">Veblika</span>
                </h1>
                <div className="prose prose-slate prose-lg max-w-none">
                    <p>Security is at the heart of everything we do. We employ industry-leading protocols to ensure your social media data and credentials remain safe.</p>
                    <h2>Data Encryption</h2>
                    <p>All data transmitted to and from Veblika is encrypted using SSL/TLS protocols.</p>
                    <h2>Secure Infrastructure</h2>
                    <p>Our infrastructure is hosted on secure cloud providers with advanced physical and digital security measures.</p>
                </div>
            </Container>
        </div>
    );
}
