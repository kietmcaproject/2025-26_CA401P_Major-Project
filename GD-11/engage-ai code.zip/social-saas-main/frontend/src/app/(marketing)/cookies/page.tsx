import React from "react";
import Container from "@/components/homePage/container";

export default function CookiesPage() {
    return (
        <div className="pt-32 pb-24 min-h-screen">
            <Container className="max-w-4xl">
                <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-8 tracking-tight">
                    Cookie <span className="text-[#F6571F]">Policy</span>
                </h1>
                <div className="prose prose-slate prose-lg max-w-none">
                    <p>This Cookie Policy explains how Veblika uses cookies and similar technologies to recognize you when you visit our website.</p>
                    <h2>What are cookies?</h2>
                    <p>Cookies are small data files that are placed on your computer or mobile device when you visit a website. Cookies are widely used by website owners in order to make their websites work, or to work more efficiently, as well as to provide reporting information.</p>
                    <h2>Why do we use cookies?</h2>
                    <p>We use first-party and third-party cookies for several reasons. Some cookies are required for technical reasons in order for our website to operate, and we refer to these as "essential" or "strictly necessary" cookies.</p>
                </div>
            </Container>
        </div>
    );
}
