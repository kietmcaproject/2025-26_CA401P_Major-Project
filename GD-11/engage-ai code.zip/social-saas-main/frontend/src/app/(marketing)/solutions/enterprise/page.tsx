"use client";

import React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import {
    ArrowRight,
    Check,
    Shield,
    Lock,
    Server,
    Users,
    FileCheck,
    Headphones,
} from "lucide-react";

const benefits = [
    {
        icon: Shield,
        title: "Enterprise-grade security",
        description: "SSO, 2FA, and SOC 2 compliance to keep your data safe.",
    },
    {
        icon: Lock,
        title: "Advanced permissions",
        description: "Granular role-based access control for large teams.",
    },
    {
        icon: Server,
        title: "Custom integrations",
        description: "API access and custom integrations with your existing stack.",
    },
    {
        icon: Users,
        title: "Unlimited users",
        description: "Add your entire team without per-seat pricing surprises.",
    },
    {
        icon: FileCheck,
        title: "Compliance workflows",
        description: "Built-in approval processes for regulated industries.",
    },
    {
        icon: Headphones,
        title: "Dedicated support",
        description: "24/7 priority support with a dedicated account manager.",
    },
];

export default function EnterprisePage() {
    return (
        <>
            {/* Hero */}
            <section className="relative py-20 md:py-28 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-purple-50 to-white" />
                <div
                    className="absolute inset-0 opacity-[0.03]"
                    style={{
                        backgroundImage:
                            "linear-gradient(#1a365d 1px, transparent 1px), linear-gradient(90deg, #1a365d 1px, transparent 1px)",
                        backgroundSize: "40px 40px",
                    }}
                />

                <div className="container mx-auto px-4 relative z-10">
                    <div className="grid lg:grid-cols-2 gap-12 items-center">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6 }}
                        >
                            <span className="inline-flex items-center gap-2 text-sm font-semibold text-purple-600 bg-purple-100 px-4 py-1.5 rounded-full mb-6">
                                <Shield size={16} />
                                For Enterprise
                            </span>
                            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-slate-900 leading-[1.1] mb-6">
                                Social at enterprise scale
                            </h1>
                            <p className="text-lg md:text-xl text-slate-500 leading-relaxed mb-8">
                                Deploy Veblika across your entire organization with the security, control, and support large teams require.
                            </p>
                            <div className="flex flex-col sm:flex-row items-start gap-4">
                                <Button
                                    asChild
                                    size="lg"
                                    className="h-12 px-8 text-base font-semibold rounded-full bg-slate-900 hover:bg-slate-800 text-white"
                                >
                                    <Link href="/contact">
                                        Contact sales
                                    </Link>
                                </Button>
                                <Button
                                    asChild
                                    variant="outline"
                                    size="lg"
                                    className="h-12 px-8 text-base font-semibold rounded-full border-slate-300"
                                >
                                    <Link href="/demo">Book a demo</Link>
                                </Button>
                            </div>
                        </motion.div>

                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.6, delay: 0.2 }}
                            className="relative"
                        >
                            <div className="relative rounded-2xl bg-gradient-to-br from-purple-100 to-purple-50 border border-purple-200/50 shadow-2xl overflow-hidden aspect-[4/3]">
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <div className="text-center">
                                        <div className="w-16 h-16 rounded-2xl bg-purple-600 flex items-center justify-center text-white mx-auto mb-4">
                                            <Shield size={32} />
                                        </div>
                                        <p className="text-purple-900 font-bold">Enterprise Dashboard</p>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                </div>
            </section>

            {/* Benefits */}
            <section className="py-16 md:py-24">
                <div className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="text-center mb-12"
                    >
                        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                            Built for enterprise needs
                        </h2>
                        <p className="text-lg text-slate-500 max-w-2xl mx-auto">
                            Security, scalability, and support designed for large organizations.
                        </p>
                    </motion.div>

                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
                        {benefits.map((benefit, index) => (
                            <motion.div
                                key={benefit.title}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: index * 0.1 }}
                                className="p-6 rounded-2xl bg-white border border-slate-200 hover:shadow-lg transition-shadow"
                            >
                                <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-4">
                                    <benefit.icon size={24} />
                                </div>
                                <h3 className="text-lg font-bold text-slate-900 mb-2">
                                    {benefit.title}
                                </h3>
                                <p className="text-slate-500 text-sm leading-relaxed">
                                    {benefit.description}
                                </p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA */}
            <section className="py-16 md:py-24 bg-slate-900">
                <div className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="max-w-3xl mx-auto text-center"
                    >
                        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                            Ready for enterprise-grade social?
                        </h2>
                        <p className="text-lg text-slate-400 mb-8">
                            Let's discuss how Veblika can work for your organization.
                        </p>
                        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                            <Button
                                asChild
                                size="lg"
                                className="h-12 px-8 text-base font-semibold rounded-full bg-white text-slate-900 hover:bg-slate-100"
                            >
                                <Link href="/contact">
                                    Contact sales
                                    <ArrowRight size={18} className="ml-2" />
                                </Link>
                            </Button>
                            <Link
                                href="/pricing"
                                className="text-slate-300 hover:text-white font-medium transition-colors"
                            >
                                View pricing →
                            </Link>
                        </div>
                    </motion.div>
                </div>
            </section>
        </>
    );
}
