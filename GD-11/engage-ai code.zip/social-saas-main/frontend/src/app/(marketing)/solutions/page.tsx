"use client";

import React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Building2, Shield, Sparkles } from "lucide-react";

const solutions = [
    {
        title: "For Agencies",
        description: "Manage multiple clients with white-label dashboards, streamlined workflows, and beautiful branded reports.",
        icon: Building2,
        href: "/solutions/agencies",
        color: "blue",
    },
    {
        title: "For Enterprise",
        description: "Scale your social presence with advanced security, custom integrations, and dedicated support.",
        icon: Shield,
        href: "/solutions/enterprise",
        color: "purple",
    },
    {
        title: "For Creators",
        description: "Grow your personal brand across platforms with smart scheduling and audience insights.",
        icon: Sparkles,
        href: "/solutions/creators",
        color: "pink",
    },
];

const colorClasses: Record<string, string> = {
    blue: "bg-blue-50 text-blue-600 group-hover:bg-blue-100",
    purple: "bg-purple-50 text-purple-600 group-hover:bg-purple-100",
    pink: "bg-pink-50 text-pink-600 group-hover:bg-pink-100",
};

export default function SolutionsPage() {
    return (
        <>
            {/* Hero */}
            <section className="relative py-20 md:py-28 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-slate-50 to-white" />
                <div
                    className="absolute inset-0 opacity-[0.03]"
                    style={{
                        backgroundImage:
                            "linear-gradient(#1a365d 1px, transparent 1px), linear-gradient(90deg, #1a365d 1px, transparent 1px)",
                        backgroundSize: "40px 40px",
                    }}
                />

                <div className="container mx-auto px-4 relative z-10">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                        className="max-w-3xl mx-auto text-center"
                    >
                        <span className="inline-block text-sm font-semibold text-purple-600 bg-purple-50 px-4 py-1.5 rounded-full mb-6">
                            Solutions
                        </span>
                        <h1 className="text-4xl md:text-6xl font-black tracking-tight text-slate-900 leading-[1.1] mb-6">
                            Built for how you work
                        </h1>
                        <p className="text-lg md:text-xl text-slate-500 leading-relaxed">
                            Whether you're an agency, enterprise, or creator — Veblika adapts to your unique needs.
                        </p>
                    </motion.div>
                </div>
            </section>

            {/* Solutions Grid */}
            <section className="py-16 md:py-24">
                <div className="container mx-auto px-4">
                    <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
                        {solutions.map((solution, idx) => (
                            <motion.div
                                key={solution.title}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.1 }}
                            >
                                <Link
                                    href={solution.href}
                                    className="group block h-full p-8 bg-white rounded-2xl border border-slate-200 hover:border-slate-300 hover:shadow-xl transition-all"
                                >
                                    <div className={`w-14 h-14 rounded-2xl ${colorClasses[solution.color]} flex items-center justify-center mb-6 transition-colors`}>
                                        <solution.icon size={28} />
                                    </div>
                                    <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-blue-600 transition-colors">
                                        {solution.title}
                                    </h3>
                                    <p className="text-slate-500 leading-relaxed mb-6">
                                        {solution.description}
                                    </p>
                                    <span className="inline-flex items-center gap-2 text-sm font-semibold text-blue-600">
                                        Learn more
                                        <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                                    </span>
                                </Link>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA */}
            <section className="py-16 md:py-24 bg-slate-50">
                <div className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="max-w-3xl mx-auto text-center"
                    >
                        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                            Not sure which solution is right?
                        </h2>
                        <p className="text-lg text-slate-500 mb-8">
                            Talk to our team and we'll help you find the perfect fit.
                        </p>
                        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                            <Button
                                asChild
                                size="lg"
                                className="h-12 px-8 text-base font-semibold rounded-full bg-slate-900 hover:bg-slate-800 text-white"
                            >
                                <Link href="/contact">
                                    Contact sales
                                </Link>
                            </Button>
                            <Button
                                asChild
                                variant="outline"
                                size="lg"
                                className="h-12 px-8 text-base font-semibold rounded-full border-slate-300"
                            >
                                <Link href="/signup">
                                    Start free trial
                                </Link>
                            </Button>
                        </div>
                    </motion.div>
                </div>
            </section>
        </>
    );
}
