"use client";

import React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import {
    ArrowRight,
    Check,
    Building2,
    Users,
    BarChart3,
    Palette,
    Shield,
    Headphones,
} from "lucide-react";

const benefits = [
    {
        icon: Building2,
        title: "Multi-client management",
        description: "Manage all your clients' social accounts from one dashboard with seamless switching.",
    },
    {
        icon: Palette,
        title: "White-label reports",
        description: "Generate beautiful, branded PDF reports with your agency's logo and colors.",
    },
    {
        icon: Users,
        title: "Client collaboration",
        description: "Invite clients to review and approve content before it goes live.",
    },
    {
        icon: BarChart3,
        title: "Cross-client analytics",
        description: "Compare performance across all clients and identify trends at a glance.",
    },
    {
        icon: Shield,
        title: "Role-based permissions",
        description: "Control exactly what team members and clients can see and do.",
    },
    {
        icon: Headphones,
        title: "Priority support",
        description: "Get dedicated support from our agency success team.",
    },
];

const testimonials = [
    {
        quote: "Veblika has transformed how we manage social for our 50+ clients. The white-label reports alone have saved us countless hours.",
        author: "Sarah Chen",
        role: "CEO, Digital Spark Agency",
        avatar: "SC",
    },
    {
        quote: "The client approval workflow is a game-changer. No more endless email threads about content changes.",
        author: "Michael Torres",
        role: "Director, Social First Media",
        avatar: "MT",
    },
];

export default function AgenciesPage() {
    return (
        <>
            {/* Hero */}
            <section className="relative py-20 md:py-28 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-blue-50 to-white" />
                <div
                    className="absolute inset-0 opacity-[0.03]"
                    style={{
                        backgroundImage:
                            "linear-gradient(#1a365d 1px, transparent 1px), linear-gradient(90deg, #1a365d 1px, transparent 1px)",
                        backgroundSize: "40px 40px",
                    }}
                />

                <div className="container mx-auto px-4 relative z-10">
                    <div className="grid lg:grid-cols-2 gap-12 items-center">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6 }}
                        >
                            <span className="inline-flex items-center gap-2 text-sm font-semibold text-blue-600 bg-blue-100 px-4 py-1.5 rounded-full mb-6">
                                <Building2 size={16} />
                                For Agencies
                            </span>
                            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-slate-900 leading-[1.1] mb-6">
                                Scale your agency without the chaos
                            </h1>
                            <p className="text-lg md:text-xl text-slate-500 leading-relaxed mb-8">
                                Manage multiple clients, automate reporting, and deliver exceptional results — all from one powerful platform built for agencies.
                            </p>
                            <div className="flex flex-col sm:flex-row items-start gap-4">
                                <Button
                                    asChild
                                    size="lg"
                                    className="h-12 px-8 text-base font-semibold rounded-full bg-[#bbf7d0] hover:bg-[#a6efc1] text-[#064e3b]"
                                >
                                    <Link href="/signup">
                                        Start free trial
                                        <ArrowRight size={18} className="ml-2" />
                                    </Link>
                                </Button>
                                <Button
                                    asChild
                                    variant="outline"
                                    size="lg"
                                    className="h-12 px-8 text-base font-semibold rounded-full border-slate-300"
                                >
                                    <Link href="/demo">Book a demo</Link>
                                </Button>
                            </div>
                        </motion.div>

                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.6, delay: 0.2 }}
                            className="relative"
                        >
                            <div className="relative rounded-2xl bg-gradient-to-br from-blue-100 to-blue-50 border border-blue-200/50 shadow-2xl overflow-hidden aspect-[4/3]">
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <div className="text-center">
                                        <div className="w-16 h-16 rounded-2xl bg-blue-600 flex items-center justify-center text-white mx-auto mb-4">
                                            <Building2 size={32} />
                                        </div>
                                        <p className="text-blue-900 font-bold">Agency Dashboard</p>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                </div>
            </section>

            {/* Benefits */}
            <section className="py-16 md:py-24">
                <div className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="text-center mb-12"
                    >
                        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                            Built for agency workflows
                        </h2>
                        <p className="text-lg text-slate-500 max-w-2xl mx-auto">
                            Everything you need to manage clients efficiently and profitably.
                        </p>
                    </motion.div>

                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
                        {benefits.map((benefit, index) => (
                            <motion.div
                                key={benefit.title}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: index * 0.1 }}
                                className="p-6 rounded-2xl bg-white border border-slate-200 hover:shadow-lg transition-shadow"
                            >
                                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
                                    <benefit.icon size={24} />
                                </div>
                                <h3 className="text-lg font-bold text-slate-900 mb-2">
                                    {benefit.title}
                                </h3>
                                <p className="text-slate-500 text-sm leading-relaxed">
                                    {benefit.description}
                                </p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Testimonials */}
            <section className="py-16 md:py-24 bg-slate-50">
                <div className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="text-center mb-12"
                    >
                        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                            Trusted by agencies worldwide
                        </h2>
                    </motion.div>

                    <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                        {testimonials.map((testimonial, index) => (
                            <motion.div
                                key={testimonial.author}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: index * 0.1 }}
                                className="bg-white rounded-2xl p-8 border border-slate-200"
                            >
                                <p className="text-slate-700 text-lg leading-relaxed mb-6">
                                    "{testimonial.quote}"
                                </p>
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold">
                                        {testimonial.avatar}
                                    </div>
                                    <div>
                                        <p className="font-semibold text-slate-900">
                                            {testimonial.author}
                                        </p>
                                        <p className="text-sm text-slate-500">{testimonial.role}</p>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA */}
            <section className="py-16 md:py-24">
                <div className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="max-w-3xl mx-auto text-center"
                    >
                        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                            Ready to scale your agency?
                        </h2>
                        <p className="text-lg text-slate-500 mb-8">
                            Join thousands of agencies using Veblika to manage social media at scale.
                        </p>
                        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                            <Button
                                asChild
                                size="lg"
                                className="h-12 px-8 text-base font-semibold rounded-full bg-[#bbf7d0] hover:bg-[#a6efc1] text-[#064e3b]"
                            >
                                <Link href="/signup">
                                    Start free trial
                                    <ArrowRight size={18} className="ml-2" />
                                </Link>
                            </Button>
                            <Link
                                href="/pricing"
                                className="text-slate-600 hover:text-slate-900 font-medium transition-colors"
                            >
                                View agency pricing →
                            </Link>
                        </div>
                    </motion.div>
                </div>
            </section>
        </>
    );
}
