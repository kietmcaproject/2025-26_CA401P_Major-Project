"use client";

import React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import {
    ArrowRight,
    Sparkles,
    Calendar,
    BarChart3,
    Palette,
    TrendingUp,
    Clock,
} from "lucide-react";

const benefits = [
    {
        icon: Calendar,
        title: "Smart scheduling",
        description: "Post at optimal times based on when your audience is most active.",
    },
    {
        icon: BarChart3,
        title: "Growth analytics",
        description: "Track followers, engagement, and discover what content performs best.",
    },
    {
        icon: Palette,
        title: "Visual planning",
        description: "Plan your feed aesthetically with our visual content calendar.",
    },
    {
        icon: TrendingUp,
        title: "Hashtag insights",
        description: "Find trending hashtags and track their performance over time.",
    },
    {
        icon: Clock,
        title: "Save hours weekly",
        description: "Batch create content and let Veblika handle the publishing.",
    },
    {
        icon: Sparkles,
        title: "Multi-platform",
        description: "Manage Instagram, TikTok, YouTube, X, and more from one place.",
    },
];

export default function CreatorsPage() {
    return (
        <>
            {/* Hero */}
            <section className="relative py-20 md:py-28 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-pink-50 to-white" />
                <div
                    className="absolute inset-0 opacity-[0.03]"
                    style={{
                        backgroundImage:
                            "linear-gradient(#1a365d 1px, transparent 1px), linear-gradient(90deg, #1a365d 1px, transparent 1px)",
                        backgroundSize: "40px 40px",
                    }}
                />

                <div className="container mx-auto px-4 relative z-10">
                    <div className="grid lg:grid-cols-2 gap-12 items-center">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6 }}
                        >
                            <span className="inline-flex items-center gap-2 text-sm font-semibold text-pink-600 bg-pink-100 px-4 py-1.5 rounded-full mb-6">
                                <Sparkles size={16} />
                                For Creators
                            </span>
                            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-slate-900 leading-[1.1] mb-6">
                                Grow your personal brand
                            </h1>
                            <p className="text-lg md:text-xl text-slate-500 leading-relaxed mb-8">
                                Focus on creating. Let Veblika handle the scheduling, analytics, and cross-platform posting so you can grow faster.
                            </p>
                            <div className="flex flex-col sm:flex-row items-start gap-4">
                                <Button
                                    asChild
                                    size="lg"
                                    className="h-12 px-8 text-base font-semibold rounded-full bg-[#bbf7d0] hover:bg-[#a6efc1] text-[#064e3b]"
                                >
                                    <Link href="/signup">
                                        Start free trial
                                        <ArrowRight size={18} className="ml-2" />
                                    </Link>
                                </Button>
                                <Button
                                    asChild
                                    variant="outline"
                                    size="lg"
                                    className="h-12 px-8 text-base font-semibold rounded-full border-slate-300"
                                >
                                    <Link href="/pricing">View pricing</Link>
                                </Button>
                            </div>
                        </motion.div>

                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.6, delay: 0.2 }}
                            className="relative"
                        >
                            <div className="relative rounded-2xl bg-gradient-to-br from-pink-100 to-pink-50 border border-pink-200/50 shadow-2xl overflow-hidden aspect-[4/3]">
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <div className="text-center">
                                        <div className="w-16 h-16 rounded-2xl bg-pink-600 flex items-center justify-center text-white mx-auto mb-4">
                                            <Sparkles size={32} />
                                        </div>
                                        <p className="text-pink-900 font-bold">Creator Dashboard</p>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                </div>
            </section>

            {/* Benefits */}
            <section className="py-16 md:py-24">
                <div className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="text-center mb-12"
                    >
                        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                            Everything creators need
                        </h2>
                        <p className="text-lg text-slate-500 max-w-2xl mx-auto">
                            Spend less time managing, more time creating.
                        </p>
                    </motion.div>

                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
                        {benefits.map((benefit, index) => (
                            <motion.div
                                key={benefit.title}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: index * 0.1 }}
                                className="p-6 rounded-2xl bg-white border border-slate-200 hover:shadow-lg transition-shadow"
                            >
                                <div className="w-12 h-12 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center mb-4">
                                    <benefit.icon size={24} />
                                </div>
                                <h3 className="text-lg font-bold text-slate-900 mb-2">
                                    {benefit.title}
                                </h3>
                                <p className="text-slate-500 text-sm leading-relaxed">
                                    {benefit.description}
                                </p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA */}
            <section className="py-16 md:py-24 bg-gradient-to-br from-pink-500 to-purple-600">
                <div className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="max-w-3xl mx-auto text-center"
                    >
                        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                            Ready to grow your audience?
                        </h2>
                        <p className="text-lg text-white/80 mb-8">
                            Join thousands of creators using Veblika to build their brand.
                        </p>
                        <Button
                            asChild
                            size="lg"
                            className="h-12 px-8 text-base font-semibold rounded-full bg-white text-slate-900 hover:bg-slate-100"
                        >
                            <Link href="/signup">
                                Start free trial
                                <ArrowRight size={18} className="ml-2" />
                            </Link>
                        </Button>
                    </motion.div>
                </div>
            </section>
        </>
    );
}
