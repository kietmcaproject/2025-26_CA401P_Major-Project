import { NextResponse } from 'next/server';

export async function POST(request: Request) {
    try {
        const { name, email, subject, message } = await request.json();

        // Log the submission (In a real scenario, you'd send an email here using Resend/Nodemailer)
        console.log('Contact Form Submission:', { name, email, subject, message });

        // Simulate a delay
        await new Promise((resolve) => setTimeout(resolve, 1000));

        // Here you would typically use a service like Resend or Nodemailer to send to care@veblika.com
        /*
        await resend.emails.send({
          from: 'onboarding@resend.dev',
          to: 'care@veblika.com',
          subject: `New Contact Form: ${subject}`,
          text: `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`,
        });
        */

        return NextResponse.json({ success: true, message: 'Message sent successfully!' });
    } catch (error) {
        console.error('Error in contact form submission:', error);
        return NextResponse.json(
            { success: false, message: 'Failed to send message. Please try again.' },
            { status: 500 }
        );
    }
}
