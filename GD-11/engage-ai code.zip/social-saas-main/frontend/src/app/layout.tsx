import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import ReactQuery from "@/providers/rct-query";
import { HydrationBoundary } from "@tanstack/react-query";
import { Toaster } from "sonner";
import { ErrorSuppressor } from "@/components/error-suppressor";
import { BrandingProvider } from "@/providers/branding-provider";
import { getResellerBranding } from "@/lib/branding";
import { headers } from "next/headers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export async function generateMetadata(): Promise<Metadata> {
  const headersList = await headers();
  const host = headersList.get("x-forwarded-host") || headersList.get("host") || "";
  const domain = host.split(",")[0]?.trim().split(":")[0] || "";
  const branding = await getResellerBranding(domain);

  return {
    title: branding?.companyName
      ? `${branding.companyName} | Social Media Management`
      : "Social Media Management",
    description: branding?.companyName
      ? `${branding.companyName} - Social Media Management Platform`
      : "Social Media Management Platform for Organisations",
    icons: branding?.favicon || branding?.logo ? { icon: branding?.favicon || branding?.logo } : undefined,
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const headersList = await headers();
  const host = headersList.get("x-forwarded-host") || headersList.get("host") || "";
  // Check for localhost and port - usually we just want the domain part if using subdomains
  // But user might be mapping specific domains.
  // For dev: localhost:3000 -> might map to localhost
  const domain = host.split(",")[0]?.trim().split(":")[0] || "";
  const branding = await getResellerBranding(domain);

  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {/* <HydrationBoundary
          state={pageProps.dehydratedState}
        ></HydrationBoundary> */}
        <ErrorSuppressor />
        <Toaster />
        <BrandingProvider value={branding}>
          <ReactQuery>{children}</ReactQuery>
        </BrandingProvider>
      </body>
    </html>
  );
}
