import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import LoginForm from "./login-form";

function getServerApiBaseUrl() {
  return (
    process.env.API_URL ||
    process.env.NEXT_PUBLIC_API_URL ||
    "http://localhost:8001"
  ).replace(/\/$/, "");
}

function getMissingProfileFields(profilePayload: any): string[] {
  const profile = profilePayload?.data || {};
  const required = [
    { key: "custom:addressline", value: profile?.addressline },
    { key: "custom:state", value: profile?.state },
    { key: "custom:city", value: profile?.city },
    { key: "custom:country", value: profile?.country },
    { key: "custom:phone", value: profile?.phone },
    { key: "custom:pincode", value: profile?.pincode },
    { key: "custom:profilePicture", value: profile?.profilePicture || profile?.profile_pic },
  ];
  return required.filter((f) => !String(f.value || "").trim()).map((f) => f.key);
}

export default async function LoginPage() {
  const cookieStore = await cookies();
  const cookieHeader = cookieStore
    .getAll()
    .map((c) => `${c.name}=${c.value}`)
    .join("; ");

  if (cookieHeader) {
    try {
      const meResponse = await fetch(`${getServerApiBaseUrl()}/api/user/me`, {
        headers: { Cookie: cookieHeader },
        cache: "no-store",
      });

      if (meResponse.ok) {
        const mePayload = await meResponse.json().catch(() => null);
        const missingProfileFields = getMissingProfileFields(mePayload);
        if (missingProfileFields.length > 0) {
          redirect("/complete-profile");
        }
        redirect("/integrations");
      }
    } catch {
      // Keep login page visible if API is unavailable.
    }
  }

  return <LoginForm />;
}
