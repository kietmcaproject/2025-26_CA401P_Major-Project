"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { authClient } from "@/lib/auth.client";
import { toast } from "sonner";

type LoginFormValues = {
  email: string;
  password: string;
};

export default function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirect");
  const [isLoading, setIsLoading] = useState(false);
  const [mfaChallenge, setMfaChallenge] = useState(false);
  const [mfaSession, setMfaSession] = useState("");
  const [mfaEmail, setMfaEmail] = useState("");
  const [mfaCode, setMfaCode] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const getRedirectPath = () => {
    if (!redirectTo) return "/integrations";

    const trimmed = redirectTo.trim();
    if (!trimmed.startsWith("/")) return "/integrations";
    if (trimmed === "/integration") return "/integrations";

    return trimmed;
  };

  const form = useForm<LoginFormValues>({
    defaultValues: {
      email: "",
      password: "",
    },
    mode: "onBlur",
  });

  const handleSuccessfulLogin = (payload: any) => {
    const loginData = payload?.data || {};
    const profileCompletionRequired = !!loginData?.profileCompletionRequired;
    toast.success("Login successful!");
    if (profileCompletionRequired) {
      router.push("/complete-profile");
    } else {
      router.push(getRedirectPath());
    }
  };

  const resetMfaChallenge = () => {
    setMfaChallenge(false);
    setMfaSession("");
    setMfaEmail("");
    setMfaCode("");
  };

  const onSubmit = async (data: LoginFormValues) => {
    setIsLoading(true);
    try {
      if (mfaChallenge) {
        if (!/^\d{6}$/.test(mfaCode.trim())) {
          toast.error("Enter a valid 6-digit authenticator code");
          return;
        }

        const mfaResult = await authClient.verifyMfaLogin({
          email: mfaEmail,
          session: mfaSession,
          code: mfaCode.trim(),
        });

        if (mfaResult.error) {
          toast.error(mfaResult.error.message || "Failed to verify MFA code");
          return;
        }

        handleSuccessfulLogin((mfaResult as any).data);
        resetMfaChallenge();
      } else {
        const result = await authClient.signIn.email({
          email: data.email,
          password: data.password,
        });

        if (result.error) {
          toast.error(result.error.message || "Failed to login");
          return;
        }

        const payload = (result as any)?.data || {};
        const loginData = payload?.data || {};
        const challengeName = loginData?.challenge || payload?.challenge || null;
        const sessionToken = loginData?.session || payload?.session || null;

        if (challengeName === "SOFTWARE_TOKEN_MFA" && sessionToken) {
          setMfaChallenge(true);
          setMfaSession(String(sessionToken));
          setMfaEmail(String(loginData?.email || data.email).toLowerCase().trim());
          setMfaCode("");
          toast.message("MFA required", {
            description: "Enter the 6-digit code from your authenticator app.",
          });
          return;
        }

        handleSuccessfulLogin(payload);
      }
    } catch (error) {
      toast.error(mfaChallenge ? "An error occurred during MFA verification" : "An error occurred during login");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl">Welcome back</CardTitle>
          <CardDescription>Enter your credentials to sign in</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Separator />
            <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-background px-2 text-xs text-muted-foreground">
              Login
            </span>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              {!mfaChallenge ? (
                <>
                  <FormField
                    control={form.control}
                    name="email"
                    rules={{
                      required: "Email is required",
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: "Please enter a valid email address",
                      },
                    }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="name@example.com" disabled={isLoading} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    rules={{
                      required: "Password is required",
                      minLength: {
                        value: 6,
                        message: "Password must be at least 6 characters",
                      },
                    }}
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between">
                          <FormLabel>Password</FormLabel>
                          <Link
                            href="/forget-password"
                            className="text-sm text-muted-foreground hover:text-primary"
                            tabIndex={-1}
                          >
                            Forgot?
                          </Link>
                        </div>
                        <FormControl>
                          <div className="relative">
                            <Input
                              type={showPassword ? "text" : "password"}
                              placeholder="Enter your password"
                              disabled={isLoading}
                              className="pr-10"
                              {...field}
                            />
                            <button
                              type="button"
                              onClick={() => setShowPassword((prev) => !prev)}
                              className="absolute inset-y-0 right-0 flex items-center px-3 text-muted-foreground hover:text-foreground"
                              aria-label={showPassword ? "Hide password" : "Show password"}
                            >
                              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                            </button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Signing in..." : "Sign in"}
                  </Button>
                </>
              ) : (
                <>
                  <FormItem>
                    <FormLabel>Authenticator Code</FormLabel>
                    <FormControl>
                      <Input
                        type="text"
                        inputMode="numeric"
                        autoComplete="one-time-code"
                        maxLength={6}
                        value={mfaCode}
                        onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                        placeholder="123456"
                        disabled={isLoading}
                      />
                    </FormControl>
                    <p className="text-xs text-muted-foreground">
                      Enter the 6-digit code for <span className="font-medium">{mfaEmail}</span>.
                    </p>
                  </FormItem>

                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Verifying..." : "Verify code"}
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    disabled={isLoading}
                    onClick={resetMfaChallenge}
                  >
                    Back to login
                  </Button>
                </>
              )}
            </form>
          </Form>
        </CardContent>
        <CardFooter className="flex justify-center">
          <p className="text-sm text-muted-foreground">
            Don&apos;t have an account?{" "}
            <Link href="/signup" className="text-primary hover:underline">
              Sign up
            </Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
