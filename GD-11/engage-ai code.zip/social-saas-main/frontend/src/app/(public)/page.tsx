"use client";

import React from 'react';
import Link from "next/link";
import { motion } from 'framer-motion';
import Image from "next/image";

// Import SVGs
import SchedulingSVG from "@/components/homePage/assets/publishing&scheduling.svg";
import SocialInboxSVG from "@/components/homePage/assets/social-inbox.svg";
import AnalyticsSVG from "@/components/homePage/assets/Analytics-&-Reports.svg";
import TeamCollaborationSVG from "@/components/homePage/assets/team-collaboration.svg";
import SocialListeningSVG from "@/components/homePage/assets/social-listening.svg";
import SecuritySVG from "@/components/homePage/assets/security-&-compliance.svg";

// shadcn imports
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
    Accordion,
    AccordionContent,
    AccordionItem,
    AccordionTrigger,
} from "@/components/ui/accordion";

// lucide icons
import {
    ArrowRight,
    Star,
    Calendar,
    MessageSquare,
    BarChart3,
    Users,
    Globe,
    Shield,
    TrendingUp,
} from 'lucide-react';

// Marketing Navbar & Footer
import MarketingNavbar from "@/components/marketing/navbar";
import MarketingFooter from "@/components/marketing/footer";

// Page Sections
import HeroSection from "@/components/marketing/home/hero-section";
import PricingPreviewSection from "@/components/marketing/home/pricing-section";
import { useBranding } from "@/providers/branding-provider";
import { LinkCard } from "@/components/card-26";

// ============================================
// LOGOS SECTION
// ============================================
function LogosSection() {
    const logos = [
        "Stripe", "Shopify", "Notion", "Figma", "Linear", "Vercel", "Supabase", "Prisma"
    ];

    return (
        <section className="py-20 border-y border-slate-100 bg-slate-50/30">
            <div className="container mx-auto px-4">
                <motion.p
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    className="text-center text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-10"
                >
                    Trusted by innovative teams worldwide
                </motion.p>
                <div className="flex flex-wrap items-center justify-center gap-x-16 gap-y-12 grayscale opacity-30 hover:grayscale-0 hover:opacity-100 transition-all duration-700">
                    {logos.map((logo, idx) => (
                        <motion.div
                            key={logo}
                            initial={{ opacity: 0, scale: 0.8 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{
                                delay: idx * 0.1,
                                type: "spring",
                                stiffness: 200,
                                damping: 10
                            }}
                            whileHover={{ y: -5, scale: 1.1 }}
                            className="text-2xl md:text-3xl font-black text-slate-900 tracking-tighter cursor-default select-none"
                        >
                            {logo}
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}

// ============================================
// FEATURES SECTION
// ============================================
function FeaturesSection() {
    const { companyName } = useBranding();
    

    const features = [
        {
            icon: Calendar,
            title: "Smart Scheduling",
            description: "Schedule posts across all platforms with AI-powered best-time suggestions.",
            href: "/features/scheduling",
            color: "blue",
            svg: SchedulingSVG
        },
        {
            icon: MessageSquare,
            title: "Unified Inbox",
            description: "Manage all comments, DMs, and mentions from one centralized inbox.",
            href: "/features/inbox",
            color: "green",
            svg: SocialInboxSVG
        },
        {
            icon: BarChart3,
            title: "Advanced Analytics",
            description: "Track performance with beautiful dashboards and custom reports.",
            href: "/features/analytics",
            color: "purple",
            svg: AnalyticsSVG
        },
        {
            icon: Users,
            title: "Team Collaboration",
            description: "Approval workflows, role-based access, and seamless teamwork.",
            href: "/features/collaboration",
            color: "cyan",
            svg: TeamCollaborationSVG
        },
        {
            icon: Globe,
            title: "Social Listening",
            description: "Monitor brand mentions, trends, and competitor activity in real-time.",
            href: "/features/listening",
            color: "orange",
            svg: SocialListeningSVG
        },
        {
            icon: Shield,
            title: "Enterprise Security",
            description: "SSO, 2FA, audit logs, and compliance workflows for large teams.",
            href: "/features/security",
            color: "slate",
            svg: SecuritySVG
        },
    ];

    const colorClasses: Record<string, string> = {
        blue: "bg-blue-50 text-blue-600 group-hover:bg-[#F6571F] group-hover:text-white",
        green: "bg-green-50 text-green-600 group-hover:bg-[#F6571F] group-hover:text-white",
        purple: "bg-purple-50 text-purple-600 group-hover:bg-[#F6571F] group-hover:text-white",
        cyan: "bg-cyan-50 text-cyan-600 group-hover:bg-[#F6571F] group-hover:text-white",
        orange: "bg-orange-50 text-orange-600 group-hover:bg-[#F6571F] group-hover:text-white",
        slate: "bg-slate-100 text-slate-600 group-hover:bg-[#F6571F] group-hover:text-white",
    };

    return (
        <section className="py-20 md:py-28">
            <div className="container mx-auto px-4">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="text-center mb-16"
                >
                    <Badge variant="secondary" className="mb-4 bg-[#FFF5F1] text-[#F6571F] border-[#F6571F]/10">
                        Features
                    </Badge>
                    <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight mb-4">
                        Everything you need to grow
                    </h2>
                    <p className="text-lg text-slate-500 max-w-2xl mx-auto font-medium">
                        From publishing to analytics, engagement to collaboration —
                        {companyName || "Veblika"} gives you the complete toolkit for social media success.
                    </p>
                </motion.div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {features.map((feature, idx) => (
                        <motion.div
                            key={feature.title}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: idx * 0.1 }}
                        >
                            <LinkCard
                                title={feature.title}
                                description={feature.description}
                                imageUrl={feature.svg}
                                href={feature.href}
                                icon={feature.icon}
                                color={colorClasses[feature.color]}
                            />
                        </motion.div>
                    ))}
                </div>

                <motion.div
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    className="text-center mt-12"
                >
                    <Button asChild variant="outline" size="lg" className="rounded-xl font-bold border-2 hover:bg-[#FFF5F1] hover:text-[#F6571F] hover:border-[#F6571F]/30 transition-all">
                        <Link href="/features">
                            See all features
                            <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                </motion.div>
            </div>
        </section>
    );
}

// ============================================
// STATS SECTION
// ============================================
function StatsSection() {
    const branding = useBranding();

    const defaultStats = [
        { value: "10K+", label: "Teams worldwide", order: 0 },
        { value: "50M+", label: "Posts scheduled", order: 1 },
        { value: "99.9%", label: "Uptime SLA", order: 2 },
        { value: "4.9", label: "Customer rating", order: 3 },
    ];

    const stats = branding.content?.stats?.length ? branding.content.stats : defaultStats;

    return (
        <section className="py-20 bg-slate-900">
            <div className="container mx-auto px-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
                    {stats.map((stat, idx) => (
                        <motion.div
                            key={stat.label}
                            initial={{ opacity: 0, scale: 0.5 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{
                                type: "spring",
                                stiffness: 150,
                                damping: 12,
                                delay: idx * 0.1
                            }}
                            className="text-center group"
                        >
                            <div className="flex items-center justify-center gap-2 mb-3">
                                <span className="text-4xl md:text-6xl font-black text-white group-hover:text-[#F6571F] transition-colors duration-500">
                                    {stat.value}
                                </span>
                                {stat.label === "Customer rating" && <Star className="w-6 h-6 text-yellow-400 fill-yellow-400 group-hover:animate-bounce" />}
                            </div>
                            <div className="h-1 w-10 bg-[#F6571F]/20 mx-auto rounded-full mb-3 group-hover:w-16 group-hover:bg-[#F6571F] transition-all duration-500" />
                            <p className="text-slate-400 font-bold uppercase tracking-wider text-xs">{stat.label}</p>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}

// ============================================
// HOW IT WORKS SECTION
// ============================================
function HowItWorksSection() {
    const steps = [
        {
            step: "01",
            title: "Connect your accounts",
            description: "Link your social profiles in seconds. We support all major platforms.",
            icon: Globe,
        },
        {
            step: "02",
            title: "Create & schedule",
            description: "Craft beautiful posts and schedule them for optimal engagement times.",
            icon: Calendar,
        },
        {
            step: "03",
            title: "Engage & grow",
            description: "Respond to your audience and watch your community thrive.",
            icon: TrendingUp,
        },
    ];

    return (
        <section className="py-20 md:py-28 bg-slate-50">
            <div className="container mx-auto px-4">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="text-center mb-16"
                >
                    <Badge variant="secondary" className="mb-4 bg-[#FFF5F1] text-[#F6571F] border-[#F6571F]/10">
                        How it works
                    </Badge>
                    <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight mb-4">
                        Get started in minutes
                    </h2>
                    <p className="text-lg text-slate-500 max-w-2xl mx-auto font-medium">
                        No complex setup. No learning curve. Just connect and start posting.
                    </p>
                </motion.div>

                <div className="grid md:grid-cols-3 gap-12 max-w-6xl mx-auto">
                    {steps.map((item, idx) => (
                        <motion.div
                            key={item.step}
                            initial={{ opacity: 0, x: -30 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.6, delay: idx * 0.2 }}
                            className="relative"
                        >
                            <div className="text-center group bg-white p-10 rounded-[3rem] border border-slate-100 hover:border-[#F6571F]/20 transition-all duration-500 hover:shadow-2xl hover:shadow-[#F6571F]/5">
                                <div className="w-24 h-24 rounded-[2.5rem] bg-[#FFF5F1] shadow-inner flex items-center justify-center mx-auto mb-8 transition-all duration-700 group-hover:rounded-2xl group-hover:rotate-12 group-hover:scale-110">
                                    <item.icon className="w-12 h-12 text-[#F6571F]" />
                                </div>
                                <span className="text-[10px] font-black text-[#F6571F] bg-[#FFF5F1] px-3 py-1 rounded-full uppercase tracking-[0.2em] mb-4 inline-block">{item.step}</span>
                                <h3 className="text-2xl font-black text-slate-900 mb-4 tracking-tight group-hover:text-[#F6571F] transition-colors">{item.title}</h3>
                                <p className="text-slate-500 leading-relaxed font-medium text-sm">{item.description}</p>
                            </div>
                            {idx < steps.length - 1 && (
                                <motion.div
                                    initial={{ opacity: 0, width: 0 }}
                                    whileInView={{ opacity: 1, width: "30%" }}
                                    viewport={{ once: true }}
                                    transition={{ duration: 1, delay: 0.5 + idx * 0.2 }}
                                    className="hidden lg:block absolute top-1/2 left-[85%] w-[30%] border-t-4 border-dotted border-[#F6571F]/20 -translate-y-12 z-0"
                                />
                            )}
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}

// ============================================
// TESTIMONIALS SECTION
// ============================================
function TestimonialsSection() {
    const branding = useBranding();
    const { companyName } = branding;

    const defaultTestimonials = [
        {
            name: "Sarah Chen",
            content: `${companyName || "Veblika"} has completely transformed how we manage social media. The scheduling and analytics alone have saved us 10+ hours per week.`,
            role: "Marketing Director",
            company: "TechFlow",
            rating: 5,
            order: 0
        },
        {
            name: "Michael Torres",
            content: "The unified inbox is a game-changer. We never miss a customer message now, and response times have dropped by 60%.",
            role: "Customer Success Lead",
            company: "StartupHub",
            rating: 5,
            order: 1
        },
        {
            name: "Emily Watson",
            content: "Finally, a social media tool that's as beautiful as it is powerful. My team actually enjoys using it.",
            role: "CEO",
            company: "Creative Co",
            rating: 5,
            order: 2
        },
    ];

    const testimonials = branding.content?.testimonials?.length
        ? branding.content.testimonials
        : defaultTestimonials;

    const getInitials = (name: string) => {
        return name.split(' ').map(n => n[0]).join('').toUpperCase();
    };

    return (
        <section className="py-20 md:py-28">
            <div className="container mx-auto px-4">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="text-center mb-16"
                >
                    <Badge variant="secondary" className="mb-4 bg-[#FFF5F1] text-[#F6571F] border-[#F6571F]/10">
                        Testimonials
                    </Badge>
                    <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight mb-4">
                        Loved by teams everywhere
                    </h2>
                </motion.div>

                <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
                    {testimonials.map((item, idx) => (
                        <motion.div
                            key={item.name}
                            initial={{ opacity: 0, y: 30, scale: 0.95 }}
                            whileInView={{ opacity: 1, y: 0, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.6, delay: idx * 0.1, type: "spring", stiffness: 100 }}
                            whileHover={{ y: -10, rotate: idx % 2 === 0 ? 1 : -1 }}
                        >
                            <Card className="h-full border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-500 bg-white rounded-3xl overflow-hidden group">
                                <CardContent className="p-8">
                                    <div className="flex gap-1.5 mb-8">
                                        {[...Array(item.rating || 5)].map((_, i) => (
                                            <Star key={i} className="w-5 h-5 text-[#F6571F] fill-[#F6571F] group-hover:animate-pulse" />
                                        ))}
                                    </div>
                                    <p className="text-slate-700 text-lg leading-relaxed mb-10 font-medium italic">
                                        "{item.content}"
                                    </p>
                                    <div className="flex items-center gap-4 mt-auto">
                                        <div className="w-14 h-14 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-lg font-black shadow-lg">
                                            {getInitials(item.name)}
                                        </div>
                                        <div>
                                            <p className="font-black text-slate-900 tracking-tight">{item.name}</p>
                                            <p className="text-sm text-slate-500 font-bold">{item.role}</p>
                                            <p className="text-xs text-[#F6571F] font-black uppercase tracking-wider mt-1">{item.company}</p>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}

// ============================================
// FAQ SECTION
// ============================================
function FAQSection() {
    const branding = useBranding();
    const { companyName } = branding;

    // Default FAQs
    const defaultFaqs = [
        {
            question: "What social platforms do you support?",
            answer: `${companyName || "Veblika"} supports Facebook, Instagram, X (Twitter), LinkedIn, TikTok, Pinterest, YouTube, and Threads. We're constantly adding new platforms.`,
        },
        {
            question: "Is there a free trial?",
            answer: "Yes! All paid plans include a 14-day free trial. No credit card required to start.",
        },
        {
            question: "Can I cancel anytime?",
            answer: "Absolutely. You can upgrade, downgrade, or cancel your subscription at any time. No long-term contracts.",
        },
        {
            question: "Do you offer team plans?",
            answer: "Yes, we have plans designed for teams of all sizes, from small agencies to large enterprises.",
        },
    ];

    // Use custom FAQs if available, otherwise use defaults
    const faqs = branding.content?.faqs && branding.content.faqs.length > 0
        ? branding.content.faqs.sort((a, b) => a.order - b.order)
        : defaultFaqs;

    return (
        <section className="py-20 md:py-28">
            <div className="container mx-auto px-4">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="text-center mb-12"
                >
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 tracking-tight mb-4">
                        Frequently asked questions
                    </h2>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="max-w-2xl mx-auto"
                >
                    <Accordion type="single" collapsible className="space-y-4">
                        {faqs.map((faq, idx) => (
                            <AccordionItem key={idx} value={`item-${idx}`} className="border border-slate-200 rounded-xl px-6 bg-white">
                                <AccordionTrigger className="text-left font-semibold text-slate-900 hover:no-underline py-4">
                                    {faq.question}
                                </AccordionTrigger>
                                <AccordionContent className="text-slate-500 pb-4">
                                    {faq.answer}
                                </AccordionContent>
                            </AccordionItem>
                        ))}
                    </Accordion>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    className="text-center mt-8"
                >
                    <p className="text-slate-500 font-medium">
                        Have more questions?{" "}
                        <Link href="/contact" className="text-[#F6571F] hover:underline font-bold">
                            Contact us
                        </Link>
                    </p>
                </motion.div>
            </div>
        </section>
    );
}

// ============================================
// MAIN PAGE COMPONENT
// ============================================
export default function HomePage() {
    return (
        <div className="min-h-screen bg-white">
            <MarketingNavbar />
            <main>
                <HeroSection />
                <LogosSection />
                <FeaturesSection />
                <StatsSection />
                <HowItWorksSection />
                <TestimonialsSection />
                <PricingPreviewSection />
                <FAQSection />
            </main>
            <MarketingFooter />
        </div>
    );
}
