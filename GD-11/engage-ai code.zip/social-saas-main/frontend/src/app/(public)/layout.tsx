"use client";

import { useAuthSession } from "@/hooks/use-auth-session";
import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";

export default function PublicLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const { isAuthenticated, isLoading } = useAuthSession();
    const router = useRouter();
    const pathname = usePathname();

    useEffect(() => {
        // If user is authenticated and not loading
        if (!isLoading && isAuthenticated) {
            // Allow access to accept-invite page even if authenticated
            if (pathname?.includes("/accept-invite")) {
                return;
            }

            // Redirect to integrations page for all other public pages
            router.push("/integrations");
        }
    }, [isLoading, isAuthenticated, router, pathname]);

    // Optional: Show loading state while checking session
    if (isLoading) {
        return (
            <div className="flex h-screen w-full items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
        );
    }

    return <>{children}</>;
}
