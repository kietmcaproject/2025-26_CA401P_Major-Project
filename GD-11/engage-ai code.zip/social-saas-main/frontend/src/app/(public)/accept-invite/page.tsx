"use client";

import { useSearchParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useAuthSession } from "@/hooks/use-auth-session";
import api from "@/utils/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";
import { authClient } from "@/lib/auth.client";

export default function AcceptInvitePage() {
    const searchParams = useSearchParams();
    const router = useRouter();
    const invitationId = searchParams.get("id");

    // Auth
    const { user, isLoading: isLoadingAuth } = useAuthSession();

    // State
    const [status, setStatus] = useState<"loading" | "valid" | "success" | "error">("loading");
    const [invitation, setInvitation] = useState<any>(null);
    const [errorMsg, setErrorMsg] = useState("");

    // 1. Validate Invitation on Mount
    useEffect(() => {
        if (!invitationId) {
            setStatus("error");
            setErrorMsg("No invitation ID provided.");
            return;
        }

        const validate = async () => {
            try {
                // Call public validation endpoint
                const { data } = await api.get(`/invitations/${invitationId}`);
                if (data.success) {
                    setInvitation(data.data);
                    setStatus("valid");
                }
            } catch (error: any) {
                setStatus("error");
                setErrorMsg(error.response?.data?.error || "Invalid or expired invitation.");
            }
        };

        validate();
    }, [invitationId]);

    // 2. Accept Handler
    const handleAccept = async () => {
        if (!user || !invitation) return;

        // Check email match
        if (user.email !== invitation.email) {
            toast.error(`This invitation is for ${invitation.email}, but you are logged in as ${user.email}. Please login with the correct account.`);
            return;
        }

        try {
            setStatus("loading");
            // Call accept endpoint with user details for robust metadata
            const { data } = await api.post(`/invitations/${invitation._id}/accept`, {
                name: user.name,
                email: user.email
            });
            if (data.success) {
                setStatus("success");
                toast.success("Joined organisation successfully!");
                // Redirect to dashboard or org home
                setTimeout(() => router.push("/settings/organization"), 1500);
            }
        } catch (error: any) {
            setStatus("valid"); // Go back to valid state to retry or show error
            toast.error(error.response?.data?.message || "Failed to accept");
        }
    };

    const handleLogin = () => {
        // Redirect to login with return URL
        const returnUrl = encodeURIComponent(`/accept-invite?id=${invitationId}`);
        router.push(`/login?callbackUrl=${returnUrl}`);
    };

    // Render
    if (isLoadingAuth || status === "loading") {
        return (
            <div className="flex h-screen w-full items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
        );
    }

    if (status === "error") {
        return (
            <div className="flex h-screen w-full items-center justify-center bg-gray-50">
                <Card className="w-full max-w-md">
                    <CardHeader className="text-center">
                        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
                            <XCircle className="h-6 w-6 text-red-600" />
                        </div>
                        <CardTitle>Invitation Error</CardTitle>
                        <CardDescription>{errorMsg}</CardDescription>
                    </CardHeader>
                    <CardFooter className="flex justify-center">
                        <Button variant="outline" onClick={() => router.push("/")}>Go Home</Button>
                    </CardFooter>
                </Card>
            </div>
        );
    }

    if (status === "success") {
        return (
            <div className="flex h-screen w-full items-center justify-center bg-gray-50">
                <Card className="w-full max-w-md">
                    <CardHeader className="text-center">
                        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                            <CheckCircle className="h-6 w-6 text-green-600" />
                        </div>
                        <CardTitle>Welcome!</CardTitle>
                        <CardDescription>
                            You have successfully joined <strong>{invitation?.orgId?.name}</strong>.
                        </CardDescription>
                    </CardHeader>
                </Card>
            </div>
        );
    }

    // Valid State
    return (
        <div className="flex h-screen w-full items-center justify-center bg-gray-50">
            <Card className="w-full max-w-md">
                <CardHeader className="text-center">
                    <CardTitle>Join {invitation?.orgId?.name}</CardTitle>
                    <CardDescription>
                        You have been invited to join as a <strong>{invitation?.roleId?.name}</strong>.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="rounded-md bg-muted p-4 text-sm text-center">
                        Invitation for: <span className="font-medium">{invitation?.email}</span>
                    </div>

                    {!user ? (
                        <div className="text-center text-sm text-yellow-600 bg-yellow-50 p-3 rounded-md">
                            You must be logged in to accept this invitation.
                        </div>
                    ) : user.email !== invitation.email ? (
                        <div className="text-center text-sm text-red-600 bg-red-50 p-3 rounded-md">
                            You are logged in as {user.email}.<br />
                            Please switch accounts to accept.
                        </div>
                    ) : null}

                </CardContent>
                <CardFooter className="flex flex-col gap-3">
                    {user ? (
                        user.email === invitation.email ? (
                            <Button className="w-full" onClick={handleAccept}>Accept Invitation</Button>
                        ) : (
                            <div className="flex w-full gap-2">
                                <Button variant="outline" className="flex-1" onClick={() => authClient.signOut().then(() => router.refresh())}>Logout</Button>
                            </div>
                        )
                    ) : (
                        <div className="flex w-full gap-2">
                            <Button className="flex-1" onClick={() => router.push(`/login?callbackUrl=${encodeURIComponent(`/accept-invite?id=${invitationId}`)}`)}>
                                Login
                            </Button>
                            <Button variant="outline" className="flex-1" onClick={() => router.push(`/signup`)}>
                                Sign Up
                            </Button>
                        </div>
                    )}
                </CardFooter>
            </Card>
        </div>
    );
}
