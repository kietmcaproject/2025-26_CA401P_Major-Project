import axios from "axios";
import { getApiBaseURL } from "@/lib/api";

// Ensure baseURL always ends with /api
const getBaseURL = () => {
  const envUrl = getApiBaseURL();
  // Remove trailing slash if present
  const cleanUrl = envUrl.replace(/\/$/, "");
  // Add /api if not already present
  return cleanUrl.endsWith("/api") ? cleanUrl : `${cleanUrl}/api`;
};

const api = axios.create({
  baseURL: getBaseURL(),
  withCredentials: true,
  timeout: 10000,
});

// Store session data globally for use in interceptors
let currentSessionToken: string | null = null;
let currentUserId: string | null = null;
let currentUserEmail: string | null = null;
let currentUserName: string | null = null;
let currentUserRole: string | null = null;
let currentResellerId: string | null = null;

// Function to update session token and user data (called from components using the hook)
export const setAuthToken = (
  token: string | null,
  userId: string | null,
  userEmail?: string | null,
  userName?: string | null,
  userRole?: string | null,
  resellerId?: string | null
) => {
  currentSessionToken = token;
  currentUserId = userId;
  currentUserEmail = userEmail || null;
  currentUserName = userName || null;
  currentUserRole = userRole || null;
  currentResellerId = resellerId || null;
};

// Add request interceptor to include request context headers when available.
api.interceptors.request.use(
  async (config) => {
    // Prefer httpOnly cookie authentication. Headers are optional context.
    if (currentSessionToken) {
      config.headers.Authorization = `Bearer ${currentSessionToken}`;
      config.headers["X-Auth-Token"] = currentSessionToken;
    }

    if (currentUserId) {
      config.headers["X-User-Id"] = currentUserId;
    }
    if (currentUserEmail) {
      config.headers["X-User-Email"] = currentUserEmail;
    }
    if (currentUserName) {
      config.headers["X-User-Name"] = currentUserName;
    }
    if (currentUserRole) {
      config.headers["X-User-Role"] = currentUserRole;
    }
    if (currentResellerId) {
      config.headers["X-Reseller-Id"] = currentResellerId;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle 401 errors (unauthorized)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      if (typeof window !== "undefined") {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

export const ImageApi = axios.create({
  baseURL: getBaseURL(),
  withCredentials: true,
  timeout: 300000,
  // Don't set Content-Type header - let axios set it automatically with boundary for multipart/form-data
});

// Add request interceptor to ImageApi to include request context headers when available.
ImageApi.interceptors.request.use(
  async (config) => {
    if (currentSessionToken) {
      config.headers.Authorization = `Bearer ${currentSessionToken}`;
      config.headers["X-Auth-Token"] = currentSessionToken;
      if (currentUserId) {
        config.headers["X-User-Id"] = currentUserId;
      }
      if (currentUserName) {
        config.headers["X-User-Name"] = currentUserName;
      }
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to ImageApi as well
ImageApi.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      if (typeof window !== "undefined") {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

export default api;
