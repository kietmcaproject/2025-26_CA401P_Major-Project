import { useEffect, useState } from "react";

/**
 * Custom hook to get the current client URL dynamically.
 * This is useful for white-labeled applications where the URL cannot be hardcoded.
 * 
 * @returns The current window origin (protocol + hostname + port)
 */
export const useClientUrl = () => {
  const [clientUrl, setClientUrl] = useState<string>("");

  useEffect(() => {
    if (typeof window !== "undefined") {
      setClientUrl(window.location.origin);
    }
  }, []);

  return clientUrl;
};
