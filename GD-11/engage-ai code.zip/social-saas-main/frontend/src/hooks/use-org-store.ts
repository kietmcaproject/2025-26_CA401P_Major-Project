import { create } from "zustand";
import { persist } from "zustand/middleware";
import { Organisation } from "../lib/queries/organisations";

interface OrgState {
    activeOrganisation: Organisation | null;
    setActiveOrganisation: (org: Organisation | null) => void;
}

export const useOrgStore = create<OrgState>()(
    persist(
        (set) => ({
            activeOrganisation: null,
            setActiveOrganisation: (org) => set({ activeOrganisation: org }),
        }),
        {
            name: "active-organisation-storage",
        }
    )
);
