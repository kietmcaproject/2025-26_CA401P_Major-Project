import { authClient } from "@/lib/auth.client";
import { useEffect } from "react";
import { setAuthToken } from "@/utils/api";

/**
 * Session hook backed by backend `/api/user/profile`.
 *
 * @returns { userId: string | null, token: string | null, user: any | null, session: any | null, isAuthenticated: boolean }
 */
export function useAuthSession() {
  const session = authClient.useSession();
  
  // Extract data from session
  const sessionData = session?.data || null;
  
  // Get userId from normalized profile response
  const userId = sessionData?.user?.id || sessionData?.session?.userId || null;
  
  // Get token from session.token
  const token = null;
  
  // Get full user object
  const user = sessionData?.user || null;
  
  // Get full session object
  const sessionInfo = sessionData?.session || null;
  
  // Extract role and resellerId from user object
  const userRole = (user as any)?.role || null;
  const resellerId = (user as any)?.resellerId || null;
  const missingProfileFields = (user as any)?.missingProfileFields || [];
  const profileCompletionRequired = !!(user as any)?.profileCompletionRequired;
  
  // Update API client with token, userId, email, name, role, and resellerId whenever they change
  // This ensures all API requests automatically include the token and user info
  useEffect(() => {
    setAuthToken(token, userId, user?.email || null, user?.name || null, userRole, resellerId);
  }, [token, userId, user?.email, user?.name, userRole, resellerId]);

  return {
    userId,        // "692d7b14b183fc3f9a664d27" - from session.data.user.id
    token,
    user,          // Full user object with email, name, etc.
    session: sessionInfo,  // Full session object
    role: userRole, // User role (e.g., "reseller", "admin")
    resellerId,    // Reseller ID if user belongs to a reseller
    missingProfileFields,
    profileCompletionRequired,
    refetch: session?.refetch,
    // Session is cookie-backed; token may be null client-side.
    isAuthenticated: !!userId,
    isLoading: session?.isPending || false,
    error: session?.error || null,
  };
}

