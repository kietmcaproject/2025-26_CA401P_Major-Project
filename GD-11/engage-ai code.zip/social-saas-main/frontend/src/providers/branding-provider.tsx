"use client";

import React, { createContext, useContext, ReactNode } from "react";
import type { ResellerContent } from "@/lib/queries/reseller-config";

interface BrandingConfig {
    companyName: string;
    logo: string;
    favicon?: string;
    domain?: string;
    isDefault?: boolean;
    colors?: {
        primary: string;
        secondary: string;
        accent: string;
        dark: string;
    };
    contact?: {
        address?: string;
        phone?: string;
        email?: string;
    };
    social?: {
        twitter?: string;
        linkedin?: string;
        facebook?: string;
        instagram?: string;
    };
    content?: Partial<ResellerContent>;
}

const BrandingContext = createContext<BrandingConfig | null>(null);

export const BrandingProvider = ({
    children,
    value
}: {
    children: ReactNode,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    value: BrandingConfig | any | null
}) => {
    return (
        <BrandingContext.Provider value={value as BrandingConfig | null}>
            {children}
        </BrandingContext.Provider>
    );
};

export const useBranding = () => {
    const context = useContext(BrandingContext);
    // If context is null, return default fallback
    return context || { companyName: "Veblika", logo: "", favicon: "", isDefault: true };
};
