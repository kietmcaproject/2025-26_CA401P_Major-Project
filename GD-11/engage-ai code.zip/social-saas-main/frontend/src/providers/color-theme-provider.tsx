"use client"

import * as React from "react"

export type Color = "orange" | "blue" | "green" | "pink" | "slate"

type ColorThemeContextType = {
    color: Color
    setColor: (color: Color) => void
}

const ColorThemeContext = React.createContext<ColorThemeContextType | undefined>(
    undefined
)

export function ColorThemeProvider({ children }: { children: React.ReactNode }) {
    const [color, setColor] = React.useState<Color>("orange")
    const [mounted, setMounted] = React.useState(false)

    React.useEffect(() => {
        // Get stored color or default to orange
        const storedColor = localStorage.getItem("color-theme") as Color
        if (storedColor) {
            setColor(storedColor)
            document.documentElement.setAttribute("data-color", storedColor)
        } else {
            // Set default
            document.documentElement.setAttribute("data-color", "orange")
        }
        setMounted(true)

        return () => {
            document.documentElement.removeAttribute("data-color")
        }
    }, [])

    const handleSetColor = (newColor: Color) => {
        setColor(newColor)
        localStorage.setItem("color-theme", newColor)
        document.documentElement.setAttribute("data-color", newColor)
    }

    return (
        <ColorThemeContext.Provider value={{ color, setColor: handleSetColor }}>
            {children}
        </ColorThemeContext.Provider>
    )
}

export function useColorTheme() {
    const context = React.useContext(ColorThemeContext)
    if (context === undefined) {
        throw new Error("useColorTheme must be used within a ColorThemeProvider")
    }
    return context
}
