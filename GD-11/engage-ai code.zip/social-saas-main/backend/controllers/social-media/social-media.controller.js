import AppCredentials from "../../models/appcredentials.model.js";
import Post from "../../models/post.model.js";
import Gallery from "../../models/gallery.model.js";
import UserModel from "../../models/user.model.js";
import { postToFacebook } from "../facebook/facebook.controller.js";
import { uploadInstagramMedia } from "../instagram/instagram.controller.js";
import { postToLinkedIn } from "../linkedin/linkedin.controller.js";
import { uploadYouTubeVideo } from "../youtube/youtube.controller.js";
import { uploadBase64Image } from "./upload-image.controller.js";
import { uploadMulterFileToS3 } from "../../utils/s3-upload.js";
import { validateInstagramImageFile } from "../../utils/instagram-image-validation.js";
import axios from "axios";
import FormData from "form-data";
import { getAppConfig } from "../../utils/getAppConfig.js";
import mongoose from "mongoose";
import {
  cancelScheduledPost,
  enqueueScheduledPost,
  isRedisConfigured,
} from "../../services/scheduled-post-queue.service.js";

const BYTES_IN_GB = 1024 * 1024 * 1024;

async function syncUserMediaStorageGb(authUserId, userEmail = null) {
  try {
    if (!authUserId) return;

    const total = await Gallery.aggregate([
      { $match: { userId: String(authUserId) } },
      { $group: { _id: null, totalBytes: { $sum: "$size" } } },
    ]);

    const totalBytes = Number(total?.[0]?.totalBytes || 0);
    const mediaStorageGb = Number((totalBytes / BYTES_IN_GB).toFixed(6));

    const candidates = [{ userId: String(authUserId) }];
    if (mongoose.isValidObjectId(authUserId)) {
      candidates.unshift({ _id: authUserId });
    }
    if (userEmail) {
      candidates.push({ email: String(userEmail).toLowerCase() });
    }

    await UserModel.findOneAndUpdate(
      { $or: candidates },
      { $set: { mediaStorageGb } },
      { new: true }
    );
  } catch (error) {
    console.error("[syncUserMediaStorageGb] Error:", error?.message || error);
  }
}

// Helper function to extract hashtags from text
function extractHashtags(text) {
  if (!text) return [];
  const hashtagRegex = /#[\w]+/g;
  const matches = text.match(hashtagRegex);
  return matches ? matches.map(tag => tag.substring(1)) : [];
}

function getCreatedByValue(authUserId) {
  return mongoose.isValidObjectId(authUserId) ? authUserId : undefined;
}

async function getInstagramPermalink(mediaId, accessToken, maxAttempts = 3) {
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await axios.get(`https://graph.instagram.com/v24.0/${mediaId}`, {
        params: {
          fields: "permalink",
          access_token: accessToken,
        },
      });

      if (res.data?.permalink) {
        return res.data.permalink;
      }
    } catch (error) {
      if (attempt === maxAttempts) {
        return null;
      }
    }

    await new Promise((resolve) => setTimeout(resolve, 1200));
  }

  return null;
}

// Get all connected platforms
export const getConnectedPlatforms = async (req, res) => {
  try {
    if (!req.user?._id) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const userId = String(req.user._id);

    const platforms = await AppCredentials.find({
      userId,
      platform: { $in: ["FACEBOOK", "INSTAGRAM", "LINKEDIN", "YOUTUBE"] },
    }).lean();

    const connectedPlatforms = platforms.map((p) => ({
      platform: p.platform,
      connected: true,
      pages: p.credentials.pages || [],
      channel: p.credentials.channel || null,
    }));

    return res.json({
      platforms: connectedPlatforms,
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ message: "Failed to fetch platforms" });
  }
};

// Post to multiple platforms at once
export const postToAllPlatforms = async (req, res) => {
  try {
    const { platforms, content, imageUrl, videoFile } = req.body;
    if (!req.user?._id) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const userId = String(req.user._id);

    if (!platforms || !Array.isArray(platforms) || platforms.length === 0) {
      return res.status(400).json({ message: "No platforms selected" });
    }

    const results = {
      success: [],
      failed: [],
    };

    // Convert base64 image to public URL if needed
    let processedImageUrl = imageUrl;
    if (imageUrl && imageUrl.startsWith("data:image")) {
      try {
        processedImageUrl = await uploadBase64Image(imageUrl, { req });
        console.log("[postToAllPlatforms] Converted base64 to URL:", processedImageUrl);
      } catch (err) {
        console.error("[postToAllPlatforms] Failed to process image:", err);
        // Continue without image
        processedImageUrl = null;
      }
    }

    // Post to each platform
    for (const platformConfig of platforms) {
      const { platform, pageId, ...platformSpecific } = platformConfig;

      try {
        let result;

        switch (platform.toUpperCase()) {
          case "FACEBOOK":
            result = await postToFacebookPlatform(
              userId,
              pageId,
              content,
              processedImageUrl
            );
            results.success.push({ platform: "FACEBOOK", result });
            break;

          case "INSTAGRAM":
            if (processedImageUrl) {
              result = await postToInstagramPlatform(
                userId,
                pageId,
                content,
                processedImageUrl
              );
              results.success.push({ platform: "INSTAGRAM", result });
            } else {
              results.failed.push({
                platform: "INSTAGRAM",
                error: "Instagram requires an image",
              });
            }
            break;

          case "LINKEDIN":
            result = await postToLinkedInPlatform(
              userId,
              pageId,
              content,
              processedImageUrl
            );
            results.success.push({ platform: "LINKEDIN", result });
            break;

          case "YOUTUBE":
            if (videoFile) {
              result = await postToYouTubePlatform(
                userId,
                content,
                videoFile,
                platformSpecific
              );
              results.success.push({ platform: "YOUTUBE", result });
            } else {
              results.failed.push({
                platform: "YOUTUBE",
                error: "YouTube requires a video file",
              });
            }
            break;

          default:
            results.failed.push({
              platform,
              error: "Unsupported platform",
            });
        }
      } catch (err) {
        console.log(`Error posting to ${platform}:`, err);
        const errorMessage = err.response?.data?.error?.message || err.message || "Posting failed";
        results.failed.push({
          platform,
          error: errorMessage,
        });
      }
    }

    return res.json({
      message: "Posting completed",
      results,
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ message: "Failed to post", error: err.message });
  }
};

// Helper functions for each platform
export async function postToFacebookPlatform(userId, pageId, message, imageUrl) {
  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "FACEBOOK",
  });

  if (!appCredential) {
    throw new Error("Facebook not connected");
  }

  const page = appCredential.credentials.pages.find(
    (p) => p.pageId === pageId
  );

  if (!page) {
    throw new Error("Page not found");
  }

  const pageToken = page.page_access_token;

  // If image is provided, use photos endpoint, otherwise use feed
  if (imageUrl) {
    // Upload photo first
    const photoRes = await axios.post(
      `https://graph.facebook.com/v20.0/${pageId}/photos`,
      null,
      {
        params: {
          url: imageUrl,
          caption: message,
          access_token: pageToken,
        },
      }
    );

    return { postId: photoRes.data.id, post_id: photoRes.data.post_id };
  } else {
    // Text-only post
    const postRes = await axios.post(
      `https://graph.facebook.com/v20.0/${pageId}/feed`,
      null,
      {
        params: {
          message,
          access_token: pageToken,
        },
      }
    );

    return { postId: postRes.data.id };
  }
}

export async function postToInstagramPlatform(userId, pageId, caption, imageUrl) {
  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "INSTAGRAM",
  });

  if (!appCredential) {
    throw new Error("Instagram not connected");
  }

  if (!imageUrl) {
    throw new Error("Instagram requires an image");
  }

  // Check for new Instagram Business Login structure
  let igAccountId, instagramToken;

  if (appCredential.credentials.instagram_account_id && appCredential.credentials.instagram_user_access_token) {
    // New structure: Instagram Business Login
    igAccountId = appCredential.credentials.instagram_account_id;
    // Use Instagram User access token for posting (Instagram Business Login)
    instagramToken = appCredential.credentials.instagram_user_access_token;
  } else {
    // Fallback: Old structure with pages
    const page = appCredential.credentials.pages?.find(
      (p) => p.pageId === pageId || !pageId
    );

    if (!page || !page.instagram_account_id) {
      throw new Error("Instagram account not found");
    }

    igAccountId = page.instagram_account_id;
    instagramToken = page.page_access_token;
  }

  try {
    // Instagram Business Login uses graph.instagram.com endpoints
    console.log("[postToInstagramPlatform] Creating media container with Instagram Graph API");
    const containerRes = await axios.post(
      `https://graph.instagram.com/v24.0/${igAccountId}/media`,
      null,
      {
        params: {
          image_url: imageUrl,
          caption: caption || "",
          access_token: instagramToken,
        },
      }
    );

    if (!containerRes.data || !containerRes.data.id) {
      throw new Error(`Failed to create media container: ${JSON.stringify(containerRes.data)}`);
    }

    const containerId = containerRes.data.id;

    // Publish the media using Instagram Graph API
    console.log("[postToInstagramPlatform] Publishing media with Instagram Graph API");
    const publishRes = await axios.post(
      `https://graph.instagram.com/v24.0/${igAccountId}/media_publish`,
      null,
      {
        params: {
          creation_id: containerId,
          access_token: instagramToken,
        },
      }
    );

    return { postId: publishRes.data.id };
  } catch (err) {
    const errorMessage = err.response?.data?.error?.message || err.message || "Instagram post failed";
    console.error("[postToInstagramPlatform] Error:", errorMessage, err.response?.data);
    throw new Error(errorMessage);
  }
}

export async function postToLinkedInPlatform(userId, pageId, text, imageUrl) {
  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "LINKEDIN",
  });

  if (!appCredential) {
    throw new Error("LinkedIn not connected");
  }

  const accessToken = appCredential.credentials.user_access_token;

  if (!accessToken) {
    throw new Error("LinkedIn access token not found");
  }

  // Use provided pageId or default to user's LinkedIn ID
  const linkedInUserId = pageId || appCredential.credentials.user_id;

  if (!linkedInUserId) {
    throw new Error("LinkedIn user ID not found. Please reconnect your LinkedIn account.");
  }

  console.log("[postToLinkedInPlatform] Posting to LinkedIn:", {
    userId,
    linkedInUserId: linkedInUserId,
    hasImage: !!imageUrl,
    textLength: text?.length || 0,
  });

  const postData = {
    author: `urn:li:person:${linkedInUserId}`,
    lifecycleState: "PUBLISHED",
    specificContent: {
      "com.linkedin.ugc.ShareContent": {
        shareCommentary: {
          text: text || "",
        },
        shareMediaCategory: imageUrl ? "IMAGE" : "NONE",
      },
    },
    visibility: {
      "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC", // Options: PUBLIC, CONNECTIONS, LOGGED_IN
    },
  };

  if (imageUrl) {
    try {
      console.log("[postToLinkedInPlatform] Uploading image to LinkedIn...");
      // Upload image to LinkedIn
      const imageUploadRes = await axios.post(
        "https://api.linkedin.com/v2/assets?action=registerUpload",
        {
          registerUploadRequest: {
            recipes: ["urn:li:digitalmediaRecipe:feedshare-image"],
            owner: `urn:li:person:${linkedInUserId}`,
            serviceRelationships: [
              {
                relationshipType: "OWNER",
                identifier: "urn:li:userGeneratedContent",
              },
            ],
          },
        },
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        }
      );

      const uploadUrl = imageUploadRes.data.value.uploadMechanism[
        "com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest"
      ].uploadUrl;
      const asset = imageUploadRes.data.value.asset;

      console.log("[postToLinkedInPlatform] Fetching image from URL...");
      const imageRes = await axios.get(imageUrl, {
        responseType: "arraybuffer",
      });

      console.log("[postToLinkedInPlatform] Uploading image to LinkedIn storage...");
      await axios.put(uploadUrl, imageRes.data, {
        headers: {
          "Content-Type": "image/jpeg",
        },
      });

      postData.specificContent["com.linkedin.ugc.ShareContent"].media = [
        {
          status: "READY",
          description: {
            text: text || "",
          },
          media: asset,
          title: {
            text: "Shared Image",
          },
        },
      ];
      console.log("[postToLinkedInPlatform] Image uploaded successfully");
    } catch (imageError) {
      console.error("[postToLinkedInPlatform] Image upload failed:", imageError.response?.data || imageError.message);
      throw new Error(`Failed to upload image to LinkedIn: ${imageError.response?.data?.message || imageError.message}`);
    }
  }

  try {
    console.log("[postToLinkedInPlatform] Publishing post to LinkedIn...");
    const postRes = await axios.post(
      "https://api.linkedin.com/v2/ugcPosts",
      postData,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
          "X-Restli-Protocol-Version": "2.0.0",
        },
      }
    );

    console.log("[postToLinkedInPlatform] ✅ Post published successfully:", postRes.data.id);
    return { postId: postRes.data.id };
  } catch (postError) {
    console.error("[postToLinkedInPlatform] ❌ Post failed:", postError.response?.data || postError.message);
    const errorMessage = postError.response?.data?.message || postError.message || "LinkedIn post failed";
    throw new Error(`LinkedIn post failed: ${errorMessage}`);
  }
}

export async function postToYouTubePlatform(userId, content, videoFile, options = {}) {
  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "YOUTUBE",
  });

  if (!appCredential) {
    throw new Error("YouTube not connected");
  }

  // This would need to be handled differently as YouTube requires file upload
  // For now, we'll return an error suggesting to use the dedicated YouTube endpoint
  throw new Error(
    "YouTube video upload requires file upload. Please use the dedicated YouTube upload endpoint."
  );
}

// Post to single platform with file upload support
export const postToSinglePlatform = async (req, res) => {
  try {
    const { platform, postType, content, pageId } = req.body;
    if (!req.user?._id) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const userId = String(req.user._id);

    if (!platform) {
      return res.status(400).json({ message: "Platform is required" });
    }

    if (!postType) {
      return res.status(400).json({ message: "Post type is required" });
    }

    if (!content) {
      return res.status(400).json({ message: "Content is required" });
    }

    // Get uploaded files
    const imageFile = req.files?.image?.[0];
    const videoFile = req.files?.video?.[0];



    // Check if it's a scheduled post
    const { scheduledAt } = req.body;
    const normalizedPlatform = String(platform).toUpperCase();
    const normalizedPostType = String(postType).toLowerCase();

    if (scheduledAt) {
      if (!isRedisConfigured()) {
        return res.status(503).json({
          message: "Scheduled posting is unavailable because Redis is not configured",
        });
      }

      const scheduledFor = new Date(scheduledAt);
      if (Number.isNaN(scheduledFor.getTime())) {
        return res.status(400).json({ message: "Invalid scheduled time" });
      }

      if (scheduledFor <= new Date()) {
        return res.status(400).json({ message: "Scheduled time must be in the future" });
      }

      console.log("[PostToSinglePlatform] Scheduling post for:", scheduledAt);

      if (normalizedPlatform === "INSTAGRAM" && normalizedPostType === "post" && imageFile) {
        validateInstagramImageFile(imageFile);
      }

      // Upload files to S3 if present (we need to store them for later)
      let mediaUrl = null;
      if (imageFile) {
        mediaUrl = await uploadMulterFileToS3(imageFile, "images", { req });
        console.log("[PostToSinglePlatform] Image uploaded to S3 for scheduling:", mediaUrl);
      } else if (videoFile) {
        mediaUrl = await uploadMulterFileToS3(videoFile, "videos", { req });
        console.log("[PostToSinglePlatform] Video uploaded to S3 for scheduling:", mediaUrl);
      }

      // Get account info for the platform
      const appCredential = await AppCredentials.findOne({
        userId,
        platform: normalizedPlatform,
      });

      const accountId = appCredential?.credentials?.instagram_account_id
        || appCredential?.credentials?.user_id // LinkedIn user ID
        || appCredential?.credentials?.pages?.[0]?.pageId
        || appCredential?.credentials?.channel?.id
        || null;

      const hashtags = extractHashtags(content);
      const createdBy = getCreatedByValue(req.user?._id);

      const postData = {
        userId,
        platform: normalizedPlatform,
        postId: `scheduled_${Date.now()}`, // Temporary ID
        postType: normalizedPostType,
        content,
        caption: content,
        mediaUrl,
        pageId: pageId || null,
        accountId,
        publishedAt: null, // Not published yet
        scheduledFor,
        status: "SCHEDULED",
        createdBy,
        hashtags,
        analyticsStatus: "pending",
        // For YouTube
        title: req.body.title || content.substring(0, 50),
        description: content,
        channelId: normalizedPlatform === "YOUTUBE" ? accountId : undefined,
      };

      let savedPost;

      try {
        savedPost = await Post.create(postData);
        await enqueueScheduledPost(savedPost);
      } catch (scheduleError) {
        if (savedPost?._id) {
          await Post.findByIdAndDelete(savedPost._id);
        }

        throw scheduleError;
      }

      return res.json({
        success: true,
        message: "Post scheduled successfully",
        result: { id: savedPost._id, status: "SCHEDULED" },
      });
    }

    let result;

    switch (normalizedPlatform) {
      case "FACEBOOK":
        if (normalizedPostType === "video" && videoFile) {
          result = await postToFacebookVideo(userId, pageId, content, videoFile);
        } else if (normalizedPostType === "post") {
          if (imageFile) {
            result = await postToFacebookImage(userId, pageId, content, imageFile);
          } else {
            result = await postToFacebookPlatform(userId, pageId, content, null);
          }
        } else {
          return res.status(400).json({ message: "Invalid post type for Facebook" });
        }
        break;

      case "INSTAGRAM":
        if (normalizedPostType === "reel" && videoFile) {
          result = await postToInstagramReel(userId, pageId, content, videoFile, { req });
        } else if (normalizedPostType === "post" && imageFile) {
          result = await postToInstagramImage(userId, pageId, content, imageFile, { req });
        } else {
          return res.status(400).json({ message: "Instagram requires media (image for post, video for reel)" });
        }
        break;

      case "YOUTUBE":
        if ((normalizedPostType === "video" || normalizedPostType === "short") && videoFile) {
          // Pass isShort flag to add #Shorts tag for YouTube Shorts
          result = await uploadYouTubeVideoFile(userId, content, videoFile, { isShort: normalizedPostType === "short", req });
        } else {
          return res.status(400).json({ message: "YouTube requires a video file" });
        }
        break;

      case "LINKEDIN":
        if (normalizedPostType === "post") {
          // Upload image to S3 if provided
          let imageUrl = null;
          if (imageFile) {
            imageUrl = await uploadMulterFileToS3(imageFile, "images", { req });
            console.log("[PostToSinglePlatform] LinkedIn image uploaded to S3:", imageUrl);
          }
          result = await postToLinkedInPlatform(userId, pageId, content, imageUrl);
        } else {
          return res.status(400).json({ message: "LinkedIn currently supports 'post' type only" });
        }
        break;

      default:
        return res.status(400).json({ message: "Unsupported platform" });
    }

    let savedPostMeta = null;

    // Save post to database for analytics tracking
    try {
      console.log("[PostToSinglePlatform] Saving post to database...");

      // Get account info for the platform
      const appCredential = await AppCredentials.findOne({
        userId,
        platform: normalizedPlatform,
      });

      const hashtags = extractHashtags(content);
      const createdBy = getCreatedByValue(req.user?._id);

      // Build post object based on platform
      let postData;

      if (normalizedPlatform === "YOUTUBE") {
        // YouTube-specific post data (all required fields from uploadYouTubeVideoFile)
        if (!result.videoId || !result.channelId || !result.title || !result.description) {
          throw new Error("Missing required YouTube fields in result. Expected: videoId, channelId, title, description");
        }

        postData = {
          userId,
          platform: "YOUTUBE",
          postId: result.videoId, // Use videoId as postId
          videoId: result.videoId,
          channelId: result.channelId,
          title: result.title,
          description: result.description,
          thumbnailUrl: result.thumbnailUrl || "",
          videoUrl: result.videoUrl || `https://www.youtube.com/watch?v=${result.videoId}`,
          postUrl: result.videoUrl || `https://www.youtube.com/watch?v=${result.videoId}`,
          postType: normalizedPostType === "video" ? "upload" : normalizedPostType, // Map "video" to "upload"
          publishedAt: new Date(),
          createdBy,
          hashtags,
          analyticsStatus: "pending",
        };

        console.log("[PostToSinglePlatform] Built YouTube post data with all required fields");
      } else {
        // Other platforms (Facebook, Instagram, LinkedIn)
        const resolvedPostId =
          normalizedPlatform === "FACEBOOK"
            ? (result.post_id || result.postId || result.id)
            : (result.postId || result.id);
        const postId = resolvedPostId || `temp_${Date.now()}`;

        if (!postId) {
          throw new Error("Failed to extract post ID from platform response");
        }

        // Upload files to S3 and get public URLs
        let mediaUrl = null;
        if (imageFile) {
          mediaUrl = await uploadMulterFileToS3(imageFile, "images", { req });
          console.log("[PostToSinglePlatform] Image uploaded to S3:", mediaUrl);
        } else if (videoFile) {
          mediaUrl = await uploadMulterFileToS3(videoFile, "videos", { req });
          console.log("[PostToSinglePlatform] Video uploaded to S3:", mediaUrl);
        }

        const accountId = appCredential?.credentials?.instagram_account_id
          || appCredential?.credentials?.user_id // LinkedIn user ID
          || appCredential?.credentials?.pages?.[0]?.pageId
          || appCredential?.credentials?.channel?.id
          || null;

        // For Instagram, accountId and pageId are the same, so we only store accountId
        // For Facebook, we need both pageId and accountId
        const isInstagram = normalizedPlatform === "INSTAGRAM";

        postData = {
          userId,
          platform: normalizedPlatform,
          postId: String(postId),
          postType: normalizedPostType,
          content,
          caption: content,
          mediaUrl,
          // Only set pageId for non-Instagram platforms (Facebook, LinkedIn)
          pageId: isInstagram ? null : (pageId || null),
          accountId,
          postUrl: result?.postUrl || null,
          publishedAt: new Date(),
          createdBy,
          hashtags,
          analyticsStatus: "pending",
        };
      }

      // Save post to database
      const savedPost = await Post.create(postData);
      savedPostMeta = {
        id: String(savedPost._id),
        postId: String(savedPost.postId),
        platform: savedPost.platform,
        postUrl: savedPost.postUrl || null,
      };

      console.log("[PostToSinglePlatform] ✅ Post saved to database for analytics:", {
        _id: savedPost._id,
        postId: savedPost.postId,
        platform: savedPost.platform,
        videoId: savedPost.videoId || "N/A",
        channelId: savedPost.channelId || "N/A",
      });
    } catch (saveError) {
      console.error("[PostToSinglePlatform] ❌ Failed to save post to database:", saveError);
      console.error("[PostToSinglePlatform] Error details:", {
        message: saveError.message,
        stack: saveError.stack,
        result: result,
        platform: normalizedPlatform,
      });
      // Don't fail the request if saving to DB fails, but log the error
    }

    return res.json({
      success: true,
      message: "Post published successfully",
      result: {
        ...result,
        postId:
          result?.publishedMediaId ||
          result?.postId ||
          (savedPostMeta ? savedPostMeta.postId : null),
        postUrl:
          result?.postUrl ||
          (savedPostMeta ? savedPostMeta.postUrl : null),
      },
      savedPost: savedPostMeta,
    });
  } catch (err) {
    console.error("Error posting:", err);
    const errorMessage = err.response?.data?.error?.message || err.message || "Posting failed";
    const statusCode = Number(err?.statusCode || err?.status || 500);
    return res.status(statusCode).json({
      success: false,
      message: errorMessage,
      error: err.response?.data || err.message,
    });
  }
};

// Helper function to post Facebook video
async function postToFacebookVideo(userId, pageId, message, videoFile) {
  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "FACEBOOK",
  });

  if (!appCredential) {
    throw new Error("Facebook not connected");
  }

  const page = appCredential.credentials.pages.find(
    (p) => p.pageId === pageId
  );

  if (!page) {
    throw new Error("Page not found");
  }

  const pageToken = page.page_access_token;

  // Upload video file directly to Facebook using buffer (memory storage)
  const form = new FormData();
  form.append("file", videoFile.buffer, {
    filename: videoFile.originalname,
    contentType: videoFile.mimetype,
  });
  form.append("description", message || "");
  form.append("access_token", pageToken);

  const videoRes = await axios.post(
    `https://graph-video.facebook.com/v20.0/${pageId}/videos`,
    form,
    {
      headers: form.getHeaders(),
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    }
  );

  return { postId: videoRes.data.id };
}

// Helper function to post Facebook image
async function postToFacebookImage(userId, pageId, message, imageFile) {
  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "FACEBOOK",
  });

  if (!appCredential) {
    throw new Error("Facebook not connected");
  }

  const page = appCredential.credentials.pages.find(
    (p) => p.pageId === pageId
  );

  if (!page) {
    throw new Error("Page not found");
  }

  const pageToken = page.page_access_token;

  // Upload image file directly to Facebook using buffer (memory storage)
  const form = new FormData();
  form.append("file", imageFile.buffer, {
    filename: imageFile.originalname,
    contentType: imageFile.mimetype,
  });
  form.append("message", message || "");
  form.append("access_token", pageToken);

  const photoRes = await axios.post(
    `https://graph.facebook.com/v20.0/${pageId}/photos`,
    form,
    {
      headers: form.getHeaders(),
    }
  );

  return { postId: photoRes.data.id, post_id: photoRes.data.post_id };
}

// Helper function to post Instagram Reel
async function postToInstagramReel(userId, pageId, caption, videoFile, options = {}) {
  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "INSTAGRAM",
  });

  if (!appCredential) {
    throw new Error("Instagram not connected");
  }

  // Check for new Instagram Business Login structure
  let igAccountId, instagramToken;

  if (appCredential.credentials.instagram_account_id && appCredential.credentials.instagram_user_access_token) {
    // New structure: Instagram Business Login
    igAccountId = appCredential.credentials.instagram_account_id;
    // Use Instagram User access token for posting (Instagram Business Login)
    instagramToken = appCredential.credentials.instagram_user_access_token;
  } else {
    // Fallback: Old structure with pages
    const page = appCredential.credentials.pages?.find(
      (p) => p.pageId === pageId || !pageId
    );

    if (!page || !page.instagram_account_id) {
      throw new Error("Instagram account not found");
    }

    igAccountId = page.instagram_account_id;
    instagramToken = page.page_access_token;
  }

  try {
    // Upload video to S3 first - Instagram requires publicly accessible HTTPS URL
    console.log("[postToInstagramReel] Uploading video to S3...");
    const videoUrl = await uploadMulterFileToS3(videoFile, "videos", options);
    console.log("[postToInstagramReel] Video uploaded to S3:", videoUrl);
    console.log("[postToInstagramReel] Video file size:", videoFile.size);

    // Verify the video URL is accessible (optional check)
    try {
      const headRes = await axios.head(videoUrl, { timeout: 5000, validateStatus: () => true });
      console.log("[postToInstagramReel] Video URL accessibility check:", headRes.status);
      if (headRes.status !== 200) {
        console.warn("[postToInstagramReel] Warning: Video URL may not be accessible. Status:", headRes.status);
      }
    } catch (urlCheckErr) {
      console.warn("[postToInstagramReel] Could not verify video URL accessibility:", urlCheckErr.message);
    }

    // Create reel container - Instagram Reels API uses Instagram Graph API
    // Note: For Reels, we need to use 'REELS' media_type and the video must be publicly accessible
    console.log("[postToInstagramReel] Creating reel container with Instagram Graph API");
    const containerRes = await axios.post(
      `https://graph.instagram.com/v24.0/${igAccountId}/media`,
      null,
      {
        params: {
          media_type: "REELS",
          video_url: videoUrl,
          caption: caption || "",
          access_token: instagramToken,
        },
      }
    ).catch(err => {
      console.error("[postToInstagramReel] Container creation error:", err.response?.data || err.message);
      throw err;
    });

    console.log("[postToInstagramReel] Container response:", containerRes.data);

    if (!containerRes.data || !containerRes.data.id) {
      const errorMsg = containerRes.data?.error?.message || JSON.stringify(containerRes.data);
      throw new Error(`Failed to create reel container: ${errorMsg}`);
    }

    const containerId = containerRes.data.id;

    // Wait for the container to be ready (Instagram requires processing time)
    let status = "IN_PROGRESS";
    let attempts = 0;
    const maxAttempts = 30; // Wait up to 5 minutes
    let statusDetails = null;

    while (status === "IN_PROGRESS" && attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 10000)); // Wait 10 seconds

      try {
        // Use Instagram Graph API for status check
        const statusRes = await axios.get(
          `https://graph.instagram.com/v24.0/${containerId}`,
          {
            params: {
              fields: "status_code,status",
              access_token: instagramToken,
            },
          }
        );

        status = statusRes.data.status_code;
        statusDetails = statusRes.data;
        attempts++;
        console.log(`[postToInstagramReel] Status check ${attempts}: ${status}`, JSON.stringify(statusRes.data, null, 2));

        // If status is ERROR, break immediately
        if (status === "ERROR") {
          // Get more error details using Instagram Graph API
          const errorRes = await axios.get(
            `https://graph.instagram.com/v24.0/${containerId}`,
            {
              params: {
                fields: "status_code,status",
                access_token: instagramToken,
              },
            }
          );
          statusDetails = errorRes.data;
          break;
        }
      } catch (statusErr) {
        console.error("[postToInstagramReel] Status check error:", statusErr.response?.data || statusErr.message);
        throw new Error(`Failed to check container status: ${statusErr.response?.data?.error?.message || statusErr.message}`);
      }
    }

    if (status !== "FINISHED") {
      const errorMessage = statusDetails?.error?.message || statusDetails?.status || `Status: ${status}`;
      console.error("[postToInstagramReel] Container error details:", JSON.stringify(statusDetails, null, 2));
      throw new Error(`Reel container failed. ${errorMessage}`);
    }

    // Publish the reel using Instagram Graph API
    console.log("[postToInstagramReel] Publishing reel with Instagram Graph API");
    const publishRes = await axios.post(
      `https://graph.instagram.com/v24.0/${igAccountId}/media_publish`,
      null,
      {
        params: {
          creation_id: containerId,
          access_token: instagramToken,
        },
      }
    );

    console.log("[postToInstagramReel] Publish response:", publishRes.data);
    const publishedMediaId = publishRes.data.id;
    const postUrl = await getInstagramPermalink(publishedMediaId, instagramToken);

    // No cleanup needed - file is in S3 now
    return {
      postId: publishedMediaId,
      publishedMediaId,
      postUrl,
      containerId,
    };
  } catch (err) {
    const errorMessage = err.response?.data?.error?.message || err.message || "Instagram reel post failed";
    console.error("[postToInstagramReel] Error:", errorMessage, err.response?.data);
    throw new Error(errorMessage);
  }
}

// Helper function to post Instagram image
async function postToInstagramImage(userId, pageId, caption, imageFile, options = {}) {
  validateInstagramImageFile(imageFile);

  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "INSTAGRAM",
  });

  if (!appCredential) {
    throw new Error("Instagram not connected");
  }

  // Check for new Instagram Business Login structure
  let igAccountId, instagramToken;

  if (appCredential.credentials.instagram_account_id && appCredential.credentials.instagram_user_access_token) {
    // New structure: Instagram Business Login
    igAccountId = appCredential.credentials.instagram_account_id;
    // Use Instagram User access token for posting (Instagram Business Login)
    instagramToken = appCredential.credentials.instagram_user_access_token;
  } else {
    // Fallback: Old structure with pages
    const page = appCredential.credentials.pages?.find(
      (p) => p.pageId === pageId || !pageId
    );

    if (!page || !page.instagram_account_id) {
      throw new Error("Instagram account not found");
    }

    igAccountId = page.instagram_account_id;
    instagramToken = page.page_access_token;
  }

  try {
    // Upload image to S3 first - Instagram requires publicly accessible HTTPS URL
    console.log("[postToInstagramImage] Uploading image to S3...");
    const imageUrl = await uploadMulterFileToS3(imageFile, "images", options);
    console.log("[postToInstagramImage] Image uploaded to S3:", imageUrl);
    console.log("[postToInstagramImage] Image file size:", imageFile.size);

    // Verify the image URL is accessible (optional check)
    try {
      const headRes = await axios.head(imageUrl, {
        timeout: 5000,
        validateStatus: () => true,
        maxRedirects: 5
      });
      console.log("[postToInstagramImage] Image URL accessibility check:", headRes.status);
      if (headRes.status !== 200) {
        console.warn("[postToInstagramImage] Warning: Image URL may not be accessible. Status:", headRes.status);
      }
    } catch (urlCheckErr) {
      console.warn("[postToInstagramImage] Could not verify image URL accessibility:", urlCheckErr.message);
      // Don't fail here, let Instagram API handle it
    }

    // Create media container using Instagram Graph API
    console.log("[postToInstagramImage] Creating media container with Instagram Graph API");
    const containerRes = await axios.post(
      `https://graph.instagram.com/v24.0/${igAccountId}/media`,
      null,
      {
        params: {
          image_url: imageUrl,
          caption: caption || "",
          access_token: instagramToken,
        },
      }
    );

    if (!containerRes.data || !containerRes.data.id) {
      throw new Error(`Failed to create media container: ${JSON.stringify(containerRes.data)}`);
    }

    const containerId = containerRes.data.id;
    console.log("[postToInstagramImage] Container created with ID:", containerId);

    // Wait for the container to be ready (Instagram requires processing time)
    let status = "IN_PROGRESS";
    let attempts = 0;
    const maxAttempts = 30; // Wait up to 5 minutes (30 * 10 seconds)
    let statusDetails = null;

    console.log("[postToInstagramImage] Waiting for container to be ready...");
    while (status === "IN_PROGRESS" && attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 10000)); // Wait 10 seconds

      try {
        // Check container status using Instagram Graph API
        const statusRes = await axios.get(
          `https://graph.instagram.com/v24.0/${containerId}`,
          {
            params: {
              fields: "status_code,status",
              access_token: instagramToken,
            },
          }
        );

        status = statusRes.data.status_code;
        statusDetails = statusRes.data;
        attempts++;
        console.log(`[postToInstagramImage] Status check ${attempts}: ${status}`, JSON.stringify(statusRes.data, null, 2));

        // If status is ERROR, break immediately
        if (status === "ERROR") {
          // Get more error details
          const errorRes = await axios.get(
            `https://graph.instagram.com/v24.0/${containerId}`,
            {
              params: {
                fields: "status_code,status",
                access_token: instagramToken,
              },
            }
          );
          statusDetails = errorRes.data;
          break;
        }
      } catch (statusErr) {
        console.error("[postToInstagramImage] Status check error:", statusErr.response?.data || statusErr.message);
        throw new Error(`Failed to check container status: ${statusErr.response?.data?.error?.message || statusErr.message}`);
      }
    }

    if (status !== "FINISHED") {
      const errorMessage = statusDetails?.error?.message || statusDetails?.status || `Status: ${status}`;
      console.error("[postToInstagramImage] Container error details:", JSON.stringify(statusDetails, null, 2));
      throw new Error(`Media container failed. ${errorMessage}`);
    }

    console.log("[postToInstagramImage] Container is ready, publishing...");

    // Publish the media using Instagram Graph API
    console.log("[postToInstagramImage] Publishing media with Instagram Graph API");
    const publishRes = await axios.post(
      `https://graph.instagram.com/v24.0/${igAccountId}/media_publish`,
      null,
      {
        params: {
          creation_id: containerId,
          access_token: instagramToken,
        },
      }
    );
    const publishedMediaId = publishRes.data.id;
    const postUrl = await getInstagramPermalink(publishedMediaId, instagramToken);

    // No cleanup needed - file is in S3 now
    return {
      postId: publishedMediaId,
      publishedMediaId,
      postUrl,
      containerId,
    };
  } catch (err) {
    const errorMessage = err.response?.data?.error?.message || err.message || "Instagram post failed";
    console.error("[postToInstagramImage] Error:", errorMessage, err.response?.data);
    throw new Error(errorMessage);
  }
}

// Helper function to upload YouTube video and fetch all required details
async function uploadYouTubeVideoFile(userId, content, videoFile, options = {}) {
  const { isShort = false } = options;

  // Get valid access token
  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "YOUTUBE",
  });

  if (!appCredential || !appCredential.credentials.refresh_token) {
    throw new Error("YouTube not connected or no refresh token found");
  }

  const tokens = appCredential.credentials;
  const now = Date.now();

  let accessToken = tokens.access_token;

  // Check if token is still valid (with 1 minute buffer)
  if (!tokens.expiry || now >= tokens.expiry - 60000) {
    // Get YouTube/Google app config from database (with fallback to env)
    let youtubeConfig;
    try {
      youtubeConfig = await getAppConfig(userId, "app/youtube");
    } catch (error) {
      console.error("[YouTube Social Media] Error getting app config:", error.message);
      throw new Error("YouTube app configuration not found");
    }

    // Refresh token
    const refreshRes = await axios.post("https://oauth2.googleapis.com/token", {
      client_id: youtubeConfig.appClientId,
      client_secret: youtubeConfig.appClientSecret,
      refresh_token: tokens.refresh_token,
      grant_type: "refresh_token",
    });

    accessToken = refreshRes.data.access_token;
    const newExpiry = Date.now() + refreshRes.data.expires_in * 1000;

    // Update in database
    await AppCredentials.findOneAndUpdate(
      { userId, platform: "YOUTUBE" },
      {
        $set: {
          "credentials.access_token": accessToken,
          "credentials.expires_in": refreshRes.data.expires_in,
          "credentials.expiry": newExpiry,
        },
      }
    );
  }

  try {
    // Prepare title and description for Shorts
    let title = content.split("\n")[0] || (isShort ? "Untitled Short" : "Untitled Video");
    let description = content || "";

    // For YouTube Shorts, add #Shorts tag to title and description
    // YouTube uses this to recognize and promote content as Shorts
    if (isShort) {
      // Add #Shorts to the title if not already present
      if (!title.toLowerCase().includes("#shorts")) {
        title = `${title} #Shorts`;
      }
      // Also add #Shorts to description if not present
      if (!description.toLowerCase().includes("#shorts")) {
        description = `${description}\n\n#Shorts`;
      }
      console.log("[uploadYouTubeVideoFile] Uploading as YouTube Short with #Shorts tag");
    }

    // Step 1: Upload file to S3 first and use public URL as source of truth
    console.log("[uploadYouTubeVideoFile] Step 1: Uploading video to S3");
    const s3VideoUrl = await uploadMulterFileToS3(videoFile, "videos/youtube", options);
    console.log("[uploadYouTubeVideoFile] S3 video URL:", s3VideoUrl);

    // Step 2: Download the S3-hosted bytes for YouTube upload
    console.log("[uploadYouTubeVideoFile] Step 2: Fetching uploaded video bytes from S3 URL");
    const s3VideoResponse = await axios.get(s3VideoUrl, {
      responseType: "arraybuffer",
    });
    const videoBuffer = Buffer.from(s3VideoResponse.data);
    const contentType = videoFile.mimetype || "video/mp4";

    // Step 3: Create YouTube resumable upload session
    console.log("[uploadYouTubeVideoFile] Step 3: Creating YouTube resumable upload session");
    const createRes = await axios.post(
      "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
      {
        snippet: {
          title: title,
          description: description,
        },
        status: {
          privacyStatus: "public",
        },
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json; charset=UTF-8",
          "X-Upload-Content-Length": videoBuffer.length,
          "X-Upload-Content-Type": contentType,
        },
      }
    );

    const uploadUrl = createRes.headers.location;

    // Step 4: Upload the actual file bytes to YouTube
    console.log("[uploadYouTubeVideoFile] Step 4: Uploading video file to YouTube");
    const uploadRes = await axios.put(uploadUrl, videoBuffer, {
      headers: {
        "Content-Length": videoBuffer.length,
        "Content-Type": contentType,
      },
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    });

    // Step 3: Get videoId from upload response
    const videoId = uploadRes.data.id;
    if (!videoId) {
      throw new Error("Failed to get video ID from YouTube upload response");
    }
    console.log("[uploadYouTubeVideoFile] Step 3: Video uploaded successfully, videoId:", videoId);

    // Step 4: Fetch video details using YouTube Data API
    console.log("[uploadYouTubeVideoFile] Step 4: Fetching video details from YouTube Data API");
    const videoDetailsRes = await axios.get(
      "https://www.googleapis.com/youtube/v3/videos",
      {
        params: {
          part: "snippet,contentDetails,status",
          id: videoId,
        },
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    const videoDetails = videoDetailsRes.data.items?.[0];
    if (!videoDetails) {
      throw new Error("Failed to fetch video details from YouTube");
    }

    // Step 5: Extract required fields from the uploaded video
    const channelId = videoDetails.snippet.channelId;
    const uploadedTitle = videoDetails.snippet.title;
    const uploadedDescription = videoDetails.snippet.description || "";

    // Get thumbnail URL (highest quality available)
    const thumbnails = videoDetails.snippet.thumbnails;
    const thumbnailUrl = thumbnails.maxres?.url || thumbnails.high?.url || thumbnails.medium?.url || thumbnails.default?.url || "";

    // Build YouTube video URL
    const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;

    console.log("[uploadYouTubeVideoFile] Step 5: Extracted video details:", {
      videoId,
      channelId,
      title: uploadedTitle.substring(0, 50) + "...",
      hasDescription: !!uploadedDescription,
      hasThumbnail: !!thumbnailUrl,
    });

    // No cleanup needed - file is in memory (buffer), not on disk

    // Step 7: Return complete YouTube post data
    return {
      postId: videoId,
      videoId,
      channelId,
      title: uploadedTitle,
      description: uploadedDescription,
      thumbnailUrl,
      videoUrl,
      sourceMediaUrl: s3VideoUrl,
      // Include access token for potential future use
      accessToken,
    };
  } catch (err) {
    console.error("[uploadYouTubeVideoFile] Error:", err.response?.data || err);
    throw new Error(err.response?.data?.error?.message || err.message || "YouTube upload failed");
  }
}

// Get all scheduled posts for a user
export const getScheduledPosts = async (req, res) => {
  try {
    if (!req.user?._id) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const userId = String(req.user._id);

    // Fetch all scheduled posts for this user
    const scheduledPosts = await Post.find({
      userId,
      status: "SCHEDULED"
    })
      .sort({ scheduledFor: 1 }) // Sort by scheduled time, earliest first
      .lean();

    return res.json({
      success: true,
      posts: scheduledPosts
    });
  } catch (err) {
    console.error("[getScheduledPosts] Error:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch scheduled posts"
    });
  }
};

// Delete a scheduled post
export const deleteScheduledPost = async (req, res) => {
  try {
    if (!req.user?._id) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const userId = String(req.user._id);
    const { id } = req.params;

    // Find the post
    const post = await Post.findById(id);

    if (!post) {
      return res.status(404).json({
        success: false,
        message: "Post not found"
      });
    }

    // Verify ownership
    if (String(post.userId) !== userId) {
      return res.status(403).json({
        success: false,
        message: "Unauthorized to delete this post"
      });
    }

    // Verify it's a scheduled post
    if (post.status !== "SCHEDULED") {
      return res.status(400).json({
        success: false,
        message: "Only scheduled posts can be deleted"
      });
    }

    if (isRedisConfigured()) {
      try {
        await cancelScheduledPost(id);
      } catch (queueError) {
        console.error("[deleteScheduledPost] Failed to cancel Redis job:", queueError);
      }
    }

    // Delete the post
    await Post.findByIdAndDelete(id);

    return res.json({
      success: true,
      message: "Scheduled post deleted successfully"
    });
  } catch (err) {
    console.error("[deleteScheduledPost] Error:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to delete scheduled post"
    });
  }
};

export const getMediaGallery = async (req, res) => {
  try {
    if (!req.user?._id) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const userId = String(req.user._id);
    const type = req.query?.type;
    const query = { userId };

    if (type === "image" || type === "video") {
      query.type = type;
    }

    const items = await Gallery.find(query).sort({ createdAt: -1 }).lean();

    return res.json({
      success: true,
      items,
    });
  } catch (err) {
    console.error("[getMediaGallery] Error:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch media gallery",
    });
  }
};

export const deleteMediaGalleryItem = async (req, res) => {
  try {
    if (!req.user?._id) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const userId = String(req.user._id);
    const { id } = req.params;

    const item = await Gallery.findById(id);
    if (!item) {
      return res.status(404).json({
        success: false,
        message: "Media item not found",
      });
    }

    if (String(item.userId) !== userId) {
      return res.status(403).json({
        success: false,
        message: "Unauthorized to delete this media item",
      });
    }

    await Gallery.findByIdAndDelete(id);
    await syncUserMediaStorageGb(userId, req.user?.email || null);

    return res.json({
      success: true,
      message: "Media item deleted successfully",
    });
  } catch (err) {
    console.error("[deleteMediaGalleryItem] Error:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to delete media item",
    });
  }
};

// Upload media to S3 for media gallery
export const uploadMedia = async (req, res) => {
  try {
    if (!req.user?._id) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const userId = String(req.user._id);
    const resellerId = req.user?.resellerId || null;
    const imageFile = req.files?.image?.[0];
    const videoFile = req.files?.video?.[0];
    const file = imageFile || videoFile;

    if (!file) {
      return res.status(400).json({
        success: false,
        message: "No file provided",
      });
    }

    const type = imageFile ? "image" : "video";
    const folder = imageFile ? "media/images" : "media/videos";
    const url = await uploadMulterFileToS3(file, folder, { req });

    const galleryItem = await Gallery.create({
      userId,
      resellerId,
      name: file.originalname,
      type,
      size: file.size,
      url,
    });
    await syncUserMediaStorageGb(userId, req.user?.email || null);

    return res.json({
      success: true,
      url,
      type,
      name: file.originalname,
      size: file.size,
      media: galleryItem,
    });
  } catch (err) {
    console.error("[uploadMedia] Error:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to upload media",
    });
  }
};

