import AppCredentials from "../../models/appcredentials.model.js";
import Post from "../../models/post.model.js";
import { postToFacebook } from "../facebook/facebook.controller.js";
import { uploadInstagramMedia } from "../instagram/instagram.controller.js";
import { postToLinkedIn } from "../linkedin/linkedin.controller.js";
import { uploadYouTubeVideo } from "../youtube/youtube.controller.js";
import { uploadBase64Image } from "./upload-image.controller.js";
import { uploadMulterFileToS3 } from "../../utils/s3-upload.js";
import axios from "axios";
import FormData from "form-data";
import { getAppConfig } from "../../utils/getAppConfig.js";

// ... (existing code - all the other functions remain the same)

// Upload media to S3 for media gallery
export const uploadMedia = async (req, res) => {
    try {
        if (!req.user?._id) {
            return res.status(401).json({ message: "Unauthorized" });
        }

        const imageFile = req.files?.image?.[0];
        const videoFile = req.files?.video?.[0];
        const file = imageFile || videoFile;

        if (!file) {
            return res.status(400).json({
                success: false,
                message: "No file provided"
            });
        }

        // Upload to S3
        const folder = imageFile ? "media/images" : "media/videos";
        const url = await uploadMulterFileToS3(file, folder, { req });

        return res.json({
            success: true,
            url,
            type: imageFile ? "image" : "video",
            name: file.originalname,
            size: file.size
        });
    } catch (err) {
        console.error("[uploadMedia] Error:", err);
        return res.status(500).json({
            success: false,
            message: "Failed to upload media"
        });
    }
};
