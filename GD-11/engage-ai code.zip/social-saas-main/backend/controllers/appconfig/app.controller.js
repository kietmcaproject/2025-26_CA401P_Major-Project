import mongoose from "mongoose";
import AppConfig from "../../models/appconfig.schema.js";
import AppCredentials from "../../models/appcredentials.model.js";
import { handleInstagramConnect } from "./connection-functions.js";

/**
 * ========================================================
 * Helper: Decode OAuth State
 * ========================================================
 */
const decodeOAuthState = (state) => {
  try {
    return JSON.parse(Buffer.from(state, "base64").toString("utf-8"));
  } catch {
    return null;
  }
};

/**
 * ========================================================
 * Resolve OAuth App Config
 *
 * Order:
 * 1. Reseller AppConfig (MANDATORY if resellerId exists)
 * 2. ENV fallback (ONLY if reseller config not found)
 * ========================================================
 */
export const resolveAppConfig = async (appName, resellerId, userId) => {
  console.log("--------------------------------------------------");
  console.log("[resolveAppConfig] START");
  console.log("[resolveAppConfig] appName:", appName);
  console.log("[resolveAppConfig] resellerId (raw):", resellerId);
  console.log(
    "[resolveAppConfig] resellerId valid ObjectId:",
    resellerId && mongoose.Types.ObjectId.isValid(resellerId)
  );

  // 1️⃣ Try user-level config first (Highest Priority)
  if (userId) {
    const userConfig = await AppConfig.findOne({
      appName,
      userId,
      type: "user",
      userId,
      type: "user",
    }).lean();

    console.log(`[resolveAppConfig] Checking user config for app: ${appName}, userId: ${userId}`);
    console.log(`[resolveAppConfig] Query result: ${userConfig ? "FOUND" : "NOT FOUND"}`);

    if (userConfig) {
      console.log("[resolveAppConfig] ✅ USING USER CONFIG");
      return {
        appClientId: userConfig.appClientId,
        appClientSecret: userConfig.appClientSecret,
        redirectUrl: userConfig.redirectUrl,
        source: "database", // user-level
      };
    }
  }

  // 2️⃣ Try reseller config next
  if (resellerId && mongoose.Types.ObjectId.isValid(resellerId)) {
    const resellerObjectId = new mongoose.Types.ObjectId(resellerId);
    console.log("[resolveAppConfig] resellerObjectId:", resellerObjectId.toString());

    const resellerConfig = await AppConfig.findOne({
      appName,
      resellerId: resellerObjectId,
      type: "reseller",
    }).lean();

    console.log(
      "[resolveAppConfig] DB QUERY RESULT:",
      resellerConfig ? "FOUND" : "NOT FOUND"
    );

    if (resellerConfig) {
      console.log("[resolveAppConfig] ✅ USING RESELLER CONFIG");
      console.log("[resolveAppConfig] resellerConfig:", resellerConfig);

      return {
        appClientId: resellerConfig.appClientId,
        appClientSecret: resellerConfig.appClientSecret,
        redirectUrl: resellerConfig.redirectUrl,
        source: "reseller",
      };
    }
  }

  console.warn("[resolveAppConfig] ⚠️ FALLING BACK TO ENV");

  const ENV_MAP = {
    "app/instagram": {
      appClientId: process.env.INSTAGRAM_APP_ID || process.env.META_APP_ID,
      appClientSecret:
        process.env.INSTAGRAM_APP_SECRET || process.env.META_APP_SECRET,
      redirectUrl: process.env.INSTAGRAM_REDIRECT_URI,
    },
    "app/facebook": {
      appClientId: process.env.FACEBOOK_APP_ID || process.env.META_APP_ID,
      appClientSecret:
        process.env.FACEBOOK_APP_SECRET || process.env.META_APP_SECRET,
      redirectUrl:
        process.env.FACEBOOK_REDIRECT_URI ||
        process.env.INSTAGRAM_REDIRECT_URI,
    },
    "app/linkedin": {
      appClientId: process.env.LINKEDIN_CLIENT_ID,
      appClientSecret: process.env.LINKEDIN_CLIENT_SECRET,
      redirectUrl: process.env.LINKEDIN_REDIRECT_URI,
    },
    "app/youtube": {
      appClientId: process.env.GOOGLE_CLIENT_ID,
      appClientSecret: process.env.GOOGLE_CLIENT_SECRET,
      redirectUrl: process.env.GOOGLE_REDIRECT_URI,
    },
  };

  console.log("[resolveAppConfig] ENV USED FOR:", appName);
  console.log("--------------------------------------------------");

  return ENV_MAP[appName]
    ? { ...ENV_MAP[appName], source: "env" }
    : null;
};


/**
 * ========================================================
 * SAVE / UPDATE APP CONFIG (RESELLER ONLY)
 * ========================================================
 */
export const appSaveConfigController = async (req, res) => {
  try {
    if (!req.user?._id) {
      return res.status(401).json({
        status: false,
        message: "Unauthorized",
      });
    }

    const { clientId, clientSecret, redirectUrl, appname, scope } = req.body;

    // Determine if saving as Reseller (Global) or User (Personal)
    // For now, if user is not reseller, it's personal.
    // Even if user IS reseller, they might want to save personal config?
    // We will assume:
    // - If Reseller wants to set GLOBAL config, they use a different UI/Endpoint (or we need a flag).
    // - BUT current `credentials-dialog` implies personal usage usually.
    // - HOWEVER, existing logic was "Reseller sets Global Config".
    // 
    // New Logic: 
    // Always save as "Personal" (User Config) unless specifically handling Reseller Global Config.
    // Since we are reusing this endpoint "appSaveConfigController" which was previously Reseller-only:
    // We should check: IF req.user.role === 'reseller' AND they intend to save global...

    // Wait, the prompt implies "user can add their own app credentials". 
    // So we should default to User Config unless maybe explicitly told otherwise?
    // BUT, the existing dashboard for resellers used this to set global config.
    // Let's assume: If user is "reseller", they are setting GLOBAL config (resellerId based).
    // If user is NOT "reseller", they are setting USER config (userId based).
    // This preserves existing reseller behavior while enabling user behavior.

    const isResellerSave = req.user.role === "reseller" && scope === "global";
    const resellerId = req.user.resellerId;
    const userId = req.user._id;

    console.log("[appSaveConfigController] Saving config:");
    console.log("appname:", appname);
    console.log("Saving as:", isResellerSave ? "Reseller Global" : "User Personal");

    let filter = {};
    let updateData = {
      appName: appname,
      appClientId: clientId,
      appClientSecret: clientSecret,
      redirectUrl,
      redirectUrl,
      createdBy: userId,
      type: isResellerSave ? "reseller" : "user",
    };

    if (isResellerSave) {
      if (!mongoose.Types.ObjectId.isValid(resellerId)) {
        return res.status(400).json({ status: false, message: "Invalid resellerId" });
      }
      // RESELLER GLOBAL CONFIG
      filter = {
        appName: appname,
        resellerId: new mongoose.Types.ObjectId(resellerId),
        type: "reseller"
      };
      updateData.resellerId = new mongoose.Types.ObjectId(resellerId);
      // Ensure we don't look for userId in this filter
      updateData.userId = undefined;
    } else {
      // USER PERSONAL CONFIG
      // Even if user is a Reseller, they are saving a personal config here.
      filter = {
        appName: appname,
        userId: userId,
        type: "user"
      };
      updateData.userId = userId;

      // Store resellerId even in user config if available, but keep type="user"
      // This helps with data completeness but query priority relies on "type"
      if (resellerId && mongoose.Types.ObjectId.isValid(resellerId)) {
        updateData.resellerId = new mongoose.Types.ObjectId(resellerId);
      } else {
        updateData.resellerId = undefined;
      }
    }

    const saved = await AppConfig.findOneAndUpdate(
      filter,
      updateData,
      { upsert: true, new: true }
    );

    return res.json({
      status: true,
      message: "App Config Saved Successfully",
      data: saved,
    });
  } catch (error) {
    console.error("[appSaveConfigController]", error);
    return res.status(500).json({ status: false, message: error.message });
  }
};

/**
 * ========================================================
 * GET AVAILABLE INTEGRATIONS
 * ========================================================
 */
export const getAppsArry = async (req, res) => {
  try {
    if (!req.user?._id) {
      return res.status(401).json({ status: false, message: "Unauthorized" });
    }

    const resellerId = req.user.resellerId;
    const userId = String(req.user._id);

    const connectedPlatforms = await AppCredentials.find({
      userId,
      platform: { $in: ["FACEBOOK", "INSTAGRAM", "LINKEDIN", "YOUTUBE"] },
    }).lean();

    const baseIntegrations = [
      { name: "Instagram", appname: "app/instagram", platform: "INSTAGRAM" },
      { name: "Facebook Page", appname: "app/facebook", platform: "FACEBOOK" },
      { name: "LinkedIn", appname: "app/linkedin", platform: "LINKEDIN" },
      { name: "YouTube", appname: "app/youtube", platform: "YOUTUBE" },
    ];

    const integrations = await Promise.all(

      baseIntegrations.map(async (integration) => {
        // 1. Resolve effective config (User > Reseller > Env)
        const config = await resolveAppConfig(
          integration.appname,
          resellerId,
          userId
        );

        // 2. Explicitly fetch Reseller Config (if resellerId exists)
        // This allows the frontend to show "Reseller Global Identity" even if overridden by User.
        let resellerConfig = null;
        if (resellerId && mongoose.Types.ObjectId.isValid(resellerId)) {
          const rc = await AppConfig.findOne({
            appName: integration.appname,
            resellerId: new mongoose.Types.ObjectId(resellerId),
            type: "reseller"
          }).lean();

          if (rc) {
            resellerConfig = {
              appClientId: rc.appClientId,
              redirectUrl: rc.redirectUrl,
              source: "reseller"
            };
          }
        }

        return {
          ...integration,
          connected: connectedPlatforms.some(
            (p) => p.platform === integration.platform
          ),
          config: config
            ? {
              appClientId: config.appClientId,
              redirectUrl: config.redirectUrl,
              source: config.source,
            }
            : null,
          resellerConfig: resellerConfig
        };
      })
    );

    return res.json({ status: true, data: { integrations } });
  } catch (error) {
    console.error("[getAppsArry]", error);
    return res.status(500).json({ status: false, message: error.message });
  }
};

/**
 * ========================================================
 * HANDLE CONNECT (OAUTH CALLBACK)
 * ========================================================
 */
export const handleTheConnect = async (req, res) => {
  try {
    const { code, appname, state } = req.body;

    // Restore user context from OAuth state (IMPORTANT)
    if (!req.user && state) {
      const decoded = decodeOAuthState(state);
      if (decoded?.userId) {
        req.user = {
          _id: decoded.userId,
          resellerId: decoded.resellerId || null,
        };
      }
    }

    if (!req.user?._id) {
      return res.status(401).json({
        status: false,
        message: "Unauthorized OAuth callback",
      });
    }

    const appConfig = await resolveAppConfig(
      appname,
      req.user.resellerId,
      req.user._id
    );

    if (!appConfig) {
      return res.status(400).json({
        status: false,
        message: "OAuth app not configured",
      });
    }

    if (appname === "app/instagram") {
      return await handleInstagramConnect(req, res, code, appConfig);
    }

    return res.status(400).json({
      status: false,
      message: "Unsupported platform",
    });
  } catch (error) {
    console.error("[handleTheConnect]", error);
    return res.status(500).json({
      status: false,
      message: error.message,
    });
  }
};
