import RoleModel from "../models/role.model.js";
import MemberModel from "../models/member.model.js";
import OrganisationModel from "../models/organisation.model.js";
import { PERMISSIONS, AVAILABLE_PERMISSIONS } from "../config/permissions.js";

// Reusing helper from members.controller, but ideally should be in a shared service
// For now, duplicating logic for speed, or importing?
// Imports across controllers can be messy if circular. 
// I'll implement a local checkPermission helper that queries effectively.

const checkPermission = async (reqOrgId, userId, requiredPermission) => {
    const membership = await MemberModel.findOne({ organisationId: reqOrgId, userId }).populate("roleId");
    if (!membership) return false;

    // Owner always has permission
    const org = await OrganisationModel.findById(reqOrgId);
    if (org && org.ownerId === userId) return true;

    // Check permissions
    const rolePermissions = membership.roleId?.permissions || [];
    const extraPermissions = membership.extraPermissions || [];
    const allPermissions = [...rolePermissions, ...extraPermissions];

    if (allPermissions.includes("*")) return true;
    return allPermissions.includes(requiredPermission);
};

export const listRoles = async (req, res) => {
    try {
        const { orgId } = req.params;
        const currentUserId = req.user.userId;

        if (!(await checkPermission(orgId, currentUserId, "role.view"))) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const roles = await RoleModel.find({ organisationId: orgId }).lean();

        // Sort: Default roles first, then by name
        roles.sort((a, b) => {
            if (a.isDefault && !b.isDefault) return -1;
            if (!a.isDefault && b.isDefault) return 1;
            return a.name.localeCompare(b.name);
        });

        res.status(200).json({ success: true, data: roles });
    } catch (error) {
        console.error("Error listing roles:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const getAvailablePermissions = async (req, res) => {
    try {
        const { orgId } = req.params;
        const currentUserId = req.user.userId;

        if (!(await checkPermission(orgId, currentUserId, "role.view"))) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        res.status(200).json({
            success: true,
            data: {
                permissions: AVAILABLE_PERMISSIONS,
                metadata: PERMISSIONS
            }
        });
    } catch (error) {
        console.error("Error getting permissions:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const getMyPermissions = async (req, res) => {
    try {
        const { orgId } = req.params;
        const currentUserId = req.user.userId;

        // Any member can access
        const membership = await MemberModel.findOne({ organisationId: orgId, userId: currentUserId }).populate("roleId");
        if (!membership) {
            return res.status(403).json({ success: false, message: "Not a member" });
        }

        const org = await OrganisationModel.findById(orgId);
        const isOwner = org.ownerId === currentUserId;

        const rolePermissions = membership.roleId?.permissions || [];
        const extraPermissions = membership.extraPermissions || [];

        let effectivePermissions = [];
        if (isOwner) {
            effectivePermissions = ["*"]; // Or return all available? Spec says "ALL PERMISSIONS". "*" usually signifies all.
            // Or I can return AVAILABLE_PERMISSIONS array.
            // Spec: "permissions = ALL PERMISSIONS".
            // Generally "*" is cleaner if frontend understands it. 
            // But let's verify if "CASL" logic expects explicit list.
            // If I return ["*"], frontend CASL needs to handle it.
            // Let's assume standard CASL `can('manage', 'all')` equates to `*` or similar.
            // But if the frontend expects a list of strings to check `.includes()`, "*" might fail unless handled.
            // I will return the full list of AVAILABLE_PERMISSIONS plus "*" just in case.
            effectivePermissions = [...AVAILABLE_PERMISSIONS, "*"];
        } else {
            effectivePermissions = [...new Set([...rolePermissions, ...extraPermissions])];
        }

        res.status(200).json({
            success: true,
            data: {
                memberId: membership._id,
                isOwner,
                role: membership.roleId,
                permissions: effectivePermissions, // The spec has separate "permissions" and "extraPermissions" in response
                extraPermissions: extraPermissions // also included in spec
            }
        });
    } catch (error) {
        console.error("Error getting my permissions:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const getRoleById = async (req, res) => {
    try {
        const { orgId, roleId } = req.params;
        const currentUserId = req.user.userId;

        if (!(await checkPermission(orgId, currentUserId, "role.view"))) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const role = await RoleModel.findOne({ _id: roleId, organisationId: orgId });
        if (!role) return res.status(404).json({ success: false, message: "Role not found" });

        res.status(200).json({ success: true, data: role });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

export const createRole = async (req, res) => {
    try {
        const { orgId } = req.params;
        const { name, description, permissions } = req.body;
        const currentUserId = req.user.userId;

        if (!(await checkPermission(orgId, currentUserId, "role.create"))) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        // Validate permissions
        if (permissions && !permissions.every(p => AVAILABLE_PERMISSIONS.includes(p))) {
            // In strict mode we might error.
            // For now allow, or filter?
            // Spec says "Permissions validated".
            const validPermissions = permissions.filter(p => AVAILABLE_PERMISSIONS.includes(p));
            if (validPermissions.length !== permissions.length) {
                return res.status(400).json({ success: false, message: "Invalid permissions provided" });
            }
        }

        const slug = name.toLowerCase().replace(/ /g, "-").replace(/[^\w-]+/g, "");

        // Check uniqueness of slug within org?
        const existing = await RoleModel.findOne({ organisationId: orgId, slug });
        if (existing) {
            return res.status(400).json({ success: false, message: "Role with this name already exists" });
        }

        const newRole = new RoleModel({
            name,
            slug,
            description,
            permissions,
            organisationId: orgId,
            isSystem: false,
            isDefault: false
        });

        await newRole.save();

        res.status(201).json({ success: true, data: newRole });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

export const updateRole = async (req, res) => {
    try {
        const { orgId, roleId } = req.params;
        const { name, description, permissions } = req.body;
        const currentUserId = req.user.userId;

        if (!(await checkPermission(orgId, currentUserId, "role.edit"))) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const role = await RoleModel.findOne({ _id: roleId, organisationId: orgId });
        if (!role) return res.status(404).json({ success: false, message: "Role not found" });

        // Rules
        if (role.slug === "owner") {
            return res.status(400).json({ success: false, message: "Cannot modify Owner role" });
        }

        if (role.isSystem) {
            // Limited updates? Spec says "Limited". Maybe name/desc ok, permissions no?
            // Or maybe just verify permissions carefully?
            // Let's assume for now System roles cannot change permissions.
            if (permissions && JSON.stringify(permissions) !== JSON.stringify(role.permissions)) {
                // return res.status(400).json({ success: false, message: "Cannot change permissions of System role" });
                // Actually spec says "System role: Limited".
                // I'll allow description update, basically.
            }
        }

        if (name) {
            role.name = name;
            role.slug = name.toLowerCase().replace(/ /g, "-").replace(/[^\w-]+/g, "");
        }
        if (description !== undefined) role.description = description;
        if (permissions && !role.isSystem) {
            if (!permissions.every(p => AVAILABLE_PERMISSIONS.includes(p))) {
                return res.status(400).json({ success: false, message: "Invalid permissions" });
            }
            role.permissions = permissions;
        }

        await role.save();
        res.status(200).json({ success: true, data: role });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

export const deleteRole = async (req, res) => {
    try {
        const { orgId, roleId } = req.params;
        const currentUserId = req.user.userId;

        if (!(await checkPermission(orgId, currentUserId, "role.delete"))) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const role = await RoleModel.findOne({ _id: roleId, organisationId: orgId });
        if (!role) return res.status(404).json({ success: false, message: "Role not found" });

        if (role.isSystem) {
            return res.status(400).json({ success: false, message: "Cannot delete system roles" });
        }

        // Check usage
        const usageCount = await MemberModel.countDocuments({ roleId });
        if (usageCount > 0) {
            return res.status(400).json({ success: false, message: "Cannot delete role in use by members" });
        }

        await RoleModel.findByIdAndDelete(roleId);
        res.status(200).json({ success: true, message: "Role deleted" });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

export const assignRole = async (req, res) => {
    try {
        const { orgId } = req.params;
        const { memberId, roleId } = req.body;
        const currentUserId = req.user.userId;

        if (!(await checkPermission(orgId, currentUserId, "role.assign"))) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const member = await MemberModel.findOne({ _id: memberId, organisationId: orgId });
        if (!member) return res.status(404).json({ success: false, message: "Member not found" });

        const org = await OrganisationModel.findById(orgId);
        if (org.ownerId === member.userId && currentUserId !== org.ownerId) {
            // Owner role can only be assigned by owner? 
            // Actually, "Owner's role cannot be changed" says spec.
            return res.status(400).json({ success: false, message: "Cannot change role of Owner" });
        }

        // If I am owner, I can change my own role? Spec says "Owner's role cannot be changed".
        // So even if I am owner, I can't change my own role (which is Owner role) to something else.
        if (org.ownerId === member.userId) {
            return res.status(400).json({ success: false, message: "Owner cannot change their own role" });
        }

        const newRole = await RoleModel.findById(roleId);
        if (!newRole || newRole.organisationId.toString() !== orgId) {
            return res.status(400).json({ success: false, message: "Invalid role" });
        }

        member.roleId = roleId;
        await member.save();

        await member.populate("roleId");

        res.status(200).json({ success: true, data: member });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};
