import OrganisationModel from "../models/organisation.model.js";
import RoleModel from "../models/role.model.js";
import MemberModel from "../models/member.model.js";
import UserModel from "../models/user.model.js";
import mongoose from "mongoose";
import { uploadMulterFileToS3 } from "../utils/s3-upload.js";

// Default roles to seed
const DEFAULT_ROLES = [
    {
        name: "Owner",
        slug: "owner",
        permissions: ["org.update", "org.delete", "member.invite", "member.remove", "member.update", "role.create", "role.update", "role.delete"],
    },
    {
        name: "Admin",
        slug: "admin",
        permissions: ["member.invite", "member.remove", "member.update"],
    },
    {
        name: "Member",
        slug: "member",
        permissions: [],
    },
];

export const createOrganisation = async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        const { name, slug, logo } = req.body;
        const userId = req.user.userId;
        const resellerId = req.user.resellerId;

        if (!name || !slug) {
            return res.status(400).json({ success: false, message: "Name and slug are required" });
        }

        // Check slug availability globally
        const existingOrg = await OrganisationModel.findOne({ slug }).session(session);
        if (existingOrg) {
            await session.abortTransaction();
            session.endSession();
            return res.status(400).json({ success: false, message: "Slug is already taken" });
        }

        // 1. Create Organisation
        const organisation = new OrganisationModel({
            name,
            slug,
            logo,
            ownerId: userId,
            resellerId,
        });
        await organisation.save({ session });

        // 2. Seed Default Roles
        const roles = [];
        for (const roleDef of DEFAULT_ROLES) {
            const role = new RoleModel({
                ...roleDef,
                organisationId: organisation._id,
            });
            await role.save({ session });
            roles.push(role);
        }

        // 3. Add Current User as Owner
        const ownerRole = roles.find((r) => r.slug === "owner");

        console.log("[DEBUG] createOrganisation - Body:", req.body);
        console.log("[DEBUG] createOrganisation - User:", req.user);

        let userName = req.body.userName || req.user.name;
        let userEmail = req.body.userEmail || req.user.email;

        // Fallback if missing from session
        if (!userName || !userEmail) {
            const user = await UserModel.findById(userId).session(session);
            if (user) {
                userName = user.full_name || user.name;
                userEmail = user.email;
            }
        }

        const member = new MemberModel({
            organisationId: organisation._id,
            userId: userId,
            roleId: ownerRole._id,
            isOwner: true,
            metadata: {
                name: userName || "Owner",
                email: userEmail
            }
        });
        await member.save({ session });

        await session.commitTransaction();
        session.endSession();

        res.status(201).json({
            success: true,
            message: "Organisation created successfully",
            data: {
                organisation,
                member: member,
            },
        });
    } catch (error) {
        await session.abortTransaction();
        session.endSession();
        console.error("Error creating organisation:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const getMyOrganisations = async (req, res) => {
    try {
        const userId = req.user.userId;

        // Find all memberships for the user
        const memberships = await MemberModel.find({ userId })
            .populate("organisationId")
            .populate("roleId");

        const organisations = memberships.map((membership) => {
            const org = membership.organisationId;
            const role = membership.roleId;

            // Handle case where org or role might have been deleted but member record remains (shouldn't happen with proper cleanup)
            if (!org || !role) return null;

            return {
                _id: org._id,
                name: org.name,
                slug: org.slug,
                logo: org.logo,
                role: {
                    _id: role._id,
                    name: role.name,
                    slug: role.slug,
                    permissions: role.permissions
                },
                isOwner: org.ownerId === userId,
                memberId: membership._id,
                extraPermissions: [] // specific member overrides if any
            };
        }).filter(Boolean);

        res.status(200).json(organisations);
    } catch (error) {
        console.error("Error fetching my organisations:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const getOrganisationById = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.userId;

        // Check if user is a member of this organisation
        const membership = await MemberModel.findOne({ organisationId: id, userId }).populate("roleId");

        if (!membership) {
            return res.status(403).json({ success: false, message: "Access denied" });
        }

        const organisation = await OrganisationModel.findById(id);
        if (!organisation) {
            return res.status(404).json({ success: false, message: "Organisation not found" });
        }

        res.status(200).json({
            success: true,
            data: {
                ...organisation.toObject(),
                role: membership.roleId.slug
            }
        });

    } catch (error) {
        console.error("Error fetching organisation:", error);
        res.status(500).json({ success: false, message: error.message });
    }
}

export const checkSlugAvailability = async (req, res) => {
    try {
        const { slug } = req.query;
        if (!slug) return res.status(400).json({ success: false, message: "Slug is required" });

        const count = await OrganisationModel.countDocuments({ slug });
        res.status(200).json({
            success: true,
            data: {
                available: count === 0
            }
        });
    } catch (error) {
        console.error("Error checking slug:", error);
        res.status(500).json({ success: false, message: error.message });
    }
}

export const updateOrganisation = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, slug, logo } = req.body;
        const userId = req.user.userId;

        // Permission check
        const membership = await MemberModel.findOne({ organisationId: id, userId }).populate("roleId");
        if (!membership) return res.status(403).json({ success: false, message: "Access denied" });

        const isOwner = membership.organisationId && (await OrganisationModel.findById(id)).ownerId === userId;
        const isOwnerRole = membership.roleId.slug === 'owner';

        // Only Owner (true owner or owner role) can update organisation settings
        if (!isOwner && !isOwnerRole) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const updates = {};
        if (name) updates.name = name;
        if (logo) updates.logo = logo;

        // Handle slug update separately because of uniqueness
        if (slug) {
            const existing = await OrganisationModel.findOne({ slug, _id: { $ne: id } });
            if (existing) {
                return res.status(400).json({ success: false, message: "Slug is already taken" });
            }
            updates.slug = slug;
        }

        const updatedOrg = await OrganisationModel.findByIdAndUpdate(id, updates, { new: true });

        res.status(200).json({
            success: true,
            message: "Organisation updated successfully",
            data: updatedOrg
        });

    } catch (error) {
        console.error("Error updating organisation:", error);
        res.status(500).json({ success: false, message: error.message });
    }
}

export const uploadLogo = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.userId;

        // Permission check
        const membership = await MemberModel.findOne({ organisationId: id, userId }).populate("roleId");
        if (!membership) return res.status(403).json({ success: false, message: "Access denied" });

        const isOwner = membership.organisationId && (await OrganisationModel.findById(id)).ownerId === userId;
        const isOwnerRole = membership.roleId.slug === 'owner';

        // Only Owner can upload logo
        if (!isOwner && !isOwnerRole) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        if (!req.file) {
            return res.status(400).json({ success: false, message: "No file uploaded" });
        }

        // Upload to S3
        // Folder structure: socialmedia/:organisationId
        const folder = `socialmedia/${id}`;
        const logoUrl = await uploadMulterFileToS3(req.file, folder, { req });

        // Update organisation with new logo URL
        const updatedOrg = await OrganisationModel.findByIdAndUpdate(
            id,
            { logo: logoUrl },
            { new: true }
        );

        res.status(200).json({
            success: true,
            message: "Logo uploaded successfully",
            data: {
                logo: logoUrl,
                organisation: updatedOrg
            }
        });

    } catch (error) {
        console.error("Error uploading logo:", error);
        res.status(500).json({ success: false, message: error.message });
    }
}

export const deleteOrganisation = async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
        const { id } = req.params;
        const userId = req.user.userId;

        const organisation = await OrganisationModel.findById(id).session(session);
        if (!organisation) {
            await session.abortTransaction();
            return res.status(404).json({ success: false, message: "Organisation not found" });
        }

        if (organisation.ownerId !== userId) {
            await session.abortTransaction();
            return res.status(403).json({ success: false, message: "Only Owner can delete organisation" });
        }

        // Delete Organisation
        await OrganisationModel.findByIdAndDelete(id).session(session);

        // Delete Members
        await MemberModel.deleteMany({ organisationId: id }).session(session);

        // Delete Roles
        await RoleModel.deleteMany({ organisationId: id }).session(session);

        await session.commitTransaction();
        session.endSession();

        res.status(200).json({
            success: true,
            message: "Organisation deleted successfully",
            data: null
        });

    } catch (error) {
        await session.abortTransaction();
        session.endSession();
        console.error("Error deleting organisation:", error);
        res.status(500).json({ success: false, message: error.message });
    }
}
