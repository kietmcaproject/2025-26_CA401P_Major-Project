import ResellerConfigModel from "../models/reseller-config.model.js";
import { uploadMulterFileToS3 } from "../utils/s3-upload.js";

export const getResellerConfig = async (req, res) => {
    try {
        // If user is a reseller, use their own ID (or resellerId if set).
        // If user is a member, use their resellerId.
        // Actually, only resellers should probably change this.
        // But members might need to READ this to see the logo.

        // Logic for determining the resellerId we are interested in:
        let idToUse = req.user.resellerId;

        if (!idToUse && req.user.role === 'reseller') {
            // If I am a reseller but have no resellerId set (maybe I am the root user of the reseller account), use my userId
            idToUse = req.user.userId;
        }

        if (!idToUse) {
            // If no reseller context, return default (maybe null)
            return res.status(200).json({ success: true, data: { logo: "" } });
        }

        let config = await ResellerConfigModel.findOne({ resellerId: idToUse });

        if (!config) {
            return res.status(200).json({ success: true, data: { logo: "" } });
        }

        return res.status(200).json({ success: true, data: config });

    } catch (error) {
        console.error("Error fetching reseller config:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const updateResellerConfig = async (req, res) => {
    try {
        // Only resellers can update
        if (req.user.role !== 'reseller') {
            return res.status(403).json({ success: false, message: "Access denied. Resellers only." });
        }

        let idToUse = req.user.resellerId;
        if (!idToUse) {
            idToUse = req.user.userId;
        }

        const updates = {};

        if (req.file) {
            // Folder structure: reseller/:resellerId
            const folder = `reseller/${idToUse}`;
            const logoUrl = await uploadMulterFileToS3(req.file, folder, { req });
            updates.logo = logoUrl;
        }

        if (req.body.companyName) {
            updates.companyName = req.body.companyName;
        }

        if (req.body.domain) {
            updates.domain = req.body.domain.toLowerCase().trim();
            // Check domain uniqueness if needed, though Mongo will enforce it
        }

        // Handle content updates
        if (req.body.content) {
            const content = typeof req.body.content === 'string'
                ? JSON.parse(req.body.content)
                : req.body.content;

            if (content.hero) {
                if (content.hero.title) updates['content.hero.title'] = content.hero.title;
                if (content.hero.subtitle) updates['content.hero.subtitle'] = content.hero.subtitle;
            }

            if (content.about) {
                if (content.about.title) updates['content.about.title'] = content.about.title;
                if (content.about.description) updates['content.about.description'] = content.about.description;
            }

            if (content.contact) {
                if (content.contact.address !== undefined) updates['content.contact.address'] = content.contact.address;
                if (content.contact.phone !== undefined) updates['content.contact.phone'] = content.contact.phone;
                if (content.contact.email !== undefined) updates['content.contact.email'] = content.contact.email;
            }

            if (content.cta) {
                if (content.cta.title !== undefined) updates['content.cta.title'] = content.cta.title;
                if (content.cta.subtitle !== undefined) updates['content.cta.subtitle'] = content.cta.subtitle;
                if (content.cta.buttonText !== undefined) updates['content.cta.buttonText'] = content.cta.buttonText;
            }

            if (content.faqs && Array.isArray(content.faqs)) {
                updates['content.faqs'] = content.faqs.map((faq, index) => ({
                    question: faq.question,
                    answer: faq.answer,
                    order: faq.order !== undefined ? faq.order : index
                }));
            }

            // Features section
            if (content.features && Array.isArray(content.features)) {
                updates['content.features'] = content.features.map((f, index) => ({
                    title: f.title,
                    description: f.description,
                    icon: f.icon || 'Zap',
                    order: f.order !== undefined ? f.order : index
                }));
            }

            // Stats section
            if (content.stats && Array.isArray(content.stats)) {
                updates['content.stats'] = content.stats.map((s, index) => ({
                    label: s.label,
                    value: s.value,
                    order: s.order !== undefined ? s.order : index
                }));
            }

            // Testimonials section
            if (content.testimonials && Array.isArray(content.testimonials)) {
                updates['content.testimonials'] = content.testimonials.map((t, index) => ({
                    name: t.name,
                    role: t.role || '',
                    company: t.company || '',
                    content: t.content,
                    avatar: t.avatar || '',
                    rating: t.rating || 5,
                    order: t.order !== undefined ? t.order : index
                }));
            }

            // Pricing section
            if (content.pricing && Array.isArray(content.pricing)) {
                updates['content.pricing'] = content.pricing.map((p, index) => ({
                    name: p.name,
                    price: p.price,
                    period: p.period || '/mo',
                    description: p.description || '',
                    features: p.features || [],
                    isPopular: p.isPopular || false,
                    buttonText: p.buttonText || 'Start free trial',
                    order: p.order !== undefined ? p.order : index
                }));
            }

            // About page
            if (content.aboutPage) {
                if (content.aboutPage.tagline !== undefined) updates['content.aboutPage.tagline'] = content.aboutPage.tagline;
                if (content.aboutPage.headline !== undefined) updates['content.aboutPage.headline'] = content.aboutPage.headline;
                if (content.aboutPage.story !== undefined) updates['content.aboutPage.story'] = content.aboutPage.story;
                if (content.aboutPage.stats && Array.isArray(content.aboutPage.stats)) {
                    updates['content.aboutPage.stats'] = content.aboutPage.stats;
                }
                if (content.aboutPage.industries && Array.isArray(content.aboutPage.industries)) {
                    updates['content.aboutPage.industries'] = content.aboutPage.industries;
                }
            }

            // Legal pages
            if (content.privacyPolicy !== undefined) updates['content.privacyPolicy'] = content.privacyPolicy;
            if (content.termsOfService !== undefined) updates['content.termsOfService'] = content.termsOfService;
        }

        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ success: false, message: "No changes provided" });
        }

        const config = await ResellerConfigModel.findOneAndUpdate(
            { resellerId: idToUse },
            { $set: updates },
            { new: true, upsert: true }
        );

        res.status(200).json({
            success: true,
            message: "Reseller configuration updated successfully",
            data: config
        });

    } catch (error) {
        console.error("Error updating reseller config:", error);
        res.status(500).json({ success: false, message: error.message });
    }
}

export const getPublicResellerConfig = async (req, res) => {
    try {
        const { domain } = req.query;
        // Or extract from req.hostname for simpler use case, but query for generality

        let config = null;

        if (domain) {
            config = await ResellerConfigModel.findOne({ domain: domain.toLowerCase() })
                .select("companyName logo domain resellerId content -_id");
        }

        // Fallback: If no config found for domain, return empty or default
        // But the requirement is to render specific details for reseller domain.

        if (!config) {
            // Default Veblika config if not found
            // Or just return null/empty
            return res.status(200).json({
                success: true,
                data: {
                    companyName: "Veblika",
                    logo: "",
                    isDefault: true
                }
            });
        }

        res.status(200).json({ success: true, data: config });
    } catch (error) {
        console.error("Error fetching public reseller config:", error);
        res.status(500).json({ success: false, message: error.message });
    }
}
