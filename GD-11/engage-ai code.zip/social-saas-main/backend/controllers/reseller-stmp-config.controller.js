import UserModel from "../models/user.model.js";
import ResellerStmpConfigurationModel from "../models/reseller-stmp-configurations.model.js";
import { extractOriginDomain, normalizeOriginDomain } from "../services/smtp-config.service.js";

async function resolveCurrentUserFromDb(req) {
  const userId = req?.user?.userId ? String(req.user.userId) : null;
  const email = req?.user?.email ? String(req.user.email).toLowerCase() : null;
  const cognitoUsername = req?.user?.cognitoUsername ? String(req.user.cognitoUsername) : null;

  if (!userId && !email && !cognitoUsername) return null;

  return UserModel.findOne({
    $or: [
      ...(userId ? [{ userId }] : []),
      ...(email ? [{ email }] : []),
      ...(cognitoUsername ? [{ COGNITO_USER_ID: cognitoUsername }] : []),
    ],
  }).lean();
}

function resolveResellerId(req, userDb) {
  return (
    String(userDb?.reseller_id || "").trim() ||
    String(req?.user?.resellerId || "").trim() ||
    (String(userDb?.role || req?.user?.role || "").toLowerCase() === "reseller"
      ? String(userDb?.userId || req?.user?.userId || "").trim()
      : "")
  );
}

export const getResellerStmpConfiguration = async (req, res) => {
  try {
    const userDb = await resolveCurrentUserFromDb(req);
    const originDomain = normalizeOriginDomain(req?.query?.originDomain) || extractOriginDomain(req);
    const resellerId = resolveResellerId(req, userDb);

    if (!originDomain && !resellerId) {
      return res.status(200).json({ success: true, data: null });
    }

    const query = originDomain ? { originDomain } : { resellerId };
    const data = await ResellerStmpConfigurationModel.findOne(query).sort({ updatedAt: -1 }).lean();

    return res.status(200).json({ success: true, data });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const upsertResellerStmpConfiguration = async (req, res) => {
  try {
    const userDb = await resolveCurrentUserFromDb(req);
    const effectiveRole = String(userDb?.role || req?.user?.role || "").toLowerCase();
    if (effectiveRole !== "reseller") {
      return res.status(403).json({ success: false, message: "Access denied. Resellers only." });
    }

    const resellerId = resolveResellerId(req, userDb);
    if (!resellerId) {
      return res.status(400).json({ success: false, message: "Reseller ID is required." });
    }

    const {
      host,
      port,
      secure,
      username,
      password,
      fromName,
      fromEmail,
      enabled,
      originDomain: bodyOriginDomain,
    } = req.body || {};

    if (!host || !username || !password) {
      return res.status(400).json({
        success: false,
        message: "host, username, and password are required.",
      });
    }

    const originDomain = normalizeOriginDomain(bodyOriginDomain) || extractOriginDomain(req);
    if (!originDomain) {
      return res.status(400).json({ success: false, message: "originDomain is required." });
    }

    const update = {
      resellerId: String(resellerId),
      originDomain,
      host: String(host).trim(),
      port: Number(port || 587),
      secure: Boolean(secure),
      username: String(username).trim(),
      password: String(password).trim(),
      fromName: String(fromName || "Veblika").trim(),
      fromEmail: String(fromEmail || "no-reply@veblika.com").trim(),
      enabled: typeof enabled === "boolean" ? enabled : true,
      updatedBy: String(userDb?.userId || req?.user?.userId || ""),
      createdBy: String(userDb?.userId || req?.user?.userId || ""),
    };

    const data = await ResellerStmpConfigurationModel.findOneAndUpdate(
      { resellerId: String(resellerId), originDomain },
      { $set: update },
      { upsert: true, new: true }
    ).lean();

    return res.status(200).json({
      success: true,
      message: "SMTP configuration saved successfully.",
      data,
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const deleteResellerStmpConfiguration = async (req, res) => {
  try {
    const userDb = await resolveCurrentUserFromDb(req);
    const effectiveRole = String(userDb?.role || req?.user?.role || "").toLowerCase();
    if (effectiveRole !== "reseller") {
      return res.status(403).json({ success: false, message: "Access denied. Resellers only." });
    }

    const resellerId = resolveResellerId(req, userDb);
    const originDomain = normalizeOriginDomain(req?.body?.originDomain || req?.query?.originDomain) || extractOriginDomain(req);
    if (!resellerId || !originDomain) {
      return res.status(400).json({ success: false, message: "resellerId and originDomain are required." });
    }

    await ResellerStmpConfigurationModel.deleteOne({ resellerId: String(resellerId), originDomain });
    return res.status(200).json({ success: true, message: "SMTP configuration removed." });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};
