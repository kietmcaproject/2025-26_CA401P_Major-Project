import UserModel from "../models/user.model.js";

const resolveResellerScope = (req) => {
  return req.user?.resellerId || (req.user?.role === "reseller" ? (req.user?.userId || req.user?._id) : null);
};

export const listResellerAppUsers = async (req, res) => {
  try {
    if (req.user?.role !== "reseller") {
      return res.status(403).json({ success: false, message: "Access denied. Resellers only." });
    }

    const resellerId = resolveResellerScope(req);
    if (!resellerId) {
      return res.status(400).json({ success: false, message: "Reseller context not found." });
    }

    const users = await UserModel.find({ reseller_id: String(resellerId) })
      .sort({ updatedAt: -1 })
      .select("_id userId full_name email role reseller_id mediaStorageGb createdAt updatedAt")
      .lean();

    return res.status(200).json({
      success: true,
      data: users.map((user) => ({
        id: String(user._id),
        authUserId: user.userId || String(user._id),
        appRole: user.role || "user",
        status: "active",
        name: user.full_name || "",
        email: user.email || "",
        resellerId: user.reseller_id || null,
        mediaStorageGb: Number(user.mediaStorageGb || 0),
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      })),
    });
  } catch (error) {
    console.error("Error fetching app users:", error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const updateAppUserStatus = async (req, res) => {
  return res.status(400).json({
    success: false,
    message: "Status updates are not supported for users model.",
  });
};
