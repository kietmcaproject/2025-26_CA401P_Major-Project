import UserModel from "../../models/user.model.js";
import mongoose from "mongoose";
import {
  AdminGetUserCommand,
  ListUsersCommand,
} from "@aws-sdk/client-cognito-identity-provider";
import { cognitoClient } from "../../config/cognito.js";

function getCognitoAttribute(user, key) {
  const attrs = Array.isArray(user?.UserAttributes) ? user.UserAttributes : [];
  const found = attrs.find((a) => a?.Name === key);
  return found?.Value ? String(found.Value) : null;
}

async function resolveCognitoUsername(req, localUser) {
  if (req.user?.cognitoUsername) return String(req.user.cognitoUsername);
  if (localUser?.COGNITO_USER_ID) return String(localUser.COGNITO_USER_ID);

  const email = String(req.user?.email || localUser?.email || "").toLowerCase().trim();
  if (!email) return null;

  const response = await cognitoClient.send(
    new ListUsersCommand({
      UserPoolId: process.env.COGNITO_USER_POOL_ID,
      Filter: `email = "${email}"`,
      Limit: 1,
    })
  );

  const found = Array.isArray(response?.Users) ? response.Users[0] : null;
  return found?.Username ? String(found.Username) : null;
}

const getUserController = async (req, res) => {
  try {
    const userId = req.user?.userId || req.user?._id;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized", status: false });
    }

    let user = null;
    if (mongoose.isValidObjectId(userId)) {
      user = await UserModel.findById(userId).select("-password").lean();
    }
    if (!user) {
      user = await UserModel.findOne({
        $or: [{ userId: String(userId) }, ...(req.user?.email ? [{ email: req.user.email }] : [])],
      })
        .select("-password")
        .lean();
    }

    let cognitoProfile = null;
    try {
      const cognitoUsername = await resolveCognitoUsername(req, user);
      if (cognitoUsername) {
        cognitoProfile = await cognitoClient.send(
          new AdminGetUserCommand({
            UserPoolId: process.env.COGNITO_USER_POOL_ID,
            Username: cognitoUsername,
          })
        );
      }
    } catch {
      // Keep profile endpoint resilient even when Cognito lookup fails.
      cognitoProfile = null;
    }

    return res.status(200).json({
      message: "User fetched successfully",
      status: true,
      data: {
        _id: user?._id || String(userId),
        userId: String(userId),
        full_name: user?.full_name || req.user?.name || "",
        email: user?.email || req.user?.email || "",
        profile_pic: user?.profile_pic || null,
        role: user?.role || req.user?.role || "user",
        resellerId: req.user?.resellerId || user?.reseller_id || null,
        reseller_id: user?.reseller_id || req.user?.resellerId || null,
        originDomain: user?.originDomain || req.user?.originDomain || null,
        COGNITO_USER_ID: user?.COGNITO_USER_ID || null,
        addressline: getCognitoAttribute(cognitoProfile, "custom:addressline") || req.user?.addressline || null,
        state: getCognitoAttribute(cognitoProfile, "custom:state") || req.user?.state || null,
        city: getCognitoAttribute(cognitoProfile, "custom:city") || req.user?.city || null,
        country: getCognitoAttribute(cognitoProfile, "custom:country") || req.user?.country || null,
        phone: getCognitoAttribute(cognitoProfile, "custom:phone") || req.user?.phone || null,
        pincode: getCognitoAttribute(cognitoProfile, "custom:pincode") || req.user?.pincode || null,
        mediaStorageGb: Number(user?.mediaStorageGb || 0),
        profilePicture:
          getCognitoAttribute(cognitoProfile, "custom:profilePicture") ||
          req.user?.profilePicture ||
          user?.profile_pic ||
          null,
        createdAt: user?.createdAt || null,
        updatedAt: user?.updatedAt || null,
      },
    });
  } catch (error) {
    return res.status(500).json({ message: error.message, status: false });
  }
};

export default getUserController;

