import {
  AdminCreateUserCommand,
  AdminSetUserPasswordCommand,
  AdminGetUserCommand,
  AdminInitiateAuthCommand,
  AdminRespondToAuthChallengeCommand,
  AdminSetUserMFAPreferenceCommand,
  AdminUpdateUserAttributesCommand,
  AssociateSoftwareTokenCommand,
  ListUsersCommand,
  VerifySoftwareTokenCommand,
} from "@aws-sdk/client-cognito-identity-provider";
import { createHmac } from "crypto";
import jwt from "jsonwebtoken";
import { cognitoClient } from "../../config/cognito.js";
import UserModel from "../../models/user.model.js";
import { sendMailWithResolvedSmtp } from "../../services/smtp-config.service.js";

const cookieBaseOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax",
};

function getCookieDomain(req) {
  if (process.env.COOKIE_DOMAIN) {
    return String(process.env.COOKIE_DOMAIN).trim();
  }

  const forwardedHost = req?.headers?.["x-forwarded-host"];
  const hostHeader = forwardedHost || req?.headers?.host || "";
  const host = String(hostHeader).split(":")[0].trim().toLowerCase();
  if (!host) return null;
  if (host === "localhost" || host.endsWith(".localhost")) return null;
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host === "::1") return null;

  const apex = getApexDomain(host);
  return apex ? `.${apex}` : null;
}

function parseJwtPayload(token) {
  try {
    const parts = String(token || "").split(".");
    if (parts.length < 2) return null;
    const payload = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    const decoded = Buffer.from(payload, "base64").toString("utf8");
    return JSON.parse(decoded);
  } catch {
    return null;
  }
}

function getSecretHash(username) {
  const clientId = process.env.COGNITO_CLIENT_ID;
  const clientSecret = process.env.COGNITO_CLIENT_SECRET;
  if (!clientId || !clientSecret || !username) return null;
  return createHmac("sha256", clientSecret)
    .update(`${username}${clientId}`)
    .digest("base64");
}

function normalizeEmail(email) {
  return String(email || "").toLowerCase().trim();
}

function escapeCognitoFilterValue(value) {
  return String(value || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

function buildCognitoUsername(email) {
  const normalizedEmail = normalizeEmail(email);
  const localPart = normalizedEmail.split("@")[0] || "";
  return localPart.trim() || "user";
}

function getApexDomain(hostname) {
  const host = String(hostname || "").trim().toLowerCase();
  if (!host) return null;
  if (host === "localhost") return "localhost";
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return host;

  const parts = host.split(".").filter(Boolean);
  if (parts.length <= 2) return host;

  const secondLevelTlds = new Set(["co.uk", "org.uk", "gov.uk", "ac.uk", "co.in", "com.au", "co.jp"]);
  const tailTwo = `${parts[parts.length - 2]}.${parts[parts.length - 1]}`;
  const tailThree = `${parts[parts.length - 3]}.${tailTwo}`;

  if (secondLevelTlds.has(tailTwo) && parts.length >= 3) {
    return tailThree;
  }

  return tailTwo;
}

function extractOriginDomain(req) {
  const rawOrigin =
    req?.body?.originDomain ||
    req?.headers?.origin ||
    req?.headers?.referer ||
    "";
  if (!rawOrigin) return null;

  const trimmed = String(rawOrigin).trim();

  try {
    const url = trimmed.includes("://") ? new URL(trimmed) : new URL(`https://${trimmed}`);
    return getApexDomain(url.hostname);
  } catch {
    return getApexDomain(trimmed.replace(/^https?:\/\//i, "").split("/")[0]);
  }
}

function normalizeDomain(input) {
  const raw = String(input || "").trim();
  if (!raw) return null;

  try {
    const url = raw.includes("://") ? new URL(raw) : new URL(`https://${raw}`);
    const hostname = String(url.hostname || "").toLowerCase().trim();
    return hostname || null;
  } catch {
    const withoutProtocol = raw.replace(/^https?:\/\//i, "");
    const firstSegment = withoutProtocol.split("/")[0] || "";
    const withoutPort = firstSegment.split(":")[0] || "";
    const hostname = String(withoutPort).toLowerCase().trim();
    return hostname || null;
  }
}

function extractCurrentDomain(req) {
  const forwardedHost = req?.headers?.["x-forwarded-host"];
  const rawDomain =
    req?.body?.originDomain ||
    req?.body?.currentDomain ||
    req?.headers?.origin ||
    req?.headers?.referer ||
    forwardedHost ||
    req?.headers?.host ||
    "";

  return normalizeDomain(rawDomain);
}

function parseAllowedDomains(rawAllowedDomains) {
  const rawValue = String(rawAllowedDomains || "").trim();
  if (!rawValue) return [];

  let list = [];

  if (rawValue.startsWith("[") && rawValue.endsWith("]")) {
    try {
      const parsed = JSON.parse(rawValue);
      if (Array.isArray(parsed)) {
        list = parsed;
      }
    } catch {
      list = [];
    }
  }

  if (list.length === 0) {
    list = rawValue.split(/[,\n;\s]+/g);
  }

  const normalized = list
    .map((item) => String(item || "").trim())
    .filter(Boolean)
    .map((item) => {
      if (item === "*") return "*";
      if (item.startsWith("*.")) {
        const wildcardBase = normalizeDomain(item.slice(2));
        return wildcardBase ? `*.${wildcardBase}` : item.toLowerCase();
      }
      return normalizeDomain(item) || item.toLowerCase();
    });

  return [...new Set(normalized)];
}

function isCurrentDomainAllowed(currentDomain, allowedDomains = []) {
  const domain = normalizeDomain(currentDomain);
  if (!domain || !Array.isArray(allowedDomains) || allowedDomains.length === 0) {
    return false;
  }

  return allowedDomains.some((allowedEntry) => {
    const allowed = String(allowedEntry || "").trim().toLowerCase();
    if (!allowed) return false;
    if (allowed === "*") return true;

    if (allowed.startsWith("*.")) {
      const wildcardBase = allowed.slice(2);
      return domain === wildcardBase || domain.endsWith(`.${wildcardBase}`);
    }

    return domain === allowed || domain.endsWith(`.${allowed}`);
  });
}

async function getCognitoUserByEmail(email) {
  const normalizedEmail = normalizeEmail(email);
  if (!normalizedEmail) return null;

  const directMatchResponse = await cognitoClient.send(
    new ListUsersCommand({
      UserPoolId: process.env.COGNITO_USER_POOL_ID,
      Filter: `email = "${escapeCognitoFilterValue(normalizedEmail)}"`,
      Limit: 1,
    })
  );

  const directMatch = Array.isArray(directMatchResponse?.Users) ? directMatchResponse.Users[0] || null : null;
  if (directMatch) {
    return directMatch;
  }

  let paginationToken;

  do {
    const response = await cognitoClient.send(
      new ListUsersCommand({
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        Limit: 60,
        ...(paginationToken ? { PaginationToken: paginationToken } : {}),
      })
    );

    const matchedUser = Array.isArray(response?.Users)
      ? response.Users.find((user) => normalizeEmail(getCognitoAttribute(user, "email")) === normalizedEmail) || null
      : null;

    if (matchedUser) {
      return matchedUser;
    }

    paginationToken = response?.PaginationToken || null;
  } while (paginationToken);

  return null;
}

async function resolveCognitoUsernameByEmail(email) {
  const user = await getCognitoUserByEmail(email);
  return user?.Username ? String(user.Username) : null;
}

async function getCognitoUserByUsername(username) {
  if (!username) return null;
  try {
    const response = await cognitoClient.send(
      new AdminGetUserCommand({
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        Username: String(username),
      })
    );
    return response || null;
  } catch (err) {
    if (err?.name === "UserNotFoundException") {
      return null;
    }
    throw err;
  }
}

function getCognitoAttribute(user, key) {
  const attrs = Array.isArray(user?.UserAttributes) ? user.UserAttributes : [];
  const found = attrs.find((a) => a?.Name === key);
  return found?.Value ? String(found.Value) : null;
}

const REQUIRED_COGNITO_PROFILE_FIELDS = [
  "custom:addressline",
  "custom:state",
  "custom:city",
  "custom:country",
  "custom:phone",
  "custom:pincode",
  "custom:profilePicture",
];

function getMissingRequiredCognitoFields(user) {
  return REQUIRED_COGNITO_PROFILE_FIELDS.filter((key) => !String(getCognitoAttribute(user, key) || "").trim());
}

async function ensureLocalUserRecord({ sub, email, name, cognitoUsername, resellerId, role, originDomain }) {
  if (!email) return;

  const existing = await UserModel.findOne({
    $or: [
      { email: normalizeEmail(email) },
      ...(sub ? [{ userId: String(sub) }] : []),
      ...(cognitoUsername ? [{ COGNITO_USER_ID: String(cognitoUsername) }] : []),
    ],
  });

  if (existing) {
    const setUpdates = {};
    const unsetUpdates = {};

    if (sub && !existing.userId) setUpdates.userId = String(sub);
    if (name && !existing.full_name) setUpdates.full_name = String(name);
    if (cognitoUsername && !existing.COGNITO_USER_ID) {
      setUpdates.COGNITO_USER_ID = String(cognitoUsername);
    }
    if (resellerId && !existing.reseller_id) {
      setUpdates.reseller_id = String(resellerId);
    }
    if (originDomain && !existing.originDomain) {
      setUpdates.originDomain = String(originDomain);
    }
    if (role && existing.role !== role) {
      setUpdates.role = String(role);
    }
    if (typeof existing.password !== "undefined") {
      unsetUpdates.password = "";
    }

    const updateQuery = {};
    if (Object.keys(setUpdates).length > 0) updateQuery.$set = setUpdates;
    if (Object.keys(unsetUpdates).length > 0) updateQuery.$unset = unsetUpdates;

    if (Object.keys(updateQuery).length > 0) {
      await UserModel.updateOne({ _id: existing._id }, updateQuery);
    }
    return;
  }

  await UserModel.create({
    full_name: String(name || email.split("@")[0] || "User"),
    email: normalizeEmail(email),
    userId: sub ? String(sub) : undefined,
    COGNITO_USER_ID: cognitoUsername ? String(cognitoUsername) : undefined,
    reseller_id: resellerId ? String(resellerId) : null,
    role: role ? String(role) : "user",
    originDomain: originDomain ? String(originDomain) : null,
  });
}

function isAwsCredentialsError(err) {
  if (!err) return false;
  const message = String(err?.message || "");
  return (
    err?.name === "CredentialsProviderError" ||
    message.includes("Could not load credentials from any providers") ||
    message.includes("Resolved credential object is not valid")
  );
}

function getFrontendBaseUrl(req) {
  const directOrigin = req?.headers?.origin || req?.headers?.referer || "";
  if (directOrigin) {
    try {
      return new URL(String(directOrigin)).origin.replace(/\/$/, "");
    } catch {
      // continue to forwarded/host fallback
    }
  }

  const forwardedProto = req?.headers?.["x-forwarded-proto"];
  const forwardedHost = req?.headers?.["x-forwarded-host"];
  const host = forwardedHost || req?.headers?.host || "";
  if (host) {
    const protocol = String(forwardedProto || "http");
    return `${protocol}://${String(host)}`.replace(/\/$/, "");
  }

  return String(process.env.FRONTEND_URL || "http://localhost:3001").replace(/\/$/, "");
}

function getApiBaseUrl(req) {
  const forwardedProto = req?.headers?.["x-forwarded-proto"];
  const forwardedHost = req?.headers?.["x-forwarded-host"];
  const host = forwardedHost || req?.headers?.host || "";
  if (host) {
    const protocol = String(forwardedProto || "http");
    return `${protocol}://${String(host)}`.replace(/\/$/, "");
  }
  return String(process.env.API_URL || "http://localhost:8001").replace(/\/$/, "");
}

async function sendResetEmail(req, to, resetLink) {
  return sendMailWithResolvedSmtp({
    req,
    to,
    subject: "Reset your password",
    html: `
      <p>We received a request to reset your password.</p>
      <p><a href="${resetLink}">Click here to reset your password</a></p>
      <p>This link will expire in 15 minutes.</p>
      <p>If you did not request this, you can ignore this email.</p>
    `,
  });
}

async function sendVerificationEmail(req, to, verifyLink) {
  return sendMailWithResolvedSmtp({
    req,
    to,
    subject: "Verify your email",
    html: `
      <p>Welcome to Veblika.</p>
      <p><a href="${verifyLink}">Click here to verify your email</a></p>
      <p>This link will expire in 24 hours.</p>
    `,
  });
}

async function resolveCognitoUsernameForRequest(req) {
  const directUsername = req?.user?.cognitoUsername || req?.user?.username || null;
  if (directUsername) return String(directUsername);

  const email = String(req?.user?.email || "").toLowerCase().trim();
  if (!email) return null;

  return resolveCognitoUsernameByEmail(email);
}

function readBearerTokenFromRequest(req) {
  const authHeader = req?.headers?.authorization;
  if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
    return authHeader.slice(7).trim();
  }

  const xAuthToken = req?.headers?.["x-auth-token"];
  if (typeof xAuthToken === "string" && xAuthToken.trim()) {
    return xAuthToken.trim();
  }

  return null;
}

function readAccessTokenFromRequest(req) {
  const candidates = [
    readBearerTokenFromRequest(req),
    req?.cookies?.accessToken,
  ]
    .map((value) => (typeof value === "string" ? value.trim() : ""))
    .filter(Boolean);

  for (const token of candidates) {
    const payload = parseJwtPayload(token);
    if (payload?.token_use === "access") {
      return token;
    }
  }

  return null;
}

function isValidTotpCode(input) {
  return /^\d{6}$/.test(String(input || "").trim());
}

async function completeLogin({
  req,
  res,
  normalizedEmail,
  loginUsername,
  authResult,
  cognitoUser,
}) {
  const idToken = authResult?.IdToken || null;
  const accessToken = authResult?.AccessToken || null;
  const refreshToken = authResult?.RefreshToken || null;
  const expiresIn = Number(authResult?.ExpiresIn || 3600);

  if (!idToken) {
    return res.status(401).json({ message: "Invalid credentials", status: false });
  }

  const payload = parseJwtPayload(idToken) || {};
  const sub = payload?.sub ? String(payload.sub) : null;
  const name = payload?.name || normalizedEmail.split("@")[0];
  const resellerIdFromToken =
    payload?.["custom:reseller_id"] || payload?.["custom:resellerId"] || null;
  const originDomainFromToken =
    payload?.["custom:originDomain"] || payload?.["custom:origin_domain"] || null;
  const roleFromToken = "user";

  await ensureLocalUserRecord({
    sub,
    email: normalizedEmail,
    name,
    cognitoUsername: loginUsername || null,
    resellerId: resellerIdFromToken,
    role: roleFromToken,
    originDomain: originDomainFromToken || extractOriginDomain(req),
  });

  const currentCognitoUser =
    cognitoUser || (loginUsername ? await getCognitoUserByUsername(loginUsername) : null);

  let missingRequiredProfileFields = getMissingRequiredCognitoFields(currentCognitoUser);

  // Best-effort auto-fill of profile picture in Cognito from local DB if available.
  if (missingRequiredProfileFields.includes("custom:profilePicture") && loginUsername) {
    const localUser = await UserModel.findOne({
      $or: [{ email: normalizedEmail }, ...(sub ? [{ userId: String(sub) }] : [])],
    })
      .select("profile_pic")
      .lean();

    const localProfilePic = String(localUser?.profile_pic || "").trim();
    if (localProfilePic) {
      try {
        await cognitoClient.send(
          new AdminUpdateUserAttributesCommand({
            UserPoolId: process.env.COGNITO_USER_POOL_ID,
            Username: loginUsername,
            UserAttributes: [{ Name: "custom:profilePicture", Value: localProfilePic }],
          })
        );
        missingRequiredProfileFields = missingRequiredProfileFields.filter(
          (field) => field !== "custom:profilePicture"
        );
      } catch (profileSyncError) {
        console.warn("Failed syncing profile picture to Cognito:", profileSyncError?.message || profileSyncError);
      }
    }
  }

  const cookieDomain = getCookieDomain(req);
  const cookieDomainOptions = cookieDomain ? { domain: cookieDomain } : {};

  const sessionAccessToken = accessToken || idToken;
  if (sessionAccessToken) {
    res.cookie("accessToken", sessionAccessToken, {
      ...cookieBaseOptions,
      ...cookieDomainOptions,
      maxAge: expiresIn * 1000,
    });
  }

  res.cookie("idToken", idToken, {
    ...cookieBaseOptions,
    ...cookieDomainOptions,
    maxAge: expiresIn * 1000,
  });

  if (refreshToken) {
    res.cookie("refreshToken", refreshToken, {
      ...cookieBaseOptions,
      ...cookieDomainOptions,
      maxAge: 30 * 24 * 60 * 60 * 1000,
    });
  }

  return res.json({
    message:
      missingRequiredProfileFields.length > 0
        ? "Login successful. Please complete required profile details."
        : "Login successful",
    status: true,
    data: {
      userId: sub,
      email: normalizedEmail,
      name,
      profileCompletionRequired: missingRequiredProfileFields.length > 0,
      missingProfileFields: missingRequiredProfileFields,
    },
  });
}

export const registerUser = async (req, res) => {
  try {
    const { name, full_name, email, password } = req.body || {};

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required", status: false });
    }

    const normalizedEmail = normalizeEmail(email);
    const resolvedName = String(full_name || name || normalizedEmail.split("@")[0] || "User").trim();
    const resellerId =
      process.env.COGNITO_RESELLER_ID ||
      process.env.RESELLER_ID ||
      process.env.COGNITO_RESELLER_ID_DEFAULT ||
      "";
    const originDomain = extractOriginDomain(req);
    const currentDomain = extractCurrentDomain(req);
    // Force default app role for all new signups.
    const resolvedRole = "user";

    const existingCognitoUser = await getCognitoUserByEmail(normalizedEmail);

    if (existingCognitoUser) {
      return res.status(409).json({
        message: "User already exists. Please login.",
        status: false,
      });
    }

    // Use the email prefix before "@" as the Cognito username.
    const cognitoUsername = buildCognitoUsername(normalizedEmail);
    const existingUsernameOwner = await getCognitoUserByUsername(cognitoUsername);
    const existingUsernameEmail = normalizeEmail(getCognitoAttribute(existingUsernameOwner, "email"));

    if (existingUsernameOwner && existingUsernameEmail !== normalizedEmail) {
      return res.status(409).json({
        message: "This username is already in use by another account",
        status: false,
      });
    }

    // Create Cognito user
    await cognitoClient.send(
      new AdminCreateUserCommand({
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        Username: cognitoUsername,
        UserAttributes: [
          { Name: "email", Value: normalizedEmail },
          { Name: "name", Value: resolvedName },
          { Name: "email_verified", Value: "false" },
        ],
        MessageAction: "SUPPRESS",
      })
    );

    await cognitoClient.send(
      new AdminSetUserPasswordCommand({
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        Username: cognitoUsername,
        Password: password,
        Permanent: true,
      })
    );

    const userAttributesToUpdate = [{ Name: "custom:role", Value: resolvedRole }];
    if (resellerId) {
      userAttributesToUpdate.push({ Name: "custom:reseller_id", Value: String(resellerId) });
    }
    if (originDomain) {
      userAttributesToUpdate.push({ Name: "custom:originDomain", Value: String(originDomain) });
    }
    if (currentDomain) {
      userAttributesToUpdate.push({ Name: "custom:allowedDomains", Value: String(currentDomain) });
    }

    await cognitoClient.send(
      new AdminUpdateUserAttributesCommand({
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        Username: cognitoUsername,
        UserAttributes: userAttributesToUpdate,
      })
    );

    const frontendBase = getFrontendBaseUrl(req);
    const verifyToken = jwt.sign(
      {
        type: "email_verify",
        email: normalizedEmail,
        redirectBase: frontendBase,
      },
      process.env.JWT_SECRET || "Automation",
      { expiresIn: "24h" }
    );
    const verifyLink = `${getApiBaseUrl(req)}/api/user/verify-email?token=${encodeURIComponent(
      verifyToken
    )}`;

    await sendVerificationEmail(req, normalizedEmail, verifyLink);

    await ensureLocalUserRecord({
      sub: null,
      email: normalizedEmail,
      name: resolvedName,
      cognitoUsername,
      resellerId,
      role: resolvedRole,
      originDomain,
    });

    return res.status(201).json({
      message: "Registered successfully. Please verify your email before login.",
      status: true,
      data: {
        userId: null,
        email: normalizedEmail,
        name: resolvedName,
      },
    });

  } catch (err) {
    if (isAwsCredentialsError(err)) {
      return res.status(500).json({
        message:
          "AWS credentials missing for Cognito. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (or COGNITO_AWS_ACCESS_KEY_ID and COGNITO_AWS_SECRET_ACCESS_KEY).",
        status: false,
      });
    }
    if (err?.name === "UsernameExistsException") {
      return res.status(409).json({ message: "User already exists. Please login.", status: false });
    }
    return res.status(500).json({ message: err.message, status: false });
  }
};

export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body || {};

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required", status: false });
    }

    const normalizedEmail = normalizeEmail(email);

    const resolvedUsername = await resolveCognitoUsernameByEmail(normalizedEmail);
    if (!resolvedUsername) {
      return res.status(404).json({ message: "User not found", status: false });
    }

    const loginUsername = resolvedUsername;
    const cognitoUser = await getCognitoUserByUsername(loginUsername);
    const currentDomain = extractCurrentDomain(req);
    const allowedDomainsRaw =
      getCognitoAttribute(cognitoUser, "custom:allowedDomains") ||
      getCognitoAttribute(cognitoUser, "custom:allowedDomain");
    const allowedDomains = parseAllowedDomains(allowedDomainsRaw);

    if (!isCurrentDomainAllowed(currentDomain, allowedDomains)) {
      return res.status(403).json({
        message: "Unauthorized to access from this domain.",
        status: false,
      });
    }

    const emailVerified = getCognitoAttribute(cognitoUser, "email_verified");
    if (emailVerified !== "true") {
      return res.status(403).json({
        message: "Please verify your email before logging in.",
        status: false,
      });
    }

    const loginAuthParams = {
      USERNAME: loginUsername,
      PASSWORD: password,
    };
    const loginSecretHash = getSecretHash(loginUsername);
    if (loginSecretHash) {
      loginAuthParams.SECRET_HASH = loginSecretHash;
    }

    const authResponse = await cognitoClient.send(
      new AdminInitiateAuthCommand({
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        ClientId: process.env.COGNITO_CLIENT_ID,
        AuthFlow: "ADMIN_USER_PASSWORD_AUTH",
        AuthParameters: loginAuthParams,
      })
    );

    if (authResponse?.ChallengeName === "SOFTWARE_TOKEN_MFA") {
      if (!authResponse?.Session) {
        return res.status(401).json({ message: "MFA session not received", status: false });
      }
      return res.status(202).json({
        message: "MFA required to complete login.",
        status: true,
        mfaRequired: true,
        data: {
          challenge: authResponse.ChallengeName,
          session: authResponse.Session,
          email: normalizedEmail,
        },
      });
    }

    return completeLogin({
      req,
      res,
      normalizedEmail,
      loginUsername,
      authResult: authResponse.AuthenticationResult || {},
      cognitoUser,
    });

  } catch (err) {
    if (isAwsCredentialsError(err)) {
      return res.status(500).json({
        message:
          "AWS credentials missing for Cognito. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (or COGNITO_AWS_ACCESS_KEY_ID and COGNITO_AWS_SECRET_ACCESS_KEY).",
        status: false,
      });
    }
    if (
      String(err?.message || "").includes("SECRET_HASH was not received") &&
      !process.env.COGNITO_CLIENT_SECRET
    ) {
      return res.status(500).json({
        message: "COGNITO_CLIENT_SECRET is required for this Cognito app client.",
        status: false,
      });
    }
    if (err?.name === "UserNotFoundException") {
      return res.status(404).json({ message: "User not found", status: false });
    }
    return res.status(401).json({ message: "Invalid credentials", status: false, error: err?.message });
  }
};

export const verifyMfaLogin = async (req, res) => {
  try {
    const { email, session, code } = req.body || {};

    if (!email || !session || !isValidTotpCode(code)) {
      return res.status(400).json({
        message: "Email, session, and a valid 6-digit code are required.",
        status: false,
      });
    }

    const normalizedEmail = normalizeEmail(email);
    const loginUsername = await resolveCognitoUsernameByEmail(normalizedEmail);
    if (!loginUsername) {
      return res.status(404).json({ message: "User not found", status: false });
    }
    const cognitoUser = await getCognitoUserByUsername(loginUsername);
    const currentDomain = extractCurrentDomain(req);
    const allowedDomainsRaw =
      getCognitoAttribute(cognitoUser, "custom:allowedDomains") ||
      getCognitoAttribute(cognitoUser, "custom:allowedDomain");
    const allowedDomains = parseAllowedDomains(allowedDomainsRaw);

    if (!isCurrentDomainAllowed(currentDomain, allowedDomains)) {
      return res.status(403).json({
        message: "Unauthorized to access from this domain.",
        status: false,
      });
    }

    const challengeResponses = {
      USERNAME: loginUsername,
      SOFTWARE_TOKEN_MFA_CODE: String(code).trim(),
    };
    const loginSecretHash = getSecretHash(loginUsername);
    if (loginSecretHash) {
      challengeResponses.SECRET_HASH = loginSecretHash;
    }

    const challengeResponse = await cognitoClient.send(
      new AdminRespondToAuthChallengeCommand({
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        ClientId: process.env.COGNITO_CLIENT_ID,
        ChallengeName: "SOFTWARE_TOKEN_MFA",
        Session: String(session),
        ChallengeResponses: challengeResponses,
      })
    );

    return completeLogin({
      req,
      res,
      normalizedEmail,
      loginUsername,
      authResult: challengeResponse.AuthenticationResult || {},
      cognitoUser,
    });
  } catch (err) {
    if (isAwsCredentialsError(err)) {
      return res.status(500).json({
        message:
          "AWS credentials missing for Cognito. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (or COGNITO_AWS_ACCESS_KEY_ID and COGNITO_AWS_SECRET_ACCESS_KEY).",
        status: false,
      });
    }
    if (err?.name === "CodeMismatchException") {
      return res.status(400).json({ message: "Invalid MFA code", status: false });
    }
    if (err?.name === "ExpiredCodeException" || err?.name === "NotAuthorizedException") {
      return res.status(401).json({ message: "MFA session expired. Please login again.", status: false });
    }
    return res.status(400).json({
      message: err?.message || "Failed to verify MFA login",
      status: false,
    });
  }
};

export const setupMfa = async (req, res) => {
  try {
    const accessToken = readAccessTokenFromRequest(req);
    if (!accessToken) {
      return res.status(401).json({
        message: "A valid Cognito access token is required. Please login again.",
        status: false,
      });
    }

    const response = await cognitoClient.send(
      new AssociateSoftwareTokenCommand({
        AccessToken: accessToken,
      })
    );

    if (!response?.SecretCode) {
      return res.status(500).json({ message: "Failed to generate MFA secret.", status: false });
    }

    return res.status(200).json({
      message: "MFA setup initiated",
      status: true,
      data: { secretCode: String(response.SecretCode) },
    });
  } catch (err) {
    if (isAwsCredentialsError(err)) {
      return res.status(500).json({
        message:
          "AWS credentials missing for Cognito. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (or COGNITO_AWS_ACCESS_KEY_ID and COGNITO_AWS_SECRET_ACCESS_KEY).",
        status: false,
      });
    }
    return res.status(400).json({
      message: err?.message || "Failed to start MFA setup",
      status: false,
    });
  }
};

export const verifyMfaSetup = async (req, res) => {
  try {
    const { code, userCode } = req.body || {};
    const resolvedCode = String(code || userCode || "").trim();
    if (!isValidTotpCode(resolvedCode)) {
      return res.status(400).json({
        message: "A valid 6-digit code is required.",
        status: false,
      });
    }

    const accessToken = readAccessTokenFromRequest(req);
    if (!accessToken) {
      return res.status(401).json({
        message: "A valid Cognito access token is required. Please login again.",
        status: false,
      });
    }

    await cognitoClient.send(
      new VerifySoftwareTokenCommand({
        AccessToken: accessToken,
        UserCode: resolvedCode,
        FriendlyDeviceName: "Authenticator",
      })
    );

    const cognitoUsername = await resolveCognitoUsernameForRequest(req);
    if (!cognitoUsername) {
      return res.status(404).json({ message: "Cognito user not found", status: false });
    }

    await cognitoClient.send(
      new AdminSetUserMFAPreferenceCommand({
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        Username: cognitoUsername,
        SoftwareTokenMfaSettings: {
          Enabled: true,
          PreferredMfa: true,
        },
      })
    );

    return res.status(200).json({
      message: "MFA setup successfully",
      status: true,
    });
  } catch (err) {
    if (isAwsCredentialsError(err)) {
      return res.status(500).json({
        message:
          "AWS credentials missing for Cognito. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (or COGNITO_AWS_ACCESS_KEY_ID and COGNITO_AWS_SECRET_ACCESS_KEY).",
        status: false,
      });
    }
    if (err?.name === "CodeMismatchException") {
      return res.status(400).json({ message: "Invalid MFA code", status: false });
    }
    return res.status(400).json({
      message: err?.message || "Failed to verify MFA setup",
      status: false,
    });
  }
};

export const disableMfa = async (req, res) => {
  try {
    const cognitoUsername = await resolveCognitoUsernameForRequest(req);
    if (!cognitoUsername) {
      return res.status(404).json({ message: "Cognito user not found", status: false });
    }

    await cognitoClient.send(
      new AdminSetUserMFAPreferenceCommand({
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        Username: cognitoUsername,
        SoftwareTokenMfaSettings: {
          Enabled: false,
          PreferredMfa: false,
        },
      })
    );

    return res.status(200).json({
      message: "MFA disabled successfully",
      status: true,
    });
  } catch (err) {
    if (isAwsCredentialsError(err)) {
      return res.status(500).json({
        message:
          "AWS credentials missing for Cognito. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (or COGNITO_AWS_ACCESS_KEY_ID and COGNITO_AWS_SECRET_ACCESS_KEY).",
        status: false,
      });
    }
    return res.status(400).json({
      message: err?.message || "Failed to disable MFA",
      status: false,
    });
  }
};

export const getMfaStatus = async (req, res) => {
  try {
    const cognitoUsername = await resolveCognitoUsernameForRequest(req);
    if (!cognitoUsername) {
      return res.status(404).json({ message: "Cognito user not found", status: false });
    }

    const cognitoUser = await getCognitoUserByUsername(cognitoUsername);
    const mfaSettings = Array.isArray(cognitoUser?.UserMFASettingList)
      ? cognitoUser.UserMFASettingList
      : [];
    const enabled = mfaSettings.includes("SOFTWARE_TOKEN_MFA");
    const preferred = String(cognitoUser?.PreferredMfaSetting || "") === "SOFTWARE_TOKEN_MFA";

    return res.status(200).json({
      message: "MFA status fetched successfully",
      status: true,
      data: {
        enabled,
        preferred,
        mfaSettings,
      },
    });
  } catch (err) {
    if (isAwsCredentialsError(err)) {
      return res.status(500).json({
        message:
          "AWS credentials missing for Cognito. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (or COGNITO_AWS_ACCESS_KEY_ID and COGNITO_AWS_SECRET_ACCESS_KEY).",
        status: false,
      });
    }
    return res.status(400).json({
      message: err?.message || "Failed to get MFA status",
      status: false,
    });
  }
};

export const logoutUser = (req, res) => {
  const cookieDomain = getCookieDomain(req);
  const cookieDomainOptions = cookieDomain ? { domain: cookieDomain } : {};
  res.clearCookie("accessToken", { ...cookieBaseOptions, ...cookieDomainOptions });
  res.clearCookie("idToken", { ...cookieBaseOptions, ...cookieDomainOptions });
  res.clearCookie("refreshToken", { ...cookieBaseOptions, ...cookieDomainOptions });
  res.json({ message: "Logged out", status: true });
};

export const forgotPasswordUser = async (req, res) => {
  try {
    const { email } = req.body || {};
    if (!email) {
      return res.status(400).json({ message: "Email is required", status: false });
    }

    const normalizedEmail = normalizeEmail(email);
    const resolvedUsername = await resolveCognitoUsernameByEmail(normalizedEmail);
    if (!resolvedUsername) {
      return res.status(404).json({
        message: "User not found",
        status: false,
      });
    }

    const token = jwt.sign(
      { type: "password_reset", email: normalizedEmail },
      process.env.JWT_SECRET || "Automation",
      { expiresIn: "15m" }
    );
    const frontendBase = getFrontendBaseUrl(req);
    const resetLink = `${frontendBase}/reset-password?token=${encodeURIComponent(token)}&email=${encodeURIComponent(
      normalizedEmail
    )}`;
    await sendResetEmail(req, normalizedEmail, resetLink);

    return res.status(200).json({
      message: "Reset link has been sent to your email",
      status: true,
    });
  } catch (err) {
    if (isAwsCredentialsError(err)) {
      return res.status(500).json({
        message:
          "AWS credentials missing for Cognito. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (or COGNITO_AWS_ACCESS_KEY_ID and COGNITO_AWS_SECRET_ACCESS_KEY).",
        status: false,
      });
    }
    return res.status(400).json({
      message: err?.message || "Failed to send reset link",
      status: false,
    });
  }
};

export const confirmForgotPasswordUser = async (req, res) => {
  try {
    const { token, newPassword } = req.body || {};
    if (!token || !newPassword) {
      return res.status(400).json({
        message: "Token and newPassword are required",
        status: false,
      });
    }

    let decoded = null;
    try {
      decoded = jwt.verify(String(token), process.env.JWT_SECRET || "Automation");
    } catch {
      return res.status(400).json({ message: "Invalid or expired reset link", status: false });
    }

    if (!decoded || decoded.type !== "password_reset" || !decoded.email) {
      return res.status(400).json({ message: "Invalid reset token", status: false });
    }

    const normalizedEmail = normalizeEmail(decoded.email);
    const resolvedUsername = await resolveCognitoUsernameByEmail(normalizedEmail);
    if (!resolvedUsername) {
      return res.status(400).json({ message: "Invalid reset link", status: false });
    }

    await cognitoClient.send(
      new AdminSetUserPasswordCommand({
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        Username: resolvedUsername,
        Password: String(newPassword),
        Permanent: true,
      })
    );

    return res.status(200).json({
      message: "Password reset successful",
      status: true,
    });
  } catch (err) {
    if (isAwsCredentialsError(err)) {
      return res.status(500).json({
        message:
          "AWS credentials missing for Cognito. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (or COGNITO_AWS_ACCESS_KEY_ID and COGNITO_AWS_SECRET_ACCESS_KEY).",
        status: false,
      });
    }
    return res.status(400).json({
      message: err?.message || "Failed to reset password",
      status: false,
    });
  }
};

export const verifyEmailUser = async (req, res) => {
  const token = req.query?.token;
  const fallbackBase = getFrontendBaseUrl(req);

  if (!token) {
    return res.redirect(`${fallbackBase}/login?verified=0&reason=missing_token`);
  }

  try {
    const decoded = jwt.verify(String(token), process.env.JWT_SECRET || "Automation");
    if (!decoded || decoded.type !== "email_verify" || !decoded.email) {
      return res.redirect(`${fallbackBase}/login?verified=0&reason=invalid_token`);
    }

    const normalizedEmail = normalizeEmail(decoded.email);
    const resolvedUsername = await resolveCognitoUsernameByEmail(normalizedEmail);
    if (!resolvedUsername) {
      return res.redirect(`${fallbackBase}/login?verified=0&reason=user_not_found`);
    }

    await cognitoClient.send(
      new AdminUpdateUserAttributesCommand({
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        Username: resolvedUsername,
        UserAttributes: [{ Name: "email_verified", Value: "true" }],
      })
    );

    const redirectBase =
      (decoded.redirectBase && String(decoded.redirectBase).replace(/\/$/, "")) || fallbackBase;
    return res.redirect(`${redirectBase}/login?verified=1`);
  } catch {
    return res.redirect(`${fallbackBase}/login?verified=0&reason=expired_or_invalid`);
  }
};
