import MemberModel from "../models/member.model.js";
import RoleModel from "../models/role.model.js";
import OrganisationModel from "../models/organisation.model.js";
import UserModel from "../models/user.model.js";
import mongoose from "mongoose";

// Helper to check permission
const checkPermission = async (reqOrgId, userId, requiredPermission) => {
    const membership = await MemberModel.findOne({ organisationId: reqOrgId, userId }).populate("roleId");
    if (!membership) return false;

    // Owner always has permission
    const org = await OrganisationModel.findById(reqOrgId);
    if (org && org.ownerId === userId) return true;

    // Check role permissions + extra permissions
    const rolePermissions = (membership.roleId && membership.roleId.permissions) ? membership.roleId.permissions : [];
    const extraPermissions = membership.extraPermissions || [];

    const allPermissions = [...rolePermissions, ...extraPermissions];

    return allPermissions.includes(requiredPermission);
};

export const addMember = async (req, res) => {
    try {
        const { orgId } = req.params;
        const { userId: targetUserId, roleId } = req.body;
        const currentUserId = req.user.userId;

        // 1. Validate permissions
        const hasPermission = await checkPermission(orgId, currentUserId, "member.invite"); // Assuming member.invite is still valid for adding
        // Spec didn't specify permission for "Add", checking previous... "member.invite" was used.
        // Spec says "Invite / Add Member" 
        // I will keep "member.invite" as per my best guess or previously established assumption unless contradicted.
        if (!hasPermission) {
            return res.status(403).json({ success: false, message: "Insufficient permissions to add members" });
        }

        // 2. Validate Org Exists
        const org = await OrganisationModel.findById(orgId);
        if (!org) return res.status(404).json({ success: false, message: "Organisation not found" });

        // 3. Ensure user is not already a member
        const existingMember = await MemberModel.findOne({ organisationId: orgId, userId: targetUserId });
        if (existingMember) {
            return res.status(400).json({ success: false, message: "User is already a member" });
        }

        // 4. Validate Role
        const role = await RoleModel.findById(roleId);
        if (!role || role.organisationId.toString() !== orgId) {
            return res.status(400).json({ success: false, message: "Invalid role specified" });
        }

        // 5. Create Member
        const newMember = new MemberModel({
            organisationId: orgId,
            userId: targetUserId,
            roleId: roleId,
            extraPermissions: []
        });
        await newMember.save();

        res.status(201).json({
            success: true,
            data: newMember
        });

    } catch (error) {
        console.error("Error adding member:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const listMembers = async (req, res) => {
    try {
        const { orgId } = req.params;
        const currentUserId = req.user.userId;

        // 1. Permission Check: member:view
        // Spec says "User must be a member of the organisation".
        // But also "Permission Required: member:view".
        // Use checkPermission.
        const hasPermission = await checkPermission(orgId, currentUserId, "member:view");
        if (!hasPermission) {
            // Fallback: if checkPermission logic implies "Owner always has permission", we are good.
            return res.status(403).json({ success: false, message: "Insufficient permissions (member:view required)" });
        }

        // 2. Fetch Members and populate Role
        const members = await MemberModel.find({ organisationId: orgId }).populate("roleId").lean();

        // 3. Fetch User Details
        const userIds = members.map(m => m.userId);
        const validObjectIds = userIds.filter(id => mongoose.isValidObjectId(id));
        const users = await UserModel.find({
            $or: [
                { _id: { $in: validObjectIds } },
                { userId: { $in: userIds } }
            ]
        }).lean();

        const userMap = new Map();
        users.forEach(u => {
            userMap.set(String(u._id), u);
            if (u.userId) userMap.set(u.userId, u);
        });

        // 4. Transform response
        const org = await OrganisationModel.findById(orgId).lean();

        let result = members.map(m => {
            const user = userMap.get(m.userId) || { name: "Unknown User", email: "", image: "" };
            const isOwner = org.ownerId === m.userId;

            return {
                _id: m._id,
                userId: m.userId,
                user: {
                    _id: user._id || m.userId,
                    name: user.full_name || user.name || "Unknown",
                    email: user.email,
                    image: user.profile_pic || user.image || ""
                },
                role: m.roleId ? {
                    _id: m.roleId._id,
                    name: m.roleId.name,
                    slug: m.roleId.slug
                } : null,
                isOwner: isOwner,
                isOwner: isOwner,
                extraPermissions: m.extraPermissions || [],
                metadata: m.metadata || { name: user.full_name || user.name || "Unknown", email: user.email }, // Fallback to user lookup if metadata missing
                createdAt: m.createdAt,
                updatedAt: m.updatedAt
            };
        });

        // 5. Sorting: Owner first -> Oldest members first
        result.sort((a, b) => {
            if (a.isOwner && !b.isOwner) return -1;
            if (!a.isOwner && b.isOwner) return 1;
            return new Date(a.createdAt) - new Date(b.createdAt);
        });

        res.status(200).json({
            success: true,
            data: result
        });

    } catch (error) {
        console.error("Error listing members:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const getMemberCount = async (req, res) => {
    try {
        const { orgId } = req.params;
        const currentUserId = req.user.userId;

        const hasPermission = await checkPermission(orgId, currentUserId, "member:view");
        if (!hasPermission) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const count = await MemberModel.countDocuments({ organisationId: orgId });

        res.status(200).json({
            success: true,
            data: { count }
        });
    } catch (error) {
        console.error("Error counting members:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const getSingleMember = async (req, res) => {
    try {
        const { orgId, memberId } = req.params;
        const currentUserId = req.user.userId;

        const hasPermission = await checkPermission(orgId, currentUserId, "member:view");
        if (!hasPermission) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const m = await MemberModel.findOne({ _id: memberId, organisationId: orgId }).populate("roleId").lean();
        if (!m) {
            return res.status(404).json({ success: false, message: "Member not found" });
        }

        // Fetch user details
        let user = { name: "Unknown", email: "", image: "" };
        const userId = m.userId;
        let mongoUser = null;
        if (mongoose.isValidObjectId(userId)) {
            mongoUser = await UserModel.findById(userId).lean();
        } else {
            mongoUser = await UserModel.findOne({ userId }).lean();
        }

        if (mongoUser) {
            user = {
                name: mongoUser.full_name || mongoUser.name,
                email: mongoUser.email,
                image: mongoUser.profile_pic || mongoUser.image
            };
        }

        const org = await OrganisationModel.findById(orgId).lean();
        const isOwner = org.ownerId === m.userId;

        const result = {
            _id: m._id,
            userId: m.userId,
            user: {
                _id: mongoUser?._id || m.userId,
                ...user
            },
            role: m.roleId ? {
                _id: m.roleId._id,
                name: m.roleId.name,
                slug: m.roleId.slug
            } : null,
            isOwner: isOwner,
            isOwner: isOwner,
            extraPermissions: m.extraPermissions || [],
            metadata: m.metadata || { name: user.name || "Unknown", email: user.email },
            createdAt: m.createdAt,
            updatedAt: m.updatedAt
        };

        res.status(200).json({
            success: true,
            data: result
        });

    } catch (error) {
        console.error("Error getting member:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const changeMemberRole = async (req, res) => {
    try {
        const { orgId, memberId } = req.params;
        const { roleId } = req.body;
        const currentUserId = req.user.userId;

        // Permission: role:assign
        const hasPermission = await checkPermission(orgId, currentUserId, "role:assign");
        if (!hasPermission) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const targetMember = await MemberModel.findOne({ _id: memberId, organisationId: orgId }).populate("roleId");
        if (!targetMember) {
            return res.status(404).json({ success: false, message: "Member not found" });
        }

        const org = await OrganisationModel.findById(orgId);

        // Rule: Owner's role cannot be changed
        if (org.ownerId === targetMember.userId) {
            return res.status(400).json({ success: false, message: "Cannot change role of Organisation Owner" });
        }

        // Rule: Non-owner changing self not allowed
        if (targetMember.userId === currentUserId && org.ownerId !== currentUserId) {
            return res.status(403).json({ success: false, message: "Cannot modify your own role" });
        }

        // Rule: Assign owner role not allowed (usually ownership transfer is separate)
        // Check if new role is Owner role
        const newRole = await RoleModel.findById(roleId);
        if (!newRole || newRole.organisationId.toString() !== orgId) {
            return res.status(400).json({ success: false, message: "Invalid role specified" });
        }

        // Assuming slug 'owner' implies owner role, checking slug
        if (newRole.slug === 'owner') {
            return res.status(400).json({ success: false, message: "Cannot assign Owner role manually. Use transfer ownership." });
        }

        targetMember.roleId = roleId;
        await targetMember.save();

        res.status(200).json({
            success: true,
            message: "Member role updated successfully"
        });

    } catch (error) {
        console.error("Error changing role:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const updateMemberExtraPermissions = async (req, res) => {
    try {
        const { orgId, memberId } = req.params;
        const { extraPermissions } = req.body; // Array of strings
        const currentUserId = req.user.userId;

        // Permission: member:edit
        const hasPermission = await checkPermission(orgId, currentUserId, "member:edit");
        if (!hasPermission) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const targetMember = await MemberModel.findOne({ _id: memberId, organisationId: orgId });
        if (!targetMember) return res.status(404).json({ success: false, message: "Member not found" });

        const org = await OrganisationModel.findById(orgId);

        // Rule: Owner cannot have extraPermissions
        if (org.ownerId === targetMember.userId) {
            return res.status(400).json({ success: false, message: "Owner cannot have extra permissions (already has all)" });
        }

        // TODO: Validate permissions exist in global registry? Skipped for now.

        targetMember.extraPermissions = extraPermissions;
        await targetMember.save();

        res.status(200).json({
            success: true,
            message: "Member permissions updated successfully",
            data: targetMember
        });

    } catch (error) {
        console.error("Error updating permissions:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const removeMember = async (req, res) => {
    try {
        const { orgId, memberId } = req.params;
        const currentUserId = req.user.userId;

        // Permission: member:remove
        const hasPermission = await checkPermission(orgId, currentUserId, "member:remove");
        if (!hasPermission) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const targetMember = await MemberModel.findOne({ _id: memberId, organisationId: orgId });
        if (!targetMember) {
            return res.status(404).json({ success: false, message: "Member not found" });
        }

        const org = await OrganisationModel.findById(orgId);

        // Rule: Owner cannot be removed
        if (org.ownerId === targetMember.userId) {
            return res.status(400).json({ success: false, message: "Cannot remove Organisation Owner" });
        }

        // Rule: You cannot remove yourself
        if (targetMember.userId === currentUserId) {
            return res.status(400).json({ success: false, message: "You cannot remove yourself" });
        }

        await MemberModel.findByIdAndDelete(memberId);

        res.status(200).json({
            success: true,
            message: "Member removed successfully"
        });

    } catch (error) {
        console.error("Error removing member:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export const getMyMembership = async (req, res) => {
    try {
        const { orgId } = req.params;
        const currentUserId = req.user.userId;

        const membership = await MemberModel.findOne({ organisationId: orgId, userId: currentUserId }).populate("roleId");
        if (!membership) {
            return res.status(404).json({ success: false, message: "Membership not found" });
        }

        const org = await OrganisationModel.findById(orgId);
        const isOwner = org.ownerId === currentUserId;

        // Calculate final permissions
        const rolePermissions = membership.roleId?.permissions || [];
        const extraPermissions = membership.extraPermissions || [];
        // If owner, maybe return '*' or all? Spec says "isOwner ? ALL : none" logic for calculation.
        // Returns explicit permissions list.
        // If owner, we might check permissions in frontend by isOwner flag, but let's provide permissions array too.
        // If owner, let's just return what they have (which might be all if default role has keys).
        // Actually spec says "Final Permissions = ... + (isOwner ? ALL : none)". 
        // Backend doesn't need to return "ALL" string, frontend usually handles isOwner checks.
        // I'll return the combined list.

        res.status(200).json({
            memberId: membership._id,
            role: membership.roleId.slug,
            permissions: [...rolePermissions, ...extraPermissions],
            isOwner: isOwner
        });

    } catch (error) {
        console.error("Error getting membership:", error);
        res.status(500).json({ success: false, message: error.message });
    }
}
