import UserModel from "../../models/user.model.js";

const resolveResellerScope = (req, localUser, effectiveRole) => {
  if (localUser?.reseller_id) return String(localUser.reseller_id);
  if (req.user?.resellerId) return String(req.user.resellerId);

  if (effectiveRole === "reseller") {
    return String(localUser?.userId || req.user?.userId || req.user?._id || "");
  }

  return null;
};

async function getRequesterFromUserDb(req) {
  const userId = String(req.user?.userId || req.user?._id || "").trim();
  const email = String(req.user?.email || "").toLowerCase().trim();

  if (!userId && !email) return null;

  const user = await UserModel.findOne({
    $or: [
      ...(userId ? [{ userId }] : []),
      ...(email ? [{ email }] : []),
    ],
  })
    .select("_id userId email role reseller_id")
    .lean();

  return user || null;
}

export const listResellerUsers = async (req, res) => {
  try {
    const requester = await getRequesterFromUserDb(req);
    const effectiveRole = String(requester?.role || req.user?.role || "").toLowerCase();

    if (effectiveRole !== "reseller") {
      return res.status(403).json({ success: false, message: "Access denied. Resellers only." });
    }

    const resellerId = resolveResellerScope(req, requester, effectiveRole);
    if (!resellerId) {
      return res.status(400).json({ success: false, message: "Reseller context not found." });
    }

    const users = await UserModel.find({ reseller_id: String(resellerId) })
      .sort({ updatedAt: -1 })
      .select("_id userId full_name email role reseller_id mediaStorageGb createdAt updatedAt")
      .lean();

    return res.status(200).json({
      success: true,
      data: users.map((user) => ({
        id: String(user._id),
        authUserId: user.userId || String(user._id),
        appRole: user.role || "user",
        name: user.full_name || "",
        email: user.email || "",
        resellerId: user.reseller_id || null,
        mediaStorageGb: Number(user.mediaStorageGb || 0),
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      })),
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export default listResellerUsers;
