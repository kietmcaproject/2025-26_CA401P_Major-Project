import UserModel from "../../models/user.model.js";
import { uploadMulterFileToS3 } from "../../utils/s3-upload.js";
import mongoose from "mongoose";
import {
    AdminUpdateUserAttributesCommand,
    ListUsersCommand,
} from "@aws-sdk/client-cognito-identity-provider";
import { cognitoClient } from "../../config/cognito.js";

const REQUIRED_COGNITO_PROFILE_FIELDS = [
    "custom:addressline",
    "custom:state",
    "custom:city",
    "custom:country",
    "custom:phone",
    "custom:pincode",
    "custom:profilePicture",
];

function isAwsCredentialsError(err) {
    if (!err) return false;
    const message = String(err?.message || "");
    return (
        err?.name === "CredentialsProviderError" ||
        message.includes("Could not load credentials from any providers") ||
        message.includes("Resolved credential object is not valid")
    );
}

async function resolveCognitoUsername(req) {
    const directUsername = req.user?.cognitoUsername || req.user?.username || null;
    if (directUsername) return String(directUsername);

    const email = String(req.user?.email || "").toLowerCase().trim();
    if (!email) return null;

    const response = await cognitoClient.send(
        new ListUsersCommand({
            UserPoolId: process.env.COGNITO_USER_POOL_ID,
            Filter: `email = "${email}"`,
            Limit: 1,
        })
    );

    const found = Array.isArray(response?.Users) ? response.Users[0] : null;
    return found?.Username ? String(found.Username) : null;
}

export const uploadProfilePhoto = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, message: "No image file provided" });
        }

        const userId = req.user._id || req.user.userId;
        let resellerId = req.user.resellerId;

        // If user doesn't have a resellerId (e.g. they are a reseller themselves or admin),
        // we might want to use a fallback or their own ID if they are a reseller.
        // Assuming if no resellerId, we might just store it under 'default' or similar, 
        // OR if they are a reseller, use their own ID.
        if (!resellerId && req.user.role === 'reseller') {
            resellerId = userId;
        }

        // Fallback if still no resellerId (e.g. platform admin or direct user)
        const rootFolder = resellerId ? resellerId : 'default';

        // Structure: resellerid/userid/image/profilephoto
        const folder = `${rootFolder}/${userId}/image/profilephoto`;

        console.log(`Uploading profile photo to folder: ${folder}`);

        const publicUrl = await uploadMulterFileToS3(req.file, folder, { req });

        // Update user profile in database
        // Update user profile in database if user exists locally
        // We don't verify strict existence here because the user might only exist in the central auth DB
        let user = null;
        if (mongoose.isValidObjectId(userId)) {
            user = await UserModel.findById(userId);
        }
        if (!user) {
            user = await UserModel.findOne({
                $or: [{ userId: String(userId) }, ...(req.user?.email ? [{ email: req.user.email }] : [])],
            });
        }

        if (user) {
            user.profile_pic = publicUrl;
            user = await user.save();
        } else {
            console.log(`User ${userId} not found in local MongoDB - skipping local update (User exists in central Auth DB)`);
        }

        const cognitoUsername = await resolveCognitoUsername(req);
        if (cognitoUsername) {
            await cognitoClient.send(
                new AdminUpdateUserAttributesCommand({
                    UserPoolId: process.env.COGNITO_USER_POOL_ID,
                    Username: cognitoUsername,
                    UserAttributes: [{ Name: "custom:profilePicture", Value: String(publicUrl) }],
                })
            );
        }

        return res.status(200).json({
            success: true,
            message: "Profile photo uploaded successfully",
            data: {
                imageUrl: publicUrl,
                user: user // user might be null if not in local DB
            }
        });

    } catch (error) {
        console.error("Error uploading profile photo:", error);
        if (isAwsCredentialsError(error)) {
            return res.status(500).json({
                success: false,
                message:
                    "AWS credentials missing for Cognito. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (or COGNITO_AWS_ACCESS_KEY_ID and COGNITO_AWS_SECRET_ACCESS_KEY).",
            });
        }
        return res.status(500).json({ success: false, message: error.message });
    }
};

export const updateRequiredProfileDetails = async (req, res) => {
    try {
        const {
            addressline,
            state,
            city,
            country,
            phone,
            pincode,
            profilePicture,
        } = req.body || {};

        const updates = [];
        const pushIfPresent = (name, value) => {
            if (typeof value === "string" && value.trim()) {
                updates.push({ Name: name, Value: value.trim() });
            }
        };

        pushIfPresent("custom:addressline", addressline);
        pushIfPresent("custom:state", state);
        pushIfPresent("custom:city", city);
        pushIfPresent("custom:country", country);
        pushIfPresent("custom:phone", phone);
        pushIfPresent("custom:pincode", pincode);
        pushIfPresent("custom:profilePicture", profilePicture);

        if (updates.length === 0) {
            return res.status(400).json({
                status: false,
                message: "No valid profile fields provided.",
                requiredFields: REQUIRED_COGNITO_PROFILE_FIELDS,
            });
        }

        const cognitoUsername = await resolveCognitoUsername(req);
        if (!cognitoUsername) {
            return res.status(404).json({
                status: false,
                message: "Cognito user not found.",
            });
        }

        await cognitoClient.send(
            new AdminUpdateUserAttributesCommand({
                UserPoolId: process.env.COGNITO_USER_POOL_ID,
                Username: cognitoUsername,
                UserAttributes: updates,
            })
        );

        if (typeof profilePicture === "string" && profilePicture.trim()) {
            const userId = req.user?._id || req.user?.userId;
            let user = null;
            if (mongoose.isValidObjectId(userId)) {
                user = await UserModel.findById(userId);
            }
            if (!user) {
                user = await UserModel.findOne({
                    $or: [{ userId: String(userId) }, ...(req.user?.email ? [{ email: req.user.email }] : [])],
                });
            }
            if (user) {
                user.profile_pic = profilePicture.trim();
                await user.save();
            }
        }

        return res.status(200).json({
            status: true,
            message: "Profile details updated successfully.",
            data: {
                updatedFields: updates.map((a) => a.Name),
            },
        });
    } catch (error) {
        if (isAwsCredentialsError(error)) {
            return res.status(500).json({
                status: false,
                message:
                    "AWS credentials missing for Cognito. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (or COGNITO_AWS_ACCESS_KEY_ID and COGNITO_AWS_SECRET_ACCESS_KEY).",
            });
        }
        return res.status(500).json({
            status: false,
            message: error?.message || "Failed to update required profile details.",
        });
    }
};
