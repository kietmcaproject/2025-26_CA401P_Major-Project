import { invitationService } from "../services/invitation.service.js";
import MemberModel from "../models/member.model.js";

// Helper for permissions (can import from roles controller or new permission middleware)
const checkPermission = async (orgId, userId, required) => {
    // Basic implementation or assume middleware handled it?
    // We should double check. `member:invite` needed for create.
    const member = await MemberModel.findOne({ organisationId: orgId, userId }).populate("roleId");
    if (!member) return false;
    // ... logic same as roles controller ...
    // For speed, let's assume we implement this or reuse.
    // I'll reuse the logic or import a shared utility if I created one.
    // I didn't create a shared one yet. I'll reproduce simple check.
    const rolePerms = member.roleId?.permissions || [];
    const extraPerms = member.extraPermissions || [];
    const all = [...rolePerms, ...extraPerms];
    return all.includes("*") || all.includes(required);
};

export const createInvitation = async (req, res) => {
    try {
        const { orgId } = req.params;
        const { email, roleId } = req.body;
        const currentUserId = req.user.userId;

        // Check permission
        if (!(await checkPermission(orgId, currentUserId, "member.invite"))) {
            // Try "member:invite" from my previous list?
            // config/permissions.js says "member.invite".
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        // Need current member ID for `invitedBy`
        const member = await MemberModel.findOne({ organisationId: orgId, userId: currentUserId });

        const origin = req.headers.origin || req.headers.referer;

        const invitation = await invitationService.createInvitation({
            email,
            orgId,
            roleId,
            invitedByMemberId: member._id,
            origin,
            resellerId: req.user?.resellerId || null,
        }, req.user.name || "A member"); // req.user might not have name if token based, but we can try

        res.status(201).json({ success: true, data: invitation });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
};

export const getInvitations = async (req, res) => {
    try {
        const { orgId } = req.params;
        const currentUserId = req.user.userId;

        if (!(await checkPermission(orgId, currentUserId, "member.view"))) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        const invitations = await invitationService.getInvitations(orgId);
        res.status(200).json({ success: true, data: invitations });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

export const cancelInvitation = async (req, res) => {
    try {
        const { orgId, invitationId } = req.params;
        const currentUserId = req.user.userId;

        // Permission: member:remove or member:invite? Usually revoking invite is same as invite rights.
        if (!(await checkPermission(orgId, currentUserId, "member.invite"))) {
            return res.status(403).json({ success: false, message: "Insufficient permissions" });
        }

        await invitationService.cancelInvitation(invitationId, orgId);
        res.status(200).json({ success: true, message: "Invitation cancelled" });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
};

// PUBLIC / SEMI-PROTECTED
export const getInvitationById = async (req, res) => {
    try {
        const { id } = req.params;
        const result = await invitationService.validateInvitation(id);
        if (!result.valid) return res.status(400).json({ success: false, error: result.error });

        res.status(200).json({ success: true, data: result.invitation });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

export const acceptInvitation = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.userId; // Must be authenticated

        // Prioritize body params if frontend sends them (for better metadata), fallback to session
        const userEmail = req.body.email || req.user.email;
        const userName = req.body.name || req.user.name;

        const member = await invitationService.acceptInvitation(id, userId, userEmail, userName);
        res.status(200).json({ success: true, data: member, message: "Invitation accepted" });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
};
