/**
 * Resolves the frontend origin from request headers.
 * Falls back to FRONTEND_URL environment variable if headers are missing.
 * @param {import('express').Request} req 
 * @returns {string}
 */
export const getFrontendOrigin = (req) => {
    const origin = req.headers.origin || req.headers.referer;
    if (origin) {
        try {
            // Return origin without trailing slash
            return new URL(origin).origin;
        } catch (e) {
            // Fallback
        }
    }
    return (process.env.FRONTEND_URL || "http://localhost:3000").replace(/\/$/, "");
};
