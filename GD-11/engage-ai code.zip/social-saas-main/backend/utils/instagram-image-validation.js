const INSTAGRAM_MIN_ASPECT_RATIO = 4 / 5;
const INSTAGRAM_MAX_ASPECT_RATIO = 1.91;

export function validateInstagramImageFile(file) {
  if (!file?.buffer) {
    return null;
  }

  const dimensions = getImageDimensions(file.buffer);
  if (!dimensions) {
    return null;
  }

  const { width, height, format } = dimensions;
  if (!width || !height) {
    return null;
  }

  const aspectRatio = width / height;

  if (
    aspectRatio < INSTAGRAM_MIN_ASPECT_RATIO ||
    aspectRatio > INSTAGRAM_MAX_ASPECT_RATIO
  ) {
    const error = new Error(
      `Instagram image aspect ratio must be between 4:5 and 1.91:1. Received ${width}x${height} (${aspectRatio.toFixed(
        2
      )}:1${format ? `, ${format}` : ""}).`
    );
    error.statusCode = 400;
    throw error;
  }

  return {
    width,
    height,
    aspectRatio,
    format,
  };
}

function getImageDimensions(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 10) {
    return null;
  }

  if (isPng(buffer)) {
    return {
      format: "png",
      width: buffer.readUInt32BE(16),
      height: buffer.readUInt32BE(20),
    };
  }

  if (isGif(buffer)) {
    return {
      format: "gif",
      width: buffer.readUInt16LE(6),
      height: buffer.readUInt16LE(8),
    };
  }

  if (isJpeg(buffer)) {
    return getJpegDimensions(buffer);
  }

  return null;
}

function isPng(buffer) {
  return (
    buffer.length >= 24 &&
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47
  );
}

function isGif(buffer) {
  return (
    buffer.length >= 10 &&
    buffer.toString("ascii", 0, 3) === "GIF"
  );
}

function isJpeg(buffer) {
  return buffer.length >= 4 && buffer[0] === 0xff && buffer[1] === 0xd8;
}

function getJpegDimensions(buffer) {
  let offset = 2;

  while (offset < buffer.length) {
    if (buffer[offset] !== 0xff) {
      offset += 1;
      continue;
    }

    const marker = buffer[offset + 1];

    if (marker === 0xd8 || marker === 0xd9) {
      offset += 2;
      continue;
    }

    if (marker >= 0xd0 && marker <= 0xd7) {
      offset += 2;
      continue;
    }

    if (offset + 4 > buffer.length) {
      break;
    }

    const blockLength = buffer.readUInt16BE(offset + 2);
    if (!blockLength || offset + 2 + blockLength > buffer.length) {
      break;
    }

    if (isStartOfFrameMarker(marker)) {
      if (offset + 9 > buffer.length) {
        break;
      }

      return {
        format: "jpeg",
        height: buffer.readUInt16BE(offset + 5),
        width: buffer.readUInt16BE(offset + 7),
      };
    }

    offset += 2 + blockLength;
  }

  return null;
}

function isStartOfFrameMarker(marker) {
  return [
    0xc0, 0xc1, 0xc2, 0xc3,
    0xc5, 0xc6, 0xc7,
    0xc9, 0xca, 0xcb,
    0xcd, 0xce, 0xcf,
  ].includes(marker);
}
