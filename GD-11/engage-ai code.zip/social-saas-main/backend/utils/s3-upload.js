import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { v4 as uuidv4 } from "uuid";
import axios from "axios";
import {
  extractFullOriginDomain,
  normalizeFullOriginDomain,
  extractOriginDomain,
  normalizeOriginDomain,
} from "../services/smtp-config.service.js";

// Cache S3 clients by credential fingerprint to avoid recreating clients.
const s3ClientCache = new Map();

/**
 * Get or create S3 client instance
 */
const toTrimmed = (value) => String(value || "").trim();

const toBoolean = (value, fallback = false) => {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value !== 0;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (["true", "1", "yes", "y", "on"].includes(normalized)) return true;
    if (["false", "0", "no", "n", "off"].includes(normalized)) return false;
  }
  return fallback;
};

const toNumber = (value, fallback) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const stripQuotes = (value) => {
  const text = toTrimmed(value);
  if (!text) return "";
  if (
    (text.startsWith('"') && text.endsWith('"')) ||
    (text.startsWith("'") && text.endsWith("'"))
  ) {
    return text.slice(1, -1).trim();
  }
  return text;
};

const getApiToken = () =>
  toTrimmed(
    process.env.SOCIAL_CONFIG_API_TOKEN ||
      process.env.X_API_TOKEN ||
      process.env.STORAGE_API_TOKEN ||
      process.env["x-api-token"] ||
      process.env.API_TOKEN
  );

const isLocalHost = (hostname) => {
  const host = toTrimmed(hostname).toLowerCase();
  if (!host) return true;
  return (
    host === "localhost" ||
    host.endsWith(".localhost") ||
    /^\d{1,3}(\.\d{1,3}){3}$/.test(host) ||
    host === "::1"
  );
};

const getParentDomain = (hostname) => {
  const parts = toTrimmed(hostname).toLowerCase().split(".").filter(Boolean);
  if (parts.length > 2) return parts.slice(1).join(".");
  return parts.join(".");
};

const buildStorageApiUrl = (originDomain) => {
  const fullOrigin = normalizeFullOriginDomain(originDomain);
  if (!fullOrigin || isLocalHost(fullOrigin)) return null;

  const parentDomain = getParentDomain(fullOrigin);
  if (!parentDomain) return null;

  return `https://reseller.${parentDomain}/api/social-config/storage?originDomain=${encodeURIComponent(
    fullOrigin
  )}`;
};

const hasRequiredStorageFields = (config) =>
  Boolean(config?.accessKeyId && config?.secretAccessKey && config?.bucketName);

const getEnvStorageConfig = () => ({
  region: stripQuotes(process.env.AWS_REGION || "ap-south-1"),
  endpoint: toTrimmed(process.env.S3_ENDPOINT),
  accessKeyId: stripQuotes(process.env.S3ACCESSKEYID),
  secretAccessKey: stripQuotes(process.env.S3ACCESSKEY),
  bucketName: stripQuotes(process.env.BUCKETNAME || "email-backend-ticket"),
  bucketPublicUrl: toTrimmed(process.env.BUCKETPUBLICURL),
  forcePathStyle: toBoolean(process.env.S3_FORCE_PATH_STYLE || true, true),
});

const mapRemoteStoragePayload = (payload) => {
  const root = payload && typeof payload === "object" ? payload : {};
  const data = root.data && typeof root.data === "object" ? root.data : null;
  if (!data) return null;

  const nestedStorage =
    (data.storage && typeof data.storage === "object" && data.storage) ||
    (data.s3 && typeof data.s3 === "object" && data.s3) ||
    {};

  const merged = { ...data, ...nestedStorage };

  const isEnabled = toBoolean(merged.isEnabled ?? merged.enabled ?? true, true);
  if (!isEnabled) return { enabled: false, config: null };

  const config = {
    region: stripQuotes(merged.region || merged.awsRegion || "ap-south-1"),
    endpoint: toTrimmed(merged.endpoint || merged.s3Endpoint),
    accessKeyId: stripQuotes(
      merged.accessKeyId ||
      merged.accessKey ||
      merged.keyId ||
      merged.s3AccessKeyId
    ),
    secretAccessKey: stripQuotes(
      merged.secretAccessKey ||
      merged.secretKey ||
      merged.s3AccessKey
    ),
    bucketName: stripQuotes(merged.bucketName || merged.bucket || merged.bucket_name),
    bucketPublicUrl: toTrimmed(
      merged.bucketPublicUrl || merged.publicUrl || merged.cdnUrl || merged.publicBaseUrl
    ),
    forcePathStyle: toBoolean(merged.forcePathStyle ?? merged.pathStyle ?? true, true),
  };

  if (!hasRequiredStorageFields(config)) {
    return { enabled: false, config: null };
  }

  return { enabled: true, config };
};

const fetchRemoteStorageConfig = async ({ req, originDomain } = {}) => {
  const fullOrigin =
    normalizeFullOriginDomain(originDomain) ||
    extractFullOriginDomain(req) ||
    normalizeOriginDomain(originDomain) ||
    extractOriginDomain(req);

  const url = buildStorageApiUrl(fullOrigin);
  if (!url) return null;

  try {
    const response = await axios.get(url, {
      timeout: 5000,
      headers: {
        "x-api-token": getApiToken(),
      },
      validateStatus: () => true,
    });

    if (response.status < 200 || response.status >= 300) {
      return null;
    }

    return mapRemoteStoragePayload(response.data);
  } catch (error) {
    console.warn("[S3 Config] Failed to fetch reseller storage config:", error?.message || error);
    return null;
  }
};

const resolveStorageContext = async (options = {}) => {
  const remote = await fetchRemoteStorageConfig(options);
  const envConfig = getEnvStorageConfig();

  if (remote?.enabled && hasRequiredStorageFields(remote.config)) {
    return { source: "reseller-api", config: remote.config };
  }

  if (hasRequiredStorageFields(envConfig)) {
    return { source: "env", config: envConfig };
  }

  console.error("[S3 Config] Missing S3 credentials in reseller API and env fallback.");
  throw new Error("S3 credentials are not configured. Set reseller storage config or env S3 values.");
};

const getS3Client = (config) => {
  const key = [
    config.region,
    config.endpoint || "",
    config.accessKeyId,
    config.bucketName,
    String(config.forcePathStyle),
  ].join("|");

  if (s3ClientCache.has(key)) {
    return s3ClientCache.get(key);
  }

  const client = new S3Client({
    region: config.region || "ap-south-1",
    credentials: {
      accessKeyId: config.accessKeyId,
      secretAccessKey: config.secretAccessKey,
    },
    ...(config.endpoint ? { endpoint: config.endpoint } : {}),
    forcePathStyle: Boolean(config.forcePathStyle),
  });

  s3ClientCache.set(key, client);
  return client;
};

const getPublicBaseUrl = (config) => {
  const configured = toTrimmed(config.bucketPublicUrl);
  if (configured) return configured.replace(/\/$/, "");

  const endpoint = toTrimmed(config.endpoint).replace(/\/$/, "");
  if (!endpoint) return "";

  return `${endpoint}/${config.bucketName}`.replace(/\/$/, "");
};

/**
 * Upload a file buffer to S3
 * @param {Buffer} fileBuffer - File buffer to upload
 * @param {string} originalFileName - Original file name
 * @param {string} contentType - MIME type (e.g., 'image/jpeg', 'video/mp4')
 * @param {string} folder - Optional folder path in S3 (e.g., 'images', 'videos')
 * @returns {Promise<string>} Public URL of the uploaded file
 */
export const uploadToS3 = async (
  fileBuffer,
  originalFileName,
  contentType,
  folder = "social-media",
  options = {}
) => {
  try {
    const storage = await resolveStorageContext(options);
    const config = storage.config;
    const client = getS3Client(config);
    const bucketName = config.bucketName;
    const publicBase = getPublicBaseUrl(config);

    // Generate unique file name
    const fileExtension = originalFileName.split(".").pop() || "jpg";
    const timestamp = Date.now();
    const uniqueId = uuidv4().split("-")[0];
    const fileName = `${folder}/${timestamp}-${uniqueId}.${fileExtension}`;

    console.log("[S3 Upload] Uploading file:", {
      source: storage.source,
      bucket: bucketName,
      key: fileName,
      contentType,
      size: fileBuffer.length,
    });

    // Upload to S3
    const command = new PutObjectCommand({
      Bucket: bucketName,
      Key: fileName,
      Body: fileBuffer,
      ContentType: contentType,
      // Note: ACL is deprecated in newer S3 buckets. Ensure bucket has public read access policy.
      // If ACL doesn't work, configure bucket policy to allow public read access
    });

    await client.send(command);

    const publicUrl = publicBase ? `${publicBase}/${fileName}` : fileName;

    console.log("[S3 Upload] File uploaded successfully:", publicUrl);

    return publicUrl;
  } catch (error) {
    console.error("[S3 Upload] Error uploading file:", error);
    console.error("[S3 Upload] Error details:", {
      message: error.message,
      name: error.name,
      stack: error.stack,
    });
    throw new Error(`Failed to upload file to S3: ${error.message}`);
  }
};

/**
 * Upload a base64 image to S3
 * @param {string} base64String - Base64 encoded image string (with data URI prefix)
 * @param {Object} options - Optional context { req, originDomain }
 * @returns {Promise<string>} Public URL of the uploaded image
 */
export const uploadBase64ToS3 = async (base64String, options = {}) => {
  try {
    // Extract base64 data
    const matches = base64String.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      throw new Error("Invalid base64 string");
    }

    const contentType = matches[1]; // e.g., 'image/jpeg'
    const imageData = matches[2];
    const buffer = Buffer.from(imageData, "base64");

    // Determine file extension from content type
    const ext = contentType.split("/")[1] || "jpg";
    const fileName = `image-${Date.now()}.${ext}`;

    // Upload to S3
    return await uploadToS3(buffer, fileName, contentType, "images", options);
  } catch (error) {
    console.error("[S3 Upload] Error uploading base64 image:", error);
    throw error;
  }
};

/**
 * Upload a file from multer file object to S3
 * @param {Object} file - Multer file object (req.file or req.files[0])
 * @param {string} folder - Optional folder path in S3
 * @param {Object} options - Optional context { req, originDomain }
 * @returns {Promise<string>} Public URL of the uploaded file
 */
export const uploadMulterFileToS3 = async (file, folder = "social-media", options = {}) => {
  try {
    if (!file || !file.buffer) {
      throw new Error("Invalid file object - file.buffer is required");
    }

    const contentType = file.mimetype || "application/octet-stream";
    const originalName = file.originalname || `file-${Date.now()}`;

    return await uploadToS3(file.buffer, originalName, contentType, folder, options);
  } catch (error) {
    console.error("[S3 Upload] Error uploading multer file:", error);
    throw error;
  }
};

export default {
  uploadToS3,
  uploadBase64ToS3,
  uploadMulterFileToS3,
};

