export const PERMISSIONS = {
    "org.update": { group: "Organisation", label: "Edit organisation" },
    "member.invite": { group: "Members", label: "Invite members" },
    "member.view": { group: "Members", label: "View members" },
    "member.edit": { group: "Members", label: "Edit member permissions" },
    "member.remove": { group: "Members", label: "Remove members" },
    "role.view": { group: "Roles", label: "View roles" },
    "role.create": { group: "Roles", label: "Create roles" },
    "role.edit": { group: "Roles", label: "Edit roles" },
    "role.delete": { group: "Roles", label: "Delete roles" },
    "role.assign": { group: "Roles", label: "Assign roles" },
    "billing.view": { group: "Billing", label: "View billing" },
    "ticket.read": { group: "Support", label: "Read tickets" },
    "ticket.reply": { group: "Support", label: "Reply to tickets" }
};

export const AVAILABLE_PERMISSIONS = Object.keys(PERMISSIONS);
