import { CognitoIdentityProviderClient } from "@aws-sdk/client-cognito-identity-provider";

const region = process.env.COGNITO_AWS_REGION || process.env.AWS_REGION || "ap-south-1";

const accessKeyId =
  process.env.COGNITO_AWS_ACCESS_KEY_ID ||
  process.env.AWS_ACCESS_KEY_ID ||
  null;

const secretAccessKey =
  process.env.COGNITO_AWS_SECRET_ACCESS_KEY ||
  process.env.AWS_SECRET_ACCESS_KEY ||
  null;

const sessionToken =
  process.env.COGNITO_AWS_SESSION_TOKEN ||
  process.env.AWS_SESSION_TOKEN ||
  null;

const clientConfig = {
  region,
};

// If explicit credentials are provided, use them.
if (accessKeyId && secretAccessKey) {
  clientConfig.credentials = {
    accessKeyId,
    secretAccessKey,
    ...(sessionToken ? { sessionToken } : {}),
  };
}

export const cognitoClient = new CognitoIdentityProviderClient({
  ...clientConfig,
});
