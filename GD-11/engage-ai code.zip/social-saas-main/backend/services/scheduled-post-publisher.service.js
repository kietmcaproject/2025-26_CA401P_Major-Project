import axios from "axios";
import AppCredentials from "../models/appcredentials.model.js";
import Post from "../models/post.model.js";
import { getAppConfig } from "../utils/getAppConfig.js";

export const publishScheduledPost = async (postId) => {
  const post = await Post.findOneAndUpdate(
    { _id: postId, status: "SCHEDULED" },
    {
      $set: {
        status: "PROCESSING",
        errorMessage: null,
      },
    },
    { new: true }
  );

  if (!post) {
    const existingPost = await Post.findById(postId).select("_id status");

    if (!existingPost) {
      console.warn(`[Scheduler] Skipping missing post ${postId}`);
      return { skipped: true, reason: "missing" };
    }

    console.warn(
      `[Scheduler] Skipping post ${postId} because it is ${existingPost.status}`
    );
    return {
      skipped: true,
      reason: String(existingPost.status || "unknown").toLowerCase(),
    };
  }

  console.log(`[Scheduler] Publishing post ${post._id} to ${post.platform}`);

  try {
    let result;

    switch (post.platform) {
      case "FACEBOOK":
        result = await publishFacebookPost(post);
        break;
      case "INSTAGRAM":
        result = await publishInstagramPost(post);
        break;
      case "LINKEDIN":
        result = await publishLinkedInPost(post);
        break;
      case "YOUTUBE":
        result = await publishYouTubePost(post);
        break;
      default:
        throw new Error(`Unsupported platform: ${post.platform}`);
    }

    post.status = "PUBLISHED";
    post.publishedAt = new Date();
    post.errorMessage = null;

    if (result?.postId) post.postId = result.postId;
    if (result?.videoId) post.videoId = result.videoId;
    if (result?.channelId) post.channelId = result.channelId;
    if (result?.postUrl) post.postUrl = result.postUrl;
    if (result?.videoUrl) post.videoUrl = result.videoUrl;
    if (result?.thumbnailUrl) post.thumbnailUrl = result.thumbnailUrl;

    await post.save();
    console.log(`[Scheduler] Successfully published post ${post._id}`);

    return result;
  } catch (error) {
    const errorMessage = getAxiosErrorMessage(error);
    console.error(`[Scheduler] Failed to publish post ${post._id}:`, errorMessage);
    post.status = "FAILED";
    post.errorMessage = errorMessage;
    await post.save({ validateBeforeSave: false });
    throw error;
  }
};

async function publishFacebookPost(post) {
  const { userId, pageId, content, mediaUrl, postType } = post;
  console.log(
    `[Scheduler] Publishing to Facebook - pageId: ${pageId}, postType: ${postType}, hasMedia: ${!!mediaUrl}`
  );

  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "FACEBOOK",
  });

  if (!appCredential) {
    throw new Error("Facebook not connected");
  }

  const page = appCredential.credentials.pages.find((item) => item.pageId === pageId);
  if (!page) {
    throw new Error("Page not found");
  }

  const pageToken = page.page_access_token;
  console.log(`[Scheduler] Found page: ${page.pageName || pageId}`);

  if (postType === "video" && mediaUrl) {
    const videoRes = await axios.post(
      `https://graph-video.facebook.com/v20.0/${pageId}/videos`,
      null,
      {
        params: {
          file_url: mediaUrl,
          description: content || "",
          access_token: pageToken,
        },
      }
    );

    return { postId: videoRes.data.id };
  }

  if (mediaUrl) {
    const photoRes = await axios.post(
      `https://graph.facebook.com/v20.0/${pageId}/photos`,
      null,
      {
        params: {
          url: mediaUrl,
          caption: content,
          access_token: pageToken,
        },
      }
    );

    return { postId: photoRes.data.id };
  }

  const postRes = await axios.post(
    `https://graph.facebook.com/v20.0/${pageId}/feed`,
    null,
    {
      params: {
        message: content,
        access_token: pageToken,
      },
    }
  );

  return { postId: postRes.data.id };
}

async function publishInstagramPost(post) {
  const { userId, pageId, caption, mediaUrl, postType } = post;
  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "INSTAGRAM",
  });

  if (!appCredential) {
    throw new Error("Instagram not connected");
  }

  if (!mediaUrl) {
    throw new Error("Instagram requires media");
  }

  let igAccountId;
  let instagramToken;

  if (
    appCredential.credentials.instagram_account_id &&
    appCredential.credentials.instagram_user_access_token
  ) {
    igAccountId = appCredential.credentials.instagram_account_id;
    instagramToken = appCredential.credentials.instagram_user_access_token;
  } else {
    const page = appCredential.credentials.pages?.find(
      (item) => item.pageId === pageId || !pageId
    );

    if (!page || !page.instagram_account_id) {
      throw new Error("Instagram account not found");
    }

    igAccountId = page.instagram_account_id;
    instagramToken = page.page_access_token;
  }

  const isVideo = postType === "reel" || postType === "video";
  const containerParams = {
    access_token: instagramToken,
    caption: caption || "",
  };

  if (isVideo) {
    containerParams.media_type = "REELS";
    containerParams.video_url = mediaUrl;
  } else {
    containerParams.image_url = mediaUrl;
  }

  console.log(
    `[Scheduler] Creating Instagram ${isVideo ? "video" : "image"} container for post ${post._id}`
  );

  try {
    const headRes = await axios.head(mediaUrl, {
      timeout: 5000,
      validateStatus: () => true,
      maxRedirects: 5,
    });
    console.log(
      `[Scheduler] Instagram media URL check for post ${post._id}: ${headRes.status}`
    );
  } catch (urlCheckErr) {
    console.warn(
      `[Scheduler] Could not verify Instagram media URL for post ${post._id}:`,
      urlCheckErr.message
    );
  }

  const containerRes = await axios.post(
    `https://graph.instagram.com/v24.0/${igAccountId}/media`,
    null,
    { params: containerParams }
  );

  const containerId = containerRes.data.id;
  console.log(`[Scheduler] Instagram container created for post ${post._id}: ${containerId}`);

  await waitForInstagramContainer(containerId, instagramToken);

  const publishRes = await axios.post(
    `https://graph.instagram.com/v24.0/${igAccountId}/media_publish`,
    null,
    {
      params: {
        creation_id: containerId,
        access_token: instagramToken,
      },
    }
  );

  return { postId: publishRes.data.id };
}

async function waitForInstagramContainer(containerId, token) {
  let tries = 0;
  const maxTries = 30;
  let lastStatus = "IN_PROGRESS";

  while (tries < maxTries) {
    const statusRes = await axios.get(`https://graph.instagram.com/v24.0/${containerId}`, {
      params: {
        fields: "status_code,status",
        access_token: token,
      },
    });

    const status = statusRes.data.status_code;
    lastStatus = status;

    console.log(
      `[Scheduler] Instagram container ${containerId} status check ${tries + 1}/${maxTries}: ${status}`
    );

    if (status === "FINISHED") {
      return;
    }

    if (status === "ERROR") {
      const details = statusRes.data?.status || "Media container failed processing";
      throw new Error(`Media container failed processing. ${details}`);
    }

    await new Promise((resolve) => setTimeout(resolve, 5000));
    tries += 1;
  }

  throw new Error(`Timeout waiting for media container. Last status: ${lastStatus}`);
}

function getAxiosErrorMessage(error) {
  const apiMessage =
    error?.response?.data?.error?.message ||
    error?.response?.data?.message ||
    error?.response?.data?.error;

  if (apiMessage) {
    return `${error.message}: ${typeof apiMessage === "string" ? apiMessage : JSON.stringify(apiMessage)}`;
  }

  return error?.message || "Unknown scheduler error";
}

async function publishLinkedInPost(post) {
  const { userId, pageId, content, mediaUrl } = post;
  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "LINKEDIN",
  });

  if (!appCredential) {
    throw new Error("LinkedIn not connected");
  }

  const accessToken = appCredential.credentials.user_access_token;
  const linkedInUserId = pageId || appCredential.credentials.user_id;

  if (!accessToken || !linkedInUserId) {
    throw new Error("LinkedIn access token or user ID not found");
  }

  const postData = {
    author: `urn:li:person:${linkedInUserId}`,
    lifecycleState: "PUBLISHED",
    specificContent: {
      "com.linkedin.ugc.ShareContent": {
        shareCommentary: {
          text: content || "",
        },
        shareMediaCategory: mediaUrl ? "IMAGE" : "NONE",
      },
    },
    visibility: {
      "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC",
    },
  };

  if (mediaUrl) {
    const imageUploadRes = await axios.post(
      "https://api.linkedin.com/v2/assets?action=registerUpload",
      {
        registerUploadRequest: {
          recipes: ["urn:li:digitalmediaRecipe:feedshare-image"],
          owner: `urn:li:person:${linkedInUserId}`,
          serviceRelationships: [
            {
              relationshipType: "OWNER",
              identifier: "urn:li:userGeneratedContent",
            },
          ],
        },
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    const uploadUrl =
      imageUploadRes.data.value.uploadMechanism[
        "com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest"
      ].uploadUrl;
    const asset = imageUploadRes.data.value.asset;

    const imageRes = await axios.get(mediaUrl, {
      responseType: "arraybuffer",
    });

    await axios.put(uploadUrl, imageRes.data, {
      headers: {
        "Content-Type": "image/jpeg",
      },
    });

    postData.specificContent["com.linkedin.ugc.ShareContent"].media = [
      {
        status: "READY",
        description: {
          text: content || "",
        },
        media: asset,
        title: {
          text: "Shared Image",
        },
      },
    ];
  }

  const postRes = await axios.post("https://api.linkedin.com/v2/ugcPosts", postData, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      "X-Restli-Protocol-Version": "2.0.0",
    },
  });

  return { postId: postRes.data.id };
}

async function publishYouTubePost(post) {
  const { userId, content, mediaUrl, title, description, channelId } = post;

  if (!mediaUrl) {
    throw new Error("YouTube requires a video file");
  }

  const { accessToken, actualChannelId } = await getValidYouTubeAccessToken(userId, channelId);

  console.log(`[Scheduler] Downloading video from S3: ${mediaUrl}`);
  const videoResponse = await axios.get(mediaUrl, {
    responseType: "arraybuffer",
  });

  const videoBuffer = Buffer.from(videoResponse.data);
  console.log(`[Scheduler] Downloaded video, size: ${videoBuffer.length} bytes`);

  const metadata = {
    snippet: {
      title: title || (content || "").substring(0, 100) || "Untitled Video",
      description: description || content || "",
      channelId: actualChannelId,
    },
    status: {
      privacyStatus: "public",
    },
  };

  const initResponse = await axios.post(
    "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
    metadata,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
        "X-Upload-Content-Length": videoBuffer.length,
        "X-Upload-Content-Type": "video/*",
      },
    }
  );

  const uploadUrl = initResponse.headers.location;

  if (!uploadUrl) {
    throw new Error("Failed to get upload URL from YouTube");
  }

  const uploadResponse = await axios.put(uploadUrl, videoBuffer, {
    headers: {
      "Content-Type": "video/*",
    },
    maxContentLength: Infinity,
    maxBodyLength: Infinity,
  });

  const videoId = uploadResponse.data.id;

  return {
    videoId,
    postId: videoId,
    channelId: actualChannelId,
    videoUrl: `https://www.youtube.com/watch?v=${videoId}`,
  };
}

async function getValidYouTubeAccessToken(userId, channelId) {
  const appCredential = await AppCredentials.findOne({
    userId,
    platform: "YOUTUBE",
  });

  if (!appCredential) {
    throw new Error("YouTube not connected");
  }

  const tokens = appCredential.credentials || {};
  let accessToken = tokens.access_token;
  const now = Date.now();

  if (tokens.refresh_token && (!tokens.expiry || now >= tokens.expiry - 60000)) {
    const youtubeConfig = await getAppConfig(userId, "app/youtube");
    const refreshRes = await axios.post("https://oauth2.googleapis.com/token", {
      client_id: youtubeConfig.appClientId,
      client_secret: youtubeConfig.appClientSecret,
      refresh_token: tokens.refresh_token,
      grant_type: "refresh_token",
    });

    accessToken = refreshRes.data.access_token;
    const newExpiry = Date.now() + refreshRes.data.expires_in * 1000;

    await AppCredentials.findOneAndUpdate(
      { userId, platform: "YOUTUBE" },
      {
        $set: {
          "credentials.access_token": accessToken,
          "credentials.expires_in": refreshRes.data.expires_in,
          "credentials.expiry": newExpiry,
        },
      }
    );
  }

  if (!accessToken) {
    throw new Error("YouTube access token not found");
  }

  const actualChannelId = channelId || appCredential.credentials.channel?.id;
  if (!actualChannelId) {
    throw new Error("YouTube channel ID not found");
  }

  return {
    accessToken,
    actualChannelId,
  };
}
