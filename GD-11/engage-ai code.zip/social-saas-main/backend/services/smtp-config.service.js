import nodemailer from "nodemailer";
import axios from "axios";

function getApexDomain(hostname) {
  const host = String(hostname || "").trim().toLowerCase();
  if (!host) return null;
  if (host === "localhost") return "localhost";
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return host;

  const parts = host.split(".").filter(Boolean);
  if (parts.length <= 2) return host;

  const secondLevelTlds = new Set(["co.uk", "org.uk", "gov.uk", "ac.uk", "co.in", "com.au", "co.jp"]);
  const tailTwo = `${parts[parts.length - 2]}.${parts[parts.length - 1]}`;
  const tailThree = `${parts[parts.length - 3]}.${tailTwo}`;

  if (secondLevelTlds.has(tailTwo) && parts.length >= 3) {
    return tailThree;
  }

  return tailTwo;
}

function parseHostFromRaw(raw) {
  if (!raw) return null;
  const value = String(raw).trim();
  if (!value) return null;

  try {
    const parsed = value.includes("://") ? new URL(value) : new URL(`https://${value}`);
    return String(parsed.hostname || "").trim().toLowerCase() || null;
  } catch {
    const normalized = value
      .replace(/^https?:\/\//i, "")
      .split("/")[0]
      .split(",")[0]
      .split(":")[0]
      .trim()
      .toLowerCase();
    return normalized || null;
  }
}

function isLikelyIp(hostname) {
  const host = String(hostname || "").trim();
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host === "::1";
}

function isLocalHost(hostname) {
  const host = String(hostname || "").trim().toLowerCase();
  return !host || host === "localhost" || host.endsWith(".localhost") || isLikelyIp(host);
}

function toBoolean(value, fallback = false) {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value !== 0;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (!normalized) return fallback;
    if (["true", "1", "yes", "y", "on"].includes(normalized)) return true;
    if (["false", "0", "no", "n", "off"].includes(normalized)) return false;
  }
  return fallback;
}

function toNumber(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function nonEmpty(value) {
  const result = String(value || "").trim();
  return result || "";
}

export function normalizeOriginDomain(raw) {
  const host = parseHostFromRaw(raw);
  if (!host) return null;
  return getApexDomain(host);
}

export function normalizeFullOriginDomain(raw) {
  return parseHostFromRaw(raw);
}

export function extractOriginDomain(req) {
  const candidates = [
    req?.body?.originDomain,
    req?.headers?.origin,
    req?.headers?.referer,
    req?.headers?.["x-forwarded-host"],
    req?.headers?.host,
  ];

  for (const candidate of candidates) {
    const normalized = normalizeOriginDomain(candidate);
    if (normalized) return normalized;
  }
  return null;
}

export function extractFullOriginDomain(req) {
  const candidates = [
    req?.body?.originDomain,
    req?.headers?.origin,
    req?.headers?.referer,
    req?.headers?.["x-forwarded-host"],
    req?.headers?.host,
  ];

  for (const candidate of candidates) {
    const normalized = normalizeFullOriginDomain(candidate);
    if (normalized) return normalized;
  }
  return null;
}

function getParentDomain(hostname) {
  const host = String(hostname || "").trim().toLowerCase();
  if (!host) return null;
  const parts = host.split(".").filter(Boolean);
  if (parts.length > 2) return parts.slice(1).join(".");
  return host;
}

function buildResellerSmtpApiUrl(originDomain) {
  const fullOrigin = normalizeFullOriginDomain(originDomain);
  if (!fullOrigin || isLocalHost(fullOrigin)) return null;

  const parentDomain = getParentDomain(fullOrigin);
  if (!parentDomain) return null;

  return `https://reseller.${parentDomain}/api/social-config/smtp?originDomain=${encodeURIComponent(fullOrigin)}`;
}

function getSmtpApiToken() {
  return nonEmpty(
    process.env.SOCIAL_CONFIG_API_TOKEN ||
      process.env.X_API_TOKEN ||
      process.env.SMTP_API_TOKEN ||
      process.env["x-api-token"] ||
      process.env.API_TOKEN
  );
}

function mapRemoteSmtpPayload(payload) {
  const root = payload && typeof payload === "object" ? payload : {};
  const data = root.data && typeof root.data === "object" ? root.data : null;

  if (!data) return null;
  const smtpData =
    data.smtp && typeof data.smtp === "object"
      ? { ...data, ...data.smtp }
      : data;

  const isEnabled =
    typeof smtpData.isEnabled === "boolean"
      ? smtpData.isEnabled
      : typeof smtpData.enabled === "boolean"
      ? smtpData.enabled
      : toBoolean(smtpData.isEnabled ?? smtpData.enabled ?? true, true);

  if (!isEnabled) {
    return { enabled: false, config: null };
  }

  const host = nonEmpty(smtpData.host || smtpData.smtpHost || smtpData.smtp_host);
  const username = nonEmpty(smtpData.username || smtpData.user || smtpData.smtpUser || smtpData.smtp_user);
  const password = nonEmpty(smtpData.password || smtpData.pass || smtpData.smtpPass || smtpData.smtp_pass);

  if (!host || !username || !password) {
    return { enabled: false, config: null };
  }

  return {
    enabled: true,
    config: {
      host,
      port: toNumber(smtpData.port || smtpData.smtpPort || smtpData.smtp_port, 587),
      secure: toBoolean(smtpData.secure ?? smtpData.isSecure ?? smtpData.smtpSecure ?? false, false),
      username,
      password,
      fromName: nonEmpty(smtpData.fromName || smtpData.from_name || smtpData.senderName || smtpData.sender_name),
      fromEmail: nonEmpty(smtpData.fromEmail || smtpData.from_email || smtpData.senderEmail || smtpData.sender_email),
    },
  };
}

async function fetchRemoteSmtpConfig(originDomain) {
  const url = buildResellerSmtpApiUrl(originDomain);
  if (!url) return null;

  try {
    const response = await axios.get(url, {
      timeout: 5000,
      headers: {
        "x-api-token": getSmtpApiToken(),
      },
      validateStatus: () => true,
    });

    if (response.status < 200 || response.status >= 300) {
      return null;
    }

    return mapRemoteSmtpPayload(response.data);
  } catch (error) {
    console.warn("[SMTP] Failed to fetch reseller SMTP config:", error?.message || error);
    return null;
  }
}

function buildFromAddress(config) {
  const fallback = process.env.DEFAULT_FROM_EMAIL || process.env.SMTP_FROM || '"Veblika" <no-reply@veblika.com>';

  if (!config) return fallback;

  const email = String(config.fromEmail || "").trim();
  if (!email) return fallback;

  const fromName = String(config.fromName || "").trim();
  return fromName ? `"${fromName}" <${email}>` : email;
}

function buildTransportOptions(config) {
  if (config) {
    return {
      host: config.host,
      port: Number(config.port || 587),
      secure: Boolean(config.secure),
      auth: {
        user: config.username,
        pass: config.password,
      },
    };
  }

  return {
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE || "false") === "true",
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  };
}

export async function resolveSmtpConfigByDomain(domain) {
  const originDomain = normalizeFullOriginDomain(domain);
  if (!originDomain) return null;
  return fetchRemoteSmtpConfig(originDomain);
}

export async function resolveSmtpContext(req, { origin, resellerId } = {}) {
  const requestDomain =
    normalizeFullOriginDomain(origin) || extractFullOriginDomain(req) || normalizeOriginDomain(origin) || extractOriginDomain(req);

  const remoteSmtp = requestDomain ? await resolveSmtpConfigByDomain(requestDomain) : null;
  const remoteConfig = remoteSmtp?.enabled ? remoteSmtp.config : null;

  const envConfigured = Boolean(process.env.SMTP_HOST);
  const usingRemote = Boolean(remoteConfig);

  if (!usingRemote && !envConfigured) {
    return {
      enabled: false,
      source: "mock",
      originDomain: requestDomain,
      resellerId: resellerId || null,
      transport: null,
      from: buildFromAddress(null),
    };
  }

  const transportOptions = buildTransportOptions(remoteConfig || null);
  const transporter = nodemailer.createTransport(transportOptions);

  return {
    enabled: true,
    source: usingRemote ? "reseller-api" : "env",
    originDomain: requestDomain,
    resellerId: resellerId || null,
    config: remoteConfig || null,
    transport: transporter,
    from: buildFromAddress(remoteConfig || null),
  };
}

export async function sendMailWithResolvedSmtp({
  req,
  origin,
  resellerId,
  to,
  subject,
  html,
}) {
  const smtp = await resolveSmtpContext(req, { origin, resellerId });
  if (!smtp.enabled || !smtp.transport) {
    console.log(`[EMAIL DEV MOCK] ${to} -> ${subject}`);
    return { success: true, source: "mock", originDomain: smtp.originDomain || null };
  }

  const info = await smtp.transport.sendMail({
    from: smtp.from,
    to,
    subject,
    html,
  });

  return {
    success: true,
    source: smtp.source,
    originDomain: smtp.originDomain || null,
    messageId: info?.messageId || null,
  };
}
