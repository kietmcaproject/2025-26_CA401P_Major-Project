import { Queue, Worker } from "bullmq";
import Post from "../models/post.model.js";
import { publishScheduledPost } from "./scheduled-post-publisher.service.js";

const QUEUE_NAME = "scheduled-social-posts";
const JOB_NAME = "publish-scheduled-post";
const JOB_PREFIX = "scheduled-post-";

let scheduledPostQueue;
let scheduledPostWorker;

export const isRedisConfigured = () =>
  Boolean(process.env.REDIS_URL || process.env.REDIS_HOST);

export const getScheduledPostJobId = (postId) => `${JOB_PREFIX}${postId}`;

export const enqueueScheduledPost = async (post) => {
  ensureRedisConfigured();

  if (!post?._id) {
    throw new Error("Scheduled post ID is required");
  }

  if (!post?.scheduledFor) {
    throw new Error("Scheduled post date is required");
  }

  const queue = getScheduledPostQueue();
  const jobId = getScheduledPostJobId(post._id);
  const existingJob = await queue.getJob(jobId);

  if (existingJob) {
    const state = await existingJob.getState();

    if (state === "completed" || state === "failed") {
      await existingJob.remove();
    } else {
      return existingJob;
    }
  }

  const delay = Math.max(new Date(post.scheduledFor).getTime() - Date.now(), 0);

  return queue.add(
    JOB_NAME,
    { postId: String(post._id) },
    {
      jobId,
      delay,
    }
  );
};

export const cancelScheduledPost = async (postId) => {
  if (!isRedisConfigured()) {
    return false;
  }

  const queue = getScheduledPostQueue();
  const job = await queue.getJob(getScheduledPostJobId(postId));

  if (!job) {
    return false;
  }

  await job.remove();
  return true;
};

export const startScheduledPostQueue = async () => {
  if (!isRedisConfigured()) {
    console.warn(
      "[Scheduler] Redis is not configured. Scheduled post worker is disabled."
    );
    return null;
  }

  getScheduledPostQueue();

  if (!scheduledPostWorker) {
    scheduledPostWorker = new Worker(
      QUEUE_NAME,
      async (job) => publishScheduledPost(job.data.postId),
      {
        connection: getRedisConnectionOptions(),
        concurrency: Number(process.env.SCHEDULED_POST_WORKER_CONCURRENCY || 1),
      }
    );

    scheduledPostWorker.on("completed", (job) => {
      console.log(`[Scheduler] Redis job completed for post ${job.data.postId}`);
    });

    scheduledPostWorker.on("failed", (job, error) => {
      console.error(
        `[Scheduler] Redis job failed for post ${job?.data?.postId}:`,
        error?.message || error
      );
    });

    scheduledPostWorker.on("error", (error) => {
      console.error("[Scheduler] Worker error:", error);
    });
  }

  await recoverInterruptedPosts();
  await rehydrateScheduledPosts();

  return scheduledPostWorker;
};

function getScheduledPostQueue() {
  if (!scheduledPostQueue) {
    scheduledPostQueue = new Queue(QUEUE_NAME, {
      connection: getRedisConnectionOptions(),
      defaultJobOptions: {
        attempts: 1,
        removeOnComplete: 1000,
        removeOnFail: 5000,
      },
    });
  }

  return scheduledPostQueue;
}

function getRedisConnectionOptions() {
  if (process.env.REDIS_URL) {
    const redisUrl = new URL(process.env.REDIS_URL);

    return {
      host: redisUrl.hostname,
      port: Number(redisUrl.port || 6379),
      username: redisUrl.username || undefined,
      password: redisUrl.password || undefined,
      db: redisUrl.pathname ? Number(redisUrl.pathname.slice(1) || 0) : 0,
      tls: redisUrl.protocol === "rediss:" ? {} : undefined,
      maxRetriesPerRequest: null,
    };
  }

  return {
    host: process.env.REDIS_HOST || "127.0.0.1",
    port: Number(process.env.REDIS_PORT || 6379),
    username: process.env.REDIS_USERNAME || undefined,
    password: process.env.REDIS_PASSWORD || undefined,
    db: Number(process.env.REDIS_DB || 0),
    maxRetriesPerRequest: null,
  };
}

function ensureRedisConfigured() {
  if (!isRedisConfigured()) {
    throw new Error("Redis is not configured for scheduled posts");
  }
}

async function recoverInterruptedPosts() {
  const processingTimeoutMs = Number(
    process.env.SCHEDULED_POST_PROCESSING_TIMEOUT_MS || 15 * 60 * 1000
  );
  const staleThreshold = new Date(Date.now() - processingTimeoutMs);

  const stalePosts = await Post.find({
    status: "PROCESSING",
    updatedAt: { $lte: staleThreshold },
    scheduledFor: { $ne: null },
  })
    .select("_id")
    .lean();

  if (stalePosts.length === 0) {
    return;
  }

  const staleIds = stalePosts.map((post) => post._id);

  await Post.updateMany(
    { _id: { $in: staleIds } },
    {
      $set: {
        status: "SCHEDULED",
        errorMessage: "Recovered after worker interruption",
      },
    }
  );

  console.log(`[Scheduler] Recovered ${staleIds.length} interrupted scheduled posts.`);
}

async function rehydrateScheduledPosts() {
  const scheduledPosts = await Post.find({
    status: "SCHEDULED",
    scheduledFor: { $ne: null },
  })
    .select("_id scheduledFor")
    .lean();

  for (const post of scheduledPosts) {
    await enqueueScheduledPost(post);
  }

  console.log(
    `[Scheduler] Rehydrated ${scheduledPosts.length} scheduled posts into Redis.`
  );
}
