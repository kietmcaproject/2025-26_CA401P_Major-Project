import InvitationModel from "../models/invitation.model.js";
import MemberModel from "../models/member.model.js";
import OrganisationModel from "../models/organisation.model.js";
import RoleModel from "../models/role.model.js";
import UserModel from "../models/user.model.js";
import mongoose from "mongoose";
import { sendMailWithResolvedSmtp } from "./smtp-config.service.js";

const sendEmail = async ({ to, subject, html, origin, resellerId }) => {
    try {
        const result = await sendMailWithResolvedSmtp({
            origin,
            resellerId,
            to,
            subject,
            html,
        });
        return { success: true, source: result.source };
    } catch (error) {
        console.error("Error sending email via SMTP:", error);
        throw new Error(`Failed to send email: ${error.message}`);
    }
};

export class InvitationService {
    async createInvitation({ email, orgId, roleId, invitedByMemberId, origin, resellerId }, inviterName) {
        const org = await OrganisationModel.findById(orgId);
        if (!org) throw new Error("Organisation not found");

        const role = await RoleModel.findOne({ _id: roleId, organisationId: orgId });
        if (!role) throw new Error("Role not found");

        // Check user existence
        const user = await UserModel.findOne({ email });
        const userExists = !!user;

        // Check if already member
        if (userExists) {
            const member = await MemberModel.findOne({ organisationId: orgId, userId: user._id });
            if (member) throw new Error("User is already a member");
        }

        // Check pending invitation
        const pending = await InvitationModel.findOne({ email, orgId, status: "pending" });
        if (pending) throw new Error("Invitation already sent");

        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 7); // 7 days expiry

        const invitation = await InvitationModel.create({
            email,
            orgId,
            roleId,
            invitedBy: invitedByMemberId,
            status: "pending",
            userExists,
            expiresAt
        });

        // Send Email - use provided origin if available, fallback to env or default
        const frontendUrl = origin || process.env.FRONTEND_URL || "http://localhost:3000";
        const joinLink = `${frontendUrl.replace(/\/$/, "")}/accept-invite?id=${invitation._id}`;

        await sendEmail({
            to: email,
            subject: `Join ${org.name} on Veblika`,
            html: `<p>${inviterName} has invited you to join <b>${org.name}</b> as a <b>${role.name}</b>.</p>
             <p><a href="${joinLink}">Click here to accept</a></p>`,
            origin,
            resellerId,
        });

        return invitation;
    }

    async getInvitations(orgId) {
        return InvitationModel.find({ orgId })
            .populate("invitedBy", "userId") // might need more populated data
            .populate("roleId", "name")
            .sort({ createdAt: -1 });
    }

    async validateInvitation(invitationId) {
        if (!mongoose.isValidObjectId(invitationId)) return { valid: false, error: "Invalid ID" };

        const invitation = await InvitationModel.findById(invitationId)
            .populate("orgId", "name logo")
            .populate("roleId", "name");

        if (!invitation) return { valid: false, error: "Not found" };
        if (invitation.status !== "pending") return { valid: false, error: "Invitation not pending" };
        if (new Date() > invitation.expiresAt) {
            invitation.status = "expired";
            await invitation.save();
            return { valid: false, error: "Expired" };
        }

        return { valid: true, invitation };
    }

    async acceptInvitation(invitationId, userId, userEmail, userName) {
        const { valid, invitation, error } = await this.validateInvitation(invitationId);
        if (!valid) throw new Error(error);

        // Check if user is already member
        const existing = await MemberModel.findOne({ organisationId: invitation.orgId._id, userId });
        if (existing) throw new Error("Already a member");

        // Verify email
        // If email was passed from trusted auth middleware, use it.
        // Otherwise, fallback to DB lookup.
        let emailToVerify = userEmail;
        let user = null;

        if (!emailToVerify) {
            user = await UserModel.findById(userId);
            if (!user) {
                console.error(`[Invitation Error] User not found in MongoDB. UserId: ${userId}`);
                throw new Error("User record not found. Please ensure you are fully signed up.");
            }
            emailToVerify = user.email;
        }

        if (emailToVerify.toLowerCase() !== invitation.email.toLowerCase()) {
            throw new Error("Invitation email does not match logged in user email");
        }

        // Create Member
        const newMember = await MemberModel.create({
            organisationId: invitation.orgId._id,
            userId,
            roleId: invitation.roleId._id, // populated
            invitedBy: invitation.invitedBy,
            isOwner: false,
            extraPermissions: [],
            metadata: {
                name: userName || (user ? (user.full_name || user.name) : "Unknown"),
                email: emailToVerify
            }
        });

        invitation.status = "accepted";
        invitation.acceptedAt = new Date();
        await invitation.save();

        return newMember;
    }

    async cancelInvitation(invitationId, orgId) {
        const invitation = await InvitationModel.findOne({ _id: invitationId, orgId });
        if (!invitation) throw new Error("Not found");
        if (invitation.status !== 'pending') throw new Error("Cannot cancel processed invite");

        await InvitationModel.deleteOne({ _id: invitationId });
    }
}

export const invitationService = new InvitationService();
