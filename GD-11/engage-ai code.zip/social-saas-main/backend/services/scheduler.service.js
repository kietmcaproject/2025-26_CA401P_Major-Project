import { startScheduledPostQueue } from "./scheduled-post-queue.service.js";

export const startScheduler = async () => {
  console.log("Starting Social Media Post Scheduler...");
  await startScheduledPostQueue();
};
