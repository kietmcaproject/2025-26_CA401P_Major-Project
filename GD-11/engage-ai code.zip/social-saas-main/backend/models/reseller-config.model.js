import mongoose from "mongoose";

const resellerConfigSchema = new mongoose.Schema(
    {
        resellerId: {
            type: String,
            required: true,
            unique: true,
            index: true,
        },
        logo: {
            type: String,
            default: "",
        },
        companyName: {
            type: String,
            default: "Veblika",
            trim: true,
        },
        domain: {
            type: String,
            unique: true,
            sparse: true,
            trim: true,
            lowercase: true
        },
        // Dynamic content fields
        content: {
            hero: {
                title: {
                    type: String,
                    default: "Your social media command center"
                },
                subtitle: {
                    type: String,
                    default: "Schedule, publish, analyze, and engage — all from one beautiful dashboard. The complete toolkit for social media success."
                }
            },
            about: {
                title: {
                    type: String,
                    default: "About Us"
                },
                description: {
                    type: String,
                    default: "We help businesses manage their social media presence effectively."
                }
            },
            contact: {
                address: {
                    type: String,
                    default: ""
                },
                phone: {
                    type: String,
                    default: ""
                },
                email: {
                    type: String,
                    default: ""
                }
            },
            cta: {
                title: {
                    type: String,
                    default: "Grow your brand presence on social media."
                },
                subtitle: {
                    type: String,
                    default: "Try Veblika free for 14 days. No credit card required."
                },
                buttonText: {
                    type: String,
                    default: "Sign Up for Free Trial"
                }
            },
            faqs: [{
                question: { type: String, required: true },
                answer: { type: String, required: true },
                order: { type: Number, default: 0 }
            }],
            // Home page sections
            features: [{
                title: { type: String, required: true },
                description: { type: String, required: true },
                icon: { type: String, default: "Zap" },
                order: { type: Number, default: 0 }
            }],
            stats: [{
                label: { type: String, required: true },
                value: { type: String, required: true },
                order: { type: Number, default: 0 }
            }],
            testimonials: [{
                name: { type: String, required: true },
                role: { type: String },
                company: { type: String },
                content: { type: String, required: true },
                avatar: { type: String },
                rating: { type: Number, default: 5 },
                order: { type: Number, default: 0 }
            }],
            // Pricing plans
            pricing: [{
                name: { type: String, required: true },
                price: { type: String, required: true },
                period: { type: String, default: "/mo" },
                description: { type: String, default: "" },
                features: [{ type: String }],
                isPopular: { type: Boolean, default: false },
                buttonText: { type: String, default: "Start free trial" },
                order: { type: Number, default: 0 }
            }],
            // About page content
            aboutPage: {
                tagline: { type: String, default: "" },
                headline: { type: String, default: "" },
                story: { type: String, default: "" },
                stats: [{
                    label: { type: String },
                    value: { type: String },
                    icon: { type: String }
                }],
                industries: [{ type: String }]
            },
            // Legal pages
            privacyPolicy: { type: String, default: "" },
            termsOfService: { type: String, default: "" }
        }
    },
    { timestamps: true }
);

const ResellerConfigModel = mongoose.model("ResellerConfig", resellerConfigSchema);

export default ResellerConfigModel;
