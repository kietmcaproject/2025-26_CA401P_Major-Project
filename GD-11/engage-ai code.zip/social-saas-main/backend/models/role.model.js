import mongoose from "mongoose";

const roleSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true,
        },
        slug: {
            type: String,
            required: true,
            trim: true,
            lowercase: true,
        },
        description: {
            type: String,
            default: ""
        },
        permissions: {
            type: [String],
            default: [],
        },
        organisationId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Organisation",
            required: true,
            index: true,
        },
        isDefault: {
            type: Boolean,
            default: false
        },
        isSystem: {
            type: Boolean,
            default: false
        }
    },
    { timestamps: true }
);

// Ensure role slugs are unique per organisation
roleSchema.index({ organisationId: 1, slug: 1 }, { unique: true });

const RoleModel = mongoose.model("Role", roleSchema);

export default RoleModel;
