import mongoose from "mongoose";

const resellerStmpConfigurationSchema = new mongoose.Schema(
  {
    resellerId: {
      type: String,
      required: true,
      index: true,
      trim: true,
    },
    originDomain: {
      type: String,
      required: true,
      index: true,
      trim: true,
      lowercase: true,
    },
    host: {
      type: String,
      required: true,
      trim: true,
    },
    port: {
      type: Number,
      default: 587,
    },
    secure: {
      type: Boolean,
      default: false,
    },
    username: {
      type: String,
      required: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
      trim: true,
    },
    fromName: {
      type: String,
      default: "Veblika",
      trim: true,
    },
    fromEmail: {
      type: String,
      default: "no-reply@veblika.com",
      trim: true,
    },
    enabled: {
      type: Boolean,
      default: true,
    },
    createdBy: {
      type: String,
      default: null,
      trim: true,
    },
    updatedBy: {
      type: String,
      default: null,
      trim: true,
    },
  },
  { timestamps: true }
);

resellerStmpConfigurationSchema.index({ resellerId: 1, originDomain: 1 }, { unique: true });

const ResellerStmpConfigurationModel = mongoose.model(
  "reseller_stmp_configuration",
  resellerStmpConfigurationSchema,
  "reseller_stmp_configurations"
);

export default ResellerStmpConfigurationModel;
