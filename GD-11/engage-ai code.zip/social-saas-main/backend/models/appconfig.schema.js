import mongoose from "mongoose";

const appSchema = new mongoose.Schema(
  {
    userId: { type: String, required: false }, // Optional - not required for reseller credentials
    appName: { type: String, required: true },
    appClientId: { type: String, required: true },
    appClientSecret: { type: String, required: true },
    redirectUrl: { type: String, required: true },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    resellerId: { type: String, required: false }, // For reseller-level credentials
    type: {
      type: String,
      enum: ["user", "reseller"],
      default: "user",
      required: true
    }
  },
  { timestamps: true }
);

// Compound unique index: one config per user per app (type 'user')
appSchema.index({ userId: 1, appName: 1, type: 1 }, { unique: true, partialFilterExpression: { type: "user" } });
// Compound unique index: one config per reseller per app (type 'reseller')
appSchema.index({ resellerId: 1, appName: 1, type: 1 }, { unique: true, partialFilterExpression: { type: "reseller" } });

const AppConfig = mongoose.model("AppConfig", appSchema);

// Migration function to drop old orgNo index
// Migration function to drop old indexes and ensure new ones
export const migrateAppConfigIndexes = async () => {
  try {
    const indexes = await AppConfig.collection.getIndexes();

    // List of old indexes to drop (including the ones from previous migrations)
    const oldIndexes = ["orgNo_1", "userId_1", "userId_1_appName_1", "resellerId_1_appName_1"];

    for (const indexName of oldIndexes) {
      if (indexes[indexName]) {
        console.log(`[AppConfig Migration] Dropping old index ${indexName}...`);
        try {
          await AppConfig.collection.dropIndex(indexName);
          console.log(`[AppConfig Migration] ✅ Successfully dropped ${indexName}`);
        } catch (err) {
          console.error(`[AppConfig Migration] Error dropping ${indexName}:`, err.message);
        }
      }
    }

    // Ensure new indexes exist
    const currentIndexes = await AppConfig.collection.getIndexes();

    // Check and create user index
    if (!currentIndexes.userId_1_appName_1_type_1) {
      console.log("[AppConfig Migration] Creating userId_1_appName_1_type_1 index...");
      await AppConfig.collection.createIndex(
        { userId: 1, appName: 1, type: 1 },
        { unique: true, partialFilterExpression: { type: "user" } }
      );
      console.log("[AppConfig Migration] ✅ Created userId_1_appName_1_type_1 index");
    }

    // Check and create reseller index
    if (!currentIndexes.resellerId_1_appName_1_type_1) {
      console.log("[AppConfig Migration] Creating resellerId_1_appName_1_type_1 index...");
      await AppConfig.collection.createIndex(
        { resellerId: 1, appName: 1, type: 1 },
        { unique: true, partialFilterExpression: { type: "reseller" } }
      );
      console.log("[AppConfig Migration] ✅ Created resellerId_1_appName_1_type_1 index");
    }

    // --- DATA MIGRATION ---
    console.log("[AppConfig Migration] Checking for data migration (adding 'type' field)...");

    // 1. Set type='user' for docs with userId currently missing type
    const userUpdate = await AppConfig.updateMany(
      { type: { $exists: false }, userId: { $exists: true, $ne: null } },
      { $set: { type: "user" } }
    );
    if (userUpdate.modifiedCount > 0) {
      console.log(`[AppConfig Migration] ✅ Migrated ${userUpdate.modifiedCount} user configs to type='user'`);
    }

    // 2. Set type='reseller' for docs with resellerId (and no userId) missing type
    const resellerUpdate = await AppConfig.updateMany(
      { type: { $exists: false }, resellerId: { $exists: true }, userId: { $in: [null, undefined] } },
      { $set: { type: "reseller" } }
    );
    if (resellerUpdate.modifiedCount > 0) {
      console.log(`[AppConfig Migration] ✅ Migrated ${resellerUpdate.modifiedCount} reseller configs to type='reseller'`);
    }

  } catch (err) {
    if (err.codeName !== 'NamespaceNotFound') {
      console.error("[AppConfig Migration] Error during migration:", err.message);
    }
  }
};

export default AppConfig;
