import mongoose from "mongoose";

const memberSchema = new mongoose.Schema(
    {
        organisationId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Organisation",
            required: true,
            index: true,
        },
        userId: {
            type: String, // String to support generic IDs and existing data
            required: true,
            index: true,
        },
        roleId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Role",
            required: true,
        },
        isOwner: {
            type: Boolean,
            default: false,
        },
        extraPermissions: {
            type: [String],
            default: [],
        },
        invitedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Member",
        },
        metadata: {
            type: mongoose.Schema.Types.Mixed,
            default: {},
        },
    },
    { timestamps: true }
);

// Ensure a user can only be a member of an organisation once
memberSchema.index({ organisationId: 1, userId: 1 }, { unique: true });

const MemberModel = mongoose.model("Member", memberSchema);

export default MemberModel;
