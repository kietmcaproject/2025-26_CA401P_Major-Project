import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    full_name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    profile_pic: {
      type: String,
    },
    role: {
      type: String,
      enum: ["admin", "reseller", "user"],
      default: "user",
    },
    userId: {
      type: String,
      unique: true,
      sparse: true, // Allows null values but ensures uniqueness when present
    },
    COGNITO_USER_ID: {
      type: String,
      unique: true,
      sparse: true,
    },
    reseller_id: {
      type: String,
      default: null,
    },
    originDomain: {
      type: String,
      default: null,
    },
    mediaStorageGb: {
      type: Number,
      default: 0,
      min: 0,
    },
  },
  { timestamps: true }
);

const UserModel = mongoose.model("user", userSchema);

export default UserModel;
