import mongoose from "mongoose";

const organisationSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      minlength: 1,
      maxlength: 100,
    },
    slug: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      match: /^[a-z0-9-]+$/, // Lowercase, a-z, 0-9, hyphen
      index: true,
    },
    logo: {
      type: String,
      default: "",
    },
    ownerId: {
      type: String, // Storing as String to support both ObjectId and external IDs
      required: true,
      index: true,
    },
    resellerId: {
      type: String,
      default: null,
    },
  },
  { timestamps: true }
);

const OrganisationModel = mongoose.model("Organisation", organisationSchema);

export default OrganisationModel;
