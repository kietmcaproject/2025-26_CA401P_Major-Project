import mongoose from "mongoose";

const InvitationSchema = new mongoose.Schema(
    {
        orgId: {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
            ref: "Organisation",
        },
        email: {
            type: String,
            required: true,
            lowercase: true,
            trim: true,
        },
        roleId: {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
            ref: "Role",
        },
        invitedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Member",
            required: true,
        },
        status: {
            type: String,
            enum: ["pending", "accepted", "rejected", "expired"],
            default: "pending",
        },
        userExists: {
            type: Boolean,
            default: false,
        },
        expiresAt: {
            type: Date,
            required: true,
        },
        acceptedAt: {
            type: Date,
        },
    },
    {
        timestamps: true,
    }
);

// Index for easier lookup
InvitationSchema.index({ email: 1, orgId: 1 });
InvitationSchema.index({ status: 1 });

const InvitationModel = mongoose.model("Invitation", InvitationSchema);
export default InvitationModel;
