import mongoose from "mongoose";

const appUserSchema = new mongoose.Schema(
  {
    authUserId: {
      type: String,
      required: true,
      unique: true,
      index: true,
      trim: true,
    },
    resellerId: {
      type: String,
      required: false,
      default: null,
      index: true,
      trim: true,
    },
    appRole: {
      type: String,
      required: true,
      default: "user",
      enum: ["admin", "reseller", "user"],
    },
    status: {
      type: String,
      required: true,
      default: "active",
      // Keep "inactive" for backward compatibility; UI/actions use active/suspended/blocked.
      enum: ["active", "inactive", "suspended", "blocked"],
    },
    profileSnapshot: {
      name: {
        type: String,
        default: "",
      },
      email: {
        type: String,
        default: "",
        lowercase: true,
        trim: true,
      },
    },
  },
  { timestamps: true }
);

const AppUserModel = mongoose.models.app_user || mongoose.model("app_user", appUserSchema, "app_users");

export const migrateAppUsersIndexes = async () => {
  try {
    const indexes = await AppUserModel.collection.indexes();
    const indexNames = new Set(indexes.map((index) => index.name));

    // Remove legacy indexes copied from user collection schema.
    for (const legacyIndex of ["email_1", "userId_1"]) {
      if (indexNames.has(legacyIndex)) {
        await AppUserModel.collection.dropIndex(legacyIndex);
        console.log(`[AppUsers Migration] Dropped legacy index: ${legacyIndex}`);
      }
    }

    if (!indexNames.has("authUserId_1")) {
      await AppUserModel.collection.createIndex({ authUserId: 1 }, { unique: true, name: "authUserId_1" });
      console.log("[AppUsers Migration] Created authUserId_1 index");
    }

    if (!indexNames.has("resellerId_1")) {
      await AppUserModel.collection.createIndex({ resellerId: 1 }, { name: "resellerId_1" });
      console.log("[AppUsers Migration] Created resellerId_1 index");
    }
  } catch (error) {
    console.log("[AppUsers Migration] Error:", error.message);
  }
};

export default AppUserModel;
