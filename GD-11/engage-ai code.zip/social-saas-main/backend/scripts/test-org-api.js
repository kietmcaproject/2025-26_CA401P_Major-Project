import axios from 'axios';

const API_URL = 'http://localhost:8001/api';
const HEADERS = {
    'x-user-id': 'test-user-123',
    'x-auth-token': 'fake-test-token',
    'x-user-role': 'user',
    'Content-Type': 'application/json'
};

async function testOrganisationAPI() {
    try {
        console.log('--- Testing Organisation & Roles API ---');

        // 1. Create Organisation
        console.log('\n1. Creating Organisation...');
        const slug = `test-org-${Date.now()}`;
        const createRes = await axios.post(`${API_URL}/organisations`, {
            name: 'Test Organisation',
            slug: slug,
            logo: 'https://example.com/logo.png'
        }, { headers: HEADERS });
        const orgId = createRes.data.data.organisation._id;
        console.log('Created Org ID:', orgId);

        // 2. Members API Test
        console.log('\n2. Testing Members API...');
        const membersRes = await axios.get(`${API_URL}/organisations/${orgId}/members`, { headers: HEADERS });
        console.log('List Members:', membersRes.data.success ? 'SUCCESS' : 'FAILED');

        // 3. Roles API Test
        console.log('\n3. Testing Roles API...');

        // 3a. List Roles
        console.log('3a. List Roles...');
        const rolesRes = await axios.get(`${API_URL}/organisations/${orgId}/roles`, { headers: HEADERS });
        console.log('List Roles:', rolesRes.data.success && rolesRes.data.data.length >= 3 ? 'SUCCESS' : 'FAILED'); // Expect at least 3 default roles
        const adminRole = rolesRes.data.data.find(r => r.slug === 'admin');
        const adminRoleId = adminRole?._id;
        console.log('Admin Role Found:', !!adminRole);

        // 3b. Get Available Permissions
        console.log('3b. Get Available Permissions...');
        const permsRes = await axios.get(`${API_URL}/organisations/${orgId}/roles/permissions`, { headers: HEADERS });
        console.log('Get Permissions:', permsRes.data.success ? 'SUCCESS' : 'FAILED');

        // 3c. Create Role
        console.log('3c. Create Role...');
        const newRoleRes = await axios.post(`${API_URL}/organisations/${orgId}/roles`, {
            name: 'Support Agent',
            description: 'Support staff',
            permissions: ['ticket.read', 'ticket.reply']
        }, { headers: HEADERS });
        const newRoleId = newRoleRes.data.data._id;
        console.log('Create Role:', newRoleRes.data.success ? 'SUCCESS' : 'FAILED');

        // 3d. Update Role
        console.log('3d. Update Role...');
        const updateRoleRes = await axios.put(`${API_URL}/organisations/${orgId}/roles/${newRoleId}`, {
            description: 'Updated description'
        }, { headers: HEADERS });
        console.log('Update Role:', updateRoleRes.data.data.description === 'Updated description' ? 'SUCCESS' : 'FAILED');

        // 3e. Get Role By ID
        const getRoleRes = await axios.get(`${API_URL}/organisations/${orgId}/roles/${newRoleId}`, { headers: HEADERS });
        console.log('Get Role By ID:', getRoleRes.data.success ? 'SUCCESS' : 'FAILED');

        // 3f. Delete Role
        console.log('3f. Delete Role...');
        const deleteRoleRes = await axios.delete(`${API_URL}/organisations/${orgId}/roles/${newRoleId}`, { headers: HEADERS });
        console.log('Delete Role:', deleteRoleRes.data.success ? 'SUCCESS' : 'FAILED');

        // 3g. Assign Role (Simulated - need another member usually, but let's try endpoint call format)
        // We will fail because we are the owner and "Owner role cannot be changed" or redundant check.
        // But verifying 400 is good enough to know endpoint exists and logic triggers.
        console.log('3g. Assign Role (Permission/Rule Check)...');
        try {
            await axios.post(`${API_URL}/organisations/${orgId}/roles/assign`, {
                memberId: membersRes.data.data[0]._id, // First member (Owner)
                roleId: adminRoleId
            }, { headers: HEADERS });
            console.log('Assign Role: FAILED (Should have prevented owner role change)');
        } catch (e) {
            console.log('Assign Role: SUCCESS (Correctly prevented owner change: ' + e.response?.data?.message + ')');
        }

        console.log('\n--- All Tests Done ---');

    } catch (error) {
        console.error('Test Failed:', error.response ? error.response.data : error.message);
    }
}

testOrganisationAPI();
