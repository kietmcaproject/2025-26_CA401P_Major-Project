import dotenv from "dotenv"
dotenv.config()
import express, { application } from "express"
import cookieParser from "cookie-parser"
import cors from "cors"
import allRouter from "./routes/allRoutes.js"
import connectDb from "./config/db.js"
import { migrateAppCredentialsIndexes } from "./models/appcredentials.model.js"
import { migrateAppConfigIndexes } from "./models/appconfig.schema.js"
import { migrateAppUsersIndexes } from "./models/app-user.model.js"

import helmet from "helmet"
import compression from "compression"
import { startScheduler } from "./services/scheduler.service.js"

const app = express()
const PORT = process.env.PORT || 8001

// Security middleware with relaxed settings for Better Auth
app.use(
  helmet({
    crossOriginResourcePolicy: { policy: "cross-origin" },
    crossOriginOpenerPolicy: { policy: "same-origin-allow-popups" },
  }),
)

// CORS - MUST be before auth routes
// Allow all origins for all environments (multi-tenant support)
app.use(
  cors({
    origin: true,
    methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    credentials: true,
    allowedHeaders: [
      "Content-Type",
      "Authorization",
      "Cookie",
      "Set-Cookie",
      "X-Requested-With",
      "Accept",
      "Origin",
      "x-auth-token",
      "X-Auth-Token",
      "x-user-id",
      "X-User-Id",
      "x-user-email",
      "X-User-Email",
      "x-user-name",
      "X-User-Name",
      "x-user-role",
      "X-User-Role",
      "x-reseller-id",
      "X-Reseller-Id",
      "Access-Control-Allow-Headers",
      "Access-Control-Request-Headers",
    ],
    exposedHeaders: ["Set-Cookie"],
  }),
)

console.log("✅ CORS middleware initialized (allow all origins)")

app.use(cookieParser())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Compression
app.use(compression())

// Files are now stored in S3, no need for local static file serving
// app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.use("/api", allRouter)

app.get("/", (req, res) => {
  res.json({ message: "API is running..." })
})

app.get("/health", (req, res) => {
  res.status(200).json({
    status: "ok",
    timestamp: new Date().toISOString(),
  })
})

app.listen(PORT, async () => {
  await connectDb()
  // Run migration to drop old orgNo index and ensure userId index exists
  await migrateAppCredentialsIndexes()
  // Run migration to drop old orgNo index from AppConfig and ensure new indexes exist
  await migrateAppConfigIndexes()
  // Run migration to clean legacy app_users indexes
  await migrateAppUsersIndexes()

  // Start the scheduler
  startScheduler()

  console.log(`Server is running on http://localhost:${PORT}`)
})
