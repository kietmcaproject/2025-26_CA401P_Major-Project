import { CognitoJwtVerifier } from "aws-jwt-verify";

const userPoolId = process.env.COGNITO_USER_POOL_ID;
const clientId = process.env.COGNITO_CLIENT_ID;

const hasCognitoConfig = Boolean(userPoolId && clientId);

const accessTokenVerifier = hasCognitoConfig
  ? CognitoJwtVerifier.create({
      userPoolId,
      tokenUse: "access",
      clientId,
    })
  : null;

const idTokenVerifier = hasCognitoConfig
  ? CognitoJwtVerifier.create({
      userPoolId,
      tokenUse: "id",
      clientId,
    })
  : null;

function parseJwtPayload(token) {
  try {
    const parts = String(token || "").split(".");
    if (parts.length < 2) return null;
    const payload = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    const decoded = Buffer.from(payload, "base64").toString("utf8");
    return JSON.parse(decoded);
  } catch {
    return null;
  }
}

function readToken(req) {
  const authHeader = req.headers.authorization;
  if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
    return authHeader.slice(7).trim();
  }

  const xAuthToken = req.headers["x-auth-token"];
  if (typeof xAuthToken === "string" && xAuthToken.trim()) {
    return xAuthToken.trim();
  }

  if (typeof req.cookies?.idToken === "string" && req.cookies.idToken.trim()) {
    return req.cookies.idToken.trim();
  }

  if (typeof req.cookies?.accessToken === "string" && req.cookies.accessToken.trim()) {
    return req.cookies.accessToken.trim();
  }

  return null;
}

function readIdToken(req) {
  if (typeof req.cookies?.idToken === "string" && req.cookies.idToken.trim()) {
    return req.cookies.idToken.trim();
  }
  return null;
}

function deriveRole(payload) {
  const customRole = payload?.["custom:role"];
  if (customRole) return String(customRole);

  const groups = Array.isArray(payload?.["cognito:groups"]) ? payload["cognito:groups"] : [];
  if (groups.includes("admin")) return "admin";
  if (groups.includes("reseller")) return "reseller";

  return "user";
}

async function verifyToken(token) {
  try {
    return await accessTokenVerifier.verify(token);
  } catch {
    return idTokenVerifier.verify(token);
  }
}

export const isAuth = async (req, res, next) => {
  try {
    const token = readToken(req);
    if (!token) {
      return res.status(401).json({ message: "Unauthorized", status: false });
    }

    let payload = null;
    if (!hasCognitoConfig) {
      // Local/dev fallback when verifier env vars are missing.
      const idToken = readIdToken(req);
      payload = parseJwtPayload(idToken) || parseJwtPayload(token);
      if (!payload) {
        return res.status(500).json({
          message: "Cognito is not configured. Set COGNITO_USER_POOL_ID and COGNITO_CLIENT_ID.",
          status: false,
        });
      }
    } else {
      payload = await verifyToken(token);
    }

    const cognitoSub = payload?.sub || payload?.username;
    if (!cognitoSub) {
      return res.status(401).json({ message: "Invalid token payload", status: false });
    }

    req.user = {
      _id: String(cognitoSub),
      userId: String(cognitoSub),
      authUserId: String(cognitoSub),
      cognitoSub: String(cognitoSub),
      cognitoUsername: payload?.["cognito:username"] || payload?.username || null,
      email: payload?.email || null,
      name: payload?.name || payload?.["cognito:username"] || null,
      role: deriveRole(payload),
      resellerId: payload?.["custom:reseller_id"] || payload?.["custom:resellerId"] || null,
      addressline: payload?.["custom:addressline"] || null,
      state: payload?.["custom:state"] || null,
      city: payload?.["custom:city"] || null,
      country: payload?.["custom:country"] || null,
      phone: payload?.["custom:phone"] || null,
      pincode: payload?.["custom:pincode"] || null,
      profilePicture: payload?.["custom:profilePicture"] || null,
      tokenUse: payload?.token_use || null,
    };

    return next();
  } catch (error) {
    return res.status(401).json({
      message: "Invalid or expired token",
      status: false,
    });
  }
};

export const verifyUser = isAuth;

export default isAuth;
