import express from "express";
import multer from "multer";

import {
  registerUser,
  loginUser,
  verifyMfaLogin,
  setupMfa,
  verifyMfaSetup,
  disableMfa,
  getMfaStatus,
  logoutUser,
  forgotPasswordUser,
  confirmForgotPasswordUser,
  verifyEmailUser,
} from "../../controllers/auth/auth.controller.js";
import { verifyUser } from "../../middleware/auth.middleware.js";
import getUserController from "../../controllers/auth/get-user.controller.js";
import {
  uploadProfilePhoto,
  updateRequiredProfileDetails,
} from "../../controllers/user/profile.controller.js";
import { listResellerUsers } from "../../controllers/user/reseller-users.controller.js";

const upload = multer({ storage: multer.memoryStorage() });

const userRouter = express.Router();

// 🔐 Auth routes
userRouter.post("/signup", registerUser);
userRouter.post("/login", loginUser);
userRouter.post("/verify-mfa-login", verifyMfaLogin);
userRouter.post("/logout", logoutUser);
userRouter.post("/forgot-password", forgotPasswordUser);
userRouter.post("/confirm-forgot-password", confirmForgotPasswordUser);
userRouter.get("/verify-email", verifyEmailUser);

// 👤 Protected routes
userRouter.get("/me", verifyUser, getUserController);
userRouter.get("/profile", verifyUser, getUserController);
userRouter.get("/mfa/status", verifyUser, getMfaStatus);
userRouter.post("/mfa/setup", verifyUser, setupMfa);
userRouter.post("/mfa/verify", verifyUser, verifyMfaSetup);
userRouter.post("/mfa/disable", verifyUser, disableMfa);
userRouter.get("/reseller-users", verifyUser, listResellerUsers);
userRouter.post("/profile/required-details", verifyUser, updateRequiredProfileDetails);
userRouter.post("/profile-photo", verifyUser, upload.single("image"), uploadProfilePhoto);

// 🧪 Debug route
userRouter.get("/test", (req, res) => {
  res.json({ message: "User router is working" });
});

// 🧪 Debug cookies
userRouter.get("/debug-cookies", (req, res) => {
  res.json({
    cookies: req.cookies,
    headers: req.headers,
  });
});

export default userRouter;
