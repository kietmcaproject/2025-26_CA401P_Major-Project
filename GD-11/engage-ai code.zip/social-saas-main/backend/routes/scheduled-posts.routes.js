import express from "express";
import { getScheduledPosts, deleteScheduledPost } from "../controllers/social-media/social-media.controller.js";
import { isAuth } from "../middleware/isAuth.middleware.js";

const router = express.Router();

// Apply authentication middleware to all routes
router.use(isAuth);

// Get all scheduled posts for the authenticated user
router.get("/", getScheduledPosts);

// Delete a scheduled post by ID
router.delete("/:id", deleteScheduledPost);

export default router;
