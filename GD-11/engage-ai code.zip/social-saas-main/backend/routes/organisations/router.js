import express from "express";
import { isAuth } from "../../middleware/isAuth.middleware.js";
import {
    createOrganisation,
    getMyOrganisations,
    getOrganisationById,
    checkSlugAvailability,
    updateOrganisation,
    deleteOrganisation,
    uploadLogo,
} from "../../controllers/organisations.controller.js";
import membersRouter from "../members/router.js";
import rolesRouter from "../roles/router.js";
import orgInvitationsRouter from "../org-invitations/router.js";
import multer from "multer";

const upload = multer({ storage: multer.memoryStorage() });

const organisationRouter = express.Router();

// Apply auth middleware to all routes
organisationRouter.use(isAuth);

organisationRouter.use("/:orgId/members", membersRouter);
organisationRouter.use("/:orgId/roles", rolesRouter);
organisationRouter.use("/:orgId/invitations", orgInvitationsRouter);

organisationRouter.post("/", createOrganisation);
organisationRouter.get("/", getMyOrganisations);
organisationRouter.get("/check-slug", checkSlugAvailability);
organisationRouter.use("/:orgId/members", membersRouter);

organisationRouter.get("/:id", getOrganisationById);
organisationRouter.put("/:id", updateOrganisation);
organisationRouter.post("/:id/logo", upload.single("logo"), uploadLogo);
organisationRouter.delete("/:id", deleteOrganisation);

export default organisationRouter;
