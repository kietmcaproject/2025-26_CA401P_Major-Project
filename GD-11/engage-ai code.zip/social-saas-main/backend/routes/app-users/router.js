import express from "express";
import { isAuth } from "../../middleware/isAuth.middleware.js";
import { listResellerAppUsers, updateAppUserStatus } from "../../controllers/app-users.controller.js";

const appUsersRouter = express.Router();

appUsersRouter.get("/reseller", isAuth, listResellerAppUsers);
appUsersRouter.patch("/:authUserId/status", isAuth, updateAppUserStatus);

export default appUsersRouter;
