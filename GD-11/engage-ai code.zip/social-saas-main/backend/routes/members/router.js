import express from "express";
import {
    addMember,
    listMembers,
    changeMemberRole,
    removeMember,
    getMyMembership,
    getMemberCount,
    getSingleMember,
    updateMemberExtraPermissions
} from "../../controllers/members.controller.js";

const membersRouter = express.Router({ mergeParams: true });

membersRouter.post("/", addMember);
membersRouter.get("/", listMembers);
membersRouter.get("/count", getMemberCount);
membersRouter.get("/me", getMyMembership);
membersRouter.get("/:memberId", getSingleMember);

// Changed from PATCH to PUT per spec
membersRouter.put("/:memberId/role", changeMemberRole);
membersRouter.put("/:memberId/permissions", updateMemberExtraPermissions);
membersRouter.delete("/:memberId", removeMember);

export default membersRouter;
