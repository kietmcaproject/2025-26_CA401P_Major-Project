import express from "express";
import { createInvitation, getInvitations, cancelInvitation } from "../../controllers/invitations.controller.js";

const orgInvitationsRouter = express.Router({ mergeParams: true });

orgInvitationsRouter.post("/", createInvitation);
orgInvitationsRouter.get("/", getInvitations);
orgInvitationsRouter.delete("/:invitationId", cancelInvitation);

export default orgInvitationsRouter;
