import express from "express";
import {
    listRoles,
    getAvailablePermissions,
    getMyPermissions,
    getRoleById,
    createRole,
    updateRole,
    deleteRole,
    assignRole
} from "../../controllers/roles.controller.js";

const rolesRouter = express.Router({ mergeParams: true });

rolesRouter.get("/", listRoles);
rolesRouter.get("/permissions", getAvailablePermissions);
rolesRouter.get("/me", getMyPermissions);
rolesRouter.get("/:roleId", getRoleById);
rolesRouter.post("/", createRole);
rolesRouter.put("/:roleId", updateRole);
rolesRouter.delete("/:roleId", deleteRole);
rolesRouter.post("/assign", assignRole);

export default rolesRouter;
