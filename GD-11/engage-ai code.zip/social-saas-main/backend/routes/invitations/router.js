import express from "express";
import { getInvitationById, acceptInvitation } from "../../controllers/invitations.controller.js";
import { isAuth } from "../../middleware/isAuth.middleware.js";

const invitationsRouter = express.Router();

invitationsRouter.get("/:id", getInvitationById);
invitationsRouter.post("/:id/accept", isAuth, acceptInvitation);

export default invitationsRouter;
