import express from "express";
import { isAuth } from "../../middleware/isAuth.middleware.js";
import {
    getResellerConfig,
    updateResellerConfig,
    getPublicResellerConfig
} from "../../controllers/reseller-config.controller.js";
import {
    deleteResellerStmpConfiguration,
    getResellerStmpConfiguration,
    upsertResellerStmpConfiguration,
} from "../../controllers/reseller-stmp-config.controller.js";
import multer from "multer";

const upload = multer({ storage: multer.memoryStorage() });

const resellerConfigRouter = express.Router();

// Public route (no auth)
resellerConfigRouter.get("/public", getPublicResellerConfig);

// Protected routes
resellerConfigRouter.get("/", isAuth, getResellerConfig);
resellerConfigRouter.post("/update", isAuth, upload.single("logo"), updateResellerConfig);
resellerConfigRouter.post("/logo", isAuth, upload.single("logo"), updateResellerConfig);
resellerConfigRouter.get("/smtp", isAuth, getResellerStmpConfiguration);
resellerConfigRouter.post("/smtp", isAuth, upsertResellerStmpConfiguration);
resellerConfigRouter.delete("/smtp", isAuth, deleteResellerStmpConfiguration);

export default resellerConfigRouter;
