// app.js — Enhanced with visual effects while keeping original logic intact

// ============================================
// HELPER FUNCTIONS
// ============================================

function el(id){ return document.getElementById(id) }

function logToHS(msg){
  const h = el('hs-log-entries'); 
  if(!h) return;
  const d = document.createElement('div'); 
  d.textContent = (new Date()).toLocaleTimeString() + ' — ' + msg; 
  h.prepend(d);
  playLogSound();
}

function logToMain(msg){
  const h = el('log-entries'); 
  if(!h) return;
  const d = document.createElement('div'); 
  d.textContent = (new Date()).toLocaleTimeString() + ' — ' + msg; 
  h.prepend(d);
  playLogSound();
}

function playLogSound(){
  // Visual feedback instead of sound
  // Future enhancement: add actual sound effects
}

function createSuccessEffect(element){
  if(!element) return;
  element.style.animation = 'none';
  setTimeout(() => {
    element.style.animation = 'successPulse 0.5s ease';
  }, 10);
}

// Screen shake for important events
function shakeScreen(){
  document.body.style.animation = 'shake 0.5s ease';
  setTimeout(() => {
    document.body.style.animation = '';
  }, 500);
}

// Visual Key Traveling Animation
function createTravelingKey(startElement, endElement){
  return new Promise(resolve => {
    const key = document.createElement('div');
    key.className = 'traveling-key';
    key.textContent = '🔑';
    
    const startRect = startElement.getBoundingClientRect();
    const endRect = endElement.getBoundingClientRect();
    
    key.style.position = 'fixed';
    key.style.left = startRect.left + startRect.width / 2 + 'px';
    key.style.top = startRect.top + startRect.height / 2 + 'px';
    
    document.body.appendChild(key);
    
    setTimeout(() => {
      key.style.transition = 'left 1.5s cubic-bezier(0.4, 0, 0.2, 1), top 1.5s cubic-bezier(0.4, 0, 0.2, 1)';
      key.style.left = endRect.left + endRect.width / 2 + 'px';
      key.style.top = endRect.top + endRect.height / 2 + 'px';
      
      setTimeout(() => {
        key.style.opacity = '0';
        key.style.transform = 'scale(0)';
        setTimeout(() => {
          key.remove();
          createSuccessEffect(endElement);
          shakeScreen();
          resolve();
        }, 300);
      }, 1500);
    }, 20);
  });
}

// ============================================
// HANDSHAKE UI REFERENCES
// ============================================

const hsClientSeq = el('hs-client-seq'), hsServerSeq = el('hs-server-seq');
const hsSendSyn = el('hs-send-syn'), hsSendSynAck = el('hs-send-synack'), hsSendAck = el('hs-send-ack');
const hsReset = el('hs-reset'), hsStatus = el('hs-status'), hsArena = el('hs-arena'), hsProceed = el('hs-proceed');
const hsClientPort = el('hs-client-port'), hsServerPort = el('hs-server-port');
const hsLog = el('hs-log-entries');
let hsStep = 0; // 0 initial, 1 after SYN, 2 after SYN-ACK, 3 connected
let clientSeq = 1000, serverSeq = 2000;

// ============================================
// HANDSHAKE PACKET ANIMATION
// ============================================

function createHsPkt(text){
  const pkt = document.createElement('div');
  pkt.className = 'hs-pkt';
  pkt.textContent = text;
  hsArena.appendChild(pkt);
  return pkt;
}

function animateHs(pkt, dir='ltr'){
  return new Promise(resolve=>{
    // Snake-like animation in 3 steps
    const startPos = dir === 'ltr' ? -120 : 120;
    const midPos1 = dir === 'ltr' ? -40 : 40;
    const midPos2 = dir === 'ltr' ? 40 : -40;
    const endPos = dir === 'ltr' ? 120 : -120;
    
    pkt.style.opacity = '0';
    pkt.style.transform = `translateX(${startPos}%)`;
    
    // Step 1: Start to 1/3 position
    setTimeout(()=>{
      pkt.style.transition = 'transform 600ms cubic-bezier(0.4, 0, 0.2, 1), opacity 200ms';
      pkt.style.transform = `translateX(${midPos1}%)`;
      pkt.style.opacity = '1';
      pulseElement(pkt);
    }, 20);
    
    // Step 2: 1/3 to 2/3 position
    setTimeout(()=>{
      pkt.style.transition = 'transform 600ms cubic-bezier(0.4, 0, 0.2, 1)';
      pkt.style.transform = 'translateX(0%)';
      pulseElement(pkt);
    }, 700);
    
    // Step 3: 2/3 to end position
    setTimeout(()=>{
      pkt.style.transition = 'transform 600ms cubic-bezier(0.4, 0, 0.2, 1)';
      pkt.style.transform = `translateX(${midPos2}%)`;
      pulseElement(pkt);
    }, 1400);
    
    // Final: Reach destination and fade out
    setTimeout(()=>{
      pkt.style.transition = 'transform 600ms cubic-bezier(0.4, 0, 0.2, 1), opacity 300ms';
      pkt.style.transform = `translateX(${endPos}%)`;
      pkt.style.opacity = '0';
      setTimeout(()=>{ 
        pkt.remove(); 
        resolve();
      }, 650);
    }, 2100);
  });
}

// ============================================
// HANDSHAKE EVENT HANDLERS
// ============================================

hsSendSyn.addEventListener('click', async ()=>{
  if(hsStep !== 0) { 
    logToHS('⚠️ Invalid step: reset to start again'); 
    shakeElement(hsSendSyn);
    return;
  }
  clientSeq += 1; 
  hsClientSeq.textContent = clientSeq;
  pulseElement(hsClientSeq);
  
  logToHS('Client → Server: SYN (seq=' + clientSeq + ')');
  const pkt = createHsPkt('SYN (seq=' + clientSeq + ')');
  await animateHs(pkt, 'ltr');
  
  hsStep = 1;
  hsSendSyn.disabled = true;
  hsSendSynAck.disabled = false;
  createSuccessEffect(hsSendSyn);
});

hsSendSynAck.addEventListener('click', async ()=>{
  if(hsStep !== 1) { 
    logToHS('⚠️ Invalid step: SYN-ACK valid after SYN'); 
    shakeElement(hsSendSynAck);
    return;
  }
  serverSeq += 1; 
  hsServerSeq.textContent = serverSeq;
  pulseElement(hsServerSeq);
  
  logToHS('Server → Client: SYN-ACK (seq=' + serverSeq + ', ack=' + (clientSeq + 1) + ')');
  const pkt = createHsPkt('SYN-ACK (seq=' + serverSeq + ', ack=' + (clientSeq + 1) + ')');
  await animateHs(pkt, 'rtl');
  
  logToHS('Client received: SYN-ACK (ack=' + (clientSeq + 1) + ')');
  hsStep = 2;
  hsSendSynAck.disabled = true;
  hsSendAck.disabled = false;
  createSuccessEffect(hsSendSynAck);
});

hsSendAck.addEventListener('click', async ()=>{
  if(hsStep !== 2) { 
    logToHS('⚠️ Invalid step: ACK valid after SYN-ACK'); 
    shakeElement(hsSendAck);
    return;
  }
  clientSeq += 1; 
  hsClientSeq.textContent = clientSeq;
  pulseElement(hsClientSeq);
  
  logToHS('Client → Server: ACK (ack=' + (serverSeq + 1) + ') — Connection established');
  const pkt = createHsPkt('ACK (ack=' + (serverSeq + 1) + ')');
  await animateHs(pkt, 'ltr');
  
  hsStep = 3;
  hsStatus.textContent = '● TCP: connected'; 
  hsStatus.classList.remove('disconnected'); 
  hsStatus.classList.add('connected');
  hsSendAck.disabled = true;
  hsProceed.disabled = false;
  
  const success = document.createElement('div'); 
  success.innerHTML = '<strong style="color:#10b981">✅ TCP connection established — Ready for encryption!</strong>';
  hsLog.prepend(success);
  logToHS('🎉 Handshake complete — you may proceed to encryption.');
  
  createCelebrationEffect();
  createSuccessEffect(hsSendAck);
  createSuccessEffect(hsProceed);
});

hsReset.addEventListener('click', ()=>{
  hsStep = 0; 
  clientSeq = 1000; 
  serverSeq = 2000;
  hsClientSeq.textContent = clientSeq; 
  hsServerSeq.textContent = serverSeq;
  hsSendSyn.disabled = false; 
  hsSendSynAck.disabled = true; 
  hsSendAck.disabled = true;
  hsStatus.textContent = '● TCP: disconnected'; 
  hsStatus.classList.remove('connected'); 
  hsStatus.classList.add('disconnected');
  hsArena.innerHTML = ''; 
  hsLog.innerHTML = '';
  hsProceed.disabled = true;
  logToHS('🔄 Handshake reset. Start again by clicking Send SYN.');
});

hsProceed.addEventListener('click', ()=>{
  if(hsStep !== 3) {
    alert('⚠️ Complete the 3-way handshake first');
    shakeElement(hsProceed);
    return;
  }
  
  const hsSection = el('handshake-section');
  const mainContent = el('main-content');
  if(hsSection) {
    hsSection.style.animation = 'fadeOut 0.5s ease';
    setTimeout(() => {
      hsSection.classList.add('hidden');
    }, 500);
  }
  if(mainContent) {
    mainContent.classList.remove('hidden');
    mainContent.style.animation = 'fadeIn 0.6s ease';
  }
  
  init();
  shakeScreen();
  
  if(mainContent) {
    setTimeout(() => {
      mainContent.scrollIntoView({behavior:'smooth'});
    }, 100);
  }
  logToMain('🚀 Proceeding to Phase 2: Secure communication section revealed.');
});

// Back to Phase 1 button
const backBtn = el('back-to-phase1');
if(backBtn) {
  backBtn.addEventListener('click', ()=>{
    const hsSection = el('handshake-section');
    const mainContent = el('main-content');
    
    if(mainContent) {
      mainContent.style.animation = 'fadeOut 0.5s ease';
      setTimeout(() => {
        mainContent.classList.add('hidden');
      }, 500);
    }
    
    if(hsSection) {
      hsSection.classList.remove('hidden');
      hsSection.style.animation = 'fadeIn 0.6s ease';
    }
    
    shakeScreen();
    
    setTimeout(() => {
      if(hsSection) hsSection.scrollIntoView({behavior:'smooth'});
    }, 100);
    
    logToHS('🔙 Returned to Phase 1: TCP Handshake.');
  });
}

// ============================================
// VISUAL EFFECT HELPERS
// ============================================

function shakeElement(element){
  if(!element) return;
  element.style.animation = 'shake 0.5s ease';
  setTimeout(() => {
    element.style.animation = '';
  }, 500);
}

function pulseElement(element){
  if(!element) return;
  element.style.animation = 'pulse 0.5s ease';
  setTimeout(() => {
    element.style.animation = '';
  }, 500);
}

function createCelebrationEffect(){
  // Create confetti-like effect
  const colors = ['#667eea', '#764ba2', '#10b981', '#f59e0b'];
  for(let i = 0; i < 20; i++){
    setTimeout(() => {
      createConfetti(colors[Math.floor(Math.random() * colors.length)]);
    }, i * 30);
  }
}

function createConfetti(color){
  const confetti = document.createElement('div');
  confetti.style.position = 'fixed';
  confetti.style.width = '8px';
  confetti.style.height = '8px';
  confetti.style.backgroundColor = color;
  confetti.style.borderRadius = '50%';
  confetti.style.left = Math.random() * 100 + '%';
  confetti.style.top = '-10px';
  confetti.style.zIndex = '1000';
  confetti.style.pointerEvents = 'none';
  confetti.style.boxShadow = `0 0 10px ${color}`;
  document.body.appendChild(confetti);
  
  const duration = 2000 + Math.random() * 1000;
  const startTime = Date.now();
  
  function animate(){
    const elapsed = Date.now() - startTime;
    const progress = elapsed / duration;
    
    if(progress < 1){
      confetti.style.transform = `translateY(${progress * window.innerHeight}px) rotate(${progress * 360}deg)`;
      confetti.style.opacity = 1 - progress;
      requestAnimationFrame(animate);
    } else {
      confetti.remove();
    }
  }
  animate();
}

// Add CSS keyframes dynamically
const style = document.createElement('style');
style.textContent = `
  @keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-10px); }
    75% { transform: translateX(10px); }
  }
  @keyframes successPulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); box-shadow: 0 0 20px rgba(16, 185, 129, 0.5); }
    100% { transform: scale(1); }
  }
  @keyframes fadeOut {
    from { opacity: 1; transform: translateY(0); }
    to { opacity: 0; transform: translateY(-20px); }
  }
`;
document.head.appendChild(style);

// ============================================
// MAIN ENCRYPTION CODE (Original Logic Preserved)
// ============================================

function str2ab(str){ return new TextEncoder().encode(str); }
function ab2str(ab){ return new TextDecoder().decode(ab); }
function ab2b64(buf){ return btoa(String.fromCharCode(...new Uint8Array(buf))); }
function b642ab(b64){ const bin = atob(b64); const len = bin.length; const arr = new Uint8Array(len); for(let i=0;i<len;i++) arr[i]=bin.charCodeAt(i); return arr; }

const tabSym = el('tab-symmetric');
const tabAsym = el('tab-asymmetric');
const btnGenKey = el('btn-gen-key');
const btnGenKeyReceiver = el('btn-gen-key-receiver');
const btnKeyExchange = el('btn-key-exchange');
const keyCards = el('key-cards');
const recvCards = el('recv-cards');
const btnEncrypt = el('btn-encrypt');
const btnImportKey = el('btn-import-key');
const btnDecrypt = el('btn-decrypt');
const plaintextEl = el('plaintext');
const packetEl = el('packet');
const attackerEl = el('attacker');
const logEntries = el('log-entries');
const chkShowCipher = el('chk-show-cipher');
const chkStealKey = el('chk-steal-key');
const decryptedEl = el('decrypted');
const quizBtns = document.querySelectorAll('.quiz-btn');
const quizResult = el('quiz-result');

let mode = 'symmetric';
let symKey = null;
let symIv = null;
let receiverSymKey = null;
let rsaKeyPair = null;
let senderHasReceiverPub = false;
let sentCipherB64 = null;
let stolenKeyExport = null;

function init(){
  if(!tabSym || !tabAsym || !btnGenKey || !btnKeyExchange || !btnEncrypt || !btnImportKey || !btnDecrypt){
    console.error('Missing required UI elements. Check IDs in HTML.');
    return;
  }
  tabSym.addEventListener('click', ()=>setMode('symmetric'));
  tabAsym.addEventListener('click', ()=>setMode('asymmetric'));
  btnGenKey.addEventListener('click', genKey);
  if(btnGenKeyReceiver) btnGenKeyReceiver.addEventListener('click', genKey);
  btnKeyExchange.addEventListener('click', senderSimulateSendKey);
  btnEncrypt.addEventListener('click', encryptAndSend);
  btnImportKey.addEventListener('click', importKeyForReceiver);
  btnDecrypt.addEventListener('click', decryptAtReceiver);
  chkShowCipher.addEventListener('change', renderPacket);
  chkStealKey.addEventListener('change', ()=>{
    logToMain('⚠️ Attacker key-steal simulation: ' + (chkStealKey.checked ? 'ON' : 'OFF'));
    if(chkStealKey.checked && attackerEl){
      attackerEl.querySelector('.attacker-icon').style.animation = 'pulse 1s ease-in-out infinite';
    } else if(attackerEl){
      attackerEl.querySelector('.attacker-icon').style.animation = '';
    }
  });
  quizBtns.forEach(b=>b.addEventListener('click', onQuiz));
  setMode('symmetric');
}

function addLog(msg){ 
  if(!logEntries) return; 
  const eln=document.createElement('div'); 
  eln.textContent=(new Date()).toLocaleTimeString() + ' — ' + msg; 
  logEntries.prepend(eln);
}

function clearState(){
  symKey = null; symIv = null; receiverSymKey = null;
  rsaKeyPair = null; senderHasReceiverPub = false;
  sentCipherB64 = null; stolenKeyExport = null;
  if(keyCards) keyCards.innerHTML = '';
  if(recvCards) recvCards.innerHTML = '';
  if(decryptedEl) decryptedEl.value = '';
  if(packetEl) packetEl.classList.add('hidden');
  if(attackerEl) {
    const icon = attackerEl.querySelector('.attacker-icon');
    if(icon) icon.textContent = '👀';
  }
  if(btnImportKey) btnImportKey.disabled = true;
  if(btnKeyExchange) btnKeyExchange.disabled = true;
  if(btnDecrypt) btnDecrypt.disabled = true;
}

function setMode(m){
  mode = m;
  tabSym.classList.toggle('active', m==='symmetric');
  tabAsym.classList.toggle('active', m==='asymmetric');
  clearState();
  if(logEntries) logEntries.innerHTML = '';
  addLog('🔄 Mode set to ' + (m==='symmetric' ? 'Symmetric (AES-256-GCM)' : 'Asymmetric (RSA-2048-OAEP)'));
  
  // Control button visibility based on mode
  if(m === 'symmetric'){
    btnGenKey.style.display = '';
    btnKeyExchange.style.display = '';
    btnGenKeyReceiver.style.display = 'none';
    btnKeyExchange.disabled = true;
    btnImportKey.disabled = true;
  } else {
    btnGenKey.style.display = 'none';
    btnKeyExchange.style.display = 'none';
    btnGenKeyReceiver.style.display = '';
    btnKeyExchange.disabled = true;
    btnImportKey.disabled = true;
  }
}

async function genKey(){
  try{
    clearState();
    addLog('🔑 Generating cryptographic key(s)...');
    if(mode === 'symmetric'){
      symKey = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, ['encrypt','decrypt']);
      symIv = crypto.getRandomValues(new Uint8Array(12));
      const raw = await crypto.subtle.exportKey('raw', symKey);
      const fp = ab2b64(raw).slice(0,20);
      keyCards.innerHTML = `<div class="card"><strong>🔑 Sender Secret Key</strong><br><small>Fingerprint: ${fp}...</small></div>`;
      recvCards.innerHTML = `<div class="card"><strong>📭 Receiver</strong><br><small>Receiver does not have secret key yet. Sender must send it.</small></div>`;
      btnKeyExchange.disabled = false;
      addLog('✅ Sender generated AES-256 key. Click "Simulate Key Exchange" to send to Receiver.');
      pulseElement(btnKeyExchange);
    } else {
      rsaKeyPair = await crypto.subtle.generateKey(
        { name: 'RSA-OAEP', modulusLength: 2048, publicExponent: new Uint8Array([1,0,1]), hash: 'SHA-256' },
        true,
        ['encrypt','decrypt']
      );
      const pubJwk = await crypto.subtle.exportKey('jwk', rsaKeyPair.publicKey);
      const pubId = (pubJwk.n || '').slice(0,20);
      recvCards.innerHTML = `
        <div class="card"><strong>🔐 Receiver Public Key</strong><br><small>Public ID: ${pubId}...</small></div>
        <div class="card"><strong>🔒 Private Key: 🔑</strong><br><small>Stays secret on Receiver (shown as icon)</small></div>
      `;
      keyCards.innerHTML = `<div class="card"><strong>📭 Sender</strong><br><small>Sender does NOT have Receiver's public key yet. Receiver must "Share Public Key".</small></div>`;
      btnImportKey.disabled = false;
      addLog('✅ Receiver generated RSA-2048 keypair. Click "Share Public Key" to give public key to Sender.');
      pulseElement(btnImportKey);
    }
  } catch(e){
    console.error(e);
    addLog('❌ Key generation error: ' + (e.message || e));
    alert('Error generating key. See console for details.');
  }
}

async function senderSimulateSendKey(){
  try{
    if(mode !== 'symmetric'){ alert('This action is for symmetric mode only.'); return; }
    if(!symKey){ alert('Generate symmetric key at Sender first.'); return; }
    
    addLog('🔄 Transferring symmetric key...');
    const senderPanel = document.querySelector('.sender');
    const receiverPanel = document.querySelector('.receiver');
    
    await createTravelingKey(senderPanel, receiverPanel);
    
    const raw = await crypto.subtle.exportKey('raw', symKey);
    receiverSymKey = await crypto.subtle.importKey('raw', raw, { name:'AES-GCM' }, true, ['decrypt']);
    recvCards.innerHTML = `<div class="card"><strong>🔑 Receiver Secret Key</strong><br><small>Fingerprint: ${ab2b64(raw).slice(0,20)}...</small></div>`;
    btnKeyExchange.disabled = true;
    btnDecrypt.disabled = false;
    addLog('✅ Sender sent secret key to Receiver (simulation). Receiver now has the secret key.');
    createSuccessEffect(recvCards);
    createCelebrationEffect();
    
    if(chkStealKey && chkStealKey.checked){
      stolenKeyExport = ab2b64(raw);
      const icon = attackerEl.querySelector('.attacker-icon');
      if(icon) icon.textContent = '🕵️‍♂️';
      addLog('⚠️ Attacker stole the symmetric key during transfer (simulation).');
      shakeElement(attackerEl);
    } else {
      stolenKeyExport = null;
      const icon = attackerEl.querySelector('.attacker-icon');
      if(icon) icon.textContent = '👀';
    }
  } catch(e){
    console.error(e);
    addLog('❌ Error sending key: ' + (e.message || e));
  }
}

async function importKeyForReceiver(){
  try{
    if(mode === 'symmetric'){ alert('In symmetric mode, Sender should send the key.'); return; }
    if(!rsaKeyPair){ alert('Generate RSA keys at Receiver first.'); return; }
    
    addLog('🔄 Sharing public key...');
    const receiverPanel = document.querySelector('.receiver');
    const senderPanel = document.querySelector('.sender');
    
    await createTravelingKey(receiverPanel, senderPanel);
    
    const pubJwk = await crypto.subtle.exportKey('jwk', rsaKeyPair.publicKey);
    senderHasReceiverPub = true;
    keyCards.innerHTML = `<div class="card"><strong>🔓 Sender Has Public Key</strong><br><small>Public ID: ${(pubJwk.n||'').slice(0,20)}...</small></div>`;
    recvCards.innerHTML = `
      <div class="card"><strong>🔐 Receiver Public Key</strong><br><small>Public ID: ${(pubJwk.n||'').slice(0,20)}...</small></div>
      <div class="card"><strong>🔒 Private Key: 🔑</strong><br><small>Stays secret on Receiver (shown as icon)</small></div>
    `;
    addLog('✅ Receiver shared PUBLIC key with Sender (simulation). Sender can now encrypt using this public key.');
    createSuccessEffect(keyCards);
    createCelebrationEffect();
    
    if(chkStealKey && chkStealKey.checked){
      try{
        const privJwk = await crypto.subtle.exportKey('jwk', rsaKeyPair.privateKey);
        stolenKeyExport = privJwk;
        const icon = attackerEl.querySelector('.attacker-icon');
        if(icon) icon.textContent = '🕵️‍♂️';
        addLog('⚠️ Attacker stole Receiver private key (simulation).');
        shakeElement(attackerEl);
      } catch(e){
        stolenKeyExport = null;
        const icon = attackerEl.querySelector('.attacker-icon');
        if(icon) icon.textContent = '👀';
        addLog('✅ Attacker failed to steal private key: browser prevented exporting private key.');
      }
    } else {
      stolenKeyExport = null;
      const icon = attackerEl.querySelector('.attacker-icon');
      if(icon) icon.textContent = '👀';
    }
    btnDecrypt.disabled = false;
  } catch(e){
    console.error(e);
    addLog('❌ Error sharing public key: ' + (e.message || e));
  }
}

async function encryptAndSend(){
  try{
    const msg = plaintextEl ? plaintextEl.value : '';
    if(!msg){ alert('Please type a message first.'); return; }
    if(mode === 'symmetric'){
      if(!symKey){ alert('Generate symmetric key at Sender first.'); return; }
      const iv = symIv || crypto.getRandomValues(new Uint8Array(12));
      const ctBuf = await crypto.subtle.encrypt({ name:'AES-GCM', iv }, symKey, str2ab(msg));
      sentCipherB64 = ab2b64(ctBuf);
      addLog('🔒 Sender encrypted message with AES-256-GCM.');
      if(packetEl){
        packetEl.textContent = chkShowCipher && chkShowCipher.checked ? sentCipherB64.slice(0, 40) + '...' : '🔐 Encrypted Data';
        packetEl.classList.remove('hidden');
        packetEl.style.left = '10px';
        setTimeout(()=>{ packetEl.style.left = '54%'; }, 80);
      }
      if(chkStealKey && chkStealKey.checked && stolenKeyExport){
        try{
          const raw = b642ab(stolenKeyExport);
          const atkKey = await crypto.subtle.importKey('raw', raw.buffer || raw, { name:'AES-GCM' }, true, ['decrypt']);
          const plain = await crypto.subtle.decrypt({ name:'AES-GCM', iv }, atkKey, b642ab(sentCipherB64).buffer || b642ab(sentCipherB64));
          const icon = attackerEl.querySelector('.attacker-icon');
          if(icon) icon.textContent = '🕵️‍♂️ ' + ab2str(plain).slice(0, 10) + '...';
          addLog('⚠️ Attacker decrypted AES ciphertext using stolen key (simulation).');
        } catch(e){
          const icon = attackerEl.querySelector('.attacker-icon');
          if(icon) icon.textContent = '❌';
        }
      }
      btnDecrypt.disabled = false;
      addLog('📤 Encrypted packet sent over network.');
    } else {
      if(!rsaKeyPair){ alert('Receiver keys not generated yet.'); return; }
      if(!senderHasReceiverPub){ alert('Sender does not have Receiver public key yet. Receiver must share public key.'); return; }
      const cipherBuf = await crypto.subtle.encrypt({ name:'RSA-OAEP' }, rsaKeyPair.publicKey, str2ab(msg));
      sentCipherB64 = ab2b64(cipherBuf);
      addLog('🔒 Sender encrypted message using Receiver public key (RSA-2048-OAEP).');
      if(packetEl){
        packetEl.textContent = chkShowCipher && chkShowCipher.checked ? sentCipherB64.slice(0, 40) + '...' : '🔐 Encrypted Data';
        packetEl.classList.remove('hidden');
        packetEl.style.left = '10px';
        setTimeout(()=>{ packetEl.style.left = '54%'; }, 80);
      }
      if(chkStealKey && chkStealKey.checked && stolenKeyExport){
        try{
          const atkPriv = await crypto.subtle.importKey('jwk', stolenKeyExport, { name:'RSA-OAEP', hash:'SHA-256' }, true, ['decrypt']);
          const plain = await crypto.subtle.decrypt({ name:'RSA-OAEP' }, atkPriv, b642ab(sentCipherB64).buffer || b642ab(sentCipherB64));
          const icon = attackerEl.querySelector('.attacker-icon');
          if(icon) icon.textContent = '🕵️‍♂️ ' + ab2str(plain).slice(0, 10) + '...';
          addLog('⚠️ Attacker decrypted RSA ciphertext using stolen private key (simulation).');
        } catch(e){
          const icon = attackerEl.querySelector('.attacker-icon');
          if(icon) icon.textContent = '❌';
        }
      }
      btnDecrypt.disabled = false;
      addLog('📤 Encrypted packet sent over network.');
    }
  } catch(e){
    console.error(e);
    addLog('❌ Encryption error: ' + (e.message || e));
    alert('Encryption failed. See console for details.');
  }
}

async function decryptAtReceiver(){
  try{
    if(!sentCipherB64){ alert('No ciphertext sent yet.'); return; }
    addLog('🔓 Receiver attempting to decrypt...');
    if(mode === 'symmetric'){
      if(!receiverSymKey){
        alert('Receiver does not have the secret key yet. Sender must send it (Simulate Key Exchange).');
        return;
      }
      const ctArr = b642ab(sentCipherB64).buffer || b642ab(sentCipherB64);
      const plainBuf = await crypto.subtle.decrypt({ name:'AES-GCM', iv: symIv }, receiverSymKey, ctArr);
      const out = ab2str(plainBuf);
      decryptedEl.value = out;
      addLog('✅ Receiver: AES decryption successful.');
      createSuccessEffect(decryptedEl);
      createCelebrationEffect();
    } else {
      if(!rsaKeyPair || !rsaKeyPair.privateKey){
        alert('Receiver private key not found. Generate keys first.');
        return;
      }
      const ctArr = b642ab(sentCipherB64).buffer || b642ab(sentCipherB64);
      const plainBuf = await crypto.subtle.decrypt({ name:'RSA-OAEP' }, rsaKeyPair.privateKey, ctArr);
      const out = ab2str(plainBuf);
      decryptedEl.value = out;
      addLog('✅ Receiver: RSA-OAEP decryption successful.');
      createSuccessEffect(decryptedEl);
      createCelebrationEffect();
    }
    if(packetEl){
      packetEl.style.left = '90%';
      setTimeout(()=>{ packetEl.classList.add('hidden'); }, 900);
    }
    if(chkStealKey && chkStealKey.checked && stolenKeyExport){
      addLog('ℹ️ Note: In this simulation attacker had stolen the key and could decrypt (if theft succeeded).');
    }
  } catch(e){
    console.error(e);
    addLog('❌ Decryption failed: ' + (e.message || e));
    decryptedEl.value = '❌ Decryption failed — wrong key or tampered packet';
    shakeElement(decryptedEl);
  }
}

function renderPacket(){
  if(!sentCipherB64 || !packetEl) return;
  const show = chkShowCipher && chkShowCipher.checked;
  packetEl.textContent = show ? sentCipherB64.slice(0, 40) + '...' : '🔐 Encrypted Data';
}

function onQuiz(e){
  const ans = e.currentTarget.dataset.answer;
  if(ans === 'private') {
    quizResult.innerHTML = '<div style="color:#10b981; animation: successPulse 0.5s ease;">✅ Correct! Private key decrypts RSA ciphertext.</div>';
    createSuccessEffect(quizResult);
    createCelebrationEffect();
  } else {
    quizResult.innerHTML = '<div style="color:#ef4444; animation: shake 0.5s ease;">❌ Incorrect. Public key encrypts, private key decrypts.</div>';
    shakeElement(quizResult);
  }
}

logToHS('🚀 Interactive demo ready. Start Phase 1 by clicking Send SYN.');
