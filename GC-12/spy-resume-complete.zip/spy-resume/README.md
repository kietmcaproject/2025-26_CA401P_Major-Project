# SPY-RESUME — Job Match Intelligence System

> TF-IDF powered resume analyzer · 100% client-side · No backend

## 📁 File Structure

```
spy-resume/
├── index.html        ← Main analyzer tool
├── login.html        ← Login page
├── signup.html       ← Sign up page
├── dashboard.html    ← User dashboard + history
├── tips.html         ← ATS Tips & Resume Guide
├── about.html        ← About the project
├── netlify.toml      ← Netlify routing config
└── README.md
```

## 🚀 Deploying to Netlify

### Option A — Drag & Drop (Fastest)
1. Select all 7 files
2. Zip them into `spy-resume.zip`
3. Go to https://app.netlify.com
4. Drag the ZIP onto the Netlify drop zone
5. Done — your site is live!

### Option B — GitHub + Netlify (Recommended for college)
1. Create a new GitHub repo: `spy-resume`
2. Upload all files to the repo
3. Go to Netlify → "Add new site" → "Import from Git"
4. Connect your GitHub and select the repo
5. Build settings: Leave blank (static site)
6. Click "Deploy Site"

Every time you push to GitHub, Netlify auto-deploys.

## 💻 Deploying to GitHub Pages
1. Create repo named `spy-resume` (or `your-username.github.io`)
2. Upload all files
3. Go to Settings → Pages → Source: `main` branch → `/root`
4. Your site: `https://yourusername.github.io/spy-resume/`

## 🔗 Pages
| Page | URL |
|------|-----|
| Analyzer | `/index.html` or `/` |
| Login | `/login.html` |
| Sign Up | `/signup.html` |
| Dashboard | `/dashboard.html` |
| ATS Tips | `/tips.html` |
| About | `/about.html` |

## ⚙️ Tech Stack
- HTML5 + CSS3 + Vanilla JavaScript (ES6+)
- PDF.js v3.11 (Mozilla) — PDF parsing
- Custom TF-IDF + Cosine Similarity engine
- localStorage — session & history persistence
- Google Fonts: Syne + Plus Jakarta Sans
- No backend · No database · No server

## 📝 Notes for College Presentation
- The login/signup is a **demo** (localStorage-based, no real backend)
- All analysis happens **100% in the browser**
- PDF.js parses PDFs without uploading anywhere
- History stores up to 10 past analyses per browser session
