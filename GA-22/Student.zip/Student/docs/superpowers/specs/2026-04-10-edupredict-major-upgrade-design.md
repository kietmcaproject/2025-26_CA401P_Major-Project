# EduPredict AI Major Project Upgrade Design

## MVP

Convert the current prediction demo into a major-project level academic monitoring system. The upgraded product will support student record management, editable interventions, richer dashboards, saved reports, and persistent data while reusing the existing ML prediction workflow.

## Recommended Approach

### Option 1: Keep Flask + React and add lightweight JSON persistence
- Fastest to ship
- No new database setup
- Easy to demo locally and deploy on free hosting
- Best fit for the existing codebase

### Option 2: Add SQLite with ORM
- Better long-term structure
- Slightly more professional backend shape
- Slower than needed for this upgrade

### Option 3: Rebuild frontend with a router and full component redesign
- Cleanest architecture
- Highest effort
- Not necessary to reach major-project quality quickly

## Chosen Direction

Use Option 1. Keep the current stack, introduce a small persistent JSON datastore in the Flask backend, and expand the frontend into a multi-page faculty dashboard. This gives the highest visible project value for the least rewrite.

## Product Positioning

EduPredict AI becomes an Academic Early Warning and Student Success Management System.

Core story for viva/demo:
- Predict student performance using ML
- Identify at-risk students early
- Manage student academic records
- Assign and track interventions
- Generate faculty-ready reports
- Monitor class-level analytics in one dashboard

## Features To Add

### 1. Dashboard
- Top-level project overview page
- KPI cards for total students, at-risk students, interventions pending, reports generated
- Recent activity feed
- Quick actions for add student, run prediction, create intervention
- Top risk watchlist

### 2. Student Management
- New Students page with searchable table
- Add student form
- Edit student form
- Delete student action
- Save prediction result into the student profile
- Filter by department, semester, risk level, and prediction status

### 3. Student Profile View
- Dedicated detail panel/page for a selected student
- Academic metrics, latest prediction, risk level, notes, mentor/faculty info
- Timeline of interventions and prediction history

### 4. Intervention Tracker
- New page for assigning support actions
- Create intervention with title, type, priority, assigned faculty, due date, status, notes
- Edit existing intervention
- Mark intervention as pending, in progress, or completed
- Link interventions to students

### 5. Reports Center
- Reports page that summarizes saved reports
- Generate class summary report from current student data
- Report cards for saved exports
- Export CSV/PDF from both batch results and managed student records

### 6. Better Analytics UX
- Keep current analytics charts
- Add risk trend summaries, department breakdown, and recommendation cards derived from current stored data

## Backend Design

### Storage
- Add `backend/data/store.json`
- Structure:
  - `students`
  - `interventions`
  - `reports`
  - `activity`

### New Endpoints
- `GET /dashboard-summary`
- `GET /students`
- `POST /students`
- `PUT /students/<id>`
- `DELETE /students/<id>`
- `POST /students/<id>/predict`
- `GET /interventions`
- `POST /interventions`
- `PUT /interventions/<id>`
- `DELETE /interventions/<id>`
- `GET /reports`
- `POST /reports/generate`
- `GET /activity`

### Backend Rules
- Keep existing prediction and export endpoints working
- Persist students/interventions/reports in JSON file
- Recalculate student risk and latest prediction whenever a student prediction is run
- Append actions to activity log for dashboard display

## Frontend Design

### Navigation
- Add pages:
  - Dashboard
  - Students
  - Single Predict
  - Batch Predict
  - Interventions
  - Reports
  - Analytics
  - Alerts
  - History

### State Strategy
- Continue using local React state lifted into `MainShell`
- Fetch persisted backend data on load
- Keep the architecture simple and avoid adding Redux or complex abstractions

### Shared UI
- Reuse current card/stat/table styles
- Add modal-style or inline editor panels for add/edit workflows
- Improve mobile responsiveness for tables and page grids

## Error Handling

- Show toast messages for save, update, delete, and prediction actions
- Gracefully handle empty states for students, interventions, and reports
- Keep backend responses simple and explicit

## Testing

- Run frontend production build to catch JSX/runtime issues
- Smoke-test backend import and key routes where possible
- No deep test harness added in this iteration to preserve speed

## Scope Guard

This upgrade will not add:
- Multi-user role management
- Real database setup
- Complex authentication
- Live email configuration UI
- Router migration

These are intentionally excluded to keep the project strong, demoable, and fast to ship.
