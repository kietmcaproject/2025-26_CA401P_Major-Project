# 🎓 EduPredict AI — Student Performance Prediction System v2

> Final Year Project | ML + Full Stack | React + Flask + Scikit-learn

---

## ✨ Features

| Feature | Description |
|---|---|
| 🔮 Single Prediction | Predict Pass/Fail for one student instantly |
| 📋 Batch Prediction | Upload CSV → predict all students at once |
| 📄 Export PDF | Download a formatted PDF report |
| 📥 Export CSV | Download results as spreadsheet |
| 🚨 Email Alerts | Send HTML email alerts to faculty (Gmail SMTP) |
| 📊 History & Charts | View all predictions with pie/bar charts |
| 🤖 4 ML Models | LR, Random Forest, SVM, Neural Network — best auto-selected |
| 🔐 Auth | Login with token stored in localStorage |

---

## 🧱 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Chart.js, Axios |
| Backend | Python Flask, Flask-CORS |
| ML | Scikit-learn (LR, RF, SVM, MLP), Pandas, NumPy |
| PDF | ReportLab |
| Email | Gmail SMTP (smtplib) |
| Deploy | Render (backend) + Vercel/Netlify (frontend) |

---

## 📁 Project Structure

```
student-performance-ai/
├── backend/
│   ├── app.py              ← Flask REST API (all endpoints)
│   ├── train_model.py      ← Train 4 ML models, save best
│   ├── requirements.txt
│   ├── render.yaml         ← Render deployment config
│   ├── model.pkl           ← Saved best model
│   ├── scaler.pkl
│   └── model_info.pkl
├── frontend/
│   ├── package.json
│   ├── public/index.html
│   └── src/
│       ├── App.js
│       ├── index.js / index.css
│       ├── pages/
│       │   ├── LoginPage.jsx
│       │   ├── MainShell.jsx   ← Sidebar layout
│       │   ├── PredictPage.jsx ← Single prediction
│       │   ├── BatchPage.jsx   ← CSV upload + export
│       │   ├── AlertPage.jsx   ← Email alerts
│       │   └── HistoryPage.jsx ← Charts + history
│       └── services/
│           ├── api.js          ← All API calls
│           └── toast.js        ← Toast notifications
└── dataset/
    ├── students.csv
    └── generate_dataset.py
```

---

## 🚀 Local Setup

### Backend

```bash
cd backend

# Install dependencies
pip install flask flask-cors scikit-learn pandas numpy reportlab gunicorn

# Generate dataset (first time only)
cd ../dataset
python generate_dataset.py

# Train models (first time only)
cd ../backend
python train_model.py

# Start Flask API
python app.py
# → Running on http://localhost:5000
```

### Frontend

```bash
cd frontend
npm install
npm start
# → Running on http://localhost:3000
```

Login: **admin / admin123**

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | API status + model accuracy |
| POST | `/login` | Authenticate → token |
| POST | `/predict` | Single student prediction |
| POST | `/predict-batch` | CSV file → batch predictions |
| POST | `/export-csv` | Download results as CSV |
| POST | `/export-pdf` | Download PDF report |
| POST | `/send-alert` | Send email alert to faculty |
| GET | `/model-info` | All model accuracy comparison |

### /predict Request & Response
```json
// Request
{ "study_hours": 6, "attendance": 75, "internal_marks": 65, "previous_score": 70 }

// Response
{ "prediction": "Pass", "probability": 0.87, "risk_level": "Low", "model_used": "Logistic Regression" }
```

### /predict-batch
- Send as `multipart/form-data` with field `file`
- CSV must have: `StudyHours`, `Attendance`, `InternalMarks`, `PreviousScore`
- Optional: `Name` column

---

## 📧 Gmail Email Setup

1. Go to your Google Account → Security → **App Passwords**
2. Generate an App Password for "Mail"
3. Open `backend/app.py` and set:
```python
GMAIL_USER     = "your_email@gmail.com"
GMAIL_PASSWORD = "your_16_char_app_password"
```
> Without this, alerts run in **simulated mode** (no real email sent).

---

## 🚀 Deployment

### Backend → Render (Free)

1. Push project to GitHub
2. Go to [render.com](https://render.com) → New Web Service
3. Connect your GitHub repo
4. Set:
   - **Root Directory**: `backend`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app`
5. Add environment variables: `GMAIL_USER`, `GMAIL_PASSWORD`
6. Deploy → get URL like `https://edupredict-api.onrender.com`

### Frontend → Vercel (Free)

1. Open `frontend/src/services/api.js`
2. Change `baseURL: ''` to your Render URL:
```js
const api = axios.create({ baseURL: 'https://edupredict-api.onrender.com' });
```
3. Go to [vercel.com](https://vercel.com) → Import GitHub repo
4. Set **Root Directory** to `frontend`
5. Deploy → get URL like `https://edupredict.vercel.app`

---

## 🤖 ML Models Comparison

| Model | Accuracy | Notes |
|---|---|---|
| Logistic Regression | **95.00%** ✅ Selected | Fast, interpretable |
| SVM | 95.00% | Good for small datasets |
| Neural Network (MLP) | 95.00% | Complex patterns |
| Random Forest | 92.50% | Robust, handles noise |

---

## 🚨 Early Warning Rules

| Condition | Risk Level | Action |
|---|---|---|
| Attendance < 60% | 🔴 High | Immediate intervention |
| Internal Marks < 50 | 🟡 Medium | Academic support |
| Both OK | 🟢 Low | Monitor regularly |

---

## 🎓 Viva Q&A

**Q1: What is Logistic Regression?**
A classification algorithm using the sigmoid function to predict binary outcomes (Pass/Fail) as probabilities between 0 and 1.

**Q2: Why use StandardScaler?**
Features have different scales (1-10 study hours vs 0-100 marks). Scaling prevents larger-range features from dominating the model.

**Q3: What is predict_proba?**
A Scikit-learn method returning probability for each class. We use `predict_proba(X)[0][1]` for probability of "Pass".

**Q4: Why compare 4 models?**
To objectively select the best performer. Each model has different strengths — we auto-select the highest accuracy on the test set.

**Q5: What is CORS?**
Cross-Origin Resource Sharing — Flask-CORS allows React (port 3000) to call Flask (port 5000) without browser blocking.

**Q6: What is the Early Warning System?**
Rule-based logic layered on ML. Attendance <60% → High Risk. Internal marks <50 → Medium Risk. Alerts faculty early.

**Q7: How does batch prediction work?**
Faculty uploads a CSV → Flask parses it with Pandas → runs `predict_one()` for each row → returns JSON array of results.

**Q8: What is ReportLab?**
A Python library to generate PDF files programmatically. We use it to create formatted student performance reports.

**Q9: What is an MLP (Neural Network)?**
Multi-Layer Perceptron — a feedforward neural network with hidden layers. `MLPClassifier(hidden_layer_sizes=(64,32))` means 2 hidden layers with 64 and 32 neurons.

**Q10: How is the model saved and loaded?**
Using Python's `pickle` module — `pickle.dump(model, file)` saves, `pickle.load(file)` restores. This avoids retraining on every API call.

---

*Built for Final Year Project | EduPredict AI v2*
