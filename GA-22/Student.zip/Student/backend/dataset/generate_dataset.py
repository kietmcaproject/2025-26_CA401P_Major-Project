"""Generate 200 realistic student records."""
import pandas as pd
import numpy as np

np.random.seed(42)
n = 200
study_hours    = np.round(np.random.uniform(1, 10, n), 1)
attendance     = np.round(np.random.uniform(40, 100, n), 1)
internal_marks = np.round(np.random.uniform(20, 100, n), 1)
previous_score = np.round(np.random.uniform(30, 100, n), 1)

results = []
for sh, att, im, ps in zip(study_hours, attendance, internal_marks, previous_score):
    score = (sh/10)*20 + (att/100)*25 + (im/100)*30 + (ps/100)*25
    score += np.random.normal(0, 3)
    results.append("Pass" if score >= 50 else "Fail")

df = pd.DataFrame({
    "StudyHours": study_hours, "Attendance": attendance,
    "InternalMarks": internal_marks, "PreviousScore": previous_score,
    "Result": results
})
df.to_csv("students.csv", index=False)
print(f"✅ {len(df)} records saved.")
print(df["Result"].value_counts())
