"""
train_model.py — Trains 4 ML models, picks the best, saves artifacts.
Models: Logistic Regression, Random Forest, SVM, Neural Network (MLP)
"""
import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model  import LogisticRegression
from sklearn.ensemble      import RandomForestClassifier
from sklearn.svm           import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics        import accuracy_score, classification_report

# ── 1. Load ──────────────────────────────────────────────────────────────────
df = pd.read_csv("../dataset/students.csv")
df.dropna(inplace=True)
df["Result"] = df["Result"].map({"Pass": 1, "Fail": 0})

FEATURES = ["StudyHours", "Attendance", "InternalMarks", "PreviousScore"]
X = df[FEATURES].values
y = df["Result"].values

# ── 2. Split & Scale ─────────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s  = scaler.transform(X_test)

# ── 3. Train all models ───────────────────────────────────────────────────────
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
    "Random Forest":       RandomForestClassifier(n_estimators=100, random_state=42),
    "SVM":                 SVC(probability=True, random_state=42),
    "Neural Network":      MLPClassifier(hidden_layer_sizes=(64,32), max_iter=500, random_state=42),
}

results = {}
for name, m in models.items():
    m.fit(X_train_s, y_train)
    acc = accuracy_score(y_test, m.predict(X_test_s))
    results[name] = {"model": m, "accuracy": acc}
    print(f"{name:22s} → {acc:.4f}")
    print(classification_report(y_test, m.predict(X_test_s)))

# ── 4. Pick best ─────────────────────────────────────────────────────────────
best_name = max(results, key=lambda k: results[k]["accuracy"])
best      = results[best_name]
print(f"\n✅ Best Model: {best_name} ({best['accuracy']:.4f})")

# ── 5. Save ──────────────────────────────────────────────────────────────────
with open("model.pkl",      "wb") as f: pickle.dump(best["model"], f)
with open("scaler.pkl",     "wb") as f: pickle.dump(scaler, f)
with open("model_info.pkl", "wb") as f:
    pickle.dump({
        "model_name": best_name,
        "accuracy":   best["accuracy"],
        "features":   FEATURES,
        "all_models": {k: v["accuracy"] for k, v in results.items()},
        # kept for backward compat
        "lr_accuracy": results["Logistic Regression"]["accuracy"],
        "rf_accuracy": results["Random Forest"]["accuracy"],
    }, f)

print("✅ Saved: model.pkl  scaler.pkl  model_info.pkl")