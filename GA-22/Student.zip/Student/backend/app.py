"""
EduPredict AI backend.

Extends the original prediction API into a lightweight academic monitoring
system with persistent students, interventions, reports, and activity logs.
"""

import csv
import io
import json
import math
import os
import pickle
import smtplib
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from statistics import mean
from uuid import uuid4

from flask import Flask, jsonify, request, send_file
from flask_cors import CORS
try:
    from fpdf import FPDF
except Exception:
    FPDF = None

app = Flask(__name__)
CORS(app)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
STORE_PATH = os.path.join(DATA_DIR, "store.json")
DATASET_PATH = os.path.join(BASE_DIR, "dataset", "students.csv")

model = None
scaler = None
model_info = {
    "model_name": "Rule-Based Fallback",
    "accuracy": 0.84,
    "features": ["StudyHours", "Attendance", "InternalMarks", "PreviousScore"],
    "all_models": {},
    "lr_accuracy": 0.84,
    "rf_accuracy": 0.82,
}
ML_READY = False

try:
    with open(os.path.join(BASE_DIR, "model.pkl"), "rb") as f:
        model = pickle.load(f)
    with open(os.path.join(BASE_DIR, "scaler.pkl"), "rb") as f:
        scaler = pickle.load(f)
    with open(os.path.join(BASE_DIR, "model_info.pkl"), "rb") as f:
        model_info = pickle.load(f)
    ML_READY = True
except Exception as exc:
    print(f"ML artifacts unavailable, using fallback predictor: {exc}")

print(f"Loaded: {model_info['model_name']} ({model_info['accuracy']:.2%})")

GMAIL_USER = os.getenv("GMAIL_USER", "")
GMAIL_PASSWORD = os.getenv("GMAIL_PASSWORD", "")
VALID_USERS = {"admin": "admin123", "faculty": "faculty123"}
TIMESTAMP_FMT = "%Y-%m-%d %H:%M:%S"


def now_str():
    return datetime.now().strftime(TIMESTAMP_FMT)


def new_id(prefix):
    return f"{prefix}_{uuid4().hex[:10]}"


def get_risk(attendance, internal_marks):
    if attendance < 60:
        return "High"
    if internal_marks < 50:
        return "Medium"
    return "Low"


def build_recommendation(risk_level):
    if risk_level == "High":
        return "Schedule parent call, attendance counselling, and weekly review."
    if risk_level == "Medium":
        return "Assign remedial classes and monitor internal marks this week."
    return "Student is stable. Continue regular mentoring and monthly review."


def fallback_predict(study_hours, attendance, internal_marks, previous_score):
    score = (
        0.15 * max(0, min(study_hours, 10)) * 10
        + 0.35 * attendance
        + 0.30 * internal_marks
        + 0.20 * previous_score
    )
    probability = max(0.05, min(0.99, score / 100))
    prediction = "Pass" if probability >= 0.55 else "Fail"
    return prediction, probability


def predict_payload(study_hours, attendance, internal_marks, previous_score):
    if ML_READY and model is not None and scaler is not None:
        try:
            scaled = scaler.transform([[study_hours, attendance, internal_marks, previous_score]])
            raw = model.predict(scaled)[0]
            prediction = "Pass" if raw == 1 else "Fail"
            probability = (
                float(model.predict_proba(scaled)[0][1])
                if hasattr(model, "predict_proba")
                else float(raw)
            )
        except Exception as exc:
            print(f"Model inference failed, using fallback predictor: {exc}")
            prediction, probability = fallback_predict(
                study_hours, attendance, internal_marks, previous_score
            )
    else:
        prediction, probability = fallback_predict(
            study_hours, attendance, internal_marks, previous_score
        )
    risk_level = get_risk(attendance, internal_marks)
    return {
        "prediction": prediction,
        "probability": round(probability, 4),
        "risk_level": risk_level,
        "model_used": model_info["model_name"],
        "recommendation": build_recommendation(risk_level),
    }


def normalize_student_payload(data):
    return {
        "name": str(data.get("name", "")).strip(),
        "department": str(data.get("department", "CSE")).strip() or "CSE",
        "semester": int(float(data.get("semester", 1) or 1)),
        "section": str(data.get("section", "A")).strip() or "A",
        "mentor": str(data.get("mentor", "Assigned Faculty")).strip() or "Assigned Faculty",
        "email": str(data.get("email", "")).strip(),
        "phone": str(data.get("phone", "")).strip(),
        "study_hours": float(data.get("study_hours", 0) or 0),
        "attendance": float(data.get("attendance", 0) or 0),
        "internal_marks": float(data.get("internal_marks", 0) or 0),
        "previous_score": float(data.get("previous_score", 0) or 0),
        "notes": str(data.get("notes", "")).strip(),
    }


def validate_student_payload(student):
    required = ["name", "study_hours", "attendance", "internal_marks", "previous_score"]
    missing = [field for field in required if student.get(field, "") == ""]
    if missing:
        return f"Missing required fields: {', '.join(missing)}"
    if not 0 <= student["attendance"] <= 100:
        return "Attendance must be between 0 and 100."
    if not 0 <= student["internal_marks"] <= 100:
        return "Internal marks must be between 0 and 100."
    if not 0 <= student["previous_score"] <= 100:
        return "Previous score must be between 0 and 100."
    return None


def normalize_intervention_payload(data):
    return {
        "student_id": str(data.get("student_id", "")).strip(),
        "student_name": str(data.get("student_name", "")).strip(),
        "title": str(data.get("title", "")).strip(),
        "type": str(data.get("type", "Mentoring")).strip() or "Mentoring",
        "priority": str(data.get("priority", "Medium")).strip() or "Medium",
        "assigned_to": str(data.get("assigned_to", "Faculty")).strip() or "Faculty",
        "due_date": str(data.get("due_date", "")).strip(),
        "status": str(data.get("status", "Pending")).strip() or "Pending",
        "notes": str(data.get("notes", "")).strip(),
    }


def validate_intervention_payload(item):
    required = ["student_id", "student_name", "title", "due_date"]
    missing = [field for field in required if not item.get(field)]
    if missing:
        return f"Missing required fields: {', '.join(missing)}"
    return None


def read_dataset_rows(limit=None):
    if not os.path.exists(DATASET_PATH):
        return []
    with open(DATASET_PATH, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    return rows[:limit] if limit else rows


def average(values):
    return round(mean(values), 2) if values else 0.0


def bucket_counts(values, bins, labels):
    counts = {label: 0 for label in labels}
    for value in values:
        for index in range(len(labels)):
            start = bins[index]
            end = bins[index + 1]
            is_last = index == len(labels) - 1
            if (start <= value < end) or (is_last and value == end):
                counts[labels[index]] += 1
                break
    return counts


def correlation(xs, ys):
    n = len(xs)
    if n == 0:
        return 0.0
    mean_x = sum(xs) / n
    mean_y = sum(ys) / n
    numerator = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    denom_x = math.sqrt(sum((x - mean_x) ** 2 for x in xs))
    denom_y = math.sqrt(sum((y - mean_y) ** 2 for y in ys))
    if denom_x == 0 or denom_y == 0:
        return 0.0
    return round(numerator / (denom_x * denom_y), 3)


def default_store():
    return {"students": [], "interventions": [], "reports": [], "activity": []}


def load_seed_students():
    if not os.path.exists(DATASET_PATH):
        return []

    rows = read_dataset_rows(limit=12)
    departments = ["CSE", "ECE", "IT", "MECH", "AIML"]
    mentors = ["Prof. Sharma", "Prof. Nair", "Prof. Reddy", "Prof. Iyer"]
    students = []

    for idx, row in enumerate(rows):
        study_hours = float(row["StudyHours"])
        attendance = float(row["Attendance"])
        internal_marks = float(row["InternalMarks"])
        previous_score = float(row["PreviousScore"])
        prediction = predict_payload(study_hours, attendance, internal_marks, previous_score)
        students.append(
            {
                "id": new_id("stu"),
                "name": f"Student {idx + 1}",
                "department": departments[idx % len(departments)],
                "semester": (idx % 8) + 1,
                "section": chr(65 + (idx % 3)),
                "mentor": mentors[idx % len(mentors)],
                "email": f"student{idx + 1}@college.edu",
                "phone": f"9876500{idx:03d}"[-10:],
                "study_hours": study_hours,
                "attendance": attendance,
                "internal_marks": internal_marks,
                "previous_score": previous_score,
                "notes": "Seeded sample student for demo.",
                "latest_prediction": prediction,
                "prediction_history": [
                    {"id": new_id("pred"), "created_at": now_str(), **prediction}
                ],
                "created_at": now_str(),
                "updated_at": now_str(),
            }
        )
    return students


def ensure_store():
    os.makedirs(DATA_DIR, exist_ok=True)
    if os.path.exists(STORE_PATH):
        return

    store = default_store()
    store["students"] = load_seed_students()
    store["activity"] = [
        {
            "id": new_id("act"),
            "type": "system",
            "message": "System initialized with sample student records.",
            "created_at": now_str(),
        }
    ]
    with open(STORE_PATH, "w", encoding="utf-8") as f:
        json.dump(store, f, indent=2)


def read_store():
    ensure_store()
    with open(STORE_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def write_store(store):
    with open(STORE_PATH, "w", encoding="utf-8") as f:
        json.dump(store, f, indent=2)


def add_activity(store, message, activity_type="activity"):
    store["activity"].insert(
        0,
        {
            "id": new_id("act"),
            "type": activity_type,
            "message": message,
            "created_at": now_str(),
        },
    )
    store["activity"] = store["activity"][:40]


def get_student_or_404(store, student_id):
    student = next((item for item in store["students"] if item["id"] == student_id), None)
    if student is None:
        return None, (jsonify({"error": "Student not found"}), 404)
    return student, None


def summarize_store(store):
    students = store["students"]
    interventions = store["interventions"]
    reports = store["reports"]

    total_students = len(students)
    high_risk = sum(
        1
        for student in students
        if student.get("latest_prediction", {}).get("risk_level") == "High"
    )
    medium_risk = sum(
        1
        for student in students
        if student.get("latest_prediction", {}).get("risk_level") == "Medium"
    )
    passed = sum(
        1
        for student in students
        if student.get("latest_prediction", {}).get("prediction") == "Pass"
    )
    failed = sum(
        1
        for student in students
        if student.get("latest_prediction", {}).get("prediction") == "Fail"
    )

    department_breakdown = {}
    for student in students:
        dept = student.get("department", "Unknown")
        department_breakdown[dept] = department_breakdown.get(dept, 0) + 1

    watchlist = sorted(
        [
            {
                "id": student["id"],
                "name": student["name"],
                "department": student["department"],
                "semester": student["semester"],
                "attendance": student["attendance"],
                "internal_marks": student["internal_marks"],
                "prediction": student.get("latest_prediction", {}).get("prediction", "-"),
                "risk_level": student.get("latest_prediction", {}).get("risk_level", "-"),
            }
            for student in students
        ],
        key=lambda item: (
            {"High": 0, "Medium": 1, "Low": 2}.get(item["risk_level"], 3),
            item["attendance"],
        ),
    )[:6]

    return {
        "total_students": total_students,
        "at_risk": high_risk + medium_risk,
        "high_risk": high_risk,
        "medium_risk": medium_risk,
        "passed": passed,
        "failed": failed,
        "pending_interventions": sum(
            1 for item in interventions if item.get("status") != "Completed"
        ),
        "reports_generated": len(reports),
        "department_breakdown": department_breakdown,
        "recent_activity": store["activity"][:8],
        "watchlist": watchlist,
    }


def dataset_analytics():
    rows = read_dataset_rows()
    total = len(rows)
    passed_rows = [row for row in rows if row["Result"] == "Pass"]
    failed_rows = [row for row in rows if row["Result"] == "Fail"]
    passed = len(passed_rows)
    failed = len(failed_rows)
    pass_rate = round((passed / total) * 100, 1) if total else 0

    study_values = [float(row["StudyHours"]) for row in rows]
    attendance_values = [float(row["Attendance"]) for row in rows]
    internal_values = [float(row["InternalMarks"]) for row in rows]
    previous_values = [float(row["PreviousScore"]) for row in rows]

    subject_avg = {
        "StudyHours": average(study_values),
        "Attendance": average(attendance_values),
        "InternalMarks": average(internal_values),
        "PreviousScore": average(previous_values),
    }

    subject_by_result = {
        "Pass": {
            "StudyHours": average([float(row["StudyHours"]) for row in passed_rows]),
            "Attendance": average([float(row["Attendance"]) for row in passed_rows]),
            "InternalMarks": average([float(row["InternalMarks"]) for row in passed_rows]),
            "PreviousScore": average([float(row["PreviousScore"]) for row in passed_rows]),
        },
        "Fail": {
            "StudyHours": average([float(row["StudyHours"]) for row in failed_rows]),
            "Attendance": average([float(row["Attendance"]) for row in failed_rows]),
            "InternalMarks": average([float(row["InternalMarks"]) for row in failed_rows]),
            "PreviousScore": average([float(row["PreviousScore"]) for row in failed_rows]),
        },
    }

    risk_dist = {"Low": 0, "Medium": 0, "High": 0}
    for row in rows:
        risk_dist[get_risk(float(row["Attendance"]), float(row["InternalMarks"]))] += 1

    attendance_counts = bucket_counts(
        attendance_values, [0, 50, 60, 75, 90, 101], ["<50%", "50-60%", "60-75%", "75-90%", "90%+"]
    )
    marks_counts = bucket_counts(
        internal_values, [0, 40, 50, 60, 75, 101], ["<40", "40-50", "50-60", "60-75", "75+"]
    )
    study_counts = bucket_counts(
        study_values, [0, 3, 5, 7, 9, 11], ["1-3h", "3-5h", "5-7h", "7-9h", "9-10h"]
    )

    top_performers = sorted(
        passed_rows,
        key=lambda row: (float(row["InternalMarks"]) * 0.5 + float(row["PreviousScore"]) * 0.5),
        reverse=True,
    )[:5]
    bottom_performers = sorted(
        failed_rows,
        key=lambda row: (float(row["InternalMarks"]) * 0.5 + float(row["PreviousScore"]) * 0.5),
    )[:5]

    result_nums = [1 if row["Result"] == "Pass" else 0 for row in rows]
    correlations = {
        "StudyHours": correlation(study_values, result_nums),
        "Attendance": correlation(attendance_values, result_nums),
        "InternalMarks": correlation(internal_values, result_nums),
        "PreviousScore": correlation(previous_values, result_nums),
    }

    return {
        "total": total,
        "passed": passed,
        "failed": failed,
        "pass_rate": pass_rate,
        "subject_avg": subject_avg,
        "subject_by_result": subject_by_result,
        "risk_distribution": risk_dist,
        "attendance_buckets": attendance_counts,
        "marks_distribution": marks_counts,
        "study_distribution": study_counts,
        "top_performers": [
            {
                "StudyHours": round(float(row["StudyHours"]), 1),
                "Attendance": round(float(row["Attendance"]), 1),
                "InternalMarks": round(float(row["InternalMarks"]), 1),
                "PreviousScore": round(float(row["PreviousScore"]), 1),
            }
            for row in top_performers
        ],
        "bottom_performers": [
            {
                "StudyHours": round(float(row["StudyHours"]), 1),
                "Attendance": round(float(row["Attendance"]), 1),
                "InternalMarks": round(float(row["InternalMarks"]), 1),
                "PreviousScore": round(float(row["PreviousScore"]), 1),
            }
            for row in bottom_performers
        ],
        "correlations": correlations,
        "model_accuracy": round(model_info["accuracy"] * 100, 2),
    }


if FPDF is not None:
    class PDF(FPDF):
        def header(self):
            self.set_fill_color(30, 64, 175)
            self.rect(0, 0, 210, 20, "F")
            self.set_font("Helvetica", "B", 13)
            self.set_text_color(255, 255, 255)
            self.set_xy(0, 4)
            self.cell(0, 12, "  EduPredict AI - Student Performance Report", align="L")
            self.ln(4)

        def footer(self):
            self.set_y(-11)
            self.set_font("Helvetica", "", 8)
            self.set_text_color(150, 150, 150)
            self.cell(0, 10, f"Page {self.page_no()} | EduPredict AI", align="C")
else:
    PDF = None


def create_pdf_bytes(results, summary):
    if FPDF is None:
        fallback = io.StringIO()
        fallback.write("EduPredict AI Report\n")
        fallback.write(f"Total: {len(results)}\n")
        fallback.write(f"Passed: {summary.get('pass', 0)}\n")
        fallback.write(f"Failed: {summary.get('fail', 0)}\n")
        fallback.write(f"High Risk: {summary.get('high_risk', 0)}\n\n")
        for index, result in enumerate(results, start=1):
            fallback.write(
                f"{index}. {result.get('name', '-')}, {result.get('prediction', '-')}, "
                f"{result.get('risk_level', '-')}, {result.get('attendance', '-')}%\n"
            )
        return fallback.getvalue().encode("utf-8")

    pdf = PDF()
    pdf.set_auto_page_break(True, 14)
    pdf.add_page()
    pdf.set_margins(12, 26, 12)
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(100, 116, 139)
    pdf.cell(
        0,
        7,
        f"Model: {model_info['model_name']} | Accuracy: {model_info['accuracy']:.1%} | Records: {len(results)}",
        new_x="LMARGIN",
        new_y="NEXT",
    )
    pdf.ln(2)

    boxes = [
        ("Total", len(results), (59, 130, 246)),
        ("Passed", summary.get("pass", 0), (16, 185, 129)),
        ("Failed", summary.get("fail", 0), (239, 68, 68)),
        ("High Risk", summary.get("high_risk", 0), (245, 158, 11)),
    ]
    box_width = 44
    for _, value, color in boxes:
        pdf.set_fill_color(*color)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font("Helvetica", "B", 18)
        pdf.cell(box_width, 11, str(value), align="C", fill=True)
    pdf.ln(11)
    for label, *_ in boxes:
        pdf.set_font("Helvetica", "", 8)
        pdf.set_text_color(100, 116, 139)
        pdf.cell(box_width, 5, label, align="C")
    pdf.ln(9)

    headers = ["#", "Name", "Hrs", "Attend", "Internal", "Prev", "Result", "Conf", "Risk"]
    widths = [8, 40, 16, 20, 18, 18, 18, 18, 18]
    pdf.set_fill_color(30, 64, 175)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Helvetica", "B", 8)
    for header, width in zip(headers, widths):
        pdf.cell(width, 7, header, align="C", fill=True)
    pdf.ln()

    for index, result in enumerate(results):
        bg = (245, 247, 250) if index % 2 == 0 else (255, 255, 255)
        pdf.set_fill_color(*bg)
        pdf.set_text_color(30, 41, 59)
        pdf.set_font("Helvetica", "", 8)
        values = [
            str(result.get("row", index + 1)),
            str(result.get("name", "-"))[:18],
            str(result.get("study_hours", "-")),
            f"{result.get('attendance', '-')}%",
            str(result.get("internal_marks", "-")),
            str(result.get("previous_score", "-")),
            result.get("prediction", "-"),
            f"{round(result.get('probability', 0) * 100)}%",
            result.get("risk_level", "-"),
        ]
        for value, width in zip(values, widths):
            pdf.cell(width, 6, str(value), align="C", fill=True)
        pdf.ln()

    return bytes(pdf.output(dest="S"))


@app.route("/login", methods=["POST"])
def login():
    data = request.get_json(force=True)
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()
    if VALID_USERS.get(username) == password:
        return jsonify(
            {
                "success": True,
                "token": f"token_{username}_{datetime.now().year}",
                "username": username,
            }
        )
    return jsonify({"success": False, "message": "Invalid credentials"}), 401


@app.route("/health", methods=["GET"])
def health():
    return jsonify(
        {
            "status": "ok",
            "model": model_info["model_name"],
            "accuracy": round(model_info["accuracy"] * 100, 2),
            "lr_accuracy": round(model_info.get("lr_accuracy", 0) * 100, 2),
            "rf_accuracy": round(model_info.get("rf_accuracy", 0) * 100, 2),
        }
    )


@app.route("/model-info", methods=["GET"])
def get_model_info():
    return jsonify(
        {
            "model_name": model_info["model_name"],
            "features": model_info["features"],
            "best_accuracy": round(model_info["accuracy"] * 100, 2),
            "lr_accuracy": round(model_info.get("lr_accuracy", 0) * 100, 2),
            "rf_accuracy": round(model_info.get("rf_accuracy", 0) * 100, 2),
            "all_models": {
                key: round(value * 100, 2)
                for key, value in model_info.get("all_models", {}).items()
            },
        }
    )


@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json(force=True)
    try:
        result = predict_payload(
            float(data["study_hours"]),
            float(data["attendance"]),
            float(data["internal_marks"]),
            float(data["previous_score"]),
        )
        return jsonify(result)
    except KeyError as exc:
        return jsonify({"error": f"Missing: {exc.args[0]}"}), 400
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/predict-batch", methods=["POST"])
def predict_batch():
    if "file" not in request.files:
        return jsonify({"error": "No file. Send CSV as form-data field 'file'"}), 400

    try:
        raw = request.files["file"].read().decode("utf-8")
        rows = list(csv.DictReader(io.StringIO(raw)))
    except Exception:
        return jsonify({"error": "Cannot parse CSV"}), 400

    if not rows:
        return jsonify({"error": "CSV is empty"}), 400

    column_map = {column.lower(): column for column in rows[0].keys()}
    aliases = {
        "study_hours": ["studyhours", "study_hours"],
        "attendance": ["attendance", "attend"],
        "internal_marks": ["internalmarks", "internal_marks", "internal"],
        "previous_score": ["previousscore", "previous_score", "prevscore"],
    }
    resolved = {}
    for key, values in aliases.items():
        match = next((column_map[name] for name in values if name in column_map), None)
        if not match:
            return jsonify({"error": f"Missing column: {key}"}), 400
        resolved[key] = match

    results = []
    for idx, row in enumerate(rows):
        try:
            result = predict_payload(
                float(row[resolved["study_hours"]]),
                float(row[resolved["attendance"]]),
                float(row[resolved["internal_marks"]]),
                float(row[resolved["previous_score"]]),
            )
            result.update(
                {
                    "row": idx + 1,
                    "id": new_id("batch"),
                    "name": str(row.get("Name", row.get("name", f"Student {idx + 1}"))),
                    "study_hours": float(row[resolved["study_hours"]]),
                    "attendance": float(row[resolved["attendance"]]),
                    "internal_marks": float(row[resolved["internal_marks"]]),
                    "previous_score": float(row[resolved["previous_score"]]),
                    "time": datetime.now().strftime("%I:%M:%S %p"),
                }
            )
            results.append(result)
        except Exception as exc:
            results.append({"row": idx + 1, "error": str(exc)})

    summary = {
        "total": len(results),
        "pass": sum(1 for item in results if item.get("prediction") == "Pass"),
        "fail": sum(1 for item in results if item.get("prediction") == "Fail"),
        "high_risk": sum(1 for item in results if item.get("risk_level") == "High"),
    }
    return jsonify({"results": results, "summary": summary})


@app.route("/dashboard-summary", methods=["GET"])
def dashboard_summary():
    return jsonify(summarize_store(read_store()))


@app.route("/students", methods=["GET"])
def get_students():
    store = read_store()
    return jsonify({"students": store["students"]})


@app.route("/students", methods=["POST"])
def create_student():
    store = read_store()
    student = normalize_student_payload(request.get_json(force=True))
    error = validate_student_payload(student)
    if error:
        return jsonify({"error": error}), 400

    prediction = predict_payload(
        student["study_hours"],
        student["attendance"],
        student["internal_marks"],
        student["previous_score"],
    )
    record = {
        "id": new_id("stu"),
        **student,
        "latest_prediction": prediction,
        "prediction_history": [{"id": new_id("pred"), "created_at": now_str(), **prediction}],
        "created_at": now_str(),
        "updated_at": now_str(),
    }
    store["students"].insert(0, record)
    add_activity(store, f"Student record created for {record['name']}.", "student")
    write_store(store)
    return jsonify({"success": True, "student": record}), 201


@app.route("/students/<student_id>", methods=["PUT"])
def update_student(student_id):
    store = read_store()
    student, error_response = get_student_or_404(store, student_id)
    if error_response:
        return error_response

    payload = normalize_student_payload(request.get_json(force=True))
    error = validate_student_payload(payload)
    if error:
        return jsonify({"error": error}), 400

    prediction = predict_payload(
        payload["study_hours"],
        payload["attendance"],
        payload["internal_marks"],
        payload["previous_score"],
    )
    student.update(payload)
    student["latest_prediction"] = prediction
    student.setdefault("prediction_history", []).insert(
        0, {"id": new_id("pred"), "created_at": now_str(), **prediction}
    )
    student["prediction_history"] = student["prediction_history"][:12]
    student["updated_at"] = now_str()
    add_activity(store, f"Student record updated for {student['name']}.", "student")
    write_store(store)
    return jsonify({"success": True, "student": student})


@app.route("/students/<student_id>", methods=["DELETE"])
def delete_student(student_id):
    store = read_store()
    student, error_response = get_student_or_404(store, student_id)
    if error_response:
        return error_response

    store["students"] = [item for item in store["students"] if item["id"] != student_id]
    store["interventions"] = [
        item for item in store["interventions"] if item["student_id"] != student_id
    ]
    add_activity(store, f"Student record deleted for {student['name']}.", "student")
    write_store(store)
    return jsonify({"success": True})


@app.route("/students/<student_id>/predict", methods=["POST"])
def predict_student(student_id):
    store = read_store()
    student, error_response = get_student_or_404(store, student_id)
    if error_response:
        return error_response

    prediction = predict_payload(
        float(student["study_hours"]),
        float(student["attendance"]),
        float(student["internal_marks"]),
        float(student["previous_score"]),
    )
    student["latest_prediction"] = prediction
    student.setdefault("prediction_history", []).insert(
        0, {"id": new_id("pred"), "created_at": now_str(), **prediction}
    )
    student["prediction_history"] = student["prediction_history"][:12]
    student["updated_at"] = now_str()
    add_activity(store, f"Prediction refreshed for {student['name']}.", "prediction")
    write_store(store)
    return jsonify({"success": True, "student": student, "result": prediction})


@app.route("/interventions", methods=["GET"])
def get_interventions():
    store = read_store()
    return jsonify({"interventions": store["interventions"]})


@app.route("/interventions", methods=["POST"])
def create_intervention():
    store = read_store()
    item = normalize_intervention_payload(request.get_json(force=True))
    error = validate_intervention_payload(item)
    if error:
        return jsonify({"error": error}), 400

    record = {
        "id": new_id("int"),
        **item,
        "created_at": now_str(),
        "updated_at": now_str(),
    }
    store["interventions"].insert(0, record)
    add_activity(
        store,
        f"Intervention '{record['title']}' assigned to {record['student_name']}.",
        "intervention",
    )
    write_store(store)
    return jsonify({"success": True, "intervention": record}), 201


@app.route("/interventions/<intervention_id>", methods=["PUT"])
def update_intervention(intervention_id):
    store = read_store()
    intervention = next(
        (item for item in store["interventions"] if item["id"] == intervention_id), None
    )
    if intervention is None:
        return jsonify({"error": "Intervention not found"}), 404

    payload = normalize_intervention_payload(request.get_json(force=True))
    error = validate_intervention_payload(payload)
    if error:
        return jsonify({"error": error}), 400

    intervention.update(payload)
    intervention["updated_at"] = now_str()
    add_activity(
        store,
        f"Intervention '{intervention['title']}' updated for {intervention['student_name']}.",
        "intervention",
    )
    write_store(store)
    return jsonify({"success": True, "intervention": intervention})


@app.route("/interventions/<intervention_id>", methods=["DELETE"])
def delete_intervention(intervention_id):
    store = read_store()
    intervention = next(
        (item for item in store["interventions"] if item["id"] == intervention_id), None
    )
    if intervention is None:
        return jsonify({"error": "Intervention not found"}), 404

    store["interventions"] = [
        item for item in store["interventions"] if item["id"] != intervention_id
    ]
    add_activity(
        store,
        f"Intervention '{intervention['title']}' removed for {intervention['student_name']}.",
        "intervention",
    )
    write_store(store)
    return jsonify({"success": True})


@app.route("/reports", methods=["GET"])
def get_reports():
    store = read_store()
    return jsonify({"reports": store["reports"]})


@app.route("/reports/generate", methods=["POST"])
def generate_report():
    store = read_store()
    request_payload = request.get_json(silent=True) or {}
    summary = summarize_store(store)
    report = {
        "id": new_id("rep"),
        "title": request_payload.get("title", f"Academic Summary {now_str()}"),
        "created_at": now_str(),
        "total_students": summary["total_students"],
        "at_risk": summary["at_risk"],
        "pending_interventions": summary["pending_interventions"],
        "high_risk": summary["high_risk"],
        "pass_rate": round(
            (summary["passed"] / summary["total_students"]) * 100
            if summary["total_students"]
            else 0,
            1,
        ),
        "top_department": (
            max(summary["department_breakdown"], key=summary["department_breakdown"].get)
            if summary["department_breakdown"]
            else "N/A"
        ),
    }
    store["reports"].insert(0, report)
    add_activity(store, f"Report generated: {report['title']}.", "report")
    write_store(store)
    return jsonify({"success": True, "report": report})


@app.route("/activity", methods=["GET"])
def get_activity():
    store = read_store()
    return jsonify({"activity": store["activity"]})


@app.route("/export-csv", methods=["POST"])
def export_csv():
    results = request.get_json(force=True).get("results", [])
    if not results:
        return jsonify({"error": "No results"}), 400

    output = io.StringIO()
    writer = csv.DictWriter(
        output,
        fieldnames=[
            "name",
            "department",
            "semester",
            "study_hours",
            "attendance",
            "internal_marks",
            "previous_score",
            "prediction",
            "probability",
            "risk_level",
        ],
        extrasaction="ignore",
    )
    writer.writeheader()
    writer.writerows(results)
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode()),
        mimetype="text/csv",
        as_attachment=True,
        download_name="student_predictions.csv",
    )


@app.route("/export-pdf", methods=["POST"])
def export_pdf():
    payload = request.get_json(force=True)
    results = payload.get("results", [])
    summary = payload.get("summary", {})
    if not results:
        return jsonify({"error": "No results"}), 400

    pdf_bytes = create_pdf_bytes(results, summary)
    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype="application/pdf" if FPDF is not None else "text/plain",
        as_attachment=True,
        download_name="student_performance_report.pdf",
    )


@app.route("/send-alert", methods=["POST"])
def send_alert():
    data = request.get_json(force=True)
    to_email = data.get("to", "")
    students = data.get("students", [])
    if not to_email:
        return jsonify({"error": "Recipient email required"}), 400
    if not students:
        return jsonify({"error": "No students"}), 400

    rows = "".join(
        (
            "<tr>"
            f"<td style='padding:9px;border-bottom:1px solid #e2e8f0'>{item.get('name', '-')}</td>"
            f"<td style='padding:9px;border-bottom:1px solid #e2e8f0;color:#dc2626;font-weight:bold'>{item.get('risk_level', '-')}</td>"
            f"<td style='padding:9px;border-bottom:1px solid #e2e8f0'>{item.get('attendance', '-')}%</td>"
            f"<td style='padding:9px;border-bottom:1px solid #e2e8f0'>{item.get('internal_marks', '-')}</td>"
            f"<td style='padding:9px;border-bottom:1px solid #e2e8f0;color:{'#059669' if item.get('prediction') == 'Pass' else '#dc2626'};font-weight:bold'>{item.get('prediction', '-')}</td>"
            "</tr>"
        )
        for item in students
    )

    html = f"""
    <html>
      <body style="font-family:Arial,sans-serif;max-width:680px;margin:0 auto;padding:20px">
        <div style="background:#1e40af;color:white;padding:20px;border-radius:10px 10px 0 0">
          <h2 style="margin:0">EduPredict Early Warning</h2>
        </div>
        <div style="background:#f8fafc;padding:20px;border:1px solid #e2e8f0">
          <p>Dear Faculty, <strong>{len(students)}</strong> student(s) were flagged as at-risk.</p>
          <table width="100%" style="border-collapse:collapse;background:white;border:1px solid #e2e8f0">
            <thead>
              <tr style="background:#1e40af;color:white">
                <th style="padding:10px;text-align:left">Name</th>
                <th style="padding:10px;text-align:left">Risk</th>
                <th style="padding:10px;text-align:left">Attendance</th>
                <th style="padding:10px;text-align:left">Internal</th>
                <th style="padding:10px;text-align:left">Prediction</th>
              </tr>
            </thead>
            <tbody>{rows}</tbody>
          </table>
        </div>
      </body>
    </html>
    """

    if GMAIL_USER and GMAIL_PASSWORD:
        try:
            message = MIMEMultipart("alternative")
            message["Subject"] = f"EduPredict: {len(students)} At-Risk Student(s)"
            message["From"] = GMAIL_USER
            message["To"] = to_email
            message.attach(MIMEText(html, "html"))
            with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
                server.login(GMAIL_USER, GMAIL_PASSWORD)
                server.sendmail(GMAIL_USER, to_email, message.as_string())
            return jsonify({"success": True, "message": f"Alert sent to {to_email}"})
        except Exception as exc:
            return jsonify({"success": False, "error": str(exc)}), 500

    return jsonify(
        {
            "success": True,
            "simulated": True,
            "message": f"[SIMULATED] Alert for {len(students)} student(s) to {to_email}.",
        }
    )


@app.route("/analytics", methods=["GET"])
def analytics():
    try:
        payload = dataset_analytics()
        payload["dashboard"] = summarize_store(read_store())
        return jsonify(payload)
    except Exception as exc:
        print("ERROR:", exc)
        return jsonify({"error": str(exc)}), 500


if __name__ == "__main__":
    ensure_store()
    app.run(debug=True, port=5000)
