// src/services/api.js
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000'
});

api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('sp_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

export const login       = (u, p)   => api.post('/login',         { username:u, password:p }).then(r=>r.data);
export const getHealth   = ()       => api.get('/health').then(r=>r.data);
export const getModelInfo= ()       => api.get('/model-info').then(r=>r.data);
export const predictOne  = (data)   => api.post('/predict',       data).then(r=>r.data);
export const sendAlert   = (to, st) => api.post('/send-alert',    { to, students:st }).then(r=>r.data);
export const getDashboardSummary = () => api.get('/dashboard-summary').then(r=>r.data);
export const getStudents = () => api.get('/students').then(r=>r.data);
export const createStudent = (data) => api.post('/students', data).then(r=>r.data);
export const updateStudent = (id, data) => api.put(`/students/${id}`, data).then(r=>r.data);
export const deleteStudent = (id) => api.delete(`/students/${id}`).then(r=>r.data);
export const predictStudent = (id) => api.post(`/students/${id}/predict`).then(r=>r.data);
export const getInterventions = () => api.get('/interventions').then(r=>r.data);
export const createIntervention = (data) => api.post('/interventions', data).then(r=>r.data);
export const updateIntervention = (id, data) => api.put(`/interventions/${id}`, data).then(r=>r.data);
export const deleteIntervention = (id) => api.delete(`/interventions/${id}`).then(r=>r.data);
export const getReports = () => api.get('/reports').then(r=>r.data);
export const generateReport = (title) => api.post('/reports/generate', { title }).then(r=>r.data);
export const getActivity = () => api.get('/activity').then(r=>r.data);

export const predictBatch = (file) => {
  const form = new FormData();
  form.append('file', file);
  return api.post('/predict-batch', form, {
    headers: { 'Content-Type':'multipart/form-data' }
  }).then(r => r.data);
};

export const exportCSV = (results) =>
  api.post('/export-csv', { results }, { responseType:'blob' }).then(r => {
    const url  = window.URL.createObjectURL(new Blob([r.data]));
    const link = document.createElement('a');
    link.href = url; link.download = 'student_predictions.csv';
    link.click(); window.URL.revokeObjectURL(url);
  });

export const exportPDF = (results, summary) =>
  api.post('/export-pdf', { results, summary }, { responseType:'blob' }).then(r => {
    const url  = window.URL.createObjectURL(new Blob([r.data], { type:'application/pdf' }));
    const link = document.createElement('a');
    link.href = url; link.download = 'student_performance_report.pdf';
    link.click(); window.URL.revokeObjectURL(url);
  });

export const getAnalytics = () => api.get('/analytics').then(r => r.data);
