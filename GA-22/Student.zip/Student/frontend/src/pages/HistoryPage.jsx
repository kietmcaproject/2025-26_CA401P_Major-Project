// src/pages/HistoryPage.jsx — Full prediction history with charts + Pass/Fail name lists
import React, { useMemo, useRef, useEffect } from 'react';
import { exportCSV } from '../services/api';
import { useToast }  from '../services/toast';
import { Chart, ArcElement, DoughnutController, BarElement, BarController,
         CategoryScale, LinearScale, Tooltip, Legend } from 'chart.js';
Chart.register(ArcElement, DoughnutController, BarElement, BarController,
               CategoryScale, LinearScale, Tooltip, Legend);

function PieChart({ pass, fail }) {
  const ref = useRef(); const chart = useRef();
  useEffect(()=>{
    if (!ref.current) return; chart.current?.destroy();
    chart.current = new Chart(ref.current,{
      type:'doughnut',
      data:{ labels:['Pass','Fail'],
             datasets:[{data:[pass,fail],backgroundColor:['#10b981','#ef4444'],borderWidth:0}]},
      options:{ cutout:'65%', plugins:{legend:{position:'bottom',labels:{color:'#94a3b8',font:{size:12}}}} }
    });
    return ()=>chart.current?.destroy();
  },[pass,fail]);
  return <canvas ref={ref}/>;
}

function RiskBar({ low, medium, high }) {
  const ref = useRef(); const chart = useRef();
  useEffect(()=>{
    if (!ref.current) return; chart.current?.destroy();
    chart.current = new Chart(ref.current,{
      type:'bar',
      data:{ labels:['Low','Medium','High'],
             datasets:[{data:[low,medium,high],
               backgroundColor:['rgba(16,185,129,.7)','rgba(245,158,11,.7)','rgba(239,68,68,.7)'],
               borderRadius:8, borderSkipped:false}]},
      options:{ responsive:true, maintainAspectRatio:false,
        plugins:{legend:{display:false}},
        scales:{x:{ticks:{color:'#64748b'},grid:{display:false}},
                y:{ticks:{color:'#64748b',stepSize:1},grid:{color:'rgba(255,255,255,.04)'}}} }
    });
    return ()=>chart.current?.destroy();
  },[low,medium,high]);
  return <canvas ref={ref}/>;
}

/* ── Small chip for a student name ── */
function NameTag({ name, confidence, risk, isPass }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:'.6rem',
      padding:'.55rem .85rem', borderRadius:8,
      background: isPass ? 'rgba(16,185,129,.1)' : 'rgba(239,68,68,.1)',
      border: `1px solid ${isPass ? 'rgba(16,185,129,.25)' : 'rgba(239,68,68,.25)'}`,
      marginBottom:'.45rem'
    }}>
      <span style={{fontSize:'1rem'}}>{isPass ? '' : ''}</span>
      <span style={{flex:1, fontWeight:600, fontSize:'.88rem', color:'var(--text)',
                    whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>
        {name}
      </span>
      <span style={{fontSize:'.75rem', color:'var(--muted)', whiteSpace:'nowrap'}}>
        {confidence}% conf
      </span>
      <span style={{
        fontSize:'.7rem', fontWeight:700, padding:'.18rem .5rem', borderRadius:20,
        background: risk==='High'?'rgba(239,68,68,.2)': risk==='Medium'?'rgba(245,158,11,.2)':'rgba(16,185,129,.2)',
        color:      risk==='High'?'#ef4444':            risk==='Medium'?'#f59e0b':           '#10b981'
      }}>
        {risk}
      </span>
    </div>
  );
}

export default function HistoryPage({ history }) {
  const toast = useToast();

  const stats = useMemo(()=>({
    total:  history.length,
    pass:   history.filter(h=>h.prediction==='Pass').length,
    fail:   history.filter(h=>h.prediction==='Fail').length,
    low:    history.filter(h=>h.risk_level==='Low').length,
    medium: history.filter(h=>h.risk_level==='Medium').length,
    high:   history.filter(h=>h.risk_level==='High').length,
    avgConf: history.length
      ? Math.round(history.reduce((s,h)=>s+h.probability,0)/history.length*100)
      : 0,
  }),[history]);

  const passStudents = useMemo(()=>history.filter(h=>h.prediction==='Pass'),[history]);
  const failStudents = useMemo(()=>history.filter(h=>h.prediction==='Fail'),[history]);

  async function handleExport() {
    if (!history.length) { toast('No history to export','error'); return; }
    try { await exportCSV(history); toast('CSV downloaded!','success'); }
    catch { toast('Export failed','error'); }
  }

  if (history.length === 0) return (
    <div>
      <h1 className="page-title"> Prediction History</h1>
      <p className="page-sub">All predictions made in this session appear here.</p>
      <div className="card">
        <div className="history-empty">
          <div className="icon">📋</div>
          <p>No predictions yet.<br/>Use <strong>Single Predict</strong> or <strong>Batch Predict</strong> to get started.</p>
        </div>
      </div>
    </div>
  );

  return (
    <div>
      <h1 className="page-title">📊 Prediction History</h1>
      <p className="page-sub">{stats.total} predictions made this session.</p>

      {/* ── Stats ── */}
      <div className="grid-3" style={{marginBottom:'1.5rem'}}>
        <div className="stat-card blue"><div className="stat-num">{stats.total}</div><div className="stat-lbl">Total Predictions</div></div>
        <div className="stat-card green"><div className="stat-num">{stats.pass}</div><div className="stat-lbl">Passed</div></div>
        <div className="stat-card red"><div className="stat-num">{stats.fail}</div><div className="stat-lbl">Failed</div></div>
      </div>

      {/* ── Charts ── */}
      <div className="grid-2" style={{marginBottom:'1.5rem'}}>
        <div className="card">
          <div className="card-title">🎯 Pass vs Fail</div>
          <div style={{height:200}}><PieChart pass={stats.pass} fail={stats.fail}/></div>
        </div>
        <div className="card">
          <div className="card-title">⚠️ Risk Distribution</div>
          <div style={{height:200}}><RiskBar low={stats.low} medium={stats.medium} high={stats.high}/></div>
        </div>
      </div>

      {/* ── Pass / Fail student name lists ── */}
      <div className="grid-2" style={{marginBottom:'1.5rem'}}>

        {/* Passed */}
        <div className="card" style={{padding:'1.25rem'}}>
          <div className="card-title" style={{marginBottom:'1rem'}}>
            <span style={{color:'#10b981'}}>✅</span>&nbsp;Students Who Passed
            <span style={{
              marginLeft:'auto', fontSize:'.75rem', fontWeight:700,
              background:'rgba(16,185,129,.15)', color:'#10b981',
              padding:'.2rem .6rem', borderRadius:20
            }}>{passStudents.length}</span>
          </div>
          {passStudents.length === 0 ? (
            <div style={{color:'var(--muted)',fontSize:'.85rem',textAlign:'center',padding:'1rem 0'}}>
              No passing students yet
            </div>
          ) : (
            <div style={{maxHeight:260, overflowY:'auto', paddingRight:4}}>
              {passStudents.map(h=>(
                <NameTag key={h.id} name={h.name||'Unknown'} isPass={true}
                  confidence={Math.round(h.probability*100)} risk={h.risk_level}/>
              ))}
            </div>
          )}
        </div>

        {/* Failed */}
        <div className="card" style={{padding:'1.25rem'}}>
          <div className="card-title" style={{marginBottom:'1rem'}}>
            <span style={{color:'#ef4444'}}>❌</span>&nbsp;Students Who Failed
            <span style={{
              marginLeft:'auto', fontSize:'.75rem', fontWeight:700,
              background:'rgba(239,68,68,.15)', color:'#ef4444',
              padding:'.2rem .6rem', borderRadius:20
            }}>{failStudents.length}</span>
          </div>
          {failStudents.length === 0 ? (
            <div style={{color:'var(--muted)',fontSize:'.85rem',textAlign:'center',padding:'1rem 0'}}>
              No failing students yet
            </div>
          ) : (
            <div style={{maxHeight:260, overflowY:'auto', paddingRight:4}}>
              {failStudents.map(h=>(
                <NameTag key={h.id} name={h.name||'Unknown'} isPass={false}
                  confidence={Math.round(h.probability*100)} risk={h.risk_level}/>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* ── Full table ── */}
      <div className="card">
        <div className="card-title" style={{justifyContent:'space-between'}}>
          📋 All Records
          <button className="btn-secondary" onClick={handleExport} style={{fontFamily:'DM Sans'}}>
            📥 Export CSV
          </button>
        </div>
        <div className="table-wrap">
          <table className="hist-table">
            <thead>
              <tr>
                <th>Time</th><th>Name</th><th>Study Hrs</th>
                <th>Attendance</th><th>Internal</th><th>Prev Score</th>
                <th>Result</th><th>Confidence</th><th>Risk</th>
              </tr>
            </thead>
            <tbody>
              {history.map(h=>(
                <tr key={h.id}>
                  <td style={{color:'var(--muted)',whiteSpace:'nowrap'}}>{h.time}</td>
                  <td style={{fontWeight:600}}>{h.name || '—'}</td>
                  <td>{h.study_hours}h</td>
                  <td>{h.attendance}%</td>
                  <td>{h.internal_marks}</td>
                  <td>{h.previous_score}</td>
                  <td><span className={`tag ${h.prediction}`}>{h.prediction}</span></td>
                  <td>{Math.round(h.probability*100)}%</td>
                  <td><span className={`tag ${h.risk_level}`}>{h.risk_level}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
