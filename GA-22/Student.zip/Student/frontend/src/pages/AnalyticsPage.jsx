// src/pages/AnalyticsPage.jsx  —  FIXED v3
import React, { useEffect, useState, useRef } from 'react';
import { getAnalytics } from '../services/api';
import { useToast } from '../services/toast';
import {
  Chart, ArcElement, DoughnutController,
  BarElement, BarController,
  RadarController, RadialLinearScale,
  CategoryScale, LinearScale, PointElement, LineElement,
  Tooltip, Legend, Filler,
} from 'chart.js';

Chart.register(
  ArcElement, DoughnutController, BarElement, BarController,
  RadarController, RadialLinearScale,
  CategoryScale, LinearScale, PointElement, LineElement,
  Tooltip, Legend, Filler
);

const TICK = { color: '#64748b', font: { size: 11 } };
const GRID = { color: 'rgba(255,255,255,.04)' };
const C = {
  green:'rgba(16,185,129,.8)',  red:  'rgba(239,68,68,.8)',
  blue: 'rgba(59,130,246,.8)', cyan: 'rgba(6,182,212,.8)',
  amber:'rgba(245,158,11,.8)', purple:'rgba(139,92,246,.8)',
  greenL:'rgba(16,185,129,.15)', redL:'rgba(239,68,68,.15)',
};

function mk(ref, config) {
  if (!ref.current) return;
  const old = Chart.getChart(ref.current);
  if (old) old.destroy();
  new Chart(ref.current, config);
}

function StatCard({ icon, label, value, sub, color }) {
  return (
    <div className="stat-card" style={{ borderTop:`3px solid ${color}` }}>
      <div style={{ fontSize:'1.5rem', marginBottom:'.35rem' }}>{icon}</div>
      <div className="stat-num" style={{ color }}>{value}</div>
      <div className="stat-lbl">{label}</div>
      {sub && <div style={{ fontSize:'.72rem', color:'var(--muted)', marginTop:'.2rem' }}>{sub}</div>}
    </div>
  );
}
function CC({ title, height, children }) {
  return (
    <div className="card animate-up" style={{ padding:'1.5rem' }}>
      <div className="card-title" style={{ marginBottom:'1rem' }}>{title}</div>
      <div style={{ height:height||220, position:'relative' }}>{children}</div>
    </div>
  );
}
function Sk({ h }) {
  return <div style={{ height:h||220, borderRadius:10, background:'var(--surface)',
    border:'1px solid var(--border)', animation:'skp 1.4s ease-in-out infinite' }}/>;
}

export default function AnalyticsPage() {
  const toast = useToast();
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [err,     setErr]     = useState(false);

  const r1=useRef(null), r2=useRef(null), r3=useRef(null), r4=useRef(null);
  const r5=useRef(null), r6=useRef(null), r7=useRef(null), r8=useRef(null);

  useEffect(() => {
    getAnalytics()
      .then(d => { setData(d); setLoading(false); })
      .catch(() => { setErr(true); setLoading(false);
                     toast('Cannot load analytics. Is Flask running?','error'); });
  }, []); // eslint-disable-line

  // ALL chart building — only runs when data is truthy, never sees null
  useEffect(() => {
    if (!data) return;
    const P = data.subject_by_result.Pass;
    const F = data.subject_by_result.Fail;

    mk(r1, {
      type:'doughnut',
      data:{ labels:['Pass','Fail'],
        datasets:[{ data:[data.passed, data.failed],
          backgroundColor:[C.green, C.red], borderWidth:0 }] },
      options:{ cutout:'70%', animation:{duration:900},
        plugins:{ legend:{ position:'bottom', labels:{ color:'#94a3b8', font:{size:12}, padding:16 } } } },
    });

    mk(r2, { type:'bar',
      data:{ labels:['Low','Medium','High'],
        datasets:[{ data:[data.risk_distribution.Low||0, data.risk_distribution.Medium||0, data.risk_distribution.High||0],
          backgroundColor:[C.green,C.amber,C.red], borderRadius:8, borderSkipped:false }] },
      options:{ responsive:true, maintainAspectRatio:false,
        plugins:{legend:{display:false}},
        scales:{ x:{ticks:TICK,grid:{display:false}}, y:{ticks:TICK,grid:GRID} } }
    });

    const aL=['<50%','50-60%','60-75%','75-90%','90%+'];
    mk(r3, { type:'bar',
      data:{ labels:aL, datasets:[{ data:aL.map(l=>data.attendance_buckets[l]||0),
        backgroundColor:[C.red,C.amber,C.cyan,C.blue,C.green], borderRadius:6, borderSkipped:false }] },
      options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}},
        scales:{ x:{ticks:TICK,grid:{display:false}}, y:{ticks:TICK,grid:GRID} } }
    });

    const mL=['<40','40-50','50-60','60-75','75+'];
    mk(r4, { type:'bar',
      data:{ labels:mL, datasets:[{ data:mL.map(l=>data.marks_distribution[l]||0),
        backgroundColor:[C.red,C.amber,C.cyan,C.blue,C.green], borderRadius:6, borderSkipped:false }] },
      options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}},
        scales:{ x:{ticks:TICK,grid:{display:false}}, y:{ticks:TICK,grid:GRID} } }
    });

    const sL=['1-3h','3-5h','5-7h','7-9h','9-10h'];
    mk(r5, { type:'bar',
      data:{ labels:sL, datasets:[{ data:sL.map(l=>data.study_distribution[l]||0),
        backgroundColor:C.purple, borderRadius:6, borderSkipped:false }] },
      options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}},
        scales:{ x:{ticks:TICK,grid:{display:false}}, y:{ticks:TICK,grid:GRID} } }
    });

    mk(r6, { type:'bar',
      data:{ labels:['Study Hrs','Attendance','Internal','Prev Score'],
        datasets:[
          { label:'Pass', data:[P.StudyHours,P.Attendance,P.InternalMarks,P.PreviousScore],
            backgroundColor:C.green, borderRadius:6, borderSkipped:false },
          { label:'Fail', data:[F.StudyHours,F.Attendance,F.InternalMarks,F.PreviousScore],
            backgroundColor:C.red,   borderRadius:6, borderSkipped:false },
        ] },
      options:{ responsive:true, maintainAspectRatio:false,
        plugins:{ legend:{ position:'top', labels:{ color:'#94a3b8', font:{size:11} } } },
        scales:{ x:{ticks:TICK,grid:{display:false}}, y:{ticks:TICK,grid:GRID} } }
    });

    const cv=[data.correlations.StudyHours, data.correlations.Attendance,
              data.correlations.InternalMarks, data.correlations.PreviousScore];
    mk(r7, { type:'bar',
      data:{ labels:['Study Hours','Attendance','Internal Marks','Prev Score'],
        datasets:[{ data:cv, backgroundColor:cv.map(v=>v>=0?C.blue:C.red),
          borderRadius:6, borderSkipped:false }] },
      options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false,
        plugins:{ legend:{display:false}, tooltip:{callbacks:{label:c=>` r = ${c.raw}`}} },
        scales:{ x:{min:-0.2,max:1,ticks:TICK,grid:GRID}, y:{ticks:TICK,grid:{display:false}} } }
    });

    mk(r8, { type:'radar',
      data:{ labels:['Study ×10','Attendance','Internal','Prev Score'],
        datasets:[
          { label:'Pass avg', borderWidth:2, backgroundColor:C.greenL, borderColor:C.green,
            pointBackgroundColor:C.green,
            data:[P.StudyHours*10,P.Attendance,P.InternalMarks,P.PreviousScore] },
          { label:'Fail avg', borderWidth:2, backgroundColor:C.redL, borderColor:C.red,
            pointBackgroundColor:C.red,
            data:[F.StudyHours*10,F.Attendance,F.InternalMarks,F.PreviousScore] },
        ] },
      options:{ responsive:true, maintainAspectRatio:false,
        plugins:{ legend:{ position:'top', labels:{ color:'#94a3b8', font:{size:11} } } },
        scales:{ r:{ min:0, max:100,
          ticks:{ color:'#64748b', backdropColor:'transparent', font:{size:10} },
          grid:{ color:'rgba(255,255,255,.06)' },
          pointLabels:{ color:'#94a3b8', font:{size:11} } } } }
    });

  }, [data]);

  return (
    <div>
      <style>{`@keyframes skp{0%,100%{opacity:1}50%{opacity:.45}}
        .ptb{width:100%;border-collapse:collapse;font-size:.82rem}
        .ptb th{text-align:left;padding:.55rem .75rem;color:var(--muted);font-weight:500;border-bottom:1px solid var(--border)}
        .ptb td{padding:.55rem .75rem;border-bottom:1px solid rgba(42,52,73,.35)}
        .ptb tr:last-child td{border-bottom:none}
      `}</style>

      <h1 className="page-title"> Analytics Dashboard</h1>
      <p className="page-sub">Class-wide statistics from {loading ? '…' : data ? `${data.total} student` : '—'} records.</p>

      {err && (
        <div className="alert danger" style={{marginBottom:'1.5rem'}}>
          <span className="alert-icon"></span>
          <div><strong>Cannot load analytics</strong>
            <p>Start Flask: <code>python app.py</code> then click Analytics again.</p></div>
        </div>
      )}

      {/* Stat cards */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'1rem',marginBottom:'1.5rem'}}>
        {loading
          ? [1,2,3,4].map(i=><Sk key={i} h={110}/>)
          : <>
              <StatCard icon="" label="Total Students"  value={data.total}                color="var(--accent)"/>
              <StatCard icon="" label="Passed"           value={data.passed}               color="var(--success)"
                sub={`${data.pass_rate}% pass rate`}/>
              <StatCard icon="" label="Failed"           value={data.failed}               color="var(--danger)"
                sub={`${(100-data.pass_rate).toFixed(1)}% fail rate`}/>
              <StatCard icon="" label="Model Accuracy"  value={`${data.model_accuracy}%`} color="var(--accent2)"/>
            </>}
      </div>

      {/* Row 1 */}
      <div className="grid-2" style={{marginBottom:'1.5rem'}}>
        <CC title=" Pass vs Fail" height={240}>{loading?<Sk h={240}/>:<canvas ref={r1}/>}</CC>
        <CC title=" Risk Distribution" height={240}>{loading?<Sk h={240}/>:<canvas ref={r2}/>}</CC>
      </div>
      {/* Row 2 */}
      <div className="grid-2" style={{marginBottom:'1.5rem'}}>
        <CC title=" Pass vs Fail by Subject" height={240}>{loading?<Sk h={240}/>:<canvas ref={r6}/>}</CC>
        <CC title=" Student Profile Radar" height={240}>{loading?<Sk h={240}/>:<canvas ref={r8}/>}</CC>
      </div>
      {/* Row 3 */}
      <div className="grid-2" style={{marginBottom:'1.5rem'}}>
        <CC title=" Attendance Buckets" height={220}>{loading?<Sk h={220}/>:<canvas ref={r3}/>}</CC>
        <CC title=" Internal Marks Buckets" height={220}>{loading?<Sk h={220}/>:<canvas ref={r4}/>}</CC>
      </div>
      {/* Row 4 */}
      <div className="grid-2" style={{marginBottom:'1.5rem'}}>
        <CC title=" Study Hours Distribution" height={220}>{loading?<Sk h={220}/>:<canvas ref={r5}/>}</CC>
        <CC title=" Feature Correlation" height={220}>{loading?<Sk h={220}/>:<canvas ref={r7}/>}</CC>
      </div>

      {/* All data-dependent sections — single top-level guard */}
      {!loading && !err && data && (
        <>
          {/* Subject averages */}
          <div className="card animate-up" style={{marginBottom:'1.5rem'}}>
            <div className="card-title"> Subject-Wise Averages</div>
            <div style={{overflowX:'auto'}}>
              <table className="ptb">
                <thead><tr><th>Subject</th><th>Overall</th><th>Pass Avg</th><th>Fail Avg</th><th>Gap</th></tr></thead>
                <tbody>
                  {[{k:'StudyHours',l:'Study Hours',u:'h'},{k:'Attendance',l:'Attendance',u:'%'},
                    {k:'InternalMarks',l:'Internal Marks',u:''},{k:'PreviousScore',l:'Previous Score',u:''}]
                    .map(({k,l,u})=>{
                      const ov=data.subject_avg[k],pv=data.subject_by_result.Pass[k],
                            fv=data.subject_by_result.Fail[k],diff=(pv-fv).toFixed(1);
                      return (<tr key={k}>
                        <td style={{fontWeight:500}}>{l}</td><td>{ov}{u}</td>
                        <td style={{color:'var(--success)',fontWeight:500}}>{pv}{u}</td>
                        <td style={{color:'var(--danger)',fontWeight:500}}>{fv}{u}</td>
                        <td style={{color:parseFloat(diff)>=0?'var(--success)':'var(--danger)',fontWeight:600}}>
                          {parseFloat(diff)>0?'+':''}{diff}{u}</td>
                      </tr>);
                    })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Top / bottom */}
          <div className="grid-2" style={{marginBottom:'1.5rem'}}>
            <div className="card animate-up">
              <div className="card-title"> Top 5 Performers</div>
              <table className="ptb">
                <thead><tr><th>#</th><th>Study</th><th>Attend</th><th>Internal</th><th>Prev</th></tr></thead>
                <tbody>{data.top_performers.map((s,i)=>(
                  <tr key={i}>
                    <td><span style={{display:'inline-flex',alignItems:'center',justifyContent:'center',
                      width:22,height:22,borderRadius:'50%',fontSize:'.72rem',fontWeight:700,
                      background:i===0?'#f59e0b':i===1?'#94a3b8':i===2?'#b45309':'var(--surface)',
                      color:i<3?'#fff':'var(--muted)'}}>{i+1}</span></td>
                    <td>{s.StudyHours}h</td><td>{s.Attendance}%</td>
                    <td style={{color:'var(--success)',fontWeight:500}}>{s.InternalMarks}</td>
                    <td>{s.PreviousScore}</td>
                  </tr>))}</tbody>
              </table>
            </div>
            <div className="card animate-up">
              <div className="card-title"> Bottom 5 At-Risk</div>
              <table className="ptb">
                <thead><tr><th>#</th><th>Study</th><th>Attend</th><th>Internal</th><th>Prev</th></tr></thead>
                <tbody>{data.bottom_performers.map((s,i)=>(
                  <tr key={i}>
                    <td><span style={{display:'inline-flex',alignItems:'center',justifyContent:'center',
                      width:22,height:22,borderRadius:'50%',fontSize:'.72rem',fontWeight:700,
                      background:'rgba(239,68,68,.15)',color:'var(--danger)'}}>{i+1}</span></td>
                    <td>{s.StudyHours}h</td>
                    <td style={{color:'var(--danger)',fontWeight:500}}>{s.Attendance}%</td>
                    <td style={{color:'var(--danger)',fontWeight:500}}>{s.InternalMarks}</td>
                    <td>{s.PreviousScore}</td>
                  </tr>))}</tbody>
              </table>
            </div>
          </div>

          {/* Insights */}
          <div className="card animate-up" style={{marginBottom:'1.5rem'}}>
            <div className="card-title"> Key Insights</div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem'}}>
              {[
                { icon:'', title:'Strongest predictor', text:(()=>{
                    const nm={StudyHours:'Study Hours',Attendance:'Attendance',
                              InternalMarks:'Internal Marks',PreviousScore:'Previous Score'};
                    const b=Object.entries(data.correlations).sort((a,b2)=>b2[1]-a[1])[0];
                    return `${nm[b[0]]} has the highest correlation with passing (r = ${b[1]}).`;
                  })() },
                { icon:'', title:'High risk students',
                  text:`${data.risk_distribution.High||0} students have attendance below 60% and need immediate intervention.` },
                { icon:'', title:'Study hours gap',
                  text:`Passing students study ${data.subject_by_result.Pass.StudyHours}h/day vs ${data.subject_by_result.Fail.StudyHours}h for failing students.` },
                { icon:'', title:'Attendance gap',
                  text:`Pass group: ${data.subject_by_result.Pass.Attendance}% vs Fail: ${data.subject_by_result.Fail.Attendance}% — a ${(data.subject_by_result.Pass.Attendance-data.subject_by_result.Fail.Attendance).toFixed(1)}% difference.` },
              ].map((ins,i)=>(
                <div key={i} style={{background:'var(--surface)',borderRadius:10,
                  padding:'1rem',border:'1px solid var(--border)'}}>
                  <div style={{fontSize:'1.1rem',marginBottom:'.35rem'}}>{ins.icon}</div>
                  <div style={{fontWeight:600,fontSize:'.88rem',marginBottom:'.3rem'}}>{ins.title}</div>
                  <div style={{fontSize:'.82rem',color:'var(--muted)',lineHeight:1.5}}>{ins.text}</div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
