import React, { useState } from 'react';
import { exportCSV, exportPDF } from '../services/api';
import { useToast } from '../services/toast';

export default function ReportsPage({ students, reports, onGenerateReport }) {
  const toast = useToast();
  const [title, setTitle] = useState('');
  const [loading, setLoading] = useState(false);

  const summary = {
    total: students.length,
    pass: students.filter((item) => item.latest_prediction?.prediction === 'Pass').length,
    fail: students.filter((item) => item.latest_prediction?.prediction === 'Fail').length,
    high_risk: students.filter((item) => item.latest_prediction?.risk_level === 'High').length,
  };

  async function handleGenerate() {
    setLoading(true);
    try {
      await onGenerateReport(title || 'Major Project Academic Report');
      setTitle('');
      toast('Report generated successfully', 'success');
    } catch {
      toast('Report generation failed', 'error');
    }
    setLoading(false);
  }

  async function handleExportCSV() {
    try {
      await exportCSV(students.map((student) => ({
        ...student,
        ...student.latest_prediction,
      })));
      toast('CSV downloaded', 'success');
    } catch {
      toast('CSV export failed', 'error');
    }
  }

  async function handleExportPDF() {
    try {
      await exportPDF(
        students.map((student, index) => ({
          row: index + 1,
          name: student.name,
          study_hours: student.study_hours,
          attendance: student.attendance,
          internal_marks: student.internal_marks,
          previous_score: student.previous_score,
          ...student.latest_prediction,
        })),
        summary
      );
      toast('PDF downloaded', 'success');
    } catch {
      toast('PDF export failed', 'error');
    }
  }

  return (
    <div>
      <h1 className="page-title">Reports Center</h1>
      <p className="page-sub">
        Create faculty-ready summaries, export class results, and keep presentation material ready for review.
      </p>

      <div className="summary-grid">
        <div className="stat-card blue"><div className="stat-num">{summary.total}</div><div className="stat-lbl">Tracked Students</div></div>
        <div className="stat-card cyan"><div className="stat-num">{summary.pass}</div><div className="stat-lbl">Predicted Pass</div></div>
        <div className="stat-card red"><div className="stat-num">{summary.high_risk}</div><div className="stat-lbl">High Risk</div></div>
        <div className="stat-card green"><div className="stat-num">{reports.length}</div><div className="stat-lbl">Saved Reports</div></div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-title">Generate New Report</div>
          <div className="field">
            <label>Report Title</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Semester 6 Early Warning Review"
            />
          </div>

          <div style={{ display: 'grid', gap: '.75rem', marginBottom: '1rem' }}>
            <div className="simple-row"><span>Total students in current workspace</span><strong>{summary.total}</strong></div>
            <div className="simple-row"><span>High risk students</span><strong>{summary.high_risk}</strong></div>
            <div className="simple-row"><span>Predicted pass students</span><strong>{summary.pass}</strong></div>
          </div>

          <div className="btn-row">
            <button className="btn-primary" onClick={handleGenerate} disabled={loading}>
              {loading ? 'Generating...' : 'Generate Summary Report'}
            </button>
            <button className="btn-secondary" onClick={handleExportCSV}>Export CSV</button>
            <button className="btn-secondary" onClick={handleExportPDF}>Export PDF</button>
          </div>
        </div>

        <div className="card">
          <div className="card-title">Saved Report Library</div>
          <div className="student-list">
            {reports.map((report) => (
              <div key={report.id} className="student-card">
                <div style={{ fontWeight: 800 }}>{report.title}</div>
                <div className="student-meta-grid">
                  <span>Total: <strong>{report.total_students}</strong></span>
                  <span>At Risk: <strong>{report.at_risk}</strong></span>
                  <span>Pass Rate: <strong>{report.pass_rate}%</strong></span>
                  <span>Top Dept: <strong>{report.top_department}</strong></span>
                </div>
                <div style={{ color: 'var(--muted)', fontSize: '.82rem' }}>
                  Generated on {report.created_at}
                </div>
              </div>
            ))}

            {!reports.length && <div className="history-empty">No saved reports yet. Generate one from the left panel.</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
