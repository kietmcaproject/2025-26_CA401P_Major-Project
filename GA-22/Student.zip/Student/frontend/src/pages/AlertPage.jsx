// src/pages/AlertPage.jsx — Fixed & polished v2
import React, { useState, useMemo } from 'react';
import { sendAlert } from '../services/api';
import { useToast }  from '../services/toast';

const RISK_COLOR = {
  High:   { bg:'rgba(239,68,68,.12)',  border:'rgba(239,68,68,.3)',  text:'#ef4444' },
  Medium: { bg:'rgba(245,158,11,.12)', border:'rgba(245,158,11,.3)', text:'#f59e0b' },
};

export default function AlertPage({ history }) {
  const toast = useToast();
  const [email,      setEmail]      = useState('');
  const [selected,   setSelected]   = useState(new Set());
  const [loading,    setLoading]    = useState(false);
  const [lastResult, setLastResult] = useState(null);

  // At-risk: High or Medium risk level
  const atRisk = useMemo(()=>
    history.filter(h => h.risk_level === 'High' || h.risk_level === 'Medium'),
  [history]);

  function toggleStudent(id) {
    setSelected(s => { const ns = new Set(s); ns.has(id)?ns.delete(id):ns.add(id); return ns; });
  }
  function selectAll() {
    setSelected(atRisk.length === selected.size ? new Set() : new Set(atRisk.map(s=>s.id)));
  }

  async function handleSend() {
    if (!email.trim())    { toast('Please enter a recipient email address','error'); return; }
    if (selected.size===0){ toast('Select at least one student to alert','error');   return; }
    setLoading(true); setLastResult(null);
    const toSend = atRisk.filter(s=>selected.has(s.id));
    try {
      const res = await sendAlert(email, toSend);
      setLastResult({ ...res, count: toSend.length, email });
      toast(res.simulated
        ? `📧 Simulated — alert preview generated for ${email}`
        : `✅ Alert sent to ${email}!`,
        'success');
    } catch { toast('Failed to send alert. Check backend.','error'); }
    setLoading(false);
  }

  const selectedStudents = atRisk.filter(s=>selected.has(s.id));
  const plural = n => n === 1 ? 'student' : 'students';

  return (
    <div>
      <h1 className="page-title"> Email Alerts</h1>
      <p className="page-sub">Send early warning alerts to faculty for at-risk students.</p>

      {/* ── Info banner ── */}
      {/* <div style={{
        display:'flex', alignItems:'flex-start', gap:'.85rem',
        background:'rgba(59,130,246,.08)', border:'1px solid rgba(59,130,246,.2)',
        borderRadius:12, padding:'1rem 1.25rem', marginBottom:'1.5rem'
      }}>
        <span style={{fontSize:'1.2rem',marginTop:'.05rem'}}>ℹ️</span>
        <div style={{fontSize:'.875rem', color:'var(--muted)', lineHeight:1.6}}>
          <strong style={{color:'var(--text)'}}>Gmail setup required for real emails.</strong>{' '}
          Open <code style={{background:'rgba(255,255,255,.08)',padding:'.1rem .35rem',borderRadius:4}}>backend/app.py</code> and
          set <code style={{background:'rgba(255,255,255,.08)',padding:'.1rem .35rem',borderRadius:4}}>GMAIL_USER</code> +{' '}
          <code style={{background:'rgba(255,255,255,.08)',padding:'.1rem .35rem',borderRadius:4}}>GMAIL_PASSWORD</code>.
          Until then, alerts run in <strong style={{color:'#f59e0b'}}>simulated mode</strong> and are not actually sent.
        </div>
      </div> */}

      <div className="grid-2">
        {/* ── Left: student checklist ── */}
        <div className="card" style={{display:'flex',flexDirection:'column'}}>
          <div className="card-title">
            At-Risk Students
            <span style={{
              marginLeft:'auto', fontSize:'.75rem', fontWeight:700,
              background:'rgba(245,158,11,.15)', color:'#f59e0b',
              padding:'.2rem .65rem', borderRadius:20
            }}>
              {atRisk.length} {plural(atRisk.length)}
            </span>
          </div>

          {atRisk.length === 0 ? (
            <div style={{flex:1,display:'flex',flexDirection:'column',alignItems:'center',
                         justifyContent:'center',padding:'2.5rem 1rem',textAlign:'center',
                         color:'var(--muted)'}}>
              <div style={{fontSize:'3rem',marginBottom:'.75rem',opacity:.25}}></div>
              <p style={{lineHeight:1.6}}>
                No at-risk students yet.<br/>
                Make predictions using <strong style={{color:'var(--text)'}}>Single Predict</strong> or{' '}
                <strong style={{color:'var(--text)'}}>Batch Predict</strong> first.
              </p>
            </div>
          ) : (
            <>
              {/* Select all bar */}
              <div style={{
                display:'flex', alignItems:'center', justifyContent:'space-between',
                padding:'.6rem .85rem', borderRadius:8, background:'var(--surface)',
                border:'1px solid var(--border)', marginBottom:'1rem', cursor:'pointer'
              }} onClick={selectAll}>
                <span style={{fontSize:'.875rem',fontWeight:500,color:'var(--text)'}}>
                  {selected.size === atRisk.length ? '☐ Deselect All' : '☑ Select All'}
                </span>
                <span style={{fontSize:'.8rem',color:'var(--muted)'}}>
                  {selected.size} / {atRisk.length} selected
                </span>
              </div>

              {/* Student rows */}
              <div style={{display:'flex',flexDirection:'column',gap:'.5rem'}}>
                {atRisk.map(s => {
                  const rc = RISK_COLOR[s.risk_level] || RISK_COLOR.Medium;
                  const isSelected = selected.has(s.id);
                  return (
                    <div key={s.id}
                      onClick={()=>toggleStudent(s.id)}
                      style={{
                        display:'flex', alignItems:'center', gap:'.85rem',
                        padding:'.85rem 1rem', borderRadius:10, cursor:'pointer',
                        background: isSelected ? rc.bg : 'var(--surface)',
                        border: `1.5px solid ${isSelected ? rc.border : 'var(--border)'}`,
                        transition:'all .15s'
                      }}>
                      {/* Checkbox */}
                      <div style={{
                        width:20, height:20, borderRadius:5, flexShrink:0,
                        border:`2px solid ${isSelected ? rc.text : 'var(--border)'}`,
                        background: isSelected ? rc.text : 'transparent',
                        display:'flex', alignItems:'center', justifyContent:'center'
                      }}>
                        {isSelected && <span style={{color:'#fff',fontSize:'.75rem',fontWeight:700}}>✓</span>}
                      </div>

                      {/* Avatar */}
                      <div style={{
                        width:36, height:36, borderRadius:'50%', flexShrink:0,
                        background: s.risk_level==='High'?'rgba(239,68,68,.2)':'rgba(245,158,11,.2)',
                        display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1rem'
                      }}>
                        {s.risk_level==='High' ? '' : ''}
                      </div>

                      {/* Info */}
                      <div style={{flex:1, minWidth:0}}>
                        <div style={{fontWeight:700, fontSize:'.9rem', color:'var(--text)',
                                     whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>
                          {s.name || `Student (${s.time})`}
                        </div>
                        <div style={{fontSize:'.775rem', color:'var(--muted)', marginTop:'.2rem'}}>
                          Attendance: <strong style={{color: s.attendance < 60 ? '#ef4444' : 'var(--text)'}}>{s.attendance}%</strong>
                          {' · '}Internal: <strong>{s.internal_marks}</strong>
                          {' · '}Study: <strong>{s.study_hours}h</strong>
                        </div>
                      </div>

                      {/* Tags */}
                      <div style={{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:'.3rem',flexShrink:0}}>
                        <span style={{
                          fontSize:'.72rem', fontWeight:700, padding:'.18rem .55rem', borderRadius:20,
                          background: rc.bg, color: rc.text, border:`1px solid ${rc.border}`
                        }}>{s.risk_level}</span>
                        <span style={{
                          fontSize:'.72rem', fontWeight:700, padding:'.18rem .55rem', borderRadius:20,
                          background: s.prediction==='Pass'?'rgba(16,185,129,.15)':'rgba(239,68,68,.15)',
                          color: s.prediction==='Pass'?'#10b981':'#ef4444'
                        }}>{s.prediction}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>

        {/* ── Right: compose & send ── */}
        <div style={{display:'flex',flexDirection:'column',gap:'1.25rem'}}>

          {/* Compose card */}
          <div className="card">
            <div className="card-title"> Send Alert Email</div>

            {/* Email input */}
            <div className="field" style={{marginBottom:'1.25rem'}}>
              <label style={{fontSize:'.85rem',fontWeight:600,color:'var(--text)',display:'block',marginBottom:'.5rem'}}>
                Recipient Email (Faculty)
              </label>
              <input
                type="email"
                value={email}
                onChange={e=>setEmail(e.target.value)}
                placeholder="faculty@college.edu"
                style={{
                  width:'100%', padding:'.65rem 1rem', borderRadius:8,
                  border:'1.5px solid var(--border)', background:'var(--surface)',
                  color:'var(--text)', fontSize:'.95rem', outline:'none',
                  transition:'border-color .2s', boxSizing:'border-box'
                }}
                onFocus={e=>e.target.style.borderColor='var(--accent)'}
                onBlur={e=>e.target.style.borderColor='var(--border)'}
              />
            </div>

            {/* Summary pill */}
            <div style={{
              display:'flex', alignItems:'center', gap:'.75rem',
              background: selected.size > 0 ? 'rgba(245,158,11,.1)' : 'var(--surface)',
              border:`1px solid ${selected.size>0?'rgba(245,158,11,.3)':'var(--border)'}`,
              borderRadius:10, padding:'.85rem 1rem', marginBottom:'1.25rem',
              transition:'all .2s'
            }}>
              <span style={{fontSize:'1.1rem'}}>{selected.size>0?'📋':''}</span>
              <div>
                <div style={{fontWeight:700, fontSize:'.9rem', color:'var(--text)'}}>
                  {selected.size} {plural(selected.size)} selected
                </div>
                <div style={{fontSize:'.78rem', color:'var(--muted)', marginTop:'.15rem'}}>
                  {selected.size > 0
                    ? `A formatted HTML alert email will be sent to the faculty.`
                    : `Select students from the list on the left.`}
                </div>
              </div>
            </div>

            {/* Selected students preview */}
            {selectedStudents.length > 0 && (
              <div style={{marginBottom:'1.25rem'}}>
                <div style={{fontSize:'.8rem',fontWeight:600,color:'var(--muted)',marginBottom:'.5rem',textTransform:'uppercase',letterSpacing:.5}}>
                  Will be included in email:
                </div>
                {selectedStudents.map(s=>(
                  <div key={s.id} style={{
                    display:'flex', alignItems:'center', gap:'.6rem',
                    padding:'.4rem .7rem', borderRadius:6, marginBottom:'.3rem',
                    background:'var(--surface)', border:'1px solid var(--border)',
                    fontSize:'.83rem'
                  }}>
                    <span>{s.risk_level==='High'?'':''}</span>
                    <span style={{fontWeight:600,flex:1,color:'var(--text)'}}>{s.name||'Unknown'}</span>
                    <span style={{color:'var(--muted)'}}>{s.attendance}% att</span>
                    <span style={{
                      fontWeight:700, color:s.risk_level==='High'?'#ef4444':'#f59e0b',
                      fontSize:'.75rem'
                    }}>{s.risk_level}</span>
                  </div>
                ))}
              </div>
            )}

            <button
              className="btn-primary full"
              onClick={handleSend}
              disabled={loading || atRisk.length===0 || selected.size===0}
              style={{opacity: (atRisk.length===0||selected.size===0)?0.5:1}}>
              {loading
                ? <><span className="spinner"/>Sending…</>
                : ` Send Alert to ${selected.size} ${plural(selected.size)}`}
            </button>
          </div>

          {/* ── Result card ── */}
          {lastResult && (
            <div className="card animate-in" style={{padding:'1.25rem'}}>
              <div className="card-title" style={{marginBottom:'1rem'}}>📬 Send Result</div>

              {lastResult.success ? (
                <div>
                  {/* Success banner */}
                  <div style={{
                    display:'flex', alignItems:'center', gap:'.85rem',
                    background: lastResult.simulated
                      ? 'rgba(245,158,11,.12)' : 'rgba(16,185,129,.12)',
                    border:`1.5px solid ${lastResult.simulated?'rgba(245,158,11,.35)':'rgba(16,185,129,.35)'}`,
                    borderRadius:10, padding:'1rem 1.15rem', marginBottom:'1rem'
                  }}>
                    <span style={{fontSize:'1.5rem'}}>{lastResult.simulated ? '' : '✅'}</span>
                    <div>
                      <div style={{fontWeight:700,fontSize:'.95rem',color:'var(--text)'}}>
                        {lastResult.simulated ? 'Alert Simulated' : 'Alert Sent Successfully!'}
                      </div>
                      <div style={{fontSize:'.83rem',color:'var(--muted)',marginTop:'.2rem'}}>
                        {lastResult.simulated
                          ? `Gmail not configured — real email was NOT sent.`
                          : `Email delivered to ${lastResult.email}`}
                      </div>
                    </div>
                  </div>

                  {/* Detail rows */}
                  {[
                    [' Recipient', lastResult.email],
                    [' Students', `${lastResult.count} ${plural(lastResult.count)}`],
                    [' Status', lastResult.simulated ? 'Simulated (no real email)' : 'Delivered'],
                  ].map(([label, val])=>(
                    <div key={label} style={{
                      display:'flex', justifyContent:'space-between', alignItems:'center',
                      padding:'.55rem 0', borderBottom:'1px solid var(--border)',
                      fontSize:'.875rem'
                    }}>
                      <span style={{color:'var(--muted)'}}>{label}</span>
                      <span style={{fontWeight:600,color:'var(--text)'}}>{val}</span>
                    </div>
                  ))}

                  {lastResult.simulated && (
                    <div style={{
                      marginTop:'1rem', padding:'.75rem', borderRadius:8,
                      background:'rgba(245,158,11,.08)', border:'1px solid rgba(245,158,11,.2)',
                      fontSize:'.8rem', color:'#f59e0b', lineHeight:1.5
                    }}>
                       To enable real emails, set <code>GMAIL_USER</code> &amp; <code>GMAIL_PASSWORD</code> in <code>backend/app.py</code>.
                    </div>
                  )}
                </div>
              ) : (
                <div style={{
                  background:'rgba(239,68,68,.1)', border:'1px solid rgba(239,68,68,.3)',
                  borderRadius:10, padding:'1rem', color:'#ef4444'
                }}>
                  ❌ <strong>Send Failed</strong> — {lastResult.error}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
