import React from 'react';

const KPI = [
  ['total_students', 'Tracked Students', 'blue'],
  ['at_risk', 'Students Needing Attention', 'red'],
  ['pending_interventions', 'Open Interventions', 'cyan'],
  ['reports_generated', 'Generated Reports', 'green'],
];

export default function DashboardPage({ summary, students, onNavigate }) {
  const empty = !summary;

  return (
    <div>
      <h1 className="page-title">Academic Command Center</h1>
      <p className="page-sub">
        One workspace for student tracking, prediction risk, faculty interventions, and report-ready oversight.
      </p>

      <div className="summary-grid">
        {KPI.map(([key, label, cls]) => (
          <div key={key} className={`stat-card ${cls}`}>
            <div className="stat-num">{empty ? '...' : summary[key]}</div>
            <div className="stat-lbl">{label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2" style={{ marginBottom: '1.25rem' }}>
        <div className="card">
          <div className="card-title">Quick Actions</div>
          <div className="quick-actions">
            <button className="btn-primary" onClick={() => onNavigate('students')}>Manage Student Records</button>
            <button className="btn-secondary" onClick={() => onNavigate('predict')}>Run Single Prediction</button>
            <button className="btn-secondary" onClick={() => onNavigate('interventions')}>Create Intervention</button>
            <button className="btn-secondary" onClick={() => onNavigate('reports')}>Build Summary Report</button>
          </div>
        </div>

        <div className="card">
          <div className="card-title">Project Value Snapshot</div>
          <div style={{ display: 'grid', gap: '.75rem' }}>
            <div className="simple-row"><span>Managed student records</span><strong>{students.length}</strong></div>
            <div className="simple-row"><span>Prediction + intervention workflow</span><strong>Live</strong></div>
            <div className="simple-row"><span>Persistent data tracking</span><strong>Enabled</strong></div>
            <div className="simple-row"><span>Faculty report generation</span><strong>Ready</strong></div>
          </div>
        </div>
      </div>

      <div className="grid-2" style={{ marginBottom: '1.25rem' }}>
        <div className="card">
          <div className="card-title">Risk Watchlist</div>
          {empty || !(summary.watchlist || []).length ? (
            <div className="history-empty">No watchlist data yet.</div>
          ) : (
            <div style={{ display: 'grid', gap: '.75rem' }}>
              {summary.watchlist.map((student) => (
                <div key={student.id} className="student-compact-card">
                  <div>
                    <div style={{ fontWeight: 800 }}>{student.name}</div>
                    <div style={{ color: 'var(--muted)', fontSize: '.82rem' }}>
                      {student.department} • Semester {student.semester} • Attendance {student.attendance}%
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '.4rem', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                    <span className={`tag ${student.risk_level}`}>{student.risk_level}</span>
                    <span className={`tag ${student.prediction}`}>{student.prediction}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card">
          <div className="card-title">Recent Activity</div>
          {empty || !(summary.recent_activity || []).length ? (
            <div className="history-empty">No recent activity yet.</div>
          ) : (
            <div style={{ display: 'grid', gap: '.75rem' }}>
              {summary.recent_activity.map((item) => (
                <div key={item.id} className="activity-row">
                  <div style={{ fontWeight: 700 }}>{item.message}</div>
                  <div style={{ color: 'var(--muted)', fontSize: '.78rem' }}>{item.created_at}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-title">Department Distribution</div>
          {!summary || !Object.keys(summary.department_breakdown || {}).length ? (
            <div className="history-empty">No department data yet.</div>
          ) : (
            <div style={{ display: 'grid', gap: '.75rem' }}>
              {Object.entries(summary.department_breakdown).map(([department, count]) => (
                <div key={department} className="simple-row">
                  <span>{department}</span>
                  <strong>{count} students</strong>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card">
          <div className="card-title">Operational Focus</div>
          <div style={{ display: 'grid', gap: '.75rem' }}>
            <div className="simple-row"><span>Most important next step</span><strong>Review watchlist</strong></div>
            <div className="simple-row"><span>Fastest faculty workflow</span><strong>Predict → Intervene → Report</strong></div>
            <div className="simple-row"><span>Best viva talking point</span><strong>Early warning system</strong></div>
          </div>
        </div>
      </div>
    </div>
  );
}
