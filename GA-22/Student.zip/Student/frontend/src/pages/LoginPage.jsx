import React, { useState } from 'react';
import { login } from '../services/api';

const HIGHLIGHTS = [
  'Student risk monitoring with prediction and intervention tracking',
  'Faculty-focused dashboard with reports, alerts, and analytics',
  'Major-project presentation ready UI with full workflow coverage',
];

export default function LoginPage({ onLogin }) {
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setError('');
  }

  function validate() {
    if (!form.username.trim() || !form.password.trim()) return 'All fields are required';
    if (form.password.length < 6) return 'Password must be at least 6 characters';
    return null;
  }

  async function submit(e) {
    e.preventDefault();
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);
    try {
      const res = await login(form.username, form.password);
      if (res.success) {
        localStorage.setItem('sp_token', res.token);
        localStorage.setItem('sp_user', res.username);
        onLogin(res.username);
      } else {
        setError(res.message || 'Invalid credentials');
      }
    } catch {
      setError('Server not reachable. Make sure backend is running.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page">
      <div className="login-card">
        <section className="login-hero">
          <div>
            <span className="login-kicker">Academic Command Center</span>
            <h1>Predict risk early. Track action faster.</h1>
            <p>
              EduPredict AI combines student performance prediction, intervention
              workflows, reporting, and class analytics in one faculty-ready dashboard.
            </p>
          </div>

          <div className="login-highlights">
            {HIGHLIGHTS.map((item) => (
              <div key={item} className="login-highlight">{item}</div>
            ))}
          </div>
        </section>

        <section className="login-form-panel">
          <h2 className="login-title">Faculty Login</h2>
          <p className="login-sub">
            Access predictions, batch analysis, academic watchlists, and major-project reports.
          </p>

          <form onSubmit={submit} noValidate>
            <div className="field">
              <label htmlFor="username">Username</label>
              <input
                id="username"
                type="text"
                name="username"
                placeholder="Enter username"
                value={form.username}
                onChange={handleChange}
                autoFocus
              />
            </div>

            <div className="field">
              <label htmlFor="password">Password</label>
              <input
                id="password"
                type="password"
                name="password"
                placeholder="Enter password"
                value={form.password}
                onChange={handleChange}
              />
              <p className="hint-text">Demo credentials: admin / admin123</p>
            </div>

            {error && <p className="error-msg">{error}</p>}

            <button className="btn-primary btn-login" type="submit" disabled={loading}>
              {loading ? <><span className="spinner" />Signing in...</> : 'Open Faculty Dashboard'}
            </button>
          </form>
        </section>
      </div>
    </div>
  );
}
