// src/pages/BatchPage.jsx — Upload CSV, get predictions, export PDF/CSV
import React, { useState, useRef } from 'react';
import { predictBatch, exportCSV, exportPDF } from '../services/api';
import { useToast } from '../services/toast';

export default function BatchPage({ onAddHistory }) {
  const toast   = useToast();
  const fileRef = useRef();
  const [results,   setResults]   = useState([]);
  const [summary,   setSummary]   = useState(null);
  const [loading,   setLoading]   = useState(false);
  const [dragging,  setDragging]  = useState(false);
  const [fileName,  setFileName]  = useState('');
  const [exporting, setExporting] = useState('');

  async function processFile(file) {
    if (!file) return;
    if (!file.name.endsWith('.csv')) { toast('Please upload a .csv file','error'); return; }
    setFileName(file.name); setLoading(true); setResults([]); setSummary(null);
    try {
      const data = await predictBatch(file);
      setResults(data.results); setSummary(data.summary);
      onAddHistory(data.results.map(r=>({...r, time:new Date().toLocaleTimeString()})));
      toast(`✅ ${data.summary.total} students processed!`, 'success');
    } catch { toast('Batch prediction failed. Check CSV format.','error'); }
    setLoading(false);
  }

  const onDrop = e => {
    e.preventDefault(); setDragging(false);
    processFile(e.dataTransfer.files[0]);
  };

  async function handleExportCSV() {
    setExporting('csv');
    try { await exportCSV(results); toast('CSV downloaded!','success'); }
    catch { toast('Export failed','error'); }
    setExporting('');
  }

  async function handleExportPDF() {
    setExporting('pdf');
    try { await exportPDF(results, summary); toast('PDF downloaded!','success'); }
    catch { toast('Export failed. Is ReportLab installed?','error'); }
    setExporting('');
  }

  // Download sample CSV
  function downloadSample() {
    const rows = [
      'Name,StudyHours,Attendance,InternalMarks,PreviousScore',
      'Rahul Sharma,7,85,72,68',
      'Priya Patel,3,45,38,42',
      'Amit Kumar,6,78,65,71',
      'Sneha Singh,9,92,88,85',
      'Rohan Gupta,2,55,30,35',
    ].join('\n');
    const url  = URL.createObjectURL(new Blob([rows],{type:'text/csv'}));
    const a    = document.createElement('a');
    a.href=url; a.download='sample_students.csv'; a.click();
    URL.revokeObjectURL(url);
    toast('Sample CSV downloaded!','info');
  }

  return (
    <div>
      <h1 className="page-title"> Batch Prediction</h1>
      <p className="page-sub">Upload a CSV file to predict performance for multiple students at once.</p>

      {/* Upload zone */}
      <div className="card" style={{marginBottom:'1.5rem'}}>
        <div className="card-title"> Upload Student CSV</div>
        <div
          className={`drop-zone ${dragging?'drag-over':''}`}
          onDragOver={e=>{e.preventDefault();setDragging(true)}}
          onDragLeave={()=>setDragging(false)}
          onDrop={onDrop}
          onClick={()=>fileRef.current.click()}
        >
          <div className="dz-icon">📂</div>
          <p>{fileName
            ? <><strong style={{color:'var(--accent2)'}}>✅ {fileName}</strong><br/><span>Click to change file</span></>
            : <><strong>Click to upload</strong> or drag & drop your CSV here</>
          }</p>
          <p style={{marginTop:'.5rem',fontSize:'.8rem'}}>Required columns: StudyHours, Attendance, InternalMarks, PreviousScore</p>
        </div>
        <input ref={fileRef} type="file" accept=".csv" style={{display:'none'}}
          onChange={e=>processFile(e.target.files[0])}/>

        <div className="btn-row">
          <button className="btn-secondary" onClick={downloadSample}>⬇ Download Sample CSV</button>
          {results.length > 0 && <>
            <button className="btn-secondary" onClick={handleExportCSV} disabled={exporting==='csv'}>
              {exporting==='csv'?<><span className="spinner"/>Exporting…</>:'📥 Export CSV'}
            </button>
            <button className="btn-secondary" onClick={handleExportPDF} disabled={exporting==='pdf'}>
              {exporting==='pdf'?<><span className="spinner"/>Generating…</>:'📄 Export PDF Report'}
            </button>
          </>}
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="card" style={{textAlign:'center',padding:'3rem'}}>
          <span className="spinner" style={{width:40,height:40,borderWidth:3}}/>
          <p style={{marginTop:'1rem',color:'var(--muted)'}}>Processing students…</p>
        </div>
      )}

      {/* Summary */}
      {summary && !loading && (
        <>
          <div className="summary-grid">
            {[
              {num:summary.total,    lbl:'Total Students', cls:'blue'},
              {num:summary.pass,     lbl:'Passed',         cls:'green'},
              {num:summary.fail,     lbl:'Failed',         cls:'red'},
              {num:summary.high_risk,lbl:'High Risk ',   cls:'red'},
            ].map(s=>(
              <div key={s.lbl} className={`stat-card ${s.cls}`}>
                <div className="stat-num">{s.num}</div>
                <div className="stat-lbl">{s.lbl}</div>
              </div>
            ))}
          </div>

          {/* Results table */}
          <div className="card">
            <div className="card-title"> Detailed Results</div>
            <div className="table-wrap">
              <table className="hist-table">
                <thead>
                  <tr>
                    <th>#</th><th>Name</th><th>Study Hrs</th>
                    <th>Attendance</th><th>Internal</th><th>Prev Score</th>
                    <th>Result</th><th>Confidence</th><th>Risk</th>
                  </tr>
                </thead>
                <tbody>
                  {results.map(r=>(
                    <tr key={r.row}>
                      <td style={{color:'var(--muted)'}}>{r.row}</td>
                      <td style={{fontWeight:500}}>{r.name}</td>
                      <td>{r.study_hours}h</td>
                      <td>{r.attendance}%</td>
                      <td>{r.internal_marks}</td>
                      <td>{r.previous_score}</td>
                      <td><span className={`tag ${r.prediction}`}>{r.prediction}</span></td>
                      <td>{Math.round(r.probability*100)}%</td>
                      <td><span className={`tag ${r.risk_level}`}>{r.risk_level}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
