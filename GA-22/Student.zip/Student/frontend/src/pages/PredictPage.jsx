// src/pages/PredictPage.jsx
import React, { useState, useEffect, useRef } from 'react';
import { predictOne } from '../services/api';
import { useToast } from '../services/toast';
import {
  Chart, ArcElement, DoughnutController, BarElement, BarController,
  CategoryScale, LinearScale, Tooltip
} from 'chart.js';
Chart.register(ArcElement, DoughnutController, BarElement, BarController,
  CategoryScale, LinearScale, Tooltip);

const FIELDS = [
  { name: 'study_hours', label: 'Study Hours / Day', min: 0, max: 10, step: 0.5, unit: 'h' },
  { name: 'attendance', label: 'Attendance (%)', min: 0, max: 100, step: 1, unit: '%' },
  { name: 'internal_marks', label: 'Internal Marks (/100)', min: 0, max: 100, step: 1, unit: '' },
  { name: 'previous_score', label: 'Previous Score (/100)', min: 0, max: 100, step: 1, unit: '' },
];
const DEFAULT = { study_hours: 5, attendance: 75, internal_marks: 60, previous_score: 65 };

const RISK_INFO = {
  High: { cls: 'danger', emoji: '', title: 'High Risk Alert!', msg: 'Attendance critically low (<60%). Immediate faculty intervention needed.' },
  Medium: { cls: 'warning', emoji: '', title: 'Medium Risk Warning', msg: 'Internal marks below 50. Academic support and counselling recommended.' },
  Low: { cls: 'success', emoji: '', title: 'Good Standing', msg: 'Student is on track. Keep monitoring regularly.' },
};

function DonutChart({ prob, pred }) {
  const ref = useRef(); const chart = useRef();
  useEffect(() => {
    if (!ref.current) return;
    chart.current?.destroy();
    const pct = Math.round(prob * 100), color = pred === 'Pass' ? '#10b981' : '#ef4444';
    chart.current = new Chart(ref.current, {
      type: 'doughnut',
      data: { datasets: [{ data: [pct, 100 - pct], backgroundColor: [color, '#1a2235'], borderWidth: 0 }] },
      options: { cutout: '76%', plugins: { legend: { display: false }, tooltip: { enabled: false } }, animation: { duration: 800 } }
    });
    return () => chart.current?.destroy();
  }, [prob, pred]);
  return <canvas ref={ref} />;
}

function BarChart({ lr, rf }) {
  const ref = useRef(); const chart = useRef();
  useEffect(() => {
    if (!ref.current) return; chart.current?.destroy();
    chart.current = new Chart(ref.current, {
      type: 'bar',
      data: {
        labels: ['Logistic Regression', 'Random Forest'],
        datasets: [{ data: [lr, rf], backgroundColor: ['rgba(59,130,246,.75)', 'rgba(6,182,212,.75)'], borderRadius: 8, borderSkipped: false }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => ` ${c.raw}%` } } },
        scales: {
          x: { ticks: { color: '#64748b' }, grid: { display: false } },
          y: { min: 80, max: 100, ticks: { color: '#64748b', callback: v => v + '%' }, grid: { color: 'rgba(255,255,255,.04)' } }
        }
      }
    });
    return () => chart.current?.destroy();
  }, [lr, rf]);
  return <canvas ref={ref} />;
}

export default function PredictPage({ onAddHistory }) {
  const toast = useToast();
  const [studentName, setStudentName] = useState('');
  const [form, setForm] = useState(DEFAULT);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [lastName, setLastName] = useState('');

  const setVal = (name, val) => setForm(f => ({ ...f, [name]: val }));

  async function handleSubmit(e) {
    e.preventDefault(); setLoading(true); setResult(null);
    const nameToUse = studentName.trim() || 'Unknown Student';
    try {
      const res = await predictOne(form);
      setResult(res);
      setLastName(nameToUse);
      onAddHistory([{ ...form, ...res, name: nameToUse, id: Date.now(), time: new Date().toLocaleTimeString() }]);
      toast(
        `${nameToUse}: ${res.prediction === 'Pass' ? 'Pass ' : 'Fail '}`,
        res.prediction === 'Pass' ? 'success' : 'error'
      );
    } catch { toast('Prediction failed. Is Flask running?', 'error'); }
    setLoading(false);
  }

  const risk = result ? RISK_INFO[result.risk_level] : null;
  const pct = result ? Math.round(result.probability * 100) : 0;

  return (
    <div>
      <h1 className="page-title"> Single Prediction</h1>
      <p className="page-sub">Enter one student's academic data to get an instant AI prediction.</p>

      <div className="predict-grid">
        {/* ── Form ── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <form className="card" onSubmit={handleSubmit}>
            <div className="card-title"> Student Data Input</div>

            {/* Student Name */}
            <div className="field" style={{ marginBottom: '1.25rem' }}>
              <label style={{ display: 'block', marginBottom: '.5rem', fontWeight: 600, fontSize: '.9rem', color: 'var(--text)' }}>
                👤 Student Name
              </label>
              <input
                type="text"
                placeholder="e.g. Riya Sharma"
                value={studentName}
                onChange={e => setStudentName(e.target.value)}
                style={{
                  width: '100%', padding: '.65rem 1rem', borderRadius: 8,
                  border: '1.5px solid var(--border)', background: 'var(--surface)',
                  color: 'var(--text)', fontSize: '.95rem', outline: 'none',
                  transition: 'border-color .2s', boxSizing: 'border-box'
                }}
                onFocus={e => e.target.style.borderColor = 'var(--accent)'}
                onBlur={e => e.target.style.borderColor = 'var(--border)'}
              />
            </div>

            {FIELDS.map(({ name, label, min, max, step, unit }) => (
              <div key={name} className="field">
                <div className="range-label-row">
                  <label style={{ margin: 0 }}>{label}</label>
                  <span className="range-val">{form[name]}{unit}</span>
                </div>
                <div className="range-row">
                  <input type="range" min={min} max={max} step={step} value={form[name]}
                    onChange={e => setVal(name, parseFloat(e.target.value))} />
                  <input type="number" min={min} max={max} step={step} value={form[name]}
                    onChange={e => setVal(name, parseFloat(e.target.value) || 0)} className="num-input" />
                </div>
              </div>
            ))}
            <button className="btn-primary full" type="submit" disabled={loading} style={{ marginTop: '.5rem' }}>
              {loading ? <><span className="spinner" />Predicting…</> : ' Predict Performance'}
            </button>
          </form>

          {/* Model comparison */}
          <div className="card">
            <div className="card-title"> Model Accuracy Comparison</div>
            <div className="chart-wrap-bar"><BarChart lr={95} rf={92.5} /></div>
          </div>
        </div>

        {/* ── Result ── */}
        <div>
          <div className="card" style={{ minHeight: 400 }}>
            <div className="card-title"> Prediction Result</div>
            {!result && !loading && (
              <div className="placeholder">
                <div className="icon"></div>
                <p>Fill in the student name &amp; data<br />and click <strong>Predict Performance</strong></p>
              </div>
            )}
            {loading && (
              <div className="placeholder">
                <span className="spinner" style={{ width: 40, height: 40, borderWidth: 3 }} />
                <p style={{ marginTop: '1rem' }}>Running AI model…</p>
              </div>
            )}
            {result && !loading && (
              <div className="animate-in">

                {/* ── Student name + verdict banner ── */}
                <div style={{
                  background: result.prediction === 'Pass'
                    ? 'linear-gradient(135deg,rgba(16,185,129,.15),rgba(52,211,153,.06))'
                    : 'linear-gradient(135deg,rgba(239,68,68,.15),rgba(248,113,113,.06))',
                  border: `1.5px solid ${result.prediction === 'Pass' ? 'rgba(16,185,129,.4)' : 'rgba(239,68,68,.4)'}`,
                  borderRadius: 12, padding: '1rem 1.25rem', marginBottom: '1.25rem',
                  display: 'flex', alignItems: 'center', gap: '1rem'
                }}>
                  <div style={{
                    width: 46, height: 46, borderRadius: '50%',
                    background: result.prediction === 'Pass' ? 'rgba(16,185,129,.2)' : 'rgba(239,68,68,.2)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: '1.5rem', flexShrink: 0
                  }}>
                    {result.prediction === 'Pass' ? '' : ''}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{
                      fontSize: '1.1rem', fontWeight: 700, color: 'var(--text)',
                      whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'
                    }}>
                      {lastName}
                    </div>
                    <div style={{
                      fontSize: '.82rem', marginTop: '.18rem', fontWeight: 600,
                      color: result.prediction === 'Pass' ? '#10b981' : '#ef4444'
                    }}>
                      {result.prediction === 'Pass' ? '✓ Predicted to Pass' : '✗ Predicted to Fail'}
                    </div>
                  </div>
                  <span className={`result-badge ${result.prediction}`}>
                    {result.prediction === 'Pass' ? '✓ Pass' : '✗ Fail'}
                  </span>
                </div>

                {/* Model tag */}
                <div className="result-header" style={{ marginBottom: '1rem' }}>
                  <span className="model-tag"> {result.model_used}</span>
                </div>

                {/* Confidence bar */}
                <div className="prob-section">
                  <div className="prob-label"><span>Confidence</span><strong>{pct}%</strong></div>
                  <div className="prob-track">
                    <div className="prob-fill" style={{
                      width: `${pct}%`,
                      background: result.prediction === 'Pass'
                        ? 'linear-gradient(90deg,#10b981,#34d399)'
                        : 'linear-gradient(90deg,#ef4444,#f87171)'
                    }} />
                  </div>
                </div>

                {/* Risk alert */}
                <div className={`alert ${risk.cls}`} style={{ marginBottom: '1.25rem' }}>
                  <span className="alert-icon">{risk.emoji}</span>
                  <div><strong>{result.risk_level} Risk — {risk.title}</strong><p>{risk.msg}</p></div>
                </div>

                {/* Donut */}
                <div className="donut-wrap">
                  <DonutChart prob={result.probability} pred={result.prediction} />
                  <div className="donut-center">
                    <span className="donut-pct">{pct}%</span>
                    <span className="donut-lbl">Confidence</span>
                  </div>
                </div>

              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
