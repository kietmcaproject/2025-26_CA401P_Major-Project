import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  getHealth,
  getDashboardSummary,
  getStudents,
  createStudent,
  updateStudent,
  deleteStudent,
  predictStudent,
  getInterventions,
  createIntervention,
  updateIntervention,
  deleteIntervention,
  getReports,
  generateReport,
} from '../services/api';
import DashboardPage from './DashboardPage';
import StudentsPage from './StudentsPage';
import PredictPage from './PredictPage';
import BatchPage from './BatchPage';
import AlertPage from './AlertPage';
import HistoryPage from './HistoryPage';
import AnalyticsPage from './AnalyticsPage';
import InterventionsPage from './InterventionsPage';
import ReportsPage from './ReportsPage';
import {
  LayoutDashboard,
  CheckCircle2,
  LayoutList,
  Bell,
  BarChart3,
  Clock,
  User,
  Users,
  ClipboardList,
  FileText,
} from 'lucide-react';

const NAV = [
  { id: 'dashboard', icon: <LayoutDashboard size={18} strokeWidth={2.5} />, label: 'Dashboard' },
  { id: 'students', icon: <Users size={18} strokeWidth={2.5} />, label: 'Students' },
  { id: 'predict', icon: <CheckCircle2 size={18} strokeWidth={2.5} />, label: 'Single Predict' },
  { id: 'batch', icon: <LayoutList size={18} strokeWidth={2.5} />, label: 'Batch Predict' },
  { id: 'interventions', icon: <ClipboardList size={18} strokeWidth={2.5} />, label: 'Interventions' },
  { id: 'reports', icon: <FileText size={18} strokeWidth={2.5} />, label: 'Reports' },
  { id: 'alerts', icon: <Bell size={18} strokeWidth={2.5} />, label: 'Email Alerts' },
  { id: 'analytics', icon: <BarChart3 size={18} strokeWidth={2.5} />, label: 'Analytics' },
  { id: 'history', icon: <Clock size={18} strokeWidth={2.5} />, label: 'History' },
];

const PAGE_LABELS = {
  dashboard: 'Faculty overview and academic control room',
  students: 'Student records, edits, and profile maintenance',
  predict: 'Single student prediction workspace',
  batch: 'Bulk prediction and report export workflow',
  interventions: 'Remedial action and follow-up board',
  reports: 'Report generation and saved summaries',
  alerts: 'Faculty email alert workflow',
  analytics: 'Performance insights and chart analysis',
  history: 'Prediction archive and session history',
};

export default function MainShell({ user, onLogout }) {
  const hasMounted = useRef(false);
  const [page, setPage] = useState('dashboard');
  const [displayPage, setDisplayPage] = useState('dashboard');
  const [pendingPage, setPendingPage] = useState(null);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [health, setHealth] = useState(null);
  const [summary, setSummary] = useState(null);
  const [students, setStudents] = useState([]);
  const [interventions, setInterventions] = useState([]);
  const [reports, setReports] = useState([]);
  const [sessionHistory, setSessionHistory] = useState([]);

  async function loadAll() {
    const [healthData, summaryData, studentData, interventionData, reportData] = await Promise.all([
      getHealth().catch(() => ({ status: 'offline' })),
      getDashboardSummary().catch(() => null),
      getStudents().catch(() => ({ students: [] })),
      getInterventions().catch(() => ({ interventions: [] })),
      getReports().catch(() => ({ reports: [] })),
    ]);
    setHealth(healthData);
    setSummary(summaryData);
    setStudents(studentData.students || []);
    setInterventions(interventionData.interventions || []);
    setReports(reportData.reports || []);
  }

  useEffect(() => {
    loadAll();
  }, []);

  useEffect(() => {
    if (!hasMounted.current) {
      hasMounted.current = true;
      return undefined;
    }

    setPendingPage(page);
    setIsTransitioning(true);
    const swapTimer = setTimeout(() => {
      setDisplayPage(page);
      window.scrollTo({ top: 0, behavior: 'auto' });
    }, 95);
    const doneTimer = setTimeout(() => {
      setIsTransitioning(false);
      setPendingPage(null);
    }, 225);
    return () => {
      clearTimeout(swapTimer);
      clearTimeout(doneTimer);
    };
  }, [page]);

  const predictionHistory = useMemo(() => {
    const persisted = students.flatMap((student) =>
      (student.prediction_history || []).map((entry) => ({
        id: entry.id,
        time: entry.created_at,
        name: student.name,
        department: student.department,
        semester: student.semester,
        study_hours: student.study_hours,
        attendance: student.attendance,
        internal_marks: student.internal_marks,
        previous_score: student.previous_score,
        prediction: entry.prediction,
        probability: entry.probability,
        risk_level: entry.risk_level,
      }))
    );
    return [...sessionHistory, ...persisted].slice(0, 200);
  }, [sessionHistory, students]);

  function addToHistory(entries) {
    setSessionHistory((current) => [...entries, ...current].slice(0, 200));
  }

  async function handleCreateStudent(data) {
    const res = await createStudent(data);
    await loadAll();
    return res;
  }

  async function handleUpdateStudent(id, data) {
    const res = await updateStudent(id, data);
    await loadAll();
    return res;
  }

  async function handleDeleteStudent(id) {
    const res = await deleteStudent(id);
    await loadAll();
    return res;
  }

  async function handlePredictStudent(id) {
    const res = await predictStudent(id);
    await loadAll();
    return res;
  }

  async function handleCreateIntervention(data) {
    const res = await createIntervention(data);
    await loadAll();
    return res;
  }

  async function handleUpdateIntervention(id, data) {
    const res = await updateIntervention(id, data);
    await loadAll();
    return res;
  }

  async function handleDeleteIntervention(id) {
    const res = await deleteIntervention(id);
    await loadAll();
    return res;
  }

  async function handleGenerateReport(title) {
    const res = await generateReport(title);
    await loadAll();
    return res;
  }

  const pages = {
    dashboard: <DashboardPage summary={summary} students={students} onNavigate={setPage} />,
    students: (
      <StudentsPage
        students={students}
        onCreateStudent={handleCreateStudent}
        onUpdateStudent={handleUpdateStudent}
        onDeleteStudent={handleDeleteStudent}
        onPredictStudent={handlePredictStudent}
      />
    ),
    predict: <PredictPage onAddHistory={addToHistory} />,
    batch: <BatchPage onAddHistory={addToHistory} />,
    interventions: (
      <InterventionsPage
        students={students}
        interventions={interventions}
        onCreateIntervention={handleCreateIntervention}
        onUpdateIntervention={handleUpdateIntervention}
        onDeleteIntervention={handleDeleteIntervention}
      />
    ),
    reports: <ReportsPage students={students} reports={reports} onGenerateReport={handleGenerateReport} />,
    alerts: <AlertPage history={predictionHistory} />,
    history: <HistoryPage history={predictionHistory} />,
    analytics: <AnalyticsPage />,
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <nav className="sidebar">
        <div className="sidebar-brand">
          <div className="brand-icon">EA</div>
          <div>
            <div className="brand-name">EduPredict AI</div>
            <div className="brand-sub">Major Project Command Suite</div>
          </div>
        </div>

        <div className="sidebar-nav">
          {NAV.map((item) => (
            <button
              key={item.id}
              className={`nav-item ${page === item.id ? 'active' : ''} ${pendingPage === item.id && isTransitioning ? 'is-pending' : ''}`}
              onClick={() => {
                if (item.id === page || isTransitioning) return;
                setPage(item.id);
              }}
              disabled={isTransitioning}
              aria-current={page === item.id ? 'page' : undefined}
            >
              <span className="nav-icon">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </div>

        <div className="sidebar-status">
          {health?.status === 'ok'
            ? <span className="tag Pass">Model {health.accuracy}% Online</span>
            : <span className="tag Fail">System Offline</span>}
        </div>

        <div className="sidebar-footer">
          <div className="user-chip"><User size={16} strokeWidth={2.5} /> {user}</div>
          <button className="btn-logout" onClick={onLogout}>Log out session</button>
        </div>
      </nav>

      <div className="main-content" style={{ flex: 1 }}>
        <div className="shell-topbar">
          <div>
            <div className="shell-title">Active workspace</div>
            <div className={`shell-subtitle ${isTransitioning ? 'shell-copy-muted' : ''}`}>
              {PAGE_LABELS[displayPage]}
            </div>
          </div>
          <div className="shell-metrics">
            <span className="shell-pill">{students.length} students tracked</span>
            <span className="shell-pill">{interventions.length} interventions</span>
            <span className="shell-pill">{reports.length} reports saved</span>
          </div>
        </div>

        <div className={`page-stage ${isTransitioning ? 'is-switching' : 'is-settled'}`}>
          <div key={displayPage} className="page-shell animate-page">
            {pages[displayPage]}
          </div>
        </div>
      </div>
    </div>
  );
}
