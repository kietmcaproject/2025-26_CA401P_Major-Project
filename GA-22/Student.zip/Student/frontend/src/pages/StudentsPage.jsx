import React, { useMemo, useState } from 'react';
import { useToast } from '../services/toast';

const EMPTY_FORM = {
  name: '',
  department: 'CSE',
  semester: 1,
  section: 'A',
  mentor: '',
  email: '',
  phone: '',
  study_hours: 5,
  attendance: 75,
  internal_marks: 60,
  previous_score: 65,
  notes: '',
};

export default function StudentsPage({
  students,
  onCreateStudent,
  onUpdateStudent,
  onDeleteStudent,
  onPredictStudent,
}) {
  const toast = useToast();
  const [query, setQuery] = useState('');
  const [department, setDepartment] = useState('All');
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const filtered = useMemo(() => {
    return students.filter((student) => {
      const matchesQuery = [student.name, student.department, student.mentor]
        .join(' ')
        .toLowerCase()
        .includes(query.toLowerCase());
      const matchesDepartment = department === 'All' || student.department === department;
      return matchesQuery && matchesDepartment;
    });
  }, [students, query, department]);

  function setField(name, value) {
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  function reset() {
    setEditingId(null);
    setForm(EMPTY_FORM);
  }

  function startEdit(student) {
    setEditingId(student.id);
    setForm({
      name: student.name || '',
      department: student.department || 'CSE',
      semester: student.semester || 1,
      section: student.section || 'A',
      mentor: student.mentor || '',
      email: student.email || '',
      phone: student.phone || '',
      study_hours: student.study_hours ?? 0,
      attendance: student.attendance ?? 0,
      internal_marks: student.internal_marks ?? 0,
      previous_score: student.previous_score ?? 0,
      notes: student.notes || '',
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingId) {
        await onUpdateStudent(editingId, form);
        toast('Student updated successfully', 'success');
      } else {
        await onCreateStudent(form);
        toast('Student created successfully', 'success');
      }
      reset();
    } catch (err) {
      toast(err?.response?.data?.error || 'Student save failed', 'error');
    }
    setSaving(false);
  }

  async function handleDelete(student) {
    if (!window.confirm(`Delete ${student.name}?`)) return;
    try {
      await onDeleteStudent(student.id);
      toast('Student deleted', 'success');
      if (editingId === student.id) reset();
    } catch {
      toast('Delete failed', 'error');
    }
  }

  async function handlePredict(student) {
    try {
      await onPredictStudent(student.id);
      toast(`Prediction refreshed for ${student.name}`, 'success');
    } catch {
      toast('Prediction refresh failed', 'error');
    }
  }

  return (
    <div>
      <h1 className="page-title">Student Management</h1>
      <p className="page-sub">
        Maintain faculty records, refresh predictions, and keep each student profile academically actionable.
      </p>

      <div className="summary-grid">
        <div className="stat-card blue"><div className="stat-num">{students.length}</div><div className="stat-lbl">Total Records</div></div>
        <div className="stat-card red"><div className="stat-num">{students.filter((item) => item.latest_prediction?.risk_level === 'High').length}</div><div className="stat-lbl">High Risk</div></div>
        <div className="stat-card cyan"><div className="stat-num">{students.filter((item) => item.latest_prediction?.prediction === 'Pass').length}</div><div className="stat-lbl">Predicted Pass</div></div>
        <div className="stat-card green"><div className="stat-num">{filtered.length}</div><div className="stat-lbl">Visible Records</div></div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-title">{editingId ? 'Edit Student Record' : 'Create Student Record'}</div>
          <form onSubmit={handleSubmit}>
            <div className="form-grid-2">
              <div className="field"><label>Name</label><input value={form.name} onChange={(e) => setField('name', e.target.value)} /></div>
              <div className="field"><label>Department</label><input value={form.department} onChange={(e) => setField('department', e.target.value)} /></div>
              <div className="field"><label>Semester</label><input type="number" value={form.semester} onChange={(e) => setField('semester', e.target.value)} /></div>
              <div className="field"><label>Section</label><input value={form.section} onChange={(e) => setField('section', e.target.value)} /></div>
              <div className="field"><label>Mentor</label><input value={form.mentor} onChange={(e) => setField('mentor', e.target.value)} /></div>
              <div className="field"><label>Email</label><input value={form.email} onChange={(e) => setField('email', e.target.value)} /></div>
              <div className="field"><label>Phone</label><input value={form.phone} onChange={(e) => setField('phone', e.target.value)} /></div>
              <div className="field"><label>Study Hours</label><input type="number" value={form.study_hours} onChange={(e) => setField('study_hours', e.target.value)} /></div>
              <div className="field"><label>Attendance</label><input type="number" value={form.attendance} onChange={(e) => setField('attendance', e.target.value)} /></div>
              <div className="field"><label>Internal Marks</label><input type="number" value={form.internal_marks} onChange={(e) => setField('internal_marks', e.target.value)} /></div>
              <div className="field"><label>Previous Score</label><input type="number" value={form.previous_score} onChange={(e) => setField('previous_score', e.target.value)} /></div>
            </div>
            <div className="field">
              <label>Faculty Notes</label>
              <textarea rows="4" value={form.notes} onChange={(e) => setField('notes', e.target.value)} />
            </div>
            <div className="btn-row">
              <button className="btn-primary" type="submit" disabled={saving}>
                {saving ? 'Saving...' : editingId ? 'Update Student' : 'Create Student'}
              </button>
              <button className="btn-secondary" type="button" onClick={reset}>Reset Form</button>
            </div>
          </form>
        </div>

        <div className="card">
          <div className="card-title">Faculty Directory View</div>
          <div className="toolbar-row">
            <input
              placeholder="Search by name, mentor, department"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <select value={department} onChange={(e) => setDepartment(e.target.value)}>
              <option>All</option>
              {[...new Set(students.map((student) => student.department))].map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>

          <div className="student-list">
            {filtered.map((student) => (
              <div key={student.id} className="student-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '1rem', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontWeight: 800, fontSize: '1rem' }}>{student.name}</div>
                    <div style={{ color: 'var(--muted)', fontSize: '.82rem' }}>
                      {student.department} • Semester {student.semester} • Section {student.section}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '.4rem', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                    <span className={`tag ${student.latest_prediction?.risk_level || 'Low'}`}>{student.latest_prediction?.risk_level || 'Low'}</span>
                    <span className={`tag ${student.latest_prediction?.prediction || 'Pass'}`}>{student.latest_prediction?.prediction || 'Pass'}</span>
                  </div>
                </div>

                <div className="student-meta-grid">
                  <span>Attendance: <strong>{student.attendance}%</strong></span>
                  <span>Internal Marks: <strong>{student.internal_marks}</strong></span>
                  <span>Previous Score: <strong>{student.previous_score}</strong></span>
                  <span>Mentor: <strong>{student.mentor}</strong></span>
                </div>

                <div style={{ color: 'var(--muted)', fontSize: '.83rem', lineHeight: 1.7 }}>
                  {student.latest_prediction?.recommendation || 'No recommendation available.'}
                </div>

                <div className="btn-row">
                  <button className="btn-secondary" onClick={() => startEdit(student)}>Edit</button>
                  <button className="btn-secondary" onClick={() => handlePredict(student)}>Refresh Prediction</button>
                  <button className="btn-secondary danger-outline" onClick={() => handleDelete(student)}>Delete</button>
                </div>
              </div>
            ))}

            {!filtered.length && <div className="history-empty">No students found. Add one from the left panel.</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
