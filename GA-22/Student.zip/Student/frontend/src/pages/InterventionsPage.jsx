import React, { useState } from 'react';
import { useToast } from '../services/toast';

const EMPTY = {
  student_id: '',
  student_name: '',
  title: '',
  type: 'Mentoring',
  priority: 'Medium',
  assigned_to: '',
  due_date: '',
  status: 'Pending',
  notes: '',
};

export default function InterventionsPage({
  students,
  interventions,
  onCreateIntervention,
  onUpdateIntervention,
  onDeleteIntervention,
}) {
  const toast = useToast();
  const [form, setForm] = useState(EMPTY);
  const [editingId, setEditingId] = useState(null);
  const [saving, setSaving] = useState(false);

  function setField(name, value) {
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  function handleStudentSelect(value) {
    const student = students.find((item) => item.id === value);
    setForm((prev) => ({
      ...prev,
      student_id: value,
      student_name: student?.name || '',
    }));
  }

  function reset() {
    setEditingId(null);
    setForm(EMPTY);
  }

  function startEdit(item) {
    setEditingId(item.id);
    setForm({ ...item });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingId) {
        await onUpdateIntervention(editingId, form);
        toast('Intervention updated', 'success');
      } else {
        await onCreateIntervention(form);
        toast('Intervention created', 'success');
      }
      reset();
    } catch (err) {
      toast(err?.response?.data?.error || 'Save failed', 'error');
    }
    setSaving(false);
  }

  async function handleDelete(item) {
    if (!window.confirm(`Delete intervention "${item.title}"?`)) return;
    try {
      await onDeleteIntervention(item.id);
      toast('Intervention deleted', 'success');
      if (editingId === item.id) reset();
    } catch {
      toast('Delete failed', 'error');
    }
  }

  return (
    <div>
      <h1 className="page-title">Intervention Tracker</h1>
      <p className="page-sub">
        Convert risk insights into faculty actions with clear ownership, due dates, and status control.
      </p>

      <div className="summary-grid">
        <div className="stat-card blue"><div className="stat-num">{interventions.length}</div><div className="stat-lbl">Total Interventions</div></div>
        <div className="stat-card red"><div className="stat-num">{interventions.filter((item) => item.priority === 'High').length}</div><div className="stat-lbl">High Priority</div></div>
        <div className="stat-card cyan"><div className="stat-num">{interventions.filter((item) => item.status === 'Pending').length}</div><div className="stat-lbl">Pending</div></div>
        <div className="stat-card green"><div className="stat-num">{interventions.filter((item) => item.status === 'Completed').length}</div><div className="stat-lbl">Completed</div></div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-title">{editingId ? 'Edit Faculty Intervention' : 'Create Faculty Intervention'}</div>
          <form onSubmit={handleSubmit}>
            <div className="field">
              <label>Student</label>
              <select value={form.student_id} onChange={(e) => handleStudentSelect(e.target.value)}>
                <option value="">Select student</option>
                {students.map((student) => (
                  <option key={student.id} value={student.id}>{student.name}</option>
                ))}
              </select>
            </div>

            <div className="form-grid-2">
              <div className="field"><label>Title</label><input value={form.title} onChange={(e) => setField('title', e.target.value)} /></div>
              <div className="field">
                <label>Type</label>
                <select value={form.type} onChange={(e) => setField('type', e.target.value)}>
                  <option>Mentoring</option>
                  <option>Parent Call</option>
                  <option>Remedial Class</option>
                  <option>Faculty Review</option>
                </select>
              </div>
              <div className="field">
                <label>Priority</label>
                <select value={form.priority} onChange={(e) => setField('priority', e.target.value)}>
                  <option>High</option>
                  <option>Medium</option>
                  <option>Low</option>
                </select>
              </div>
              <div className="field">
                <label>Status</label>
                <select value={form.status} onChange={(e) => setField('status', e.target.value)}>
                  <option>Pending</option>
                  <option>In Progress</option>
                  <option>Completed</option>
                </select>
              </div>
              <div className="field"><label>Assigned Faculty</label><input value={form.assigned_to} onChange={(e) => setField('assigned_to', e.target.value)} /></div>
              <div className="field"><label>Due Date</label><input type="date" value={form.due_date} onChange={(e) => setField('due_date', e.target.value)} /></div>
            </div>

            <div className="field">
              <label>Notes</label>
              <textarea rows="4" value={form.notes} onChange={(e) => setField('notes', e.target.value)} />
            </div>

            <div className="btn-row">
              <button className="btn-primary" type="submit" disabled={saving}>
                {saving ? 'Saving...' : editingId ? 'Update Intervention' : 'Create Intervention'}
              </button>
              <button className="btn-secondary" type="button" onClick={reset}>Reset Form</button>
            </div>
          </form>
        </div>

        <div className="card">
          <div className="card-title">Intervention Board</div>
          <div className="student-list">
            {interventions.map((item) => (
              <div key={item.id} className="student-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '1rem', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontWeight: 800 }}>{item.title}</div>
                    <div style={{ color: 'var(--muted)', fontSize: '.82rem' }}>
                      {item.student_name} • {item.type}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '.4rem', flexWrap: 'wrap' }}>
                    <span className={`tag ${item.priority === 'High' ? 'High' : item.priority === 'Medium' ? 'Medium' : 'Low'}`}>{item.priority}</span>
                    <span className={`tag ${item.status === 'Completed' ? 'Pass' : item.status === 'In Progress' ? 'Medium' : 'Fail'}`}>{item.status}</span>
                  </div>
                </div>

                <div className="student-meta-grid">
                  <span>Faculty: <strong>{item.assigned_to}</strong></span>
                  <span>Due Date: <strong>{item.due_date}</strong></span>
                  <span>Status: <strong>{item.status}</strong></span>
                </div>

                <div style={{ color: 'var(--muted)', fontSize: '.83rem', lineHeight: 1.7 }}>
                  {item.notes || 'No notes added yet.'}
                </div>

                <div className="btn-row">
                  <button className="btn-secondary" onClick={() => startEdit(item)}>Edit</button>
                  <button className="btn-secondary danger-outline" onClick={() => handleDelete(item)}>Delete</button>
                </div>
              </div>
            ))}

            {!interventions.length && <div className="history-empty">No interventions created yet. Add one from the left panel.</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
