// src/App.js
import React, { useState } from 'react';
import { ToastProvider } from './services/toast';
import LoginPage    from './pages/LoginPage';
import MainShell    from './pages/MainShell';

export default function App() {
  const [user, setUser] = useState(() => {
    const token = localStorage.getItem('sp_token');
    return token ? localStorage.getItem('sp_user') : null;
  });

  function handleLogout() {
    localStorage.removeItem('sp_token');
    localStorage.removeItem('sp_user');
    setUser(null);
  }

  return (
    <ToastProvider>
      {user
        ? <MainShell user={user} onLogout={handleLogout} />
        : <LoginPage onLogin={setUser} />}
    </ToastProvider>
  );
}
