#include <iostream>
#include <vector>
using namespace std;

int main() {
    // Write your solution here
    int a;
    cin>>a;
    int b;
    cin>>b;
    cout<<a+b;
    return 0;
}