import java.util.*;
public class Main {
    public static void main(String[] args) {
      scanner sc = new Scanner(System.in);

        // Write your solution here
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.print(a + b);
    }
}