FROM gcc:12
WORKDIR /app

# Copy everything (you can mount code at runtime instead to avoid rebuilding)
COPY . /app

# Try to build at image build time if Main.cpp exists, but don't fail the build
RUN if [ -f Main.cpp ]; then g++ -std=c++17 -O2 Main.cpp -o main || true; fi

# At container start: prefer built binary, otherwise build and run
CMD ["/bin/sh","-c","if [ -f main ]; then ./main; elif [ -f Main.cpp ]; then g++ -std=c++17 -O2 Main.cpp -o main && ./main; else echo 'No Main.cpp found in /app' && exit 1; fi"]
