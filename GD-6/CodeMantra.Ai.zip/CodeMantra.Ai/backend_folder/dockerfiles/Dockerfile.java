FROM eclipse-temurin:17-jdk

WORKDIR /app

# Do not COPY sources at build time. The image will compile and run Java files
# that are mounted into `/app` at container runtime (e.g. submissions).
CMD ["/bin/sh","-c","if [ -f /app/Main.java ]; then javac /app/Main.java && java -cp /app Main; else echo 'No Main.java found in /app' && exit 1; fi"]
