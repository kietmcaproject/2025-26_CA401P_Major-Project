// This hook is not currently used in the application.
// Clearing its content to prevent unused code from causing potential issues.
export {};
