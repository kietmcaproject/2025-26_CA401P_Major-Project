import React from 'react';

// This component is currently not used in the application but is kept for future use.
// Making it a valid component to prevent potential build errors from an empty .tsx file.
export const ApiKeyModal: React.FC = () => {
  return null;
};
