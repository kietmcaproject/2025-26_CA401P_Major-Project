import React, { useState } from 'react';

type DiffLine = {
    type: 'added' | 'removed' | 'common';
    line: string;
    oldLineNum?: number;
    newLineNum?: number;
};

// A basic implementation of Longest Common Subsequence for line-based diffing.
function calculateDiff(oldStr: string, newStr: string): DiffLine[] {
    const oldLines = oldStr.split('\n');
    const newLines = newStr.split('\n');

    const dp = Array(oldLines.length + 1).fill(null).map(() => Array(newLines.length + 1).fill(0));

    for (let i = 1; i <= oldLines.length; i++) {
        for (let j = 1; j <= newLines.length; j++) {
            if (oldLines[i - 1] === newLines[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1] + 1;
            } else {
                dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
            }
        }
    }

    const diff: DiffLine[] = [];
    let i = oldLines.length;
    let j = newLines.length;

    while (i > 0 || j > 0) {
        if (i > 0 && j > 0 && oldLines[i - 1] === newLines[j - 1]) {
            diff.unshift({ type: 'common', line: oldLines[i - 1], oldLineNum: i, newLineNum: j });
            i--;
            j--;
        } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
            diff.unshift({ type: 'added', line: newLines[j - 1], newLineNum: j });
            j--;
        } else if (i > 0 && (j === 0 || dp[i][j - 1] < dp[i - 1][j])) {
            diff.unshift({ type: 'removed', line: oldLines[i - 1], oldLineNum: i });
            i--;
        } else {
            break;
        }
    }
    return diff;
}


interface CodeDiffBlockProps {
    originalCode: string;
    suggestedCode: string;
    onApply: (code: string) => void;
}

export const CodeDiffBlock: React.FC<CodeDiffBlockProps> = ({ originalCode, suggestedCode, onApply }) => {
    const [copied, setCopied] = useState(false);
    
    const handleCopy = () => {
        navigator.clipboard.writeText(suggestedCode);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const diff = calculateDiff(originalCode, suggestedCode);

    return (
        <div className="my-2 bg-white dark:bg-dark-surface rounded-lg border border-gray-200 dark:border-dark-border overflow-hidden">
            <div className="flex justify-end gap-3 px-3 py-1.5 text-xs text-gray-500 dark:text-dark-text-secondary bg-gray-100 dark:bg-dark-bg/50">
                <button onClick={() => onApply(suggestedCode)} className="font-medium hover:text-primary-500">Apply Fix</button>
                <button onClick={handleCopy} className="font-medium hover:text-primary-500">{copied ? 'Copied!' : 'Copy Fix'}</button>
            </div>
            <div className="text-sm font-mono overflow-x-auto">
                {diff.map((item, index) => {
                    const lineStyles = {
                        added: 'bg-green-50 dark:bg-green-500/10',
                        removed: 'bg-red-50 dark:bg-red-500/10',
                        common: 'bg-white dark:bg-dark-surface',
                    };

                    const lineNumStyles = "w-10 px-2 text-right select-none text-gray-400 dark:text-gray-500 bg-gray-50 dark:bg-dark-bg/30";

                    const prefix = { added: '+', removed: '-', common: ' ' };
                    
                    return (
                        <div key={index} className={`flex w-full ${lineStyles[item.type]}`}>
                            <span className={lineNumStyles}>{item.oldLineNum || ''}</span>
                            <span className={lineNumStyles}>{item.newLineNum || ''}</span>
                            <code className="flex-1 pl-2 pr-4 whitespace-pre-wrap">
                                <span className="mr-2 select-none">{prefix[item.type]}</span>
                                {item.line || ' '}
                            </code>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};