import React from 'react';
import { Language, Theme, Page } from '../types';
import { LANGUAGE_OPTIONS } from '../constants';
import { SunIcon, MoonIcon, CosmoCodeIcon, CodeIcon } from './Icons';

interface HeaderProps {
  language: Language;
  onLanguageChange: (language: Language) => void;
  theme: Theme;
  toggleTheme: () => void;
  page: Page;
  onNavigate: (page: Page) => void;
}

const NavLink: React.FC<{ page: Page; currentPage: Page; onNavigate: (page: Page) => void; children: React.ReactNode }> = ({ page, currentPage, onNavigate, children }) => (
    <button
        onClick={() => onNavigate(page)}
        className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
            currentPage === page
                ? 'text-primary-600 dark:text-primary-400'
                : 'text-gray-600 dark:text-dark-text-secondary hover:text-gray-900 dark:hover:text-white'
        }`}
    >
        {children}
    </button>
);


export const Header: React.FC<HeaderProps> = ({ language, onLanguageChange, theme, toggleTheme, page, onNavigate }) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 h-16 bg-white/80 dark:bg-dark-bg/80 backdrop-blur-lg border-b border-gray-200/80 dark:border-dark-border/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center justify-between">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('landing')}>
          <CosmoCodeIcon className="w-8 h-8" />
          <h1 className="text-xl font-bold text-gray-800 dark:text-white">Cosmo Code</h1>
        </div>

        {page !== 'home' && (
             <nav className="hidden md:flex items-center gap-2">
                <NavLink page="landing" currentPage={page} onNavigate={onNavigate}>Home</NavLink>
                <NavLink page="about" currentPage={page} onNavigate={onNavigate}>About</NavLink>
                <NavLink page="contact" currentPage={page} onNavigate={onNavigate}>Contact</NavLink>
             </nav>
        )}
       

        <div className="flex items-center gap-4">
            {page === 'home' ? (
                 <div className="relative">
                    <select
                        value={language}
                        onChange={(e) => onLanguageChange(e.target.value as Language)}
                        className="appearance-none bg-gray-100 dark:bg-dark-surface border border-gray-300 dark:border-dark-border rounded-md py-2 pl-3 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 text-gray-900 dark:text-dark-text-primary"
                        aria-label="Select programming language"
                    >
                        {LANGUAGE_OPTIONS.map((lang) => (
                        <option key={lang.id} value={lang.id}>
                            {lang.name}
                        </option>
                        ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700 dark:text-gray-400">
                        <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                    </div>
                </div>
            ) : (
                 <button
                    onClick={() => onNavigate('home')}
                    className="hidden sm:flex items-center gap-2 px-4 py-2 bg-primary-500 text-white font-semibold rounded-lg hover:bg-primary-600 disabled:bg-primary-300 transition-all transform hover:scale-105"
                >
                    <CodeIcon className="h-5 w-5" />
                    Launch Editor
                </button>
            )}
         
          <button
            onClick={toggleTheme}
            className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-dark-surface focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-dark-bg focus:ring-primary-500 transition-colors"
            aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
          >
            {theme === 'light' ? <MoonIcon className="h-5 w-5" /> : <SunIcon className="h-5 w-5" />}
          </button>
        </div>
      </div>
    </header>
  );
};