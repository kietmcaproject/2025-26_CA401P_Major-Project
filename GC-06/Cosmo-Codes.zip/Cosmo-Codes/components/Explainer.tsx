import React from 'react';

// This component is not currently used in the application.
// Returning null to prevent it from rendering or causing errors.
export const Explainer: React.FC = () => {
  return null;
};
