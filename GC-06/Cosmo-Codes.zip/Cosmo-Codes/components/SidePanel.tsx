import React, { useState, useRef, useEffect } from 'react';
import { PlayIcon, SparklesIcon, SendIcon, CheckIcon, AlertTriangleIcon, LightbulbIcon, UserIcon, CosmoCodeIcon, InfoIcon, TerminalIcon, OpenAIIcon, ClaudeIcon } from './Icons';
import type { AssistantMessage, Language, DebugResult, ModelName, ModelDebugResult, CodeSuggestion, ModelOptimizationResult } from '../types';
import { CodeDiffBlock } from './CodeDiffBlock';

interface AssistantPanelProps {
  messages: AssistantMessage[];
  language: Language;
  isLoading: boolean;
  onRunCode: () => void;
  onSendMessage: (message: string) => void;
  onExplainFix: (originalCode: string, error: string, suggestion: string) => void;
  onCodeUpdate: (newCode: string) => void;
}

const SuggestionChip: React.FC<{ onClick: () => void, children: React.ReactNode }> = ({ onClick, children }) => (
    <button onClick={onClick} className="text-xs text-primary-600 dark:text-primary-400 bg-primary-100 dark:bg-primary-500/10 px-2 py-1 rounded-full hover:bg-primary-200 dark:hover:bg-primary-500/20 transition-colors">
        {children}
    </button>
);

const SimpleCodeBlock: React.FC<{ code: string; onApply: (code: string) => void }> = ({ code, onApply }) => {
    const [copied, setCopied] = useState(false);
    const handleCopy = () => {
        navigator.clipboard.writeText(code);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="my-2 bg-gray-100 dark:bg-dark-surface rounded-lg border border-gray-200 dark:border-dark-border overflow-hidden">
            <div className="flex justify-end gap-3 px-3 py-1.5 text-xs text-gray-500 dark:text-dark-text-secondary bg-gray-50 dark:bg-dark-bg/50">
                <button onClick={() => onApply(code)} className="font-medium hover:text-primary-500">Apply Code</button>
                <button onClick={handleCopy} className="font-medium hover:text-primary-500">{copied ? 'Copied!' : 'Copy'}</button>
            </div>
            <pre className="p-3 text-sm whitespace-pre-wrap overflow-x-auto">
                <code className="font-mono">{code}</code>
            </pre>
        </div>
    );
};

const FormattedDescription: React.FC<{ text: string }> = ({ text }) => {
    const complexityRegex = /(Time Complexity|Space Complexity):\s*(O\([^\)]+\))/gi;
    const complexities: { key: string; value: string }[] = [];
    
    // Extract complexities and remove them from the main description
    const mainDescription = text.replace(complexityRegex, (match, key, value) => {
        complexities.push({ key: key.trim(), value: value.trim() });
        return ''; // Remove the match from the string
    }).trim();

    return (
        <div>
            <p className="text-sm my-1 text-gray-600 dark:text-dark-text-secondary whitespace-pre-wrap">
                {mainDescription}
            </p>
            {complexities.length > 0 && (
                <div className="flex flex-wrap items-center gap-2 mt-2">
                    {complexities.map((comp, index) => (
                        <div key={index} className="flex items-center gap-1.5 text-xs px-2 py-1 rounded-full bg-gray-100 dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
                            <span className="font-semibold text-gray-600 dark:text-dark-text-secondary">{comp.key}:</span>
                            <span className="font-mono text-gray-800 dark:text-dark-text-primary">{comp.value}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

const ModelResultContent: React.FC<{ originalCode: string, resultData: DebugResult, onExplainFix: (suggestion: string) => void, onCodeUpdate: (code: string) => void }> = ({ originalCode, resultData, onExplainFix, onCodeUpdate }) => (
    <div>
        <h4 className="font-semibold text-gray-800 dark:text-dark-text-primary">{resultData.errorName}</h4>
        <p className="text-sm my-2 text-gray-600 dark:text-dark-text-secondary whitespace-pre-wrap">{resultData.explanation}</p>
        <div className="flex items-center gap-2 mb-2">
            <SuggestionChip onClick={() => onExplainFix(resultData.suggestion)}>
                <LightbulbIcon className="w-3 h-3 inline mr-1" /> Explain This Fix
            </SuggestionChip>
        </div>
        <h5 className="font-semibold mt-3 text-gray-800 dark:text-dark-text-primary">Suggested Fix:</h5>
        <CodeDiffBlock 
            originalCode={originalCode}
            suggestedCode={resultData.suggestion}
            onApply={onCodeUpdate}
        />
        {resultData.alternatives.map((alt, i) => (
             <div key={i} className="mt-3">
                <h5 className="font-semibold text-gray-800 dark:text-dark-text-primary">{alt.title}</h5>
                <FormattedDescription text={alt.description} />
                <SimpleCodeBlock code={alt.code} onApply={onCodeUpdate} />
             </div>
        ))}
    </div>
);

const OptimizationContent: React.FC<{ suggestion: CodeSuggestion, onCodeUpdate: (code: string) => void }> = ({ suggestion, onCodeUpdate }) => (
    <div className="mt-3">
        <h5 className="font-semibold text-gray-800 dark:text-dark-text-primary">{suggestion.title}</h5>
        <FormattedDescription text={suggestion.description} />
        <SimpleCodeBlock code={suggestion.code} onApply={onCodeUpdate} />
    </div>
);


const AnalysisResultCard: React.FC<{ result: AssistantMessage['runResult']; onExplainFix: AssistantPanelProps['onExplainFix']; onCodeUpdate: AssistantPanelProps['onCodeUpdate']; }> = ({ result, onExplainFix, onCodeUpdate }) => {
    if (!result) return null;
    const { success, output, suggestion, optimizationSuggestions, originalCode, isOptimizing } = result;

    const [activeTab, setActiveTab] = useState<ModelName | 'Best'>('Best');

    const modelIcons: Record<ModelName, React.FC<{ className?: string }>> = {
        'Gemini': CosmoCodeIcon,
        'OpenAI': OpenAIIcon,
        'Claude': ClaudeIcon
    };

    const handleExplainFix = (suggestion: string) => {
        onExplainFix(originalCode, output, suggestion);
    };

    const renderTabs = (results: ModelDebugResult[] | ModelOptimizationResult[]) => {
        const availableModels = results.map(r => r.modelName);
        return (
            <div className="flex border-b border-gray-200 dark:border-dark-border mb-4">
                <TabButton name="Best" icon={SparklesIcon} isActive={activeTab === 'Best'} onClick={() => setActiveTab('Best')} />
                {availableModels.map(modelName => (
                    <TabButton key={modelName} name={modelName} icon={modelIcons[modelName]} isActive={activeTab === modelName} onClick={() => setActiveTab(modelName)} />
                ))}
            </div>
        );
    };

    const TabButton: React.FC<{ name: string; icon: React.FC<{ className?: string }>; isActive: boolean; onClick: () => void; }> = ({ name, icon: Icon, isActive, onClick }) => (
        <button onClick={onClick} className={`flex items-center gap-2 px-4 py-2 text-sm font-semibold border-b-2 transition-colors ${isActive ? 'border-primary-500 text-primary-600 dark:text-primary-400' : 'border-transparent text-gray-500 dark:text-dark-text-secondary hover:text-gray-700 dark:hover:text-white'}`}>
            <Icon className="w-4 h-4" />
            <span>{name}</span>
        </button>
    );
    
    return (
        <div className="my-2 p-4 rounded-xl bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
            <div className="flex items-center gap-3">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${success ? 'bg-green-100 dark:bg-green-500/10 text-green-600 dark:text-green-400' : 'bg-red-100 dark:bg-red-500/10 text-red-500 dark:text-red-400'}`}>
                    {success ? <CheckIcon className="w-5 h-5" /> : <AlertTriangleIcon className="w-5 h-5" />}
                </div>
                <h3 className={`font-bold text-lg ${success ? 'text-gray-800 dark:text-dark-text-primary' : 'text-red-500 dark:text-red-400'}`}>
                    {success ? 'Execution Successful' : 'Execution Failed'}
                </h3>
            </div>
            
            {output && (
                <>
                    <div className="flex items-center gap-2 mt-4 mb-2 text-xs text-gray-500 dark:text-dark-text-secondary">
                        <TerminalIcon className="w-4 h-4" />
                        <span className="font-semibold">Console Output</span>
                        <div title="Code is executed by an advanced AI that simulates a real runtime environment.">
                            <InfoIcon className="w-4 h-4 cursor-help" />
                        </div>
                    </div>
                    <pre className="text-xs whitespace-pre-wrap font-mono bg-gray-100 dark:bg-dark-bg p-3 rounded-lg">{output}</pre>
                </>
            )}
            
            {suggestion && (
                <div className="mt-4 pt-4 border-t border-gray-200 dark:border-dark-border">
                    {renderTabs(suggestion.all)}
                    <div className="animate-fade-in">
                        {activeTab === 'Best' && (
                            suggestion.best ? (
                                <ModelResultContent originalCode={originalCode} resultData={suggestion.best} onExplainFix={handleExplainFix} onCodeUpdate={onCodeUpdate} />
                            ) : <p className="text-sm text-gray-500">No single best suggestion could be determined, but you can review individual model responses.</p>
                        )}
                        {suggestion.all.map(modelResult => activeTab === modelResult.modelName && (
                            <div key={modelResult.modelName}>
                                {modelResult.result ? (
                                    <ModelResultContent originalCode={originalCode} resultData={modelResult.result} onExplainFix={handleExplainFix} onCodeUpdate={onCodeUpdate} />
                                ) : <p className="text-sm text-red-500">{modelResult.modelName} API Error: {modelResult.error}</p>}
                            </div>
                        ))}
                    </div>
                </div>
            )}
            
            {isOptimizing && (
                <div className="mt-4 pt-4 border-t border-gray-200 dark:border-dark-border">
                    <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-dark-text-secondary animate-pulse">
                        <SparklesIcon className="w-4 h-4" />
                        <span>Analyzing for optimizations...</span>
                    </div>
                </div>
            )}

            {optimizationSuggestions && (optimizationSuggestions.all.length > 0 || optimizationSuggestions.best) && (
                 <div className="mt-4 pt-4 border-t border-gray-200 dark:border-dark-border">
                    <h4 className="font-semibold text-gray-800 dark:text-dark-text-primary mb-2">Optimization Suggestions</h4>
                     {renderTabs(optimizationSuggestions.all)}
                     <div className="animate-fade-in">
                         {activeTab === 'Best' && (
                             optimizationSuggestions.best ? (
                                 optimizationSuggestions.best.map((opt, i) => <OptimizationContent key={i} suggestion={opt} onCodeUpdate={onCodeUpdate} />)
                             ) : <p className="text-sm text-gray-500">No single best optimization could be determined. Please review the individual model suggestions.</p>
                         )}
                         {optimizationSuggestions.all.map(modelResult => activeTab === modelResult.modelName && (
                             <div key={modelResult.modelName}>
                                 {modelResult.result && modelResult.result.length > 0 ? (
                                     modelResult.result.map((opt, i) => <OptimizationContent key={i} suggestion={opt} onCodeUpdate={onCodeUpdate} />)
                                 ) : modelResult.error ? (
                                    <p className="text-sm text-red-500">{modelResult.modelName} API Error: {modelResult.error}</p>
                                 ) : (
                                    <p className="text-sm text-gray-500">{modelResult.modelName} did not provide any suggestions.</p>
                                 )}
                             </div>
                         ))}
                     </div>
                </div>
            )}
        </div>
    );
};


const MessageDisplay: React.FC<{ message: AssistantMessage; onExplainFix: AssistantPanelProps['onExplainFix']; onCodeUpdate: AssistantPanelProps['onCodeUpdate']; }> = ({ message, onExplainFix, onCodeUpdate }) => {
    const { role, content, runResult } = message;

    const Avatar: React.FC<{ role: 'user' | 'model' }> = ({ role }) => (
        <div className={`flex items-center justify-center w-8 h-8 rounded-full self-start ${role === 'user' ? 'bg-gray-200 dark:bg-gray-700' : 'bg-primary-500'}`}>
            {role === 'user' ? <UserIcon className="w-5 h-5 text-gray-600 dark:text-gray-300" /> : <CosmoCodeIcon className="w-6 h-6 p-0.5 text-white" />}
        </div>
    );

    if (role === 'system') {
        return <AnalysisResultCard result={runResult} onExplainFix={onExplainFix} onCodeUpdate={onCodeUpdate} />;
    }

    const isUser = role === 'user';
    const messageAlignment = isUser ? 'justify-end' : 'justify-start';
    const messageContainerStyle = isUser ? 'flex-row-reverse' : 'flex-row';
    const bubbleStyle = isUser 
        ? 'bg-primary-500 text-white rounded-br-none'
        : 'bg-white dark:bg-dark-surface text-gray-800 dark:text-dark-text-primary border border-gray-200 dark:border-dark-border rounded-bl-none';

    return (
        <div className={`flex ${messageAlignment} w-full`}>
            <div className={`flex ${messageContainerStyle} gap-3 items-start max-w-xl`}>
                {!isUser && <Avatar role="model" />}
                <div className={`p-3 rounded-xl ${bubbleStyle}`}>
                    <div className="prose prose-sm dark:prose-invert max-w-none prose-p:my-1 prose-pre:my-2 prose-pre:bg-gray-100 dark:prose-pre:bg-dark-bg prose-pre:p-3 prose-pre:rounded-lg" dangerouslySetInnerHTML={{ __html: content.replace(/```(\w*)\n([\s\S]*?)```/g, '<pre><code>$2</code></pre>') }} />
                </div>
            </div>
        </div>
    );
};


export const SidePanel: React.FC<AssistantPanelProps> = ({ messages, language, isLoading, onRunCode, onSendMessage, onExplainFix, onCodeUpdate }) => {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    onSendMessage(input);
    setInput('');
  };

  return (
    <div className="flex flex-col h-full bg-gray-50 dark:bg-dark-bg text-gray-900 dark:text-dark-text-primary">
      <div className="p-3 border-b border-gray-200 dark:border-dark-border">
        <button
          onClick={onRunCode}
          disabled={isLoading}
          className="group w-full flex items-center justify-center gap-2 px-4 py-1.5 bg-primary-500 text-white text-sm font-semibold rounded-lg hover:bg-primary-600 disabled:opacity-50 transition-all duration-200 ease-in-out transform hover:scale-[1.03] active:scale-[0.98] hover:shadow-md hover:shadow-primary-500/40"
        >
          <PlayIcon className="h-5 w-5 transition-transform duration-200 group-hover:rotate-12" />
          {isLoading ? 'Running...' : 'Run Code'}
        </button>
      </div>
      
      <div className="flex-1 p-4 overflow-y-auto">
        {messages.length === 0 && !isLoading ? (
            <div className="flex flex-col items-center justify-center h-full text-center text-gray-400 dark:text-gray-500 p-4">
                <CosmoCodeIcon className="w-16 h-16 mb-4" />
                <h2 className="text-lg font-semibold text-gray-700 dark:text-dark-text-primary">Ready to Analyze?</h2>
                <p className="mt-1 text-sm">
                    Write some code in the editor and click <span className="font-semibold text-primary-500 dark:text-primary-400">Run Code</span>.
                </p>
                <p className="mt-1 text-sm">
                    Your results and AI feedback will appear here.
                </p>
            </div>
        ) : (
            <div className="space-y-4">
                {messages.map((msg) => (
                    <MessageDisplay key={msg.id} message={msg} onExplainFix={onExplainFix} onCodeUpdate={onCodeUpdate} />
                ))}
            </div>
        )}

        {isLoading && messages[messages.length - 1]?.role === 'user' && (
             <div className="flex justify-start pt-4">
                 <div className="flex flex-row gap-3 items-start max-w-xl">
                    <div className={`flex items-center justify-center w-8 h-8 rounded-full self-start bg-primary-500`}>
                        <CosmoCodeIcon className="w-6 h-6 p-0.5 text-white" />
                    </div>
                    <div className="p-3 rounded-xl bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
                        <div className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                            <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></div>
                        </div>
                    </div>
                 </div>
            </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t border-gray-200 dark:border-dark-border bg-white dark:bg-dark-bg/80">
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`Ask a follow-up question...`}
            className="flex-1 bg-gray-100 dark:bg-dark-surface border border-gray-300 dark:border-dark-border rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary-500"
            disabled={isLoading}
          />
          <button type="submit" disabled={isLoading || !input.trim()} className="p-2.5 rounded-full bg-primary-500 text-white disabled:opacity-50 hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors">
            {isLoading ? <SparklesIcon className="h-5 w-5 animate-pulse" /> : <SendIcon className="h-5 w-5" />}
          </button>
        </form>
      </div>
    </div>
  );
};