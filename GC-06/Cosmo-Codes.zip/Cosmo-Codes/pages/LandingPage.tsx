import React from 'react';
import type { Page } from '../types';
import { CosmoCodeIcon, ZapIcon, BookOpenIcon, CodeIcon, SparklesIcon, BugIcon, MessageSquareIcon } from '../components/Icons';

interface LandingPageProps {
  onNavigate: (page: Page) => void;
}

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode; delay: number }> = ({ icon, title, children, delay }) => (
    <div className="bg-white dark:bg-dark-surface p-6 rounded-xl shadow-lg hover:shadow-primary-500/20 hover:-translate-y-2 transition-all duration-300 border border-gray-200 dark:border-dark-border" style={{ animationDelay: `${delay * 0.1}s`, animationFillMode: 'backwards' }}>
      <div className="flex items-center justify-center w-12 h-12 bg-primary-100 dark:bg-primary-500/10 rounded-full text-primary-600 dark:text-primary-300 mb-4">
        {icon}
      </div>
      <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-2">{title}</h3>
      <p className="text-gray-600 dark:text-dark-text-secondary text-sm">{children}</p>
    </div>
  );

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  return (
    <div className="animate-fade-in">
        {/* Hero Section */}
        <div className="relative text-center py-24 sm:py-32 px-4 overflow-hidden">
             <div className="absolute inset-0 bg-grid-gray-200/50 dark:bg-grid-gray-700/20 [mask-image:linear-gradient(to_bottom,white_50%,transparent_100%)] dark:[mask-image:linear-gradient(to_bottom,rgba(11,17,32,1)_40%,transparent_100%)]"></div>
             <CosmoCodeIcon className="w-24 h-24 mx-auto mb-4 animate-float" />
             <h1 className="text-5xl sm:text-7xl font-extrabold tracking-tight bg-gradient-to-r from-primary-600 via-blue-500 to-purple-600 gradient-text">
                Cosmo Code
             </h1>
             <h2 className="text-4xl sm:text-6xl font-extrabold text-gray-800 dark:text-gray-200 tracking-tight mt-2">
                Your AI Coding Analyzer
             </h2>
            <p className="mt-6 max-w-2xl mx-auto text-lg text-gray-600 dark:text-dark-text-secondary">
                Debug, learn, and optimize your code in any language with a powerful AI companion by your side. Go from error to excellence in seconds.
            </p>
            <button
                onClick={() => onNavigate('home')}
                className="mt-8 relative group inline-flex items-center justify-center px-8 py-3 text-lg font-bold text-white bg-gradient-to-r from-primary-600 to-blue-500 rounded-lg overflow-hidden shadow-2xl transition-transform transform hover:scale-105"
            >
                 <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent group-hover:animate-shimmer" style={{ backgroundSize: '200% 100%' }}></span>
                 <SparklesIcon className="w-5 h-5 mr-3" />
                 Start Analyzing for Free
            </button>
        </div>

        {/* Features Section */}
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 dark:text-white">A Smarter Way to Code</h2>
                <p className="mt-2 max-w-2xl mx-auto text-md text-gray-600 dark:text-dark-text-secondary">
                    Cosmo Code provides a suite of powerful features designed for a seamless learning journey.
                </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
              <FeatureCard icon={<BugIcon className="w-6 h-6" />} title="Instant Debugging" delay={1}>
                Don't get stuck. Our AI instantly analyzes your code, explains the problem in simple terms, and provides multiple corrected solutions.
              </FeatureCard>
              <FeatureCard icon={<BookOpenIcon className="w-6 h-6" />} title="In-Depth Explanations" delay={2}>
                Curious how code works? Let our AI provide a detailed, line-by-line explanation of the logic, syntax, and concepts.
              </FeatureCard>
              <FeatureCard icon={<CodeIcon className="w-6 h-6" />} title="Multi-Language Support" delay={3}>
                Master multiple languages without switching platforms. Practice and learn in Python, JavaScript, C++, and Java, all in one place.
              </FeatureCard>
               <FeatureCard icon={<ZapIcon className="w-6 h-6" />} title="Optimization Suggestions" delay={4}>
                Write more efficient code. After a successful run, get suggestions on how to optimize your code for better performance and readability.
              </FeatureCard>
               <FeatureCard icon={<MessageSquareIcon className="w-6 h-6" />} title="Conversational Learning" delay={5}>
                Ask follow-up questions and chat with the AI tutor. It understands the context of your code, providing relevant and helpful answers.
              </FeatureCard>
               <FeatureCard icon={<SparklesIcon className="w-6 h-6" />} title="AI-Powered Refactoring" delay={6}>
                Transform your code with a single prompt. Ask the AI to add features, refactor logic, or convert your code to another language.
              </FeatureCard>
            </div>
        </div>
    </div>
  );
};