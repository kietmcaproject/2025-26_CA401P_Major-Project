import React, { useState, useCallback, useEffect } from 'react';
import Split from 'react-split';
import { CodeEditor } from '../components/CodeEditor';
import { SidePanel } from '../components/SidePanel';
import { InputPromptModal } from '../components/InputPromptModal';
import { Language, AssistantMessage, Theme, ModelDebugResult, DebugResult, ModelOptimizationResult, CodeSuggestion } from '../types';
import { LANGUAGE_OPTIONS } from '../constants';
import { runCode, getDebugSuggestion, getOptimizationSuggestions, streamExplainFix, streamChatResponse, checkForInputNeeded } from '../services/geminiService';
import { getOpenAIDebugSuggestion, getOpenAIOptimizationSuggestions } from '../services/openAIService';
import { getClaudeDebugSuggestion, getClaudeOptimizationSuggestions } from '../services/claudeService';


const cleanCodeSnippet = (code: string): string => {
  const match = code.match(/(?:```|''')(?:[a-zA-Z]+)?\n?([\s\S]+?)\n?(?:```|''')/);
  if (match && match[1]) {
    return match[1].trim();
  }
  return code.trim();
};

const LANGUAGE_OPTIONS_MAP = Object.fromEntries(
  LANGUAGE_OPTIONS.map(opt => [opt.id, opt.name])
) as Record<Language, string>;

// Helper function to detect rate limit errors from the API response.
const isRateLimitError = (error: unknown): boolean => {
  const errorString = error instanceof Error ? error.toString() : JSON.stringify(error);
  return errorString.includes('429') || errorString.includes('RESOURCE_EXHAUSTED');
};

const findBestDebugSuggestion = (results: ModelDebugResult[]): DebugResult | null => {
    // Basic strategy: return the first successful result.
    // This can be enhanced later to compare complexity, conciseness, etc.
    return results.find(r => r.result)?.result || null;
}

// --- Complexity Analysis Algorithm ---
const COMPLEXITY_ORDER = ['O(1)', 'O(log n)', 'O(n)', 'O(n log n)', 'O(n^2)', 'O(2^n)', 'O(n!)'];
const getComplexityRank = (complexity: string | null): number => {
  if (!complexity) return Infinity;
  const rank = COMPLEXITY_ORDER.indexOf(complexity);
  return rank === -1 ? Infinity : rank;
};

const parseComplexity = (description: string): { time: string | null; space: string | null } => {
    const timeMatch = description.match(/Time Complexity:\s*(O\([^\)]+\))/i);
    const spaceMatch = description.match(/Space Complexity:\s*(O\([^\)]+\))/i);
    return {
        time: timeMatch ? timeMatch[1] : null,
        space: spaceMatch ? spaceMatch[1] : null,
    };
};

const findBestOptimization = (results: ModelOptimizationResult[]): CodeSuggestion[] | null => {
    let bestSuggestions: CodeSuggestion[] | null = null;
    let bestTimeRank = Infinity;
    let bestSpaceRank = Infinity;

    for (const modelResult of results) {
        if (!modelResult.result || modelResult.result.length === 0) continue;
        const suggestion = modelResult.result[0];
        const { time, space } = parseComplexity(suggestion.description);
        const timeRank = getComplexityRank(time);
        const spaceRank = getComplexityRank(space);

        if (timeRank < bestTimeRank) {
            bestTimeRank = timeRank;
            bestSpaceRank = spaceRank;
            bestSuggestions = modelResult.result;
        } else if (timeRank === bestTimeRank && spaceRank < bestSpaceRank) {
            bestSpaceRank = spaceRank;
            bestSuggestions = modelResult.result;
        }
    }
    
    if (!bestSuggestions) {
        const firstValidResult = results.find(r => r.result && r.result.length > 0);
        return firstValidResult?.result || null;
    }
    return bestSuggestions;
};
// --- End Complexity Analysis Algorithm ---


interface HomePageProps {
    language: Language;
    code: string;
    setCode: (code: string) => void;
    theme: Theme;
}

export const HomePage: React.FC<HomePageProps> = ({ language, code, setCode, theme }) => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [messages, setMessages] = useState<AssistantMessage[]>([]);
  const [inputPrompt, setInputPrompt] = useState<{ message: string; onConfirm: (input: string) => void; onCancel: () => void; } | null>(null);
  const [lastOptimizedCode, setLastOptimizedCode] = useState<string | null>(null);

  useEffect(() => {
    setMessages([]);
    setLastOptimizedCode(null);
  }, [language]);

  const proceedWithExecution = useCallback(async (userInput?: string) => {
    const runningMessage: AssistantMessage = {
      id: Date.now().toString(),
      role: 'system',
      content: 'Running code...',
      timestamp: Date.now(),
      runResult: { success: false, originalCode: code, output: 'Running...'}
    };
    setMessages(prev => [...prev, runningMessage]);

    try {
      // Step 1: Run code and get immediate output.
      const result = await runCode(language, code, userInput);
      
      if (result.success) {
        const shouldOptimize = code !== lastOptimizedCode;

        // On success, show result immediately and load optimizations in the background.
        const systemMessage: AssistantMessage = {
            id: runningMessage.id,
            role: 'system',
            content: 'Execution successful.',
            timestamp: Date.now(),
            runResult: {
                originalCode: code,
                success: true,
                output: result.output || 'Code executed successfully with no output.',
                isOptimizing: shouldOptimize,
            },
        };
        setMessages(prev => prev.map(m => m.id === runningMessage.id ? systemMessage : m));
        
        if (shouldOptimize) {
            setLastOptimizedCode(code);

            const optimizationPromises = [
                getOptimizationSuggestions(language, code),
                getOpenAIOptimizationSuggestions(language, code),
                getClaudeOptimizationSuggestions(language, code),
            ];

            Promise.allSettled(optimizationPromises)
                .then(promiseResults => {
                    const allOptimizations: ModelOptimizationResult[] = promiseResults.map((res, index): ModelOptimizationResult => {
                        const modelName = ['Gemini', 'OpenAI', 'Claude'][index] as 'Gemini' | 'OpenAI' | 'Claude';
                        if (res.status === 'fulfilled') {
                            const suggestions = res.value;
                            suggestions.forEach(sugg => { sugg.code = cleanCodeSnippet(sugg.code); });
                            return { modelName, result: suggestions };
                        } else {
                            return { modelName, error: res.reason?.message || 'Unknown error' };
                        }
                    });

                    const bestOptimization = findBestOptimization(allOptimizations);
                    
                    setMessages(prev => prev.map(m => 
                        m.id === systemMessage.id 
                        ? { ...m, runResult: { ...m.runResult!, optimizationSuggestions: { all: allOptimizations, best: bestOptimization }, isOptimizing: false } } 
                        : m
                    ));
                })
                .catch(err => {
                    console.error("Failed to get optimization suggestions:", err);
                    setMessages(prev => prev.map(m =>
                        m.id === systemMessage.id
                        ? { ...m, runResult: { ...m.runResult!, isOptimizing: false } }
                        : m
                    ));
                });
        }

      } else { 
        // On failure, get debug suggestions from all models in parallel.
        const suggestionPromises = [
            getDebugSuggestion(language, code, result.output),
            getOpenAIDebugSuggestion(language, code, result.output),
            getClaudeDebugSuggestion(language, code, result.output),
        ];

        const promiseResults = await Promise.allSettled(suggestionPromises);
        
        const allSuggestions: ModelDebugResult[] = promiseResults.map((res, index): ModelDebugResult => {
            const modelName = ['Gemini', 'OpenAI', 'Claude'][index] as 'Gemini' | 'OpenAI' | 'Claude';
            if (res.status === 'fulfilled') {
                const suggestion = res.value;
                suggestion.suggestion = cleanCodeSnippet(suggestion.suggestion);
                suggestion.alternatives.forEach(alt => { alt.code = cleanCodeSnippet(alt.code); });
                return { modelName, result: suggestion };
            } else {
                return { modelName, error: res.reason?.message || 'Unknown error' };
            }
        });

        const bestSuggestion = findBestDebugSuggestion(allSuggestions);

        // Create a single message with both the error and all fixes.
        const systemMessage: AssistantMessage = {
            id: runningMessage.id,
            role: 'system',
            content: 'Execution failed.',
            timestamp: Date.now(),
            runResult: {
                originalCode: code,
                success: false,
                output: result.output,
                suggestion: {
                    all: allSuggestions,
                    best: bestSuggestion
                },
            },
        };
        setMessages(prev => prev.map(m => m.id === runningMessage.id ? systemMessage : m));
      }

    } catch (error) {
      console.error(error);
      const errorOutput = isRateLimitError(error)
        ? `API Rate Limit Exceeded\n\nYou've made too many requests in a short period. Please wait a moment before trying again.\n\nIf the issue persists, check your API key usage and billing details.`
        : `An unexpected error occurred. Please check the console for details.`;

      const errorMessage: AssistantMessage = {
        id: runningMessage.id,
        role: 'system',
        content: `An error occurred: ${error instanceof Error ? error.message : 'Unknown error'}`,
        timestamp: Date.now(),
        runResult: {
            originalCode: code,
            success: false,
            output: errorOutput,
        }
      };
      setMessages(prev => prev.map(m => m.id === runningMessage.id ? errorMessage : m));
    } finally {
      setIsLoading(false);
    }
  }, [language, code, lastOptimizedCode]);

  const handleRunCode = useCallback(async () => {
    setIsLoading(true);
    
    // Clear previous system messages
    setMessages(prev => prev.filter(m => m.role !== 'system'));

    try {
      const checkResult = await checkForInputNeeded(language, code);

      if (checkResult.requiresInput) {
        setInputPrompt({
          message: checkResult.prompt || "This code requires user input to run.",
          onConfirm: (userInput: string) => {
            setInputPrompt(null);
            proceedWithExecution(userInput);
          },
          onCancel: () => {
            setInputPrompt(null);
            setIsLoading(false);
          },
        });
      } else {
        proceedWithExecution();
      }
    } catch (error) {
      console.error("Input check error:", error);
       const errorOutput = isRateLimitError(error)
        ? `API Rate Limit Exceeded\n\nThe code analysis could not be completed. Please wait a moment before trying again.`
        : `An error occurred during code analysis: ${error instanceof Error ? error.message : 'Unknown error'}`;

      const errorMessage: AssistantMessage = {
        id: Date.now().toString(),
        role: 'system',
        content: 'Code analysis failed.',
        timestamp: Date.now(),
        runResult: {
            originalCode: code,
            success: false,
            output: errorOutput
        }
      };
      setMessages(prev => [...prev, errorMessage]);
      setIsLoading(false);
    }
  }, [language, code, proceedWithExecution]);
  
  const handleExplainFix = useCallback(async (originalCode: string, error: string, suggestion: string) => {
    setIsLoading(true);
    const modelMessageId = Date.now().toString();
    const modelMessage: AssistantMessage = { id: modelMessageId, role: 'model', content: '', timestamp: Date.now() };
    setMessages(prev => [...prev, modelMessage]);

    try {
        await streamExplainFix(language, originalCode, error, suggestion, (chunk) => {
            setMessages(prev => prev.map(m => 
                m.id === modelMessageId ? { ...m, content: m.content + chunk } : m
            ));
        });
    } catch (e) {
        console.error("Explanation error:", e);
        const errorContent = isRateLimitError(e)
            ? 'Sorry, I couldn\'t generate an explanation due to a rate limit. Please wait a moment and try again.'
            : 'Sorry, I encountered an error while generating the explanation.';
        setMessages(prev => prev.map(m => 
            m.id === modelMessageId ? { ...m, content: errorContent } : m
        ));
    } finally {
        setIsLoading(false);
    }
  }, [language]);

  const handleSendMessage = useCallback(async (message: string) => {
    setIsLoading(true);
    const userMessage: AssistantMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: message,
      timestamp: Date.now(),
    };
    const currentHistory = [...messages.filter(m => m.role !== 'system'), userMessage];
    setMessages(currentHistory);

    const modelMessageId = (Date.now() + 1).toString();
    const modelMessage: AssistantMessage = { id: modelMessageId, role: 'model', content: '', timestamp: Date.now() };
    setMessages(prev => [...prev, modelMessage]);
    
    try {
      await streamChatResponse(language, code, currentHistory, message, (chunk) => {
        setMessages(prev => prev.map(m =>
          m.id === modelMessageId ? { ...m, content: m.content + chunk } : m
        ));
      });
    } catch (e) {
      console.error("Chat error:", e);
      const errorContent = isRateLimitError(e)
            ? 'Sorry, I couldn\'t respond due to a rate limit. Please wait a moment and try again.'
            : 'Sorry, I encountered an error. Please try again.';
      setMessages(prev => prev.map(m =>
          m.id === modelMessageId ? { ...m, content: errorContent } : m
      ));
    } finally {
      setIsLoading(false);
    }

  }, [language, code, messages]);

  return (
    <div className="h-full bg-white dark:bg-gray-900">
        <Split
          className="flex h-full"
          sizes={[60, 40]}
          minSize={300}
          expandToMin={false}
          gutterSize={10}
          gutterAlign="center"
          snapOffset={30}
          dragInterval={1}
          direction="horizontal"
          cursor="col-resize"
        >
          <div className="h-full overflow-hidden">
            <CodeEditor
              code={code}
              onCodeChange={setCode}
              language={language}
              theme={theme}
            />
          </div>
          <div className="h-full overflow-hidden">
            <SidePanel
                messages={messages}
                language={language}
                isLoading={isLoading}
                onRunCode={handleRunCode}
                onSendMessage={handleSendMessage}
                onExplainFix={handleExplainFix}
                onCodeUpdate={setCode}
            />
          </div>
        </Split>
      {inputPrompt && (
        <InputPromptModal
            message={inputPrompt.message}
            onConfirm={inputPrompt.onConfirm}
            onCancel={inputPrompt.onCancel}
        />
      )}
    </div>
  );
};