
export enum Language {
  PYTHON = 'python',
  JAVASCRIPT = 'javascript',
  CPP = 'cpp',
  JAVA = 'java',
}

export interface CodeSuggestion {
  title: string;
  description: string;
  code: string;
}

export interface DebugResult {
  errorName: string;
  explanation: string;
  suggestion: string;
  alternatives: CodeSuggestion[];
}

export type ModelName = 'Gemini' | 'OpenAI' | 'Claude';

export interface ModelDebugResult {
  modelName: ModelName;
  result?: DebugResult;
  error?: string;
}
export interface ModelOptimizationResult {
  modelName: ModelName;
  result?: CodeSuggestion[];
  error?: string;
}


// A unified message type for the new assistant panel.
export interface AssistantMessage {
  id: string;
  role: 'user' | 'model' | 'system';
  // Content can be markdown.
  content: string;
  timestamp: number;
  // This field holds data for special system messages, like code execution results.
  runResult?: {
    success: boolean;
    originalCode: string;
    // This will be the console output on success, or the error message on failure.
    output: string;
    // The AI's suggested fix, only present on failure.
    suggestion?: {
      all: ModelDebugResult[];
      best: DebugResult | null;
    };
    // The AI's optimization suggestions, only present on the first successful run.
    optimizationSuggestions?: {
      all: ModelOptimizationResult[];
      best: CodeSuggestion[] | null;
    };
    isOptimizing?: boolean;
  };
}

export type Theme = 'light' | 'dark';

// FIX: Added Page type to be used for navigation across components.
export type Page = 'home' | 'about' | 'contact' | 'landing';