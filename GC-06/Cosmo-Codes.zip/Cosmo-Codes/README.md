# Cosmo Code

Cosmo Code is an interactive, real-time coding tutor powered by the Gemini API. It helps users practice coding, get instant AI-powered debugging assistance, and clarify doubts across multiple programming languages like Python, Java, C++, and JavaScript.

## Features

- **Multi-Language Support:** Practice coding in Python, JavaScript, C++, and Java.
- **AI-Powered Debugging:** Get instant, clear explanations for your code errors and suggested fixes.
- **Code Explanation:** Select a piece of code and get a step-by-step explanation from the AI.
- **Interactive Chat:** Ask follow-up questions and get help from an AI tutor that is aware of your current code.
- **Light & Dark Mode:** A comfortable viewing experience in any lighting.
- **Responsive Design:** Works on various screen sizes.

## How to Run Locally

This project is now configured with the API key you provided, making it fully functional.

**IMPORTANT SECURITY NOTE:** Your API key has been added directly to `services/geminiService.ts`. To protect your key, avoid committing this file to public version control systems like GitHub.

### 1. Prerequisites

- A modern web browser (like Chrome, Firefox, or Edge).
- A code editor. [Visual Studio Code](https://code.visualstudio.com/) is recommended.
- The [Live Server extension for VS Code](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer). This makes it easy to run the project.

### 2. Running the Application

1.  Download or clone the project files to your local machine.
2.  Open the project folder in Visual Studio Code.
3.  Right-click on the `index.html` file in the VS Code file explorer.
4.  Select **"Open with Live Server"**.
5.  Your browser will open with the application running.

## Technology Stack

- **HTML, CSS, JavaScript/TypeScript**
- **React:** For building the user interface.
- **Tailwind CSS:** For styling.
- **Monaco Editor:** The code editor that powers VS Code.
- **Google Gemini API:** For all AI-powered features.