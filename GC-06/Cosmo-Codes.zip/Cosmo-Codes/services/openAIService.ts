// FIX: The 'Language' enum is used as a value, so it must be imported directly, not as a type.
import { Language, type DebugResult, type CodeSuggestion } from "../types";

// NEVER store API keys in code.
// Use Vite environment variable instead.
const OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY;

/**
 * MOCKED FUNCTION: This function simulates a call to the OpenAI API.
 * Replace this with a real `fetch` call to the OpenAI API endpoint.
 */
export const getOpenAIDebugSuggestion = async (
  language: Language,
  code: string,
  error: string
): Promise<DebugResult> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));

  return {
    errorName: "OpenAI: Syntax Error",
    explanation:
      "OpenAI's model identified that the print statement is missing parentheses. Wrap the text in parentheses.",
    suggestion: `print("Hello, World!")  # FIX: OpenAI suggests adding parentheses.`,
    alternatives: [
      {
        title: "Optimized Version",
        description:
          "For printing a single string, this is already optimal. Time Complexity: O(1), Space Complexity: O(1).",
        code: `if __name__ == "__main__":\n    print("Hello, World!")`
      },
      {
        title: "Concise Version",
        description:
          "Using f-strings for variable interpolation is modern and concise.",
        code: `greeting = "World"\nprint(f"Hello, {greeting}!")`
      }
    ]
  };
};

export const getOpenAIOptimizationSuggestions = async (
  language: Language,
  code: string
): Promise<CodeSuggestion[]> => {
  await new Promise(resolve => setTimeout(resolve, 500));

  if (language === Language.PYTHON && code.trim().startsWith("print(")) {
    return [
      {
        title: "Optimized Version (Using f-strings)",
        description:
          "Using f-strings is a modern and efficient technique. Time Complexity: O(1), Space Complexity: O(1).",
        code: `message = "Hello, World!"\nprint(f"{message}")`
      }
    ];
  }

  return [
    {
      title: "Optimized Version (List Comprehension)",
      description:
        "List comprehensions are more Pythonic and faster for simple loops. Time Complexity: O(n), Space Complexity: O(n).",
      code: `squares = [i*i for i in range(10)]\nfor s in squares:\n    print(s)`
    }
  ];
};
