// FIX: The 'Language' enum is used as a value, so it must be imported directly, not as a type.
import { Language, type DebugResult, type CodeSuggestion } from "../types";

const CLAUDE_API_KEY = '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';

/**
 * MOCKED FUNCTION: This function simulates a call to the Anthropic Claude API.
 * Replace this with a real `fetch` call to the Claude API endpoint.
 * You'll need to adapt the prompt from `geminiService.ts` to the format
 * expected by the Claude Messages API.
 */
export const getClaudeDebugSuggestion = async (language: Language, code: string, error: string): Promise<DebugResult> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 600));
  
  // To test error states, you can uncomment the following line:
  // if (Math.random() > 0.5) throw new Error("Claude API key is invalid.");

  // Return a sample DebugResult object.
  return {
    errorName: "Claude: Missing Parentheses",
    explanation: "According to Claude's analysis, the 'print' keyword is a function in modern Python and requires its arguments to be enclosed in parentheses.",
    suggestion: `print("Hello, World!") # FIX: Claude identified missing parentheses.`,
    alternatives: [
      {
        title: "Optimized Version",
        description: "This is already optimally efficient. Time Complexity: O(1), Space Complexity: O(1).",
        code: `def main():\n    # It is good practice to wrap code in a function\n    print("Hello, World!")\n\nmain()`
      },
      {
        title: "Concise Version",
        description: "The original fix is as concise as possible for this specific task.",
        code: `print("Hello, World!")`
      }
    ]
  };
};

export const getClaudeOptimizationSuggestions = async (language: Language, code: string): Promise<CodeSuggestion[]> => {
    await new Promise(resolve => setTimeout(resolve, 600));
    
    // Smarter mock: Check for simple print statements.
    if (language === Language.PYTHON && code.trim().startsWith('print(')) {
        return [{
            title: "Optimized Version (Main Guard)",
            description: "It's a best practice in Python to place executable code inside a `if __name__ == '__main__':` block. This ensures the code doesn't run when the file is imported as a module. Time Complexity: O(1), Space Complexity: O(1).",
            code: `if __name__ == "__main__":\n    print("Hello, World!")`
        }];
    }

    // Default mock response for more complex code.
    return [
       {
        title: "Optimized Version (Generator Expression)",
        description: "Using a generator expression avoids creating the full list in memory at once, which is more memory-efficient. Time Complexity: O(n), Space Complexity: O(1).",
        code: `squares_generator = (i*i for i in range(10))\nfor s in squares_generator:\n    print(s)`
      }
    ];
};