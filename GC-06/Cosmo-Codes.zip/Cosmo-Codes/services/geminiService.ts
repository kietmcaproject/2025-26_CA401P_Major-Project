import { GoogleGenAI, Type } from "@google/genai";
import type { Language, AssistantMessage, DebugResult, CodeSuggestion } from "../types";

// NOTE: The application now supports multiple models.
// Each model has its own service file.
const GEMINI_API_KEY = 'AIzaSyDg83IIiU-d5pl-2m_o7PSd_OopPhaJd9w';


// Initialize the GoogleGenAI client with the provided API key.
const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });

export const checkForInputNeeded = async (language: Language, code: string): Promise<{ requiresInput: boolean, prompt: string }> => {
    const prompt = `Analyze the following ${language} code snippet. Determine if it requires any user input from stdin to run (e.g., from Python's \`input()\`, Java's \`Scanner\`, C++'s \`cin\`).

Code:
\`\`\`${language}
${code}
\`\`\`

If it requires input, create a short, friendly prompt message to ask the user for that input. For example, if the code is \`name = input("Enter your name:")\`, a good prompt would be "Enter your name:". If there's no specific prompt in the code, create a generic one like "Please provide the necessary input to run the code."

If the code does *not* require any user input to run, the prompt should be an empty string.

Your response MUST be a JSON object with two fields:
1.  "requiresInput": a boolean, \`true\` if input is needed, \`false\` otherwise.
2.  "prompt": a string containing the user-friendly prompt message, or an empty string.
`;

    const checkSchema = {
        type: Type.OBJECT,
        properties: {
            requiresInput: { type: Type.BOOLEAN },
            prompt: { type: Type.STRING },
        },
        required: ['requiresInput', 'prompt'],
    };

    const response = await ai.models.generateContent({
        model: "gemini-flash-latest",
        contents: prompt,
        config: {
            systemInstruction: "You are an expert code analyst. Your task is to determine if a code snippet requires user input and respond in a specific JSON format.",
            responseMimeType: "application/json",
            responseSchema: checkSchema,
        },
    });

    try {
        const result = JSON.parse(response.text.trim());
        return result as { requiresInput: boolean, prompt: string };
    } catch (e) {
        console.error("Failed to parse Gemini input check response:", response.text);
        return { requiresInput: false, prompt: '' }; // Fallback
    }
}

const runPrompt = (language: Language, code: string, userInput: string | undefined): string => `
You are a world-class code interpreter for ${language}.

Your task is to simulate the execution of the provided code snippet.

---
**CODE TO PROCESS**
\`\`\`${language}
${code}
\`\`\`

${userInput ? `
---
**USER INPUT (stdin)**
Use the following value(s) as standard input for the code. Do not prompt for it.
${userInput}
---
` : ''}

**RESPONSE INSTRUCTIONS**
Your response MUST be a single JSON object with two fields:
1. "success": a boolean, \`true\` if execution completes without errors, \`false\` otherwise.
2. "output": a string containing the complete standard output if successful, or the full, complete error message if it fails.
`;

const runSchema = {
    type: Type.OBJECT,
    properties: {
        success: { type: Type.BOOLEAN },
        output: { type: Type.STRING },
    },
    required: ['success', 'output'],
};

export interface RunResult {
    success: boolean;
    output: string;
}

export const runCode = async (language: Language, code: string, userInput: string | undefined): Promise<RunResult> => {
    const prompt = runPrompt(language, code, userInput);
    const response = await ai.models.generateContent({
        model: "gemini-flash-latest",
        contents: prompt,
        config: {
            systemInstruction: `You are a world-class code interpreter for ${language}. Your task is to simulate the execution of the provided code snippet and return a JSON object with the result.`,
            responseMimeType: "application/json",
            responseSchema: runSchema,
        },
    });

    try {
        const result = JSON.parse(response.text.trim());
        return result as RunResult;
    } catch (e) {
        console.error("Failed to parse Gemini run response:", response.text);
        return {
            success: false,
            output: "Error: The AI code interpreter failed to provide a valid response.",
        };
    }
};

const debugPrompt = (language: Language, code: string, error: string): string => `
You are a friendly coding tutor for ${language}. A student's code has failed. Your task is to provide a full debugging analysis.

---
**CODE THAT FAILED**
\`\`\`${language}
${code}
\`\`\`

---
**ERROR MESSAGE**
\`\`\`
${error}
\`\`\`

---
**RESPONSE INSTRUCTIONS**
Your response MUST be a single JSON object containing:
- "errorName": A short name for the error.
- "explanation": A beginner-friendly explanation of what the error is and a clear, one-sentence summary of how to fix it. For example: "This error occurs because 'print' is a function in this version of Python and requires parentheses. The fix is to enclose 'Hello, World!' in parentheses."
- "suggestion": The corrected code snippet. You MUST modify the original "CODE THAT FAILED" as minimally as possible to fix the error. Only return the corrected code block. Do NOT add any example usage, main function calls, or other boilerplate unless it was part of the original code that failed.
- "alternatives": An array of two alternative implementations (one optimized, one concise).

---
**CODE QUALITY RULES (For ALL generated code suggestions):**
- **Minimalism (for main "suggestion" ONLY):** The main suggestion should contain the absolute minimum changes to fix the error.
- **Formatting:** All code must be well-formatted with proper indentation.
- **Clarity:** For the main "suggestion", add a concise, helpful comment ONLY on the lines that you changed, explaining what the fix was. For example: \`// FIX: Added parentheses as 'print' is a function.\`. Do not add comments to unchanged lines.
---

**DETAILED RULES FOR ALTERNATIVES:**
- **Optimized Version**: Title must be "Optimized Version". Description must quantify performance gains (**Time Complexity** and **Space Complexity** using Big O).
- **Concise Version**: Title must be "Concise Version". Description must explain the idiomatic language features used. Alternatives can be more extensive rewrites.
---
`;

const debugSchema = {
    type: Type.OBJECT,
    properties: {
        errorName: { type: Type.STRING },
        explanation: { type: Type.STRING },
        suggestion: { type: Type.STRING },
        alternatives: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING },
                    description: { type: Type.STRING },
                    code: { type: Type.STRING },
                },
                required: ['title', 'description', 'code'],
            }
        }
    },
    required: ['errorName', 'explanation', 'suggestion', 'alternatives'],
};

export const getDebugSuggestion = async (language: Language, code: string, error: string): Promise<DebugResult> => {
    const prompt = debugPrompt(language, code, error);
    const response = await ai.models.generateContent({
        model: "gemini-flash-latest",
        contents: prompt,
        config: {
            systemInstruction: `You are a friendly coding tutor for ${language}. Your task is to provide a full debugging analysis in a specific JSON format.`,
            responseMimeType: "application/json",
            // @ts-ignore
            responseSchema: debugSchema,
        },
    });

    try {
        const result = JSON.parse(response.text.trim());
        return result as DebugResult;
    } catch (e) {
        console.error("Failed to parse Gemini debug response:", response.text);
        // Return a default error structure
        return {
            errorName: "Analysis Failed",
            explanation: "The AI failed to analyze the error. Please try running the code again.",
            suggestion: "// No suggestion available.",
            alternatives: [],
        };
    }
};

const optimizationPrompt = (language: Language, code: string): string => `
You are a world-class coding tutor for ${language}. A student's code has run successfully. Your goal is to teach them better ways to code.

---
**SUCCESSFUL CODE**
\`\`\`${language}
${code}
\`\`\`

---
**RESPONSE INSTRUCTIONS**
Your response MUST be a single JSON object with one key: "optimizationSuggestions". This should be an array of two alternative implementations.

**CRITICAL RULE: ALL suggestions MUST preserve the original core logic, functionality, and output of the "SUCCESSFUL CODE". Do NOT change what the code accomplishes; only change *how* it accomplishes it more efficiently or concisely.**

Strive to always provide at least one suggestion, even for simple code, to teach best practices or alternative language features. For example, for a "Hello World" program, you could show how to format strings or define the main function in a more standard way. If it is genuinely impossible to make any meaningful suggestion that adheres to the CRITICAL RULE, return an empty array.

**CODE QUALITY RULES (For ALL generated code suggestions):**
- **Formatting:** Must be well-formatted.
- **Completeness:** Must be a complete, runnable example.
- **Clarity:** Use minimal comments.
---

**DETAILED RULES FOR ALTERNATIVES:**
- **Optimized Version**: Title must be "Optimized Version". Description must quantify performance gains (**Time Complexity** and **Space Complexity** using Big O).
- **Concise Version**: Title must be "Concise Version". Description must explain the idiomatic language features used.
---
`;

const optimizationSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            code: { type: Type.STRING },
        },
        required: ['title', 'description', 'code'],
    }
};

const optimizationResponseSchema = {
    type: Type.OBJECT,
    properties: {
        optimizationSuggestions: { ...optimizationSchema, nullable: true },
    },
    required: ['optimizationSuggestions'],
};

export const getOptimizationSuggestions = async (language: Language, code: string): Promise<CodeSuggestion[]> => {
    const prompt = optimizationPrompt(language, code);
    const response = await ai.models.generateContent({
        model: "gemini-flash-latest",
        contents: prompt,
        config: {
            systemInstruction: `You are a world-class coding tutor for ${language}. Your goal is to provide optimization suggestions for successful code in a specific JSON format.`,
            responseMimeType: "application/json",
            // @ts-ignore
            responseSchema: optimizationResponseSchema,
        },
    });

    try {
        const result = JSON.parse(response.text.trim());
        return (result.optimizationSuggestions || []) as CodeSuggestion[];
    } catch (e) {
        console.error("Failed to parse Gemini optimization response:", response.text);
        return [];
    }
};

export const streamExplainCode = async (
    language: Language,
    code: string,
    onChunk: (chunk: string) => void
): Promise<void> => {
    const prompt = `You are an expert, friendly coding tutor for beginners. A student wants to understand a piece of code.
The programming language is: ${language}

The code is:
\`\`\`${language}
${code}
\`\`\`

Please provide a clear, step-by-step explanation of this code. Break down its functionality, logic, and overall purpose. Explain the concepts involved in a way that is easy for a beginner to understand. Use simple markdown for formatting like paragraphs (separated by a blank line), lists, and bold text to make it easy to read. Do not use headings. Ensure proper spacing and grammar.`;

    const response = await ai.models.generateContentStream({
        model: 'gemini-flash-latest',
        contents: prompt,
    });

    for await (const chunk of response) {
        onChunk(chunk.text);
    }
};

export const streamExplainFix = async (
    language: Language,
    code: string,
    error: string,
    suggestion: string,
    onChunk: (chunk: string) => void
): Promise<void> => {
    const prompt = `You are an expert, friendly coding tutor. A student's code has an error, and you have already provided a fix. Now, the student wants a step-by-step explanation of the fix.

The programming language is: ${language}

The student's original (incorrect) code is:
\`\`\`${language}
${code}
\`\`\`

The error message was:
\`\`\`
${error}
\`\`\`

The suggested fix was:
\`\`\`${language}
${suggestion}
\`\`\`

Please provide a clean, step-by-step explanation of *why* the original code was wrong and *why* the suggested fix is correct. Explain the underlying concepts clearly for a beginner. Use simple markdown for formatting like paragraphs (separated by a blank line), lists, and bold text to make the explanation easy to read. Do not use headings.`;

    const response = await ai.models.generateContentStream({
        model: 'gemini-flash-latest',
        contents: prompt,
    });

    for await (const chunk of response) {
        onChunk(chunk.text);
    }
};

export const streamChatResponse = async (
    language: Language,
    currentCode: string,
    history: AssistantMessage[],
    newMessage: string,
    onChunk: (chunk: string) => void
): Promise<void> => {
    const chatHistory = history
        .filter(m => m.role === 'user' || m.role === 'model')
        .map(m => ({
            role: m.role,
            parts: [{ text: m.content }]
        }));

    const systemInstruction = `You are a helpful and patient coding tutor for the ${language} programming language.

CODE GENERATION RULES: When you write code, you MUST follow these rules:
1. Your primary output should be the code itself, inside a markdown block.
2. Do NOT add any inline comments unless the logic is exceptionally complex or non-obvious. Comments for variable declarations, simple loops, or standard function calls are strictly forbidden.
3. After the code block, provide a single, brief sentence explaining what the code does. Do NOT explain the code line-by-line unless the user explicitly asks for it.

Your tone should be encouraging and clear for a beginner. Use simple markdown for formatting like paragraphs, lists, and bold text. Do not use headings.

The user's current code is:
\`\`\`${language}
${currentCode}
\`\`\`
`;
    
    const chat = ai.chats.create({
        model: 'gemini-flash-latest',
        config: {
          systemInstruction,
        },
        history: chatHistory,
    });

    const response = await chat.sendMessageStream({ message: newMessage });
    for await (const chunk of response) {
        onChunk(chunk.text);
    }
};
