import React, { useState } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { LandingPage } from './pages/LandingPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { useTheme } from './hooks/useTheme';
import { Language, Page } from './types';
import { DEFAULT_CODE } from './constants';

const App: React.FC = () => {
  const [theme, toggleTheme] = useTheme();
  const [language, setLanguage] = useState<Language>(Language.PYTHON);
  const [code, setCode] = useState<string>(DEFAULT_CODE[Language.PYTHON]);
  const [page, setPage] = useState<Page>('landing');

  const handleLanguageChange = (newLanguage: Language) => {
    setLanguage(newLanguage);
    setCode(DEFAULT_CODE[newLanguage]);
  };

  const handleNavigate = (newPage: Page) => {
    setPage(newPage);
  }

  const renderPage = () => {
    switch(page) {
      case 'home':
        return <HomePage 
            language={language}
            code={code}
            setCode={setCode}
            theme={theme}
        />;
      case 'about':
        return <AboutPage onNavigate={handleNavigate} />;
      case 'contact':
        return <ContactPage />;
      case 'landing':
      default:
        return <LandingPage onNavigate={handleNavigate} />;
    }
  }
  
  return (
    <div className="flex flex-col h-screen bg-gray-50 dark:bg-dark-bg font-sans">
      <Header
        language={language}
        onLanguageChange={handleLanguageChange}
        theme={theme}
        toggleTheme={toggleTheme}
        page={page}
        onNavigate={handleNavigate}
      />
      <main className={`flex-1 ${page === 'home' ? 'overflow-hidden' : ''} pt-16`}>
        {renderPage()}
      </main>
      {page !== 'home' && <Footer />}
    </div>
  );
};

export default App;