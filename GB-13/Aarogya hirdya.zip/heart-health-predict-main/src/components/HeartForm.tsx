import { useState } from "react";
import { Heart, Activity, AlertTriangle, CheckCircle, Loader2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { predictHeartDisease, type HeartInput } from "@/lib/heartModel";

const defaultValues: HeartInput = {
  age: 50,
  sex: 1,
  cp: 0,
  trestbps: 120,
  chol: 200,
  fbs: 0,
  restecg: 0,
  thalach: 150,
  exang: 0,
  oldpeak: 0,
  slope: 1,
  ca: 0,
  thal: 2,
};

export default function HeartForm() {
  const [form, setForm] = useState<HeartInput>(defaultValues);
  const [result, setResult] = useState<{ probability: number; risk: "low" | "moderate" | "high" } | null>(null);
  const [loading, setLoading] = useState(false);

  const update = (key: keyof HeartInput, value: string | number) => {
    setForm((prev) => ({ ...prev, [key]: Number(value) }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate network latency for UX
    setTimeout(() => {
      setResult(predictHeartDisease(form));
      setLoading(false);
    }, 800);
  };

  const riskConfig = {
    low: { color: "text-success", bg: "bg-success/10", border: "border-success/30", icon: CheckCircle, label: "Low Risk" },
    moderate: { color: "text-warning", bg: "bg-warning/10", border: "border-warning/30", icon: AlertTriangle, label: "Moderate Risk" },
    high: { color: "text-danger", bg: "bg-danger/10", border: "border-danger/30", icon: AlertTriangle, label: "High Risk" },
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Age */}
          <div className="space-y-2">
            <Label htmlFor="age" className="text-sm font-medium text-foreground">Age</Label>
            <Input id="age" type="number" min={1} max={120} value={form.age} onChange={(e) => update("age", e.target.value)} className="bg-card" />
          </div>

          {/* Sex */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-foreground">Sex</Label>
            <Select value={String(form.sex)} onValueChange={(v) => update("sex", v)}>
              <SelectTrigger className="bg-card"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">Female</SelectItem>
                <SelectItem value="1">Male</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Chest Pain Type */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-foreground">Chest Pain Type</Label>
            <Select value={String(form.cp)} onValueChange={(v) => update("cp", v)}>
              <SelectTrigger className="bg-card"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">Typical Angina</SelectItem>
                <SelectItem value="1">Atypical Angina</SelectItem>
                <SelectItem value="2">Non-anginal Pain</SelectItem>
                <SelectItem value="3">Asymptomatic</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Resting BP */}
          <div className="space-y-2">
            <Label htmlFor="trestbps" className="text-sm font-medium text-foreground">Resting Blood Pressure (mm Hg)</Label>
            <Input id="trestbps" type="number" min={80} max={250} value={form.trestbps} onChange={(e) => update("trestbps", e.target.value)} className="bg-card" />
          </div>

          {/* Cholesterol */}
          <div className="space-y-2">
            <Label htmlFor="chol" className="text-sm font-medium text-foreground">Cholesterol (mg/dl)</Label>
            <Input id="chol" type="number" min={100} max={600} value={form.chol} onChange={(e) => update("chol", e.target.value)} className="bg-card" />
          </div>

          {/* Fasting Blood Sugar */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-foreground">Fasting Blood Sugar &gt; 120 mg/dl</Label>
            <Select value={String(form.fbs)} onValueChange={(v) => update("fbs", v)}>
              <SelectTrigger className="bg-card"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">No</SelectItem>
                <SelectItem value="1">Yes</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Resting ECG */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-foreground">Resting ECG Results</Label>
            <Select value={String(form.restecg)} onValueChange={(v) => update("restecg", v)}>
              <SelectTrigger className="bg-card"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">Normal</SelectItem>
                <SelectItem value="1">ST-T Abnormality</SelectItem>
                <SelectItem value="2">Left Ventricular Hypertrophy</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Max Heart Rate */}
          <div className="space-y-2">
            <Label htmlFor="thalach" className="text-sm font-medium text-foreground">Max Heart Rate Achieved</Label>
            <Input id="thalach" type="number" min={60} max={220} value={form.thalach} onChange={(e) => update("thalach", e.target.value)} className="bg-card" />
          </div>

          {/* Exercise Induced Angina */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-foreground">Exercise Induced Angina</Label>
            <Select value={String(form.exang)} onValueChange={(v) => update("exang", v)}>
              <SelectTrigger className="bg-card"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">No</SelectItem>
                <SelectItem value="1">Yes</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* ST Depression */}
          <div className="space-y-2">
            <Label htmlFor="oldpeak" className="text-sm font-medium text-foreground">ST Depression (Oldpeak)</Label>
            <Input id="oldpeak" type="number" step="0.1" min={0} max={10} value={form.oldpeak} onChange={(e) => update("oldpeak", e.target.value)} className="bg-card" />
          </div>

          {/* Slope */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-foreground">Slope of Peak Exercise ST</Label>
            <Select value={String(form.slope)} onValueChange={(v) => update("slope", v)}>
              <SelectTrigger className="bg-card"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">Upsloping</SelectItem>
                <SelectItem value="1">Flat</SelectItem>
                <SelectItem value="2">Downsloping</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Major Vessels */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-foreground">Major Vessels (0–3)</Label>
            <Select value={String(form.ca)} onValueChange={(v) => update("ca", v)}>
              <SelectTrigger className="bg-card"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">0</SelectItem>
                <SelectItem value="1">1</SelectItem>
                <SelectItem value="2">2</SelectItem>
                <SelectItem value="3">3</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Thalassemia */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-foreground">Thalassemia</Label>
            <Select value={String(form.thal)} onValueChange={(v) => update("thal", v)}>
              <SelectTrigger className="bg-card"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="1">Normal</SelectItem>
                <SelectItem value="2">Fixed Defect</SelectItem>
                <SelectItem value="3">Reversible Defect</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex gap-3 pt-2">
          <Button type="submit" disabled={loading} className="px-8 py-3 text-base font-semibold">
            {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Activity className="w-5 h-5 mr-2" />}
            Predict Risk
          </Button>
          <Button type="button" variant="outline" onClick={() => { setForm(defaultValues); setResult(null); }}>
            Reset
          </Button>
        </div>
      </form>

      {/* Result */}
      {result && (
        <Card className={`mt-8 animate-slide-up border-2 ${riskConfig[result.risk].border}`}>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className={`p-4 rounded-2xl ${riskConfig[result.risk].bg}`}>
                {(() => {
                  const Icon = riskConfig[result.risk].icon;
                  return <Icon className={`w-10 h-10 ${riskConfig[result.risk].color}`} />;
                })()}
              </div>
              <div className="flex-1">
                <h3 className={`text-2xl font-display font-bold ${riskConfig[result.risk].color}`}>
                  {riskConfig[result.risk].label}
                </h3>
                <p className="text-muted-foreground mt-1">
                  Probability of heart disease: <span className="font-semibold text-foreground">{(result.probability * 100).toFixed(1)}%</span>
                </p>
              </div>
              <div className="hidden sm:block">
                <Heart className={`w-16 h-16 ${result.risk === "high" ? "text-danger animate-pulse-glow" : result.risk === "moderate" ? "text-warning" : "text-success"}`} />
              </div>
            </div>

            {/* Progress bar */}
            <div className="mt-5">
              <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-1000 ease-out ${
                    result.risk === "high" ? "bg-danger" : result.risk === "moderate" ? "bg-warning" : "bg-success"
                  }`}
                  style={{ width: `${result.probability * 100}%` }}
                />
              </div>
            </div>

            <p className="text-xs text-muted-foreground mt-4">
              ⚠️ This is a simplified prediction model for educational purposes only. Always consult a healthcare professional for medical advice.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
