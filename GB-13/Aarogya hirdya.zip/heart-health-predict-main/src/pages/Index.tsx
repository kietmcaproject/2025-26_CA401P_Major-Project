import { Heart, Activity, ShieldCheck, Zap } from "lucide-react";
import HeartForm from "@/components/HeartForm";

const features = [
  { icon: Activity, title: "ML-Powered Analysis", desc: "Logistic regression model trained on clinical data" },
  { icon: ShieldCheck, title: "13 Health Parameters", desc: "Comprehensive cardiovascular risk assessment" },
  { icon: Zap, title: "Instant Results", desc: "Real-time prediction with probability scoring" },
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto flex items-center gap-3 py-4 px-4">
          <div className="p-2 rounded-xl bg-primary/10">
            <Heart className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-xl font-display font-bold text-foreground">HeartGuard</h1>
          <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-0.5 rounded-full ml-1">AI</span>
        </div>
      </header>

      {/* Hero */}
      <section className="container mx-auto px-4 pt-16 pb-10 text-center">
        <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-sm font-medium px-4 py-1.5 rounded-full mb-6">
          <Activity className="w-4 h-4" />
          Machine Learning Prediction
        </div>
        <h2 className="text-4xl md:text-5xl font-display font-extrabold text-foreground leading-tight max-w-2xl mx-auto">
          Heart Disease
          <span className="text-primary"> Risk Predictor</span>
        </h2>
        <p className="text-muted-foreground text-lg mt-4 max-w-xl mx-auto">
          Enter your medical parameters below to get an instant AI-powered assessment of your cardiovascular health risk.
        </p>

        {/* Feature cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-10 max-w-3xl mx-auto">
          {features.map((f) => (
            <div key={f.title} className="flex flex-col items-center p-5 rounded-2xl bg-card border border-border hover:shadow-lg transition-shadow">
              <f.icon className="w-8 h-8 text-primary mb-3" />
              <h3 className="font-semibold text-foreground text-sm">{f.title}</h3>
              <p className="text-muted-foreground text-xs mt-1">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Form Section */}
      <section className="container mx-auto px-4 pb-20">
        <HeartForm />
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-6 text-center text-xs text-muted-foreground">
        <p>HeartGuard — For educational purposes only. Not a substitute for professional medical advice.</p>
      </footer>
    </div>
  );
};

export default Index;
