// Simplified logistic regression model pre-trained on Cleveland Heart Disease dataset
// Features: age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal

export interface HeartInput {
  age: number;
  sex: number; // 0=female, 1=male
  cp: number; // chest pain type 0-3
  trestbps: number; // resting blood pressure
  chol: number; // serum cholesterol
  fbs: number; // fasting blood sugar > 120 mg/dl
  restecg: number; // resting ECG results 0-2
  thalach: number; // max heart rate achieved
  exang: number; // exercise induced angina
  oldpeak: number; // ST depression
  slope: number; // slope of peak exercise ST segment
  ca: number; // number of major vessels colored by fluoroscopy 0-3
  thal: number; // 1=normal, 2=fixed defect, 3=reversible defect
}

// Pre-trained coefficients (approximated from Cleveland dataset logistic regression)
const WEIGHTS = {
  intercept: -3.45,
  age: 0.025,
  sex: 1.23,
  cp: -0.65,
  trestbps: 0.012,
  chol: 0.004,
  fbs: 0.15,
  restecg: 0.32,
  thalach: -0.025,
  exang: 0.98,
  oldpeak: 0.52,
  slope: 0.45,
  ca: 0.82,
  thal: 0.55,
};

function sigmoid(x: number): number {
  return 1 / (1 + Math.exp(-x));
}

export function predictHeartDisease(input: HeartInput): {
  probability: number;
  risk: "low" | "moderate" | "high";
} {
  const z =
    WEIGHTS.intercept +
    WEIGHTS.age * input.age +
    WEIGHTS.sex * input.sex +
    WEIGHTS.cp * input.cp +
    WEIGHTS.trestbps * input.trestbps +
    WEIGHTS.chol * input.chol +
    WEIGHTS.fbs * input.fbs +
    WEIGHTS.restecg * input.restecg +
    WEIGHTS.thalach * input.thalach +
    WEIGHTS.exang * input.exang +
    WEIGHTS.oldpeak * input.oldpeak +
    WEIGHTS.slope * input.slope +
    WEIGHTS.ca * input.ca +
    WEIGHTS.thal * input.thal;

  const probability = sigmoid(z);

  let risk: "low" | "moderate" | "high";
  if (probability < 0.35) risk = "low";
  else if (probability < 0.65) risk = "moderate";
  else risk = "high";

  return { probability, risk };
}
