// module.exports = {
//     mongoURl : "mongodb+srv://shubhranshu1905patel_db_user:OucCmGKzHhZJtcIb@cluster0.9yeg8ex.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
//     Jwt_secret  : ",dmfkdnfdnfjdjfndjfnjdf"
// }

module.exports = {
    mongoURl: "mongodb+srv://abcd:1234@cluster0.7e9dlcb.mongodb.net/?appName=Cluster0",
    Jwt_secret: ",ksdfjlslskdjfl"
}