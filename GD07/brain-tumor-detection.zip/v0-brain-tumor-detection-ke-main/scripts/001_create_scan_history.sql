-- Create scan_history table to store MRI scan results
CREATE TABLE IF NOT EXISTS public.scan_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  image_pathname TEXT NOT NULL,
  tumor_detected BOOLEAN NOT NULL,
  confidence_percentage DECIMAL(5,2) NOT NULL,
  scan_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.scan_history ENABLE ROW LEVEL SECURITY;

-- Policies for scan_history
CREATE POLICY "Users can view their own scan history" 
  ON public.scan_history FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own scans" 
  ON public.scan_history FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own scans" 
  ON public.scan_history FOR DELETE 
  USING (auth.uid() = user_id);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_scan_history_user_id ON public.scan_history(user_id);
CREATE INDEX IF NOT EXISTS idx_scan_history_scan_date ON public.scan_history(scan_date DESC);
