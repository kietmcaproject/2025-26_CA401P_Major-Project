import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

// Simulated tumor detection algorithm
// In production, this would call an actual ML model API
function simulateTumorDetection(): { tumorDetected: boolean; confidencePercentage: number } {
  // Simulate analysis with random results for demo purposes
  // In a real application, this would use a trained ML model
  const random = Math.random()
  
  // 30% chance of detecting tumor for demo
  const tumorDetected = random < 0.3
  
  // Generate confidence percentage
  // If tumor detected: 60-95% confidence
  // If no tumor: 75-99% confidence
  const confidencePercentage = tumorDetected
    ? Math.floor(60 + Math.random() * 35)
    : Math.floor(75 + Math.random() * 24)

  return { tumorDetected, confidencePercentage }
}

export async function POST(request: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { imagePathname } = await request.json()
    console.log("[v0] Detecting tumor for image:", imagePathname, "user:", user.id)

    if (!imagePathname) {
      return NextResponse.json({ error: "No image pathname provided" }, { status: 400 })
    }

    // Simulate processing delay (1-2 seconds)
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000))

    // Run simulated detection
    const { tumorDetected, confidencePercentage } = simulateTumorDetection()

    // Save result to database
    const { data, error } = await supabase
      .from("scan_history")
      .insert({
        user_id: user.id,
        image_url: `/api/file?pathname=${encodeURIComponent(imagePathname)}`,
        image_pathname: imagePathname,
        tumor_detected: tumorDetected,
        confidence_percentage: confidencePercentage,
      })
      .select()
      .single()

    if (error) {
      console.error("[v0] Database error:", error.message, error.details, error.hint)
      return NextResponse.json({ error: `Failed to save result: ${error.message}` }, { status: 500 })
    }

    console.log("[v0] Detection result saved successfully, id:", data.id)
    return NextResponse.json({
      id: data.id,
      tumorDetected,
      confidencePercentage,
      createdAt: data.created_at,
    })
  } catch (error) {
    console.error("Detection error:", error)
    return NextResponse.json({ error: "Detection failed" }, { status: 500 })
  }
}
