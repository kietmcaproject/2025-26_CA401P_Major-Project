import { put } from "@vercel/blob"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Validate file type
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"]
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json(
        { error: "Invalid file type. Please upload a JPG, PNG, GIF, or WebP image." },
        { status: 400 }
      )
    }

    // Upload to Vercel Blob (private storage)
    const blob = await put(`mri-scans/${Date.now()}-${file.name}`, file, {
      access: "private",
    })

    console.log("[v0] Upload successful, pathname:", blob.pathname)
    return NextResponse.json({ pathname: blob.pathname, url: blob.url })
  } catch (error) {
    console.error("[v0] Upload error:", error)
    return NextResponse.json({ error: "Upload failed" }, { status: 500 })
  }
}
