"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Spinner } from "@/components/ui/spinner"
import { Empty } from "@/components/ui/empty"

interface ScanRecord {
  id: string
  image_url: string
  image_pathname: string
  tumor_detected: boolean
  confidence_percentage: number
  created_at: string
}

export default function HistoryPage() {
  const [history, setHistory] = useState<ScanRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchHistory() {
      try {
        const response = await fetch("/api/history")
        if (!response.ok) {
          throw new Error("Failed to fetch history")
        }
        const data = await response.json()
        setHistory(data.history)
      } catch (err) {
        setError(err instanceof Error ? err.message : "An error occurred")
      } finally {
        setLoading(false)
      }
    }

    fetchHistory()
  }, [])

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Spinner className="h-8 w-8" />
      </div>
    )
  }

  if (error) {
    return (
      <Card>
        <CardContent className="py-8">
          <p className="text-center text-destructive">{error}</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Scan History</h1>
        <p className="text-muted-foreground">
          Review your previous MRI scan results to track changes over time
        </p>
      </div>

      {history.length === 0 ? (
        <Card>
          <CardContent className="py-12">
            <Empty>
              <Empty.Icon>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="48"
                  height="48"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M3 3v18h18" />
                  <path d="m19 9-5 5-4-4-3 3" />
                </svg>
              </Empty.Icon>
              <Empty.Title>No scan history</Empty.Title>
              <Empty.Description>
                Upload your first MRI scan to start tracking your results
              </Empty.Description>
            </Empty>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {history.map((record) => (
            <Card key={record.id}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">
                    {formatDate(record.created_at)}
                  </CardTitle>
                  <span
                    className={`
                      px-3 py-1 rounded-full text-sm font-medium
                      ${record.tumor_detected
                        ? "bg-destructive/10 text-destructive"
                        : "bg-green-500/10 text-green-600"
                      }
                    `}
                  >
                    {record.tumor_detected ? "Tumor Detected" : "No Tumor Detected"}
                  </span>
                </div>
                <CardDescription>
                  Confidence: {record.confidence_percentage}%
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 rounded-md overflow-hidden bg-muted flex-shrink-0">
                    <img
                      src={`/api/file?pathname=${encodeURIComponent(record.image_pathname)}`}
                      alt="MRI Scan"
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${record.tumor_detected ? "bg-destructive" : "bg-green-500"}`}
                          style={{ width: `${record.confidence_percentage}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium w-12 text-right">
                        {record.confidence_percentage}%
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      Analysis confidence level
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
