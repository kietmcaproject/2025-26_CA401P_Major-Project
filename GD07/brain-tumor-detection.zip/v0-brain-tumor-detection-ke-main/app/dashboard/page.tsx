import { MRIUpload } from "@/components/mri-upload"

export default function DashboardPage() {
  return (
    <div className="max-w-2xl mx-auto">
      <MRIUpload />
    </div>
  )
}
