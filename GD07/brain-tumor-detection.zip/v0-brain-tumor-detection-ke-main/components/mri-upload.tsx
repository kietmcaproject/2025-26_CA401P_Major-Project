"use client"

import { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Spinner } from "@/components/ui/spinner"
import { DetectionResult } from "@/components/detection-result"

interface ScanResult {
  id: string
  tumorDetected: boolean
  confidencePercentage: number
  createdAt: string
}

export function MRIUpload() {
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)
  const [error, setError] = useState<string | null>(null)

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const selectedFile = acceptedFiles[0]
    if (selectedFile) {
      setFile(selectedFile)
      setPreview(URL.createObjectURL(selectedFile))
      setResult(null)
      setError(null)
    }
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "image/*": [".jpeg", ".jpg", ".png", ".gif", ".webp"],
    },
    maxFiles: 1,
  })

  const handleAnalyze = async () => {
    if (!file) return

    setError(null)
    setUploading(true)

    try {
      // Upload the file
      const formData = new FormData()
      formData.append("file", file)

      const uploadResponse = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      })

      if (!uploadResponse.ok) {
        const data = await uploadResponse.json()
        throw new Error(data.error || "Upload failed")
      }

      const { pathname } = await uploadResponse.json()
      setUploading(false)
      setAnalyzing(true)

      // Analyze the image
      const detectResponse = await fetch("/api/detect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imagePathname: pathname }),
      })

      if (!detectResponse.ok) {
        const data = await detectResponse.json()
        throw new Error(data.error || "Detection failed")
      }

      const scanResult = await detectResponse.json()
      setResult(scanResult)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setUploading(false)
      setAnalyzing(false)
    }
  }

  const handleReset = () => {
    setFile(null)
    setPreview(null)
    setResult(null)
    setError(null)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Upload MRI Scan</CardTitle>
          <CardDescription>
            Upload a brain MRI image to analyze for potential tumors
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!preview ? (
            <div
              {...getRootProps()}
              className={`
                border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors
                ${isDragActive ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"}
              `}
            >
              <input {...getInputProps()} />
              <div className="space-y-2">
                <div className="text-4xl text-muted-foreground">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="48"
                    height="48"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mx-auto"
                  >
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                    <polyline points="17 8 12 3 7 8" />
                    <line x1="12" x2="12" y1="3" y2="15" />
                  </svg>
                </div>
                <p className="text-lg font-medium">
                  {isDragActive ? "Drop the image here" : "Drag and drop MRI image here"}
                </p>
                <p className="text-sm text-muted-foreground">
                  or click to select a file (JPG, PNG, GIF, WebP)
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative aspect-square max-w-md mx-auto rounded-lg overflow-hidden bg-muted">
                <img
                  src={preview}
                  alt="MRI Preview"
                  className="object-contain w-full h-full"
                />
              </div>
              <div className="flex justify-center gap-4">
                <Button variant="outline" onClick={handleReset} disabled={uploading || analyzing}>
                  Choose Different Image
                </Button>
                <Button onClick={handleAnalyze} disabled={uploading || analyzing}>
                  {uploading ? (
                    <>
                      <Spinner className="mr-2 h-4 w-4" />
                      Uploading...
                    </>
                  ) : analyzing ? (
                    <>
                      <Spinner className="mr-2 h-4 w-4" />
                      Analyzing...
                    </>
                  ) : (
                    "Analyze Scan"
                  )}
                </Button>
              </div>
            </div>
          )}
          {error && (
            <p className="mt-4 text-sm text-destructive text-center">{error}</p>
          )}
        </CardContent>
      </Card>

      {result && <DetectionResult result={result} />}
    </div>
  )
}
