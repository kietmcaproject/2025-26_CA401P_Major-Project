import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface DetectionResultProps {
  result: {
    id: string
    tumorDetected: boolean
    confidencePercentage: number
    createdAt: string
  }
}

export function DetectionResult({ result }: DetectionResultProps) {
  const { tumorDetected, confidencePercentage } = result

  return (
    <Card className={tumorDetected ? "border-destructive" : "border-green-500"}>
      <CardHeader>
        <CardTitle className="text-center">Analysis Result</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center space-y-4">
          <div
            className={`
              inline-flex items-center justify-center w-24 h-24 rounded-full text-4xl font-bold
              ${tumorDetected ? "bg-destructive/10 text-destructive" : "bg-green-500/10 text-green-600"}
            `}
          >
            {confidencePercentage}%
          </div>
          <div>
            <p className={`text-xl font-semibold ${tumorDetected ? "text-destructive" : "text-green-600"}`}>
              {tumorDetected ? "Tumor Detected" : "No Tumor Detected"}
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              Confidence: {confidencePercentage}%
            </p>
          </div>
          <p className="text-xs text-muted-foreground max-w-md mx-auto">
            Note: This is a simulated result for demonstration purposes. 
            In a real application, this would use a trained machine learning model. 
            Always consult a medical professional for actual diagnosis.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
