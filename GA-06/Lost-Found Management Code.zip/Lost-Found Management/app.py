from flask import Flask, Blueprint, render_template, redirect, url_for, flash, request, session
from flask_bcrypt import Bcrypt
from flask_login import login_user, logout_user, login_required, current_user, LoginManager
import random
import os
from datetime import datetime, timezone, timedelta
from werkzeug.utils import secure_filename
from itsdangerous import URLSafeTimedSerializer as Serializer, SignatureExpired
from flask_mail import Mail, Message
from models import ClaimedItem, db, User, PasswordResetToken, Item, Category, Notification, ItemStatusEnum, AdminStoreItem
from zoneinfo import ZoneInfo
app = Flask(__name__)

app.config['SECRET_KEY'] = 'd6b5f6a4d1c1e3c9b7d9d2f1e8b9c0a4e5d6f7a8b9c0d1e2f3a4b5c6d7e8f9g0h'
app.config['SQLALCHEMY_DATABASE_URI'] =  'mysql+pymysql://code:12345678@127.0.0.1:3306/lostfound'
#'mysql+pymysql://root:@localhost/lost-found_db'
app.config['UPLOAD_FOLDER'] = os.path.join('static', 'images')
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USERNAME'] = 'thakurarunkumar2004@gmail.com'
app.config['MAIL_PASSWORD'] = 'add your gmail setting option created app password'
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False



db.init_app(app)
mail = Mail(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


def send_otp_reg(email, otp):
    msg = Message('Email Confirmation OTP Code', sender=app.config['MAIL_USERNAME'], recipients=[email])
    msg.html = f'''
    <div style="font-family: Arial, sans-serif; color: #333;">
        <h2 style="color: #004085; text-align: centre;">LOST-FOUND Management Team</h2>
        <p>Welcome!</p>
        <p>Thank you for signing up! Please confirm your college email ID.</p>
        <p style="font-size: 18px; color: #007bff;"><strong>Your OTP code is: {otp}</strong></p>
        <p style="color: #6c757d;">If you did not request this, please ignore this email.</p>
        <hr>
        <p style="font-size: 12px; color: #6c757d;">This is an automated message, please do not reply.</p>
    </div>
    '''
    try:
        mail.send(msg)
    except Exception as e:
        print(f"Failed to send email: {e}")
        flash('Failed to send OTP. Please try again later.', category='danger')

def send_otp_forget_pass(email, otp):
    msg = Message('Password Reset OTP Code', sender=app.config['MAIL_USERNAME'], recipients=[email])
    msg.html = f'''
    <div style="font-family: Arial, sans-serif; color: #333;">
        <h2 style="color: #004085;  text-align: centre;">LOST-FOUND Management Team</h2>
        <p>You have requested a password reset.</p>
        <p style="font-size: 18px; color: #007bff;"><strong>Your OTP code is: {otp}</strong></p>
        <p style="color: #6c757d;">If you did not request this, please secure your account immediately.</p>
        <hr>
        <p style="font-size: 12px; color: #6c757d;">This is an automated message, please do not reply.</p>
    </div>
    '''
    try:
        mail.send(msg)
    except Exception as e:
        print(f"Failed to send email: {e}")
        flash('Failed to send OTP. Please try again later.', category='danger')

def send_claim_otp(email, otp, item_name):
    msg = Message(
        'Item Claim Verification OTP',
        sender=app.config['MAIL_USERNAME'],
        recipients=[email]
    )

    msg.html = f"""
    <h3>Item Claim OTP Verification</h3>
    <p>Item: <b>{item_name}</b></p>
    <h2>Your OTP: {otp}</h2>
    <p>Enter this OTP to claim the item.</p>
    """

    try:
        mail.send(msg)
    except Exception as e:
        print("Claim OTP Email Error:", e)


def generate_otp():
    return f"{random.randint(100000, 999999)}"

EXPIRATION_TIME = 600

def send_category_match_notifications(new_item):
    # Only trigger when a FOUND item is added
    if new_item.status != 'found':
        return

    # Find all LOST items with SAME category (excluding current user)
    lost_items = Item.query.filter(
        Item.status == 'lost',
        Item.category_id == new_item.category_id,
        Item.user_id != new_item.user_id
    ).all()

    if not lost_items:
        return  # No matching lost complaints

    # Get unique users who lost items in this category
    notified_user_ids = set()
    matched_users = []

    for lost in lost_items:
        if lost.user_id not in notified_user_ids:
            user = User.query.get(lost.user_id)
            if user:
                matched_users.append(user)
                notified_user_ids.add(user.id)

    # Send Email + Save Notification
    for user in matched_users:
        # EMAIL CONTENT
        msg = Message(
            subject=f"Possible Match Found for Your Lost Item ({new_item.name})",
            sender=app.config['MAIL_USERNAME'],
            recipients=[user.email]
        )

        msg.body = f"""
Hello {user.first_name},

Good news! 🎉

Someone has reported a FOUND item that matches your lost item category.

Item Found: {new_item.name}
Category: {new_item.category.name}
Location: {new_item.location}
Date: {new_item.date}

Please login to the Lost & Found Portal and check if this item belongs to you.

Portal Link: http://127.0.0.1:5000/item/{new_item.id}

- Lost & Found Management System
"""

        try:
            mail.send(msg)
        except Exception as e:
            print("Notification Email Error:", e)

        # SAVE INTO notifications TABLE (your schema)
        notification = Notification(
            user_id=user.id,
            item_id=new_item.id,
            message=f"A {new_item.category.name} item was found: {new_item.name}. Check if it's yours!",
            sent_at=get_ist_time()
        )
        db.session.add(notification)

    db.session.commit()


def generate_token(data, expiration=EXPIRATION_TIME):
    s = Serializer(app.config['SECRET_KEY'], expires_in=expiration)
    return s.dumps(data).decode('utf-8')

def verify_token(token):
    s = Serializer(app.config['SECRET_KEY'])
    try:
        data = s.loads(token)
    except SignatureExpired:
        return None
    return data

from datetime import datetime  # make sure this is already imported at top

def get_ist_time():
    return datetime.now(ZoneInfo("Asia/Kolkata"))

@app.route('/admin')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        flash('Access denied.', 'danger')
        return redirect(url_for('home_page'))

    students = User.query.filter_by(is_admin=False).all()
    admins = User.query.filter_by(is_admin=True).all()

    normal_items = Item.query.all()
    stored_items = AdminStoreItem.query.all()

    # Merge active items
    active_items = []

    for item in normal_items:
        item.source = "user"
        active_items.append(item)

    for item in stored_items:
        item.source = "admin"
        active_items.append(item)

    claimed_items = ClaimedItem.query.order_by(
        ClaimedItem.claim_time.desc()
    ).all()

    categories = Category.query.all()

    return render_template(
        'admin_dashboard.html',
        students=students,
        admins=admins,
        items=active_items,
        categories=categories,
        claimed_items=claimed_items,
        current_date=get_ist_time()
    )

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        password = request.form.get('password')
        roll_number = request.form.get('roll_number')
        batch = request.form.get('batch')
        course = request.form.get('course')
        branch = request.form.get('branch')

        if not email.endswith('@kiet.edu'):
            flash('Email must end with @kiet.edu domain.', category='danger')
            return redirect(url_for('register'))

        if len(password) < 8 or not any(char.isdigit() for char in password) or not any(
                char.isalpha() for char in password):
            flash('Password must be at least 8 characters long and contain both letters and digits.', category='danger')
            return redirect(url_for('register'))

        user = User.query.filter_by(email=email).first()
        if user:
            flash('Email address already registered.', category='danger')
            return redirect(url_for('register'))

        otp = generate_otp()  # Ensure this function is defined to generate an OTP
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

        session['temp_user'] = {
            'email': email,
            'first_name': first_name,
            'last_name': last_name,
            'password': hashed_password,
            'roll_number': roll_number,
            'batch': batch,
            'course': course,
            'branch': branch,
            'otp': otp,
            'otp_generated_at': get_ist_time()
        }

        send_otp_reg(email, otp)  # Ensure this function is defined to send an OTP
        flash('An OTP has been sent to your email. Please verify to complete registration.', category='info')
        return redirect(url_for('verify_registration'))

    return render_template('register.html')


# Route for verifying registration
@app.route('/verify_registration', methods=['GET', 'POST'])
def verify_registration():
    if request.method == 'POST':
        otp = request.form.get('otp')
        temp_user = session.get('temp_user')

        if temp_user:
            # Convert both to timezone-aware datetimes for comparison
            otp_generated_at = temp_user.get('otp_generated_at')
            otp_age = get_ist_time() - otp_generated_at

            if otp_age.total_seconds() > 600:  # 10 minutes in seconds
                flash('OTP has expired. Please request a new one.', category='danger')
                return redirect(url_for('register'))

            if temp_user['otp'] == otp:
                new_user = User(
                    email=temp_user['email'],
                    first_name=temp_user['first_name'],
                    last_name=temp_user['last_name'],
                    password=temp_user['password'],
                    roll_number=temp_user['roll_number'],
                    batch=temp_user['batch'],
                    course=temp_user['course'],
                    branch=temp_user['branch'],
                    is_verified=True
                )
                db.session.add(new_user)
                db.session.commit()
                session.pop('temp_user', None)
                flash('Your account has been created successfully!', category='success')
                return redirect(url_for('login'))
            else:
                flash('Invalid OTP. Please try again.', category='danger')

    return render_template('verify_registration.html')

# Route for user login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        if user and bcrypt.check_password_hash(user.password, password):
            if user.is_verified:
                login_user(user)
                flash('Login successful!', category='success')
                return redirect(url_for('home_page'))
            else:
                flash('Please verify your email before logging in.', category='danger')
        else:
            flash('Login failed. Check your credentials.', category='danger')
    return render_template('login.html')


# Route for user logout
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', category='info')
    return redirect(url_for('login'))


@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        if user:
            otp = generate_otp()
            expires_at = datetime.utcnow() + timedelta(minutes=10)
            reset_token = PasswordResetToken(user_id=user.id, otp=otp, expires_at=expires_at)
            db.session.add(reset_token)
            db.session.commit()
            send_otp_forget_pass(email, otp)
            session['reset_email'] = email  # Store email in session
            flash('An OTP has been sent to your email for password reset.', category='info')
            return redirect(url_for('verify_reset_password'))
        else:
            flash('Email not registered.', category='danger')

    return render_template('forgot_password.html')

# Route for verifying password reset
@app.route('/verify_reset_password', methods=['GET', 'POST'])
def verify_reset_password():
    email = session.get('reset_email')  # Retrieve email from session
    if not email:
        flash('No email found in session. Please try again.', category='danger')
        return redirect(url_for('forgot_password'))

    if request.method == 'POST':
        otp = request.form.get('otp')
        user = User.query.filter_by(email=email).first()
        if user:
            reset_token = PasswordResetToken.query.filter_by(user_id=user.id, otp=otp).first()
            if reset_token and reset_token.expires_at > datetime.utcnow():
                session['reset_user'] = user.id
                db.session.delete(reset_token)
                db.session.commit()
                flash('OTP verified. You can now reset your password.', category='success')
                return redirect(url_for('reset_password'))
            else:
                flash('Invalid or expired OTP. Please try again.', category='danger')
        else:
            flash('Email not registered.', category='danger')

    return render_template('verify_reset_password.html', email=email)

# Route for resetting password
@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'POST':
        password = request.form.get('password')
        user_id = session.get('reset_user')

        # Check if the password is None
        if password is None or len(password) < 8 or not any(char.isdigit() for char in password) or not any(
                char.isalpha() for char in password):
            flash('Password must be at least 8 characters long and contain both letters and digits.', category='danger')
            return redirect(url_for('reset_password'))

        if user_id:
            user = User.query.get(user_id)
            user.password = bcrypt.generate_password_hash(password).decode('utf-8')
            db.session.commit()
            session.pop('reset_user', None)
            flash('Your password has been reset successfully!', category='success')
            return redirect(url_for('login'))
        else:
            flash('No user session found. Please try again.', category='danger')

    return render_template('reset_password.html')



@app.route('/')
def home_page():
    search_term = request.args.get('search', '')
    category_id = request.args.get('category', '')

    normal_items = Item.query.all()
    stored_items = AdminStoreItem.query.all()

    all_items = []
    my_posts = []

    for item in normal_items:
        item.source = "user"

        if current_user.is_authenticated and item.user_id == current_user.id:
            item.post_type = "my_post"
            my_posts.append(item)
        else:
            item.post_type = "other_post"

        all_items.append(item)

    for item in stored_items:
        item.source = "admin"
        item.post_type = "admin"
        all_items.append(item)

    # Filter search
    if search_term:
        all_items = [
            i for i in all_items
            if search_term.lower() in i.name.lower()
            or search_term.lower() in (i.description or "").lower()
        ]

    # Filter category
    if category_id:
        all_items = [
            i for i in all_items
            if str(i.category_id) == str(category_id)
        ]

    categories = Category.query.all()

    return render_template(
        'home.html',
        items=all_items,
        my_posts=my_posts,
        categories=categories
    )
    
        
@app.route('/add_item', methods=['GET', 'POST'])
def add_item():
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        category_id = request.form.get('category')
        status = request.form.get('status')
        date = request.form.get('date')
        location = request.form.get('location')
        image = request.files.get('image')

        # Handle image upload if any
        image_filename = 'default.jpg'
        if image and image.filename:
            image_filename = secure_filename(image.filename)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
            image.save(image_path)

        new_item = Item(
            name=name,
            description=description,
            category_id=category_id,
            status=status,
            date=date,
            location=location,
            image_file=image_filename,
            user_id=current_user.id
        )

        db.session.add(new_item)
        db.session.commit()

        # ⭐ AUTO CATEGORY MATCH NOTIFICATION SYSTEM (NEW)
        send_category_match_notifications(new_item)

        flash('Item added successfully! Matching users have been notified if applicable.', 'success')
        return redirect(url_for('home_page'))


    categories = Category.query.all()
    return render_template('add_item.html', categories=categories)


@app.route('/edit_item/<int:item_id>', methods=['GET', 'POST'])
@login_required
def edit_item(item_id):
    item = Item.query.get_or_404(item_id)

    if request.method == 'POST':
        # Basic fields (always update on Save)
        item.name = request.form.get('name')
        item.description = request.form.get('description')
        item.category_id = request.form.get('category')
        item.status = request.form.get('status')
        item.location = request.form.get('location')

        # Date convert safely
        date_str = request.form.get('date')
        if date_str:
            item.date = datetime.strptime(date_str, '%Y-%m-%d').date()

        # IMAGE REPLACE LOGIC (ONLY WHEN SAVE IS CLICKED)
        image = request.files.get('image_file')

        # If user selected a new image AND clicked Save
        if image and image.filename:
            # Delete old image (except default)
            if item.image_file and item.image_file != 'default.jpg':
                old_image_path = os.path.join(app.config['UPLOAD_FOLDER'], item.image_file)
                if os.path.exists(old_image_path):
                    os.remove(old_image_path)

            # Save new image with SAME filename (true replace)
            filename = secure_filename(image.filename)
            save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image.save(save_path)

            # Update database ONLY after Save
            item.image_file = filename

        # Commit happens ONLY when Save button is pressed
        db.session.commit()
        flash('Item updated successfully!', 'success')
        return redirect(url_for('item_detail', item_id=item.id))

    categories = Category.query.all()
    return render_template('edit_item.html', item=item, categories=categories)


@app.route('/delete_item/<int:item_id>', methods=['POST'])
@login_required
def delete_item(item_id):
    item = Item.query.get_or_404(item_id)

    # 🔥 DELETE LINKED NOTIFICATIONS FIRST (FK FIX)
    notifications = Notification.query.filter_by(item_id=item.id).all()
    for n in notifications:
        db.session.delete(n)

    db.session.flush()
    db.session.delete(item)
    db.session.commit()

    flash('Item deleted successfully.', 'success')
    return redirect(url_for('home_page'))

@app.route('/item/<int:item_id>')
def item_detail(item_id):
    item = Item.query.get_or_404(item_id)
    return render_template('item_detail.html', item=item)
@app.route('/send-claim-otp/<int:item_id>', methods=['POST'])
@login_required
def send_claim_otp_route(item_id):
    email = request.form.get('email')
    item = Item.query.get_or_404(item_id)

    # 1️⃣ Email required
    if not email:
        return {"status": "error", "message": "Email is required"}

    email = email.strip().lower()
    current_email = current_user.email.strip().lower()

    # 2️⃣ Prevent same sender & receiver (IMPORTANT)
    if email == current_email:
        return {
            "status": "error",
            "message": "Please enter correct student email id. Sender and receiver cannot be same."
        }

    # 3️⃣ Check registered email on portal (YOUR REQUIREMENT)
    receiver = User.query.filter_by(email=email).first()
    if not receiver:
        return {
            "status": "error",
            "message": f'This email "{email}" is not registered on the portal. Please register first then claim/deliver the item.'
        }

    # 4️⃣ Prevent action if item already claimed
    if item.claimed:
        return {
            "status": "error",
            "message": "This item is already claimed/delivered."
        }

    # 5️⃣ VALID CASE → GENERATE OTP (NO WRONG OWNER RESTRICTION)
    otp = str(random.randint(100000, 999999))

    item.claim_otp = otp
    item.otp_verified = False
    db.session.commit()

    # SEND OTP EMAIL
    msg = Message(
        subject='Item Verification OTP - Lost & Found Portal',
        sender=app.config['MAIL_USERNAME'],
        recipients=[email]
    )

    msg.body = f"""
Hello Student,

Item: {item.name}
Category: {item.category.name}
Location: {item.location}

Your OTP for verification is: {otp}

Note:
- Do not share this OTP with anyone
- This OTP is required to claim/deliver the item

Lost & Found Portal
"""

    try:
        mail.send(msg)
    except Exception as e:
        print("Mail Error:", e)
        return {"status": "error", "message": "Failed to send OTP email. Check mail configuration."}

    return {
        "status": "success",
        "message": "OTP sent successfully to registered student email."
    }

# VERIFY OTP AND MOVE TO CLAIMED TABLE

@app.route('/verify-claim-otp/<int:item_id>', methods=['POST'])
@login_required
def verify_claim_otp(item_id):
    entered_otp = request.form.get('otp')
    email = request.form.get('email')

    item = Item.query.get_or_404(item_id)

    # OTP validation
    if item.claim_otp != entered_otp:
        flash('Invalid OTP. Delivery cancelled.', 'danger')
        return redirect(url_for('item_detail', item_id=item_id))

    receiver = User.query.filter_by(email=email).first()

    receiver_name = email
    if receiver:
        receiver_name = f"{receiver.first_name} {receiver.last_name}"

    owner = User.query.get(item.user_id)

    # ✅ CREATE ARCHIVE RECORD
    claimed = ClaimedItem(
    item_id=item.id,
    claimer_id=current_user.id,
    item_name=item.name,
    lost_person_name=f"{owner.first_name} {owner.last_name}",
    claimed_person_name=receiver_name,
    lost_email=owner.email,
    claimed_email=email,
    image_file=item.image_file,
    claim_time=get_ist_time()   # ✅ ADD THIS
    )
    
    db.session.add(claimed)

    # 🔥 FINAL FK SAFE DELETE (NO MORE IntegrityError)
    notifications = Notification.query.filter_by(item_id=item.id).all()
    for n in notifications:
        db.session.delete(n)

    # Flush child deletes first
    db.session.flush()

    # Now delete item safely
    db.session.delete(item)
    db.session.commit()

    flash(f'OTP Verified! "{item.name}" delivered successfully.', 'success')
    return redirect(url_for('home_page'))


# ADMIN: SEND OTP FROM ADMIN STORED ITEM
@app.route('/admin-send-otp/<int:store_id>', methods=['POST'])
@login_required
def admin_send_otp(store_id):
    if not current_user.is_admin:
        return {"status": "error", "message": "Admin access required"}

    email = request.form.get('email')

    if not email:
        return {"status": "error", "message": "Email is required"}

    email = email.strip().lower()

    # Prevent admin sending to self
    if email == current_user.email.lower():
        return {
            "status": "error",
            "message": "Admin cannot deliver item to own email."
        }

    # Check registered user
    receiver = User.query.filter_by(email=email).first()
    if not receiver:
        return {
            "status": "error",
            "message": f'This email "{email}" is not registered on the portal.'
        }

    stored_item = AdminStoreItem.query.get_or_404(store_id)

    # Generate OTP
    otp = generate_otp()

    session['admin_delivery_otp'] = otp
    session['admin_delivery_store_id'] = store_id
    session['admin_receiver_email'] = email

    # Send OTP mail
    msg = Message(
        subject='Admin Item Delivery OTP - Lost & Found',
        sender=app.config['MAIL_USERNAME'],
        recipients=[email]
    )

    msg.body = f"""
Hello Student,

Item: {stored_item.name}
Location: Admin Office

Your OTP for verification is: {otp}

Do not share this OTP.

Lost & Found Portal
"""

    try:
        mail.send(msg)
    except Exception as e:
        print("Admin OTP Mail Error:", e)
        return {"status": "error", "message": "Failed to send OTP email."}

    return {
        "status": "success",
        "message": "OTP sent successfully to registered email."
    }
    
@app.route('/admin-verify-otp', methods=['POST'])
@login_required
def admin_verify_otp():
    if not current_user.is_admin:
        flash('Access denied.', 'danger')
        return redirect(url_for('admin_dashboard'))

    entered_otp = request.form.get('otp')
    store_id = session.get('admin_delivery_store_id')
    receiver_email = session.get('admin_receiver_email')

    if not store_id:
        flash('Session expired. Try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

    if entered_otp != session.get('admin_delivery_otp'):
        flash('Invalid OTP.', 'danger')
        return redirect(url_for('admin_dashboard'))

    stored_item = AdminStoreItem.query.get_or_404(store_id)
    owner = User.query.get(stored_item.owner_id)

    # CREATE CLAIMED RECORD
    claimed = ClaimedItem(
    item_id=stored_item.original_item_id,
    claimer_id=current_user.id,
    item_name=stored_item.name,
    lost_person_name=f"{owner.first_name} {owner.last_name}",
    claimed_person_name=receiver_email,
    lost_email=owner.email,
    claimed_email=receiver_email,
    claim_time=get_ist_time(),
    image_file=stored_item.image_file   # ✅ SAVE IMAGE
    )

    db.session.add(claimed)
    db.session.delete(stored_item)
    db.session.commit()

    # Clear session
    session.pop('admin_delivery_otp', None)
    session.pop('admin_delivery_store_id', None)
    session.pop('admin_receiver_email', None)

    flash('OTP Verified! Item delivered and archived successfully.', 'success')
    return redirect(url_for('admin_dashboard'))

    

# ADMIN: STORE ITEM IN ADMIN OFFICE (MOVE FROM ITEMS → ADMIN STORE TABLE)
@app.route('/store_in_admin/<int:item_id>', methods=['POST'])
@login_required
def store_in_admin(item_id):
    if not current_user.is_admin:
        flash('Access denied.', 'danger')
        return redirect(url_for('home_page'))

    item = Item.query.get_or_404(item_id)

    # 🔥 DELETE NOTIFICATIONS FIRST (MANDATORY FOR FK)
    notifications = Notification.query.filter_by(item_id=item.id).all()
    for n in notifications:
        db.session.delete(n)

    # MOVE item to Admin Store table
    stored_item = AdminStoreItem(
        original_item_id=item.id,
        name=item.name,
        description=item.description,
        category_id=item.category_id,
        status=item.status,
        date=item.date,
        location=item.location,
        image_file=item.image_file,
        owner_id=item.user_id,
        stored_by_admin_id=current_user.id,
        stored_at=get_ist_time()
    )

    db.session.add(stored_item)

    # Flush deletes before removing parent row
    db.session.flush()

    # Now safe delete
    db.session.delete(item)
    db.session.commit()

    flash('Item moved to Admin Store Office successfully!', 'success')
    return redirect(url_for('admin_dashboard'))


@app.route('/notifications')
@login_required
def view_notifications():
    notifications = Notification.query.filter_by(user_id=current_user.id).all()
    return render_template('notifications.html', notifications=notifications)

# ADMIN: VIEW ANY USER PROFILE (READ-ONLY)
@app.route('/admin/user/<int:user_id>')
@login_required
def admin_view_user(user_id):
    if not current_user.is_admin:
        flash('Access denied. Admins only.', 'danger')
        return redirect(url_for('home_page'))

    user = User.query.get_or_404(user_id)

    # Admin can only VIEW, not edit
    return render_template(
        'admin_user_profile.html',
        user=user
    )
@app.route('/profile')
@login_required
def view_profile():
    courses = {
        'BTECH': 'Btech',
        'MCA': 'MCA',
        'MTECH': 'Mtech',
        'MSC': 'Msc',
        'PHD': 'PHD'
    }
    branches = {
        'CSE': 'CSE',
        'ECE': 'ECE',
        'EEE': 'EEE',
        'ICE': 'ICE',
        'Chem': 'Chem',
        'Civil': 'Civil',
        'MECH': 'MECH',
        'Prod': 'Prod','MCA': 'MCA',
        'Other': 'Other'
    }
    return render_template('profile.html', courses=courses, branches=branches)



@app.route('/update_profile', methods=['GET', 'POST'])
@login_required
def update_profile():
    if request.method == 'POST':
        user = User.query.get(current_user.id)
        user.first_name = request.form['first_name']
        user.last_name = request.form['last_name']
        user.roll_number = request.form['roll_number']
        user.batch = request.form['batch']
        user.course = request.form['course']
        user.branch = request.form['branch']

        # Handle image upload
        if 'profile_pic' in request.files:
            file = request.files['profile_pic']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join('static/images', filename)
                file.save(file_path)
                user.profile_pic = filename

        db.session.commit()
        flash('Profile updated successfully.', 'success')
        return redirect(url_for('view_profile'))

    return render_template('edit_profile.html')

def allowed_file(filename):
    allowed_extensions = {'jpg', 'jpeg', 'png', 'gif'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions


if __name__ == '__main__':
    app.run(debug=True)

